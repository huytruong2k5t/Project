onerror {quit -code 1}
onbreak {quit -code 1}
run 100000 ns
quit -code 0
