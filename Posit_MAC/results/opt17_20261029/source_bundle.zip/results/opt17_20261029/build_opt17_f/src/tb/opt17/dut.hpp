#pragma once
#include "Vopt17_f.h"
#include "Vopt17_f___024root.h"
using DUT = Vopt17_f;
#define DUT_FUSED 1
#define DUT_REFERENCE 0
#define P_WRAPPER(name) dut.rootp->opt17_f__DOT__u_wrapper__DOT__##name
#define P_FRONT(name) dut.rootp->opt17_f__DOT__u_wrapper__DOT__u_front__DOT__##name
#define P_AC(name) dut.rootp->opt17_f__DOT__u_wrapper__DOT__u_front__DOT__u_ac__DOT__##name
#define P_CORE(name) dut.rootp->opt17_f__DOT__u_wrapper__DOT__u_core__DOT__##name
#define P_ACC_NEXT dut.rootp->opt17_f__DOT__u_wrapper__DOT__u_core__DOT__u_acc__DOT__acc_next
#define P_LAUNCH P_WRAPPER(launch)
#define P_ITER P_WRAPPER(iterations_done)
