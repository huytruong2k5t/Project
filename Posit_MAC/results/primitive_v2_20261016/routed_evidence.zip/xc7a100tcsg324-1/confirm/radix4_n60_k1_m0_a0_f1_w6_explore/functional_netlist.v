// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2026.1 (win64) Build 6511674 Tue Jun 16 11:02:23 MDT 2026
// Date        : Fri Oct 16 16:26:59 2026
// Host        : MSI running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim {C:/HCMUT/HK261/Do an
//               2/Posit_MAC/results/primitive_v2_20261016/xc7a100tcsg324-1/confirm/radix4_n60_k1_m0_a0_f1_w6_explore/functional_netlist.v}
// Design      : primitive_v2_top
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a100tcsg324-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module primitive_v2_boundary
   (result,
    amount,
    clk_core,
    data,
    fill_val);
  output [59:0]result;
  input [5:0]amount;
  input clk_core;
  input [59:0]data;
  input fill_val;

  wire [5:0]amount;
  wire clk_core;
  wire [59:0]data;
  wire [59:0]data_q;
  wire fill_val;
  wire [59:0]\g_multi.g_stages[0].g_pair.selected ;
  wire [59:0]\g_multi.g_stages[1].g_pair.selected ;
  wire [5:0]\g_shift.amount_q ;
  wire \g_shift.g_right.g_dynamic.fill_q ;
  wire [59:0]result;
  wire \result[28]_i_1_n_0 ;
  wire \result[29]_i_1_n_0 ;
  wire \result[30]_i_1_n_0 ;
  wire \result[31]_i_1_n_0 ;
  wire \result[32]_i_1_n_0 ;
  wire \result[33]_i_1_n_0 ;
  wire \result[34]_i_1_n_0 ;
  wire \result[35]_i_1_n_0 ;
  wire \result[36]_i_1_n_0 ;
  wire \result[37]_i_1_n_0 ;
  wire \result[38]_i_1_n_0 ;
  wire \result[39]_i_1_n_0 ;
  wire \result[40]_i_1_n_0 ;
  wire \result[41]_i_1_n_0 ;
  wire \result[42]_i_1_n_0 ;
  wire \result[43]_i_1_n_0 ;
  wire \result[44]_i_1_n_0 ;
  wire \result[45]_i_1_n_0 ;
  wire \result[46]_i_1_n_0 ;
  wire \result[47]_i_1_n_0 ;
  wire \result[48]_i_1_n_0 ;
  wire \result[49]_i_1_n_0 ;
  wire \result[50]_i_1_n_0 ;
  wire \result[51]_i_1_n_0 ;
  wire \result[52]_i_1_n_0 ;
  wire \result[53]_i_1_n_0 ;
  wire \result[54]_i_1_n_0 ;
  wire \result[55]_i_1_n_0 ;
  wire \result[56]_i_1_n_0 ;
  wire \result[57]_i_1_n_0 ;
  wire \result[58]_i_1_n_0 ;
  wire \result[59]_i_1_n_0 ;
  wire \result[59]_i_2_n_0 ;
  wire [27:0]result_d;

  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[0] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[0]),
        .Q(data_q[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[10] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[10]),
        .Q(data_q[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[11] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[11]),
        .Q(data_q[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[12] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[12]),
        .Q(data_q[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[13] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[13]),
        .Q(data_q[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[14] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[14]),
        .Q(data_q[14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[15] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[15]),
        .Q(data_q[15]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[16] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[16]),
        .Q(data_q[16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[17] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[17]),
        .Q(data_q[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[18] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[18]),
        .Q(data_q[18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[19] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[19]),
        .Q(data_q[19]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[1] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[1]),
        .Q(data_q[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[20] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[20]),
        .Q(data_q[20]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[21] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[21]),
        .Q(data_q[21]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[22] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[22]),
        .Q(data_q[22]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[23] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[23]),
        .Q(data_q[23]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[24] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[24]),
        .Q(data_q[24]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[25] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[25]),
        .Q(data_q[25]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[26] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[26]),
        .Q(data_q[26]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[27] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[27]),
        .Q(data_q[27]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[28] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[28]),
        .Q(data_q[28]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[29] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[29]),
        .Q(data_q[29]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[2] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[2]),
        .Q(data_q[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[30] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[30]),
        .Q(data_q[30]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[31] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[31]),
        .Q(data_q[31]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[32] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[32]),
        .Q(data_q[32]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[33] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[33]),
        .Q(data_q[33]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[34] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[34]),
        .Q(data_q[34]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[35] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[35]),
        .Q(data_q[35]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[36] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[36]),
        .Q(data_q[36]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[37] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[37]),
        .Q(data_q[37]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[38] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[38]),
        .Q(data_q[38]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[39] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[39]),
        .Q(data_q[39]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[3] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[3]),
        .Q(data_q[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[40] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[40]),
        .Q(data_q[40]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[41] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[41]),
        .Q(data_q[41]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[42] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[42]),
        .Q(data_q[42]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[43] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[43]),
        .Q(data_q[43]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[44] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[44]),
        .Q(data_q[44]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[45] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[45]),
        .Q(data_q[45]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[46] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[46]),
        .Q(data_q[46]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[47] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[47]),
        .Q(data_q[47]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[48] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[48]),
        .Q(data_q[48]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[49] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[49]),
        .Q(data_q[49]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[4] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[4]),
        .Q(data_q[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[50] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[50]),
        .Q(data_q[50]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[51] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[51]),
        .Q(data_q[51]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[52] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[52]),
        .Q(data_q[52]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[53] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[53]),
        .Q(data_q[53]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[54] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[54]),
        .Q(data_q[54]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[55] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[55]),
        .Q(data_q[55]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[56] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[56]),
        .Q(data_q[56]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[57] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[57]),
        .Q(data_q[57]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[58] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[58]),
        .Q(data_q[58]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[59] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[59]),
        .Q(data_q[59]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[5] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[5]),
        .Q(data_q[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[6] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[6]),
        .Q(data_q[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[7] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[7]),
        .Q(data_q[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[8] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[8]),
        .Q(data_q[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[9] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[9]),
        .Q(data_q[9]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \g_shift.amount_q_reg[0] 
       (.C(clk_core),
        .CE(1'b1),
        .D(amount[0]),
        .Q(\g_shift.amount_q [0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \g_shift.amount_q_reg[1] 
       (.C(clk_core),
        .CE(1'b1),
        .D(amount[1]),
        .Q(\g_shift.amount_q [1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \g_shift.amount_q_reg[2] 
       (.C(clk_core),
        .CE(1'b1),
        .D(amount[2]),
        .Q(\g_shift.amount_q [2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \g_shift.amount_q_reg[3] 
       (.C(clk_core),
        .CE(1'b1),
        .D(amount[3]),
        .Q(\g_shift.amount_q [3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \g_shift.amount_q_reg[4] 
       (.C(clk_core),
        .CE(1'b1),
        .D(amount[4]),
        .Q(\g_shift.amount_q [4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \g_shift.amount_q_reg[5] 
       (.C(clk_core),
        .CE(1'b1),
        .D(amount[5]),
        .Q(\g_shift.amount_q [5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \g_shift.g_right.g_dynamic.fill_q_reg 
       (.C(clk_core),
        .CE(1'b1),
        .D(fill_val),
        .Q(\g_shift.g_right.g_dynamic.fill_q ),
        .R(1'b0));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[0]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [16]),
        .I1(\g_multi.g_stages[1].g_pair.selected [0]),
        .I2(\g_multi.g_stages[1].g_pair.selected [48]),
        .I3(\g_shift.amount_q [4]),
        .I4(\g_shift.amount_q [5]),
        .I5(\g_multi.g_stages[1].g_pair.selected [32]),
        .O(result_d[0]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[0]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [4]),
        .I1(\g_multi.g_stages[0].g_pair.selected [0]),
        .I2(\g_multi.g_stages[0].g_pair.selected [12]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [8]),
        .O(\g_multi.g_stages[1].g_pair.selected [0]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[0]_i_3 
       (.I0(data_q[1]),
        .I1(data_q[0]),
        .I2(data_q[3]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[2]),
        .O(\g_multi.g_stages[0].g_pair.selected [0]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[10]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [26]),
        .I1(\g_multi.g_stages[1].g_pair.selected [10]),
        .I2(\g_multi.g_stages[1].g_pair.selected [58]),
        .I3(\g_shift.amount_q [4]),
        .I4(\g_shift.amount_q [5]),
        .I5(\g_multi.g_stages[1].g_pair.selected [42]),
        .O(result_d[10]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[10]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [14]),
        .I1(\g_multi.g_stages[0].g_pair.selected [10]),
        .I2(\g_multi.g_stages[0].g_pair.selected [22]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [18]),
        .O(\g_multi.g_stages[1].g_pair.selected [10]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[10]_i_3 
       (.I0(data_q[11]),
        .I1(data_q[10]),
        .I2(data_q[13]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[12]),
        .O(\g_multi.g_stages[0].g_pair.selected [10]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[11]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [27]),
        .I1(\g_multi.g_stages[1].g_pair.selected [11]),
        .I2(\g_multi.g_stages[1].g_pair.selected [59]),
        .I3(\g_shift.amount_q [4]),
        .I4(\g_shift.amount_q [5]),
        .I5(\g_multi.g_stages[1].g_pair.selected [43]),
        .O(result_d[11]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[11]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [15]),
        .I1(\g_multi.g_stages[0].g_pair.selected [11]),
        .I2(\g_multi.g_stages[0].g_pair.selected [23]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [19]),
        .O(\g_multi.g_stages[1].g_pair.selected [11]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[11]_i_3 
       (.I0(data_q[12]),
        .I1(data_q[11]),
        .I2(data_q[14]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[13]),
        .O(\g_multi.g_stages[0].g_pair.selected [11]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[12]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [28]),
        .I1(\g_multi.g_stages[1].g_pair.selected [12]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [4]),
        .I4(\g_shift.amount_q [5]),
        .I5(\g_multi.g_stages[1].g_pair.selected [44]),
        .O(result_d[12]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[12]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [16]),
        .I1(\g_multi.g_stages[0].g_pair.selected [12]),
        .I2(\g_multi.g_stages[0].g_pair.selected [24]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [20]),
        .O(\g_multi.g_stages[1].g_pair.selected [12]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[12]_i_3 
       (.I0(data_q[13]),
        .I1(data_q[12]),
        .I2(data_q[15]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[14]),
        .O(\g_multi.g_stages[0].g_pair.selected [12]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[13]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [29]),
        .I1(\g_multi.g_stages[1].g_pair.selected [13]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [4]),
        .I4(\g_shift.amount_q [5]),
        .I5(\g_multi.g_stages[1].g_pair.selected [45]),
        .O(result_d[13]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[13]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [17]),
        .I1(\g_multi.g_stages[0].g_pair.selected [13]),
        .I2(\g_multi.g_stages[0].g_pair.selected [25]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [21]),
        .O(\g_multi.g_stages[1].g_pair.selected [13]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[13]_i_3 
       (.I0(data_q[14]),
        .I1(data_q[13]),
        .I2(data_q[16]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[15]),
        .O(\g_multi.g_stages[0].g_pair.selected [13]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[14]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [30]),
        .I1(\g_multi.g_stages[1].g_pair.selected [14]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [4]),
        .I4(\g_shift.amount_q [5]),
        .I5(\g_multi.g_stages[1].g_pair.selected [46]),
        .O(result_d[14]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[14]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [18]),
        .I1(\g_multi.g_stages[0].g_pair.selected [14]),
        .I2(\g_multi.g_stages[0].g_pair.selected [26]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [22]),
        .O(\g_multi.g_stages[1].g_pair.selected [14]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[14]_i_3 
       (.I0(data_q[15]),
        .I1(data_q[14]),
        .I2(data_q[17]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[16]),
        .O(\g_multi.g_stages[0].g_pair.selected [14]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[15]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [31]),
        .I1(\g_multi.g_stages[1].g_pair.selected [15]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [4]),
        .I4(\g_shift.amount_q [5]),
        .I5(\g_multi.g_stages[1].g_pair.selected [47]),
        .O(result_d[15]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[15]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [19]),
        .I1(\g_multi.g_stages[0].g_pair.selected [15]),
        .I2(\g_multi.g_stages[0].g_pair.selected [27]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [23]),
        .O(\g_multi.g_stages[1].g_pair.selected [15]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[15]_i_3 
       (.I0(data_q[16]),
        .I1(data_q[15]),
        .I2(data_q[18]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[17]),
        .O(\g_multi.g_stages[0].g_pair.selected [15]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[16]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [32]),
        .I1(\g_multi.g_stages[1].g_pair.selected [16]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [4]),
        .I4(\g_shift.amount_q [5]),
        .I5(\g_multi.g_stages[1].g_pair.selected [48]),
        .O(result_d[16]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[16]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [20]),
        .I1(\g_multi.g_stages[0].g_pair.selected [16]),
        .I2(\g_multi.g_stages[0].g_pair.selected [28]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [24]),
        .O(\g_multi.g_stages[1].g_pair.selected [16]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[16]_i_3 
       (.I0(data_q[17]),
        .I1(data_q[16]),
        .I2(data_q[19]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[18]),
        .O(\g_multi.g_stages[0].g_pair.selected [16]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[17]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [33]),
        .I1(\g_multi.g_stages[1].g_pair.selected [17]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [4]),
        .I4(\g_shift.amount_q [5]),
        .I5(\g_multi.g_stages[1].g_pair.selected [49]),
        .O(result_d[17]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[17]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [21]),
        .I1(\g_multi.g_stages[0].g_pair.selected [17]),
        .I2(\g_multi.g_stages[0].g_pair.selected [29]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [25]),
        .O(\g_multi.g_stages[1].g_pair.selected [17]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[17]_i_3 
       (.I0(data_q[18]),
        .I1(data_q[17]),
        .I2(data_q[20]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[19]),
        .O(\g_multi.g_stages[0].g_pair.selected [17]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[18]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [34]),
        .I1(\g_multi.g_stages[1].g_pair.selected [18]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [4]),
        .I4(\g_shift.amount_q [5]),
        .I5(\g_multi.g_stages[1].g_pair.selected [50]),
        .O(result_d[18]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[18]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [22]),
        .I1(\g_multi.g_stages[0].g_pair.selected [18]),
        .I2(\g_multi.g_stages[0].g_pair.selected [30]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [26]),
        .O(\g_multi.g_stages[1].g_pair.selected [18]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[18]_i_3 
       (.I0(data_q[19]),
        .I1(data_q[18]),
        .I2(data_q[21]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[20]),
        .O(\g_multi.g_stages[0].g_pair.selected [18]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[19]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [35]),
        .I1(\g_multi.g_stages[1].g_pair.selected [19]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [4]),
        .I4(\g_shift.amount_q [5]),
        .I5(\g_multi.g_stages[1].g_pair.selected [51]),
        .O(result_d[19]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[19]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [23]),
        .I1(\g_multi.g_stages[0].g_pair.selected [19]),
        .I2(\g_multi.g_stages[0].g_pair.selected [31]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [27]),
        .O(\g_multi.g_stages[1].g_pair.selected [19]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[19]_i_3 
       (.I0(data_q[20]),
        .I1(data_q[19]),
        .I2(data_q[22]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[21]),
        .O(\g_multi.g_stages[0].g_pair.selected [19]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[1]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [17]),
        .I1(\g_multi.g_stages[1].g_pair.selected [1]),
        .I2(\g_multi.g_stages[1].g_pair.selected [49]),
        .I3(\g_shift.amount_q [4]),
        .I4(\g_shift.amount_q [5]),
        .I5(\g_multi.g_stages[1].g_pair.selected [33]),
        .O(result_d[1]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[1]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [5]),
        .I1(\g_multi.g_stages[0].g_pair.selected [1]),
        .I2(\g_multi.g_stages[0].g_pair.selected [13]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [9]),
        .O(\g_multi.g_stages[1].g_pair.selected [1]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[1]_i_3 
       (.I0(data_q[2]),
        .I1(data_q[1]),
        .I2(data_q[4]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[3]),
        .O(\g_multi.g_stages[0].g_pair.selected [1]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[20]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [36]),
        .I1(\g_multi.g_stages[1].g_pair.selected [20]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [4]),
        .I4(\g_shift.amount_q [5]),
        .I5(\g_multi.g_stages[1].g_pair.selected [52]),
        .O(result_d[20]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[20]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [24]),
        .I1(\g_multi.g_stages[0].g_pair.selected [20]),
        .I2(\g_multi.g_stages[0].g_pair.selected [32]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [28]),
        .O(\g_multi.g_stages[1].g_pair.selected [20]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[20]_i_3 
       (.I0(data_q[21]),
        .I1(data_q[20]),
        .I2(data_q[23]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[22]),
        .O(\g_multi.g_stages[0].g_pair.selected [20]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[21]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [37]),
        .I1(\g_multi.g_stages[1].g_pair.selected [21]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [4]),
        .I4(\g_shift.amount_q [5]),
        .I5(\g_multi.g_stages[1].g_pair.selected [53]),
        .O(result_d[21]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[21]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [25]),
        .I1(\g_multi.g_stages[0].g_pair.selected [21]),
        .I2(\g_multi.g_stages[0].g_pair.selected [33]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [29]),
        .O(\g_multi.g_stages[1].g_pair.selected [21]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[21]_i_3 
       (.I0(data_q[22]),
        .I1(data_q[21]),
        .I2(data_q[24]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[23]),
        .O(\g_multi.g_stages[0].g_pair.selected [21]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[22]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [38]),
        .I1(\g_multi.g_stages[1].g_pair.selected [22]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [4]),
        .I4(\g_shift.amount_q [5]),
        .I5(\g_multi.g_stages[1].g_pair.selected [54]),
        .O(result_d[22]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[22]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [26]),
        .I1(\g_multi.g_stages[0].g_pair.selected [22]),
        .I2(\g_multi.g_stages[0].g_pair.selected [34]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [30]),
        .O(\g_multi.g_stages[1].g_pair.selected [22]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[22]_i_3 
       (.I0(data_q[23]),
        .I1(data_q[22]),
        .I2(data_q[25]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[24]),
        .O(\g_multi.g_stages[0].g_pair.selected [22]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[23]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [39]),
        .I1(\g_multi.g_stages[1].g_pair.selected [23]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [4]),
        .I4(\g_shift.amount_q [5]),
        .I5(\g_multi.g_stages[1].g_pair.selected [55]),
        .O(result_d[23]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[23]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [27]),
        .I1(\g_multi.g_stages[0].g_pair.selected [23]),
        .I2(\g_multi.g_stages[0].g_pair.selected [35]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [31]),
        .O(\g_multi.g_stages[1].g_pair.selected [23]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[23]_i_3 
       (.I0(data_q[24]),
        .I1(data_q[23]),
        .I2(data_q[26]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[25]),
        .O(\g_multi.g_stages[0].g_pair.selected [23]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[24]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [40]),
        .I1(\g_multi.g_stages[1].g_pair.selected [24]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [4]),
        .I4(\g_shift.amount_q [5]),
        .I5(\g_multi.g_stages[1].g_pair.selected [56]),
        .O(result_d[24]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[24]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [28]),
        .I1(\g_multi.g_stages[0].g_pair.selected [24]),
        .I2(\g_multi.g_stages[0].g_pair.selected [36]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [32]),
        .O(\g_multi.g_stages[1].g_pair.selected [24]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[24]_i_3 
       (.I0(data_q[25]),
        .I1(data_q[24]),
        .I2(data_q[27]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[26]),
        .O(\g_multi.g_stages[0].g_pair.selected [24]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[25]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [41]),
        .I1(\g_multi.g_stages[1].g_pair.selected [25]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [4]),
        .I4(\g_shift.amount_q [5]),
        .I5(\g_multi.g_stages[1].g_pair.selected [57]),
        .O(result_d[25]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[25]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [29]),
        .I1(\g_multi.g_stages[0].g_pair.selected [25]),
        .I2(\g_multi.g_stages[0].g_pair.selected [37]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [33]),
        .O(\g_multi.g_stages[1].g_pair.selected [25]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[25]_i_3 
       (.I0(data_q[26]),
        .I1(data_q[25]),
        .I2(data_q[28]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[27]),
        .O(\g_multi.g_stages[0].g_pair.selected [25]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[26]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [42]),
        .I1(\g_multi.g_stages[1].g_pair.selected [26]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [4]),
        .I4(\g_shift.amount_q [5]),
        .I5(\g_multi.g_stages[1].g_pair.selected [58]),
        .O(result_d[26]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[26]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [30]),
        .I1(\g_multi.g_stages[0].g_pair.selected [26]),
        .I2(\g_multi.g_stages[0].g_pair.selected [38]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [34]),
        .O(\g_multi.g_stages[1].g_pair.selected [26]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[26]_i_3 
       (.I0(data_q[27]),
        .I1(data_q[26]),
        .I2(data_q[29]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[28]),
        .O(\g_multi.g_stages[0].g_pair.selected [26]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[27]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [43]),
        .I1(\g_multi.g_stages[1].g_pair.selected [27]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [4]),
        .I4(\g_shift.amount_q [5]),
        .I5(\g_multi.g_stages[1].g_pair.selected [59]),
        .O(result_d[27]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[27]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [31]),
        .I1(\g_multi.g_stages[0].g_pair.selected [27]),
        .I2(\g_multi.g_stages[0].g_pair.selected [39]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [35]),
        .O(\g_multi.g_stages[1].g_pair.selected [27]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[27]_i_3 
       (.I0(data_q[28]),
        .I1(data_q[27]),
        .I2(data_q[30]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[29]),
        .O(\g_multi.g_stages[0].g_pair.selected [27]));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT4 #(
    .INIT(16'h0E02)) 
    \result[28]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [28]),
        .I1(\g_shift.amount_q [4]),
        .I2(\g_shift.amount_q [5]),
        .I3(\g_multi.g_stages[1].g_pair.selected [44]),
        .O(\result[28]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[28]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [32]),
        .I1(\g_multi.g_stages[0].g_pair.selected [28]),
        .I2(\g_multi.g_stages[0].g_pair.selected [40]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [36]),
        .O(\g_multi.g_stages[1].g_pair.selected [28]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[28]_i_3 
       (.I0(data_q[29]),
        .I1(data_q[28]),
        .I2(data_q[31]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[30]),
        .O(\g_multi.g_stages[0].g_pair.selected [28]));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT4 #(
    .INIT(16'h0E02)) 
    \result[29]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [29]),
        .I1(\g_shift.amount_q [4]),
        .I2(\g_shift.amount_q [5]),
        .I3(\g_multi.g_stages[1].g_pair.selected [45]),
        .O(\result[29]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[29]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [33]),
        .I1(\g_multi.g_stages[0].g_pair.selected [29]),
        .I2(\g_multi.g_stages[0].g_pair.selected [41]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [37]),
        .O(\g_multi.g_stages[1].g_pair.selected [29]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[29]_i_3 
       (.I0(data_q[30]),
        .I1(data_q[29]),
        .I2(data_q[32]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[31]),
        .O(\g_multi.g_stages[0].g_pair.selected [29]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[2]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [18]),
        .I1(\g_multi.g_stages[1].g_pair.selected [2]),
        .I2(\g_multi.g_stages[1].g_pair.selected [50]),
        .I3(\g_shift.amount_q [4]),
        .I4(\g_shift.amount_q [5]),
        .I5(\g_multi.g_stages[1].g_pair.selected [34]),
        .O(result_d[2]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[2]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [6]),
        .I1(\g_multi.g_stages[0].g_pair.selected [2]),
        .I2(\g_multi.g_stages[0].g_pair.selected [14]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [10]),
        .O(\g_multi.g_stages[1].g_pair.selected [2]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[2]_i_3 
       (.I0(data_q[3]),
        .I1(data_q[2]),
        .I2(data_q[5]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[4]),
        .O(\g_multi.g_stages[0].g_pair.selected [2]));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT4 #(
    .INIT(16'h0E02)) 
    \result[30]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [30]),
        .I1(\g_shift.amount_q [4]),
        .I2(\g_shift.amount_q [5]),
        .I3(\g_multi.g_stages[1].g_pair.selected [46]),
        .O(\result[30]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[30]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [34]),
        .I1(\g_multi.g_stages[0].g_pair.selected [30]),
        .I2(\g_multi.g_stages[0].g_pair.selected [42]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [38]),
        .O(\g_multi.g_stages[1].g_pair.selected [30]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[30]_i_3 
       (.I0(data_q[31]),
        .I1(data_q[30]),
        .I2(data_q[33]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[32]),
        .O(\g_multi.g_stages[0].g_pair.selected [30]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT4 #(
    .INIT(16'h0E02)) 
    \result[31]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [31]),
        .I1(\g_shift.amount_q [4]),
        .I2(\g_shift.amount_q [5]),
        .I3(\g_multi.g_stages[1].g_pair.selected [47]),
        .O(\result[31]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[31]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [35]),
        .I1(\g_multi.g_stages[0].g_pair.selected [31]),
        .I2(\g_multi.g_stages[0].g_pair.selected [43]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [39]),
        .O(\g_multi.g_stages[1].g_pair.selected [31]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[31]_i_3 
       (.I0(data_q[32]),
        .I1(data_q[31]),
        .I2(data_q[34]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[33]),
        .O(\g_multi.g_stages[0].g_pair.selected [31]));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT4 #(
    .INIT(16'h0E02)) 
    \result[32]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [32]),
        .I1(\g_shift.amount_q [4]),
        .I2(\g_shift.amount_q [5]),
        .I3(\g_multi.g_stages[1].g_pair.selected [48]),
        .O(\result[32]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[32]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [36]),
        .I1(\g_multi.g_stages[0].g_pair.selected [32]),
        .I2(\g_multi.g_stages[0].g_pair.selected [44]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [40]),
        .O(\g_multi.g_stages[1].g_pair.selected [32]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[32]_i_3 
       (.I0(data_q[33]),
        .I1(data_q[32]),
        .I2(data_q[35]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[34]),
        .O(\g_multi.g_stages[0].g_pair.selected [32]));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT4 #(
    .INIT(16'h0E02)) 
    \result[33]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [33]),
        .I1(\g_shift.amount_q [4]),
        .I2(\g_shift.amount_q [5]),
        .I3(\g_multi.g_stages[1].g_pair.selected [49]),
        .O(\result[33]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[33]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [37]),
        .I1(\g_multi.g_stages[0].g_pair.selected [33]),
        .I2(\g_multi.g_stages[0].g_pair.selected [45]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [41]),
        .O(\g_multi.g_stages[1].g_pair.selected [33]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[33]_i_3 
       (.I0(data_q[34]),
        .I1(data_q[33]),
        .I2(data_q[36]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[35]),
        .O(\g_multi.g_stages[0].g_pair.selected [33]));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT4 #(
    .INIT(16'h0E02)) 
    \result[34]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [34]),
        .I1(\g_shift.amount_q [4]),
        .I2(\g_shift.amount_q [5]),
        .I3(\g_multi.g_stages[1].g_pair.selected [50]),
        .O(\result[34]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[34]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [38]),
        .I1(\g_multi.g_stages[0].g_pair.selected [34]),
        .I2(\g_multi.g_stages[0].g_pair.selected [46]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [42]),
        .O(\g_multi.g_stages[1].g_pair.selected [34]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[34]_i_3 
       (.I0(data_q[35]),
        .I1(data_q[34]),
        .I2(data_q[37]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[36]),
        .O(\g_multi.g_stages[0].g_pair.selected [34]));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT4 #(
    .INIT(16'h0E02)) 
    \result[35]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [35]),
        .I1(\g_shift.amount_q [4]),
        .I2(\g_shift.amount_q [5]),
        .I3(\g_multi.g_stages[1].g_pair.selected [51]),
        .O(\result[35]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[35]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [39]),
        .I1(\g_multi.g_stages[0].g_pair.selected [35]),
        .I2(\g_multi.g_stages[0].g_pair.selected [47]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [43]),
        .O(\g_multi.g_stages[1].g_pair.selected [35]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[35]_i_3 
       (.I0(data_q[36]),
        .I1(data_q[35]),
        .I2(data_q[38]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[37]),
        .O(\g_multi.g_stages[0].g_pair.selected [35]));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT4 #(
    .INIT(16'h0E02)) 
    \result[36]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [36]),
        .I1(\g_shift.amount_q [4]),
        .I2(\g_shift.amount_q [5]),
        .I3(\g_multi.g_stages[1].g_pair.selected [52]),
        .O(\result[36]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[36]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [40]),
        .I1(\g_multi.g_stages[0].g_pair.selected [36]),
        .I2(\g_multi.g_stages[0].g_pair.selected [48]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [44]),
        .O(\g_multi.g_stages[1].g_pair.selected [36]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[36]_i_3 
       (.I0(data_q[37]),
        .I1(data_q[36]),
        .I2(data_q[39]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[38]),
        .O(\g_multi.g_stages[0].g_pair.selected [36]));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT4 #(
    .INIT(16'h0E02)) 
    \result[37]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [37]),
        .I1(\g_shift.amount_q [4]),
        .I2(\g_shift.amount_q [5]),
        .I3(\g_multi.g_stages[1].g_pair.selected [53]),
        .O(\result[37]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[37]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [41]),
        .I1(\g_multi.g_stages[0].g_pair.selected [37]),
        .I2(\g_multi.g_stages[0].g_pair.selected [49]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [45]),
        .O(\g_multi.g_stages[1].g_pair.selected [37]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[37]_i_3 
       (.I0(data_q[38]),
        .I1(data_q[37]),
        .I2(data_q[40]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[39]),
        .O(\g_multi.g_stages[0].g_pair.selected [37]));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT4 #(
    .INIT(16'h0E02)) 
    \result[38]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [38]),
        .I1(\g_shift.amount_q [4]),
        .I2(\g_shift.amount_q [5]),
        .I3(\g_multi.g_stages[1].g_pair.selected [54]),
        .O(\result[38]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[38]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [42]),
        .I1(\g_multi.g_stages[0].g_pair.selected [38]),
        .I2(\g_multi.g_stages[0].g_pair.selected [50]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [46]),
        .O(\g_multi.g_stages[1].g_pair.selected [38]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[38]_i_3 
       (.I0(data_q[39]),
        .I1(data_q[38]),
        .I2(data_q[41]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[40]),
        .O(\g_multi.g_stages[0].g_pair.selected [38]));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT4 #(
    .INIT(16'h0E02)) 
    \result[39]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [39]),
        .I1(\g_shift.amount_q [4]),
        .I2(\g_shift.amount_q [5]),
        .I3(\g_multi.g_stages[1].g_pair.selected [55]),
        .O(\result[39]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[39]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [43]),
        .I1(\g_multi.g_stages[0].g_pair.selected [39]),
        .I2(\g_multi.g_stages[0].g_pair.selected [51]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [47]),
        .O(\g_multi.g_stages[1].g_pair.selected [39]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[39]_i_3 
       (.I0(data_q[40]),
        .I1(data_q[39]),
        .I2(data_q[42]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[41]),
        .O(\g_multi.g_stages[0].g_pair.selected [39]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[3]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [19]),
        .I1(\g_multi.g_stages[1].g_pair.selected [3]),
        .I2(\g_multi.g_stages[1].g_pair.selected [51]),
        .I3(\g_shift.amount_q [4]),
        .I4(\g_shift.amount_q [5]),
        .I5(\g_multi.g_stages[1].g_pair.selected [35]),
        .O(result_d[3]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[3]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [7]),
        .I1(\g_multi.g_stages[0].g_pair.selected [3]),
        .I2(\g_multi.g_stages[0].g_pair.selected [15]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [11]),
        .O(\g_multi.g_stages[1].g_pair.selected [3]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[3]_i_3 
       (.I0(data_q[4]),
        .I1(data_q[3]),
        .I2(data_q[6]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[5]),
        .O(\g_multi.g_stages[0].g_pair.selected [3]));
  LUT4 #(
    .INIT(16'h0E02)) 
    \result[40]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [40]),
        .I1(\g_shift.amount_q [4]),
        .I2(\g_shift.amount_q [5]),
        .I3(\g_multi.g_stages[1].g_pair.selected [56]),
        .O(\result[40]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[40]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [44]),
        .I1(\g_multi.g_stages[0].g_pair.selected [40]),
        .I2(\g_multi.g_stages[0].g_pair.selected [52]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [48]),
        .O(\g_multi.g_stages[1].g_pair.selected [40]));
  LUT4 #(
    .INIT(16'hCCCA)) 
    \result[40]_i_3 
       (.I0(\g_multi.g_stages[0].g_pair.selected [56]),
        .I1(\g_shift.g_right.g_dynamic.fill_q ),
        .I2(\g_shift.amount_q [2]),
        .I3(\g_shift.amount_q [3]),
        .O(\g_multi.g_stages[1].g_pair.selected [56]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[40]_i_4 
       (.I0(data_q[41]),
        .I1(data_q[40]),
        .I2(data_q[43]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[42]),
        .O(\g_multi.g_stages[0].g_pair.selected [40]));
  LUT4 #(
    .INIT(16'h0E02)) 
    \result[41]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [41]),
        .I1(\g_shift.amount_q [4]),
        .I2(\g_shift.amount_q [5]),
        .I3(\g_multi.g_stages[1].g_pair.selected [57]),
        .O(\result[41]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[41]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [45]),
        .I1(\g_multi.g_stages[0].g_pair.selected [41]),
        .I2(\g_multi.g_stages[0].g_pair.selected [53]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [49]),
        .O(\g_multi.g_stages[1].g_pair.selected [41]));
  LUT4 #(
    .INIT(16'hCCCA)) 
    \result[41]_i_3 
       (.I0(\g_multi.g_stages[0].g_pair.selected [57]),
        .I1(\g_shift.g_right.g_dynamic.fill_q ),
        .I2(\g_shift.amount_q [2]),
        .I3(\g_shift.amount_q [3]),
        .O(\g_multi.g_stages[1].g_pair.selected [57]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[41]_i_4 
       (.I0(data_q[42]),
        .I1(data_q[41]),
        .I2(data_q[44]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[43]),
        .O(\g_multi.g_stages[0].g_pair.selected [41]));
  LUT4 #(
    .INIT(16'h0E02)) 
    \result[42]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [42]),
        .I1(\g_shift.amount_q [4]),
        .I2(\g_shift.amount_q [5]),
        .I3(\g_multi.g_stages[1].g_pair.selected [58]),
        .O(\result[42]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[42]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [46]),
        .I1(\g_multi.g_stages[0].g_pair.selected [42]),
        .I2(\g_multi.g_stages[0].g_pair.selected [54]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [50]),
        .O(\g_multi.g_stages[1].g_pair.selected [42]));
  LUT4 #(
    .INIT(16'hCCCA)) 
    \result[42]_i_3 
       (.I0(\g_multi.g_stages[0].g_pair.selected [58]),
        .I1(\g_shift.g_right.g_dynamic.fill_q ),
        .I2(\g_shift.amount_q [2]),
        .I3(\g_shift.amount_q [3]),
        .O(\g_multi.g_stages[1].g_pair.selected [58]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[42]_i_4 
       (.I0(data_q[43]),
        .I1(data_q[42]),
        .I2(data_q[45]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[44]),
        .O(\g_multi.g_stages[0].g_pair.selected [42]));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT4 #(
    .INIT(16'h0E02)) 
    \result[43]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [43]),
        .I1(\g_shift.amount_q [4]),
        .I2(\g_shift.amount_q [5]),
        .I3(\g_multi.g_stages[1].g_pair.selected [59]),
        .O(\result[43]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[43]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [47]),
        .I1(\g_multi.g_stages[0].g_pair.selected [43]),
        .I2(\g_multi.g_stages[0].g_pair.selected [55]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [51]),
        .O(\g_multi.g_stages[1].g_pair.selected [43]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[43]_i_3 
       (.I0(data_q[44]),
        .I1(data_q[43]),
        .I2(data_q[46]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[45]),
        .O(\g_multi.g_stages[0].g_pair.selected [43]));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT4 #(
    .INIT(16'h0E02)) 
    \result[44]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [44]),
        .I1(\g_shift.amount_q [4]),
        .I2(\g_shift.amount_q [5]),
        .I3(\g_shift.g_right.g_dynamic.fill_q ),
        .O(\result[44]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[44]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [48]),
        .I1(\g_multi.g_stages[0].g_pair.selected [44]),
        .I2(\g_multi.g_stages[0].g_pair.selected [56]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [52]),
        .O(\g_multi.g_stages[1].g_pair.selected [44]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[44]_i_3 
       (.I0(data_q[45]),
        .I1(data_q[44]),
        .I2(data_q[47]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[46]),
        .O(\g_multi.g_stages[0].g_pair.selected [44]));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT4 #(
    .INIT(16'h0E02)) 
    \result[45]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [45]),
        .I1(\g_shift.amount_q [4]),
        .I2(\g_shift.amount_q [5]),
        .I3(\g_shift.g_right.g_dynamic.fill_q ),
        .O(\result[45]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[45]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [49]),
        .I1(\g_multi.g_stages[0].g_pair.selected [45]),
        .I2(\g_multi.g_stages[0].g_pair.selected [57]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [53]),
        .O(\g_multi.g_stages[1].g_pair.selected [45]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[45]_i_3 
       (.I0(data_q[46]),
        .I1(data_q[45]),
        .I2(data_q[48]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[47]),
        .O(\g_multi.g_stages[0].g_pair.selected [45]));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT4 #(
    .INIT(16'h0E02)) 
    \result[46]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [46]),
        .I1(\g_shift.amount_q [4]),
        .I2(\g_shift.amount_q [5]),
        .I3(\g_shift.g_right.g_dynamic.fill_q ),
        .O(\result[46]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[46]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [50]),
        .I1(\g_multi.g_stages[0].g_pair.selected [46]),
        .I2(\g_multi.g_stages[0].g_pair.selected [58]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [54]),
        .O(\g_multi.g_stages[1].g_pair.selected [46]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[46]_i_3 
       (.I0(data_q[47]),
        .I1(data_q[46]),
        .I2(data_q[49]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[48]),
        .O(\g_multi.g_stages[0].g_pair.selected [46]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT4 #(
    .INIT(16'h0E02)) 
    \result[47]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [47]),
        .I1(\g_shift.amount_q [4]),
        .I2(\g_shift.amount_q [5]),
        .I3(\g_shift.g_right.g_dynamic.fill_q ),
        .O(\result[47]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[47]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [51]),
        .I1(\g_multi.g_stages[0].g_pair.selected [47]),
        .I2(\g_multi.g_stages[0].g_pair.selected [59]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [55]),
        .O(\g_multi.g_stages[1].g_pair.selected [47]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[47]_i_3 
       (.I0(data_q[48]),
        .I1(data_q[47]),
        .I2(data_q[50]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[49]),
        .O(\g_multi.g_stages[0].g_pair.selected [47]));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT4 #(
    .INIT(16'h0E02)) 
    \result[48]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [48]),
        .I1(\g_shift.amount_q [4]),
        .I2(\g_shift.amount_q [5]),
        .I3(\g_shift.g_right.g_dynamic.fill_q ),
        .O(\result[48]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[48]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [52]),
        .I1(\g_multi.g_stages[0].g_pair.selected [48]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [56]),
        .O(\g_multi.g_stages[1].g_pair.selected [48]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[48]_i_3 
       (.I0(data_q[49]),
        .I1(data_q[48]),
        .I2(data_q[51]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[50]),
        .O(\g_multi.g_stages[0].g_pair.selected [48]));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT4 #(
    .INIT(16'h0E02)) 
    \result[49]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [49]),
        .I1(\g_shift.amount_q [4]),
        .I2(\g_shift.amount_q [5]),
        .I3(\g_shift.g_right.g_dynamic.fill_q ),
        .O(\result[49]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[49]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [53]),
        .I1(\g_multi.g_stages[0].g_pair.selected [49]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [57]),
        .O(\g_multi.g_stages[1].g_pair.selected [49]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[49]_i_3 
       (.I0(data_q[50]),
        .I1(data_q[49]),
        .I2(data_q[52]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[51]),
        .O(\g_multi.g_stages[0].g_pair.selected [49]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[4]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [20]),
        .I1(\g_multi.g_stages[1].g_pair.selected [4]),
        .I2(\g_multi.g_stages[1].g_pair.selected [52]),
        .I3(\g_shift.amount_q [4]),
        .I4(\g_shift.amount_q [5]),
        .I5(\g_multi.g_stages[1].g_pair.selected [36]),
        .O(result_d[4]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[4]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [8]),
        .I1(\g_multi.g_stages[0].g_pair.selected [4]),
        .I2(\g_multi.g_stages[0].g_pair.selected [16]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [12]),
        .O(\g_multi.g_stages[1].g_pair.selected [4]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[4]_i_3 
       (.I0(data_q[5]),
        .I1(data_q[4]),
        .I2(data_q[7]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[6]),
        .O(\g_multi.g_stages[0].g_pair.selected [4]));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT4 #(
    .INIT(16'h0E02)) 
    \result[50]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [50]),
        .I1(\g_shift.amount_q [4]),
        .I2(\g_shift.amount_q [5]),
        .I3(\g_shift.g_right.g_dynamic.fill_q ),
        .O(\result[50]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[50]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [54]),
        .I1(\g_multi.g_stages[0].g_pair.selected [50]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [58]),
        .O(\g_multi.g_stages[1].g_pair.selected [50]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[50]_i_3 
       (.I0(data_q[51]),
        .I1(data_q[50]),
        .I2(data_q[53]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[52]),
        .O(\g_multi.g_stages[0].g_pair.selected [50]));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT4 #(
    .INIT(16'h0E02)) 
    \result[51]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [51]),
        .I1(\g_shift.amount_q [4]),
        .I2(\g_shift.amount_q [5]),
        .I3(\g_shift.g_right.g_dynamic.fill_q ),
        .O(\result[51]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[51]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [55]),
        .I1(\g_multi.g_stages[0].g_pair.selected [51]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [59]),
        .O(\g_multi.g_stages[1].g_pair.selected [51]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[51]_i_3 
       (.I0(data_q[52]),
        .I1(data_q[51]),
        .I2(data_q[54]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[53]),
        .O(\g_multi.g_stages[0].g_pair.selected [51]));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT4 #(
    .INIT(16'h0E02)) 
    \result[52]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [52]),
        .I1(\g_shift.amount_q [4]),
        .I2(\g_shift.amount_q [5]),
        .I3(\g_shift.g_right.g_dynamic.fill_q ),
        .O(\result[52]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hF0F0AACC)) 
    \result[52]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [56]),
        .I1(\g_multi.g_stages[0].g_pair.selected [52]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .O(\g_multi.g_stages[1].g_pair.selected [52]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[52]_i_3 
       (.I0(data_q[53]),
        .I1(data_q[52]),
        .I2(data_q[55]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[54]),
        .O(\g_multi.g_stages[0].g_pair.selected [52]));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT4 #(
    .INIT(16'h0E02)) 
    \result[53]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [53]),
        .I1(\g_shift.amount_q [4]),
        .I2(\g_shift.amount_q [5]),
        .I3(\g_shift.g_right.g_dynamic.fill_q ),
        .O(\result[53]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hF0F0AACC)) 
    \result[53]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [57]),
        .I1(\g_multi.g_stages[0].g_pair.selected [53]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .O(\g_multi.g_stages[1].g_pair.selected [53]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[53]_i_3 
       (.I0(data_q[54]),
        .I1(data_q[53]),
        .I2(data_q[56]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[55]),
        .O(\g_multi.g_stages[0].g_pair.selected [53]));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT4 #(
    .INIT(16'h0E02)) 
    \result[54]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [54]),
        .I1(\g_shift.amount_q [4]),
        .I2(\g_shift.amount_q [5]),
        .I3(\g_shift.g_right.g_dynamic.fill_q ),
        .O(\result[54]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hF0F0AACC)) 
    \result[54]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [58]),
        .I1(\g_multi.g_stages[0].g_pair.selected [54]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .O(\g_multi.g_stages[1].g_pair.selected [54]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[54]_i_3 
       (.I0(data_q[55]),
        .I1(data_q[54]),
        .I2(data_q[57]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[56]),
        .O(\g_multi.g_stages[0].g_pair.selected [54]));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT4 #(
    .INIT(16'h0E02)) 
    \result[55]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [55]),
        .I1(\g_shift.amount_q [4]),
        .I2(\g_shift.amount_q [5]),
        .I3(\g_shift.g_right.g_dynamic.fill_q ),
        .O(\result[55]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hF0F0AACC)) 
    \result[55]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [59]),
        .I1(\g_multi.g_stages[0].g_pair.selected [55]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .O(\g_multi.g_stages[1].g_pair.selected [55]));
  LUT4 #(
    .INIT(16'hCCCA)) 
    \result[55]_i_3 
       (.I0(data_q[59]),
        .I1(\g_shift.g_right.g_dynamic.fill_q ),
        .I2(\g_shift.amount_q [0]),
        .I3(\g_shift.amount_q [1]),
        .O(\g_multi.g_stages[0].g_pair.selected [59]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[55]_i_4 
       (.I0(data_q[56]),
        .I1(data_q[55]),
        .I2(data_q[58]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[57]),
        .O(\g_multi.g_stages[0].g_pair.selected [55]));
  LUT6 #(
    .INIT(64'h0000FFFE00000002)) 
    \result[56]_i_1 
       (.I0(\g_multi.g_stages[0].g_pair.selected [56]),
        .I1(\g_shift.amount_q [2]),
        .I2(\g_shift.amount_q [3]),
        .I3(\g_shift.amount_q [4]),
        .I4(\g_shift.amount_q [5]),
        .I5(\g_shift.g_right.g_dynamic.fill_q ),
        .O(\result[56]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[56]_i_2 
       (.I0(data_q[57]),
        .I1(data_q[56]),
        .I2(data_q[59]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[58]),
        .O(\g_multi.g_stages[0].g_pair.selected [56]));
  LUT6 #(
    .INIT(64'h0000FFFE00000002)) 
    \result[57]_i_1 
       (.I0(\g_multi.g_stages[0].g_pair.selected [57]),
        .I1(\g_shift.amount_q [2]),
        .I2(\g_shift.amount_q [3]),
        .I3(\g_shift.amount_q [4]),
        .I4(\g_shift.amount_q [5]),
        .I5(\g_shift.g_right.g_dynamic.fill_q ),
        .O(\result[57]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[57]_i_2 
       (.I0(data_q[58]),
        .I1(data_q[57]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[59]),
        .O(\g_multi.g_stages[0].g_pair.selected [57]));
  LUT6 #(
    .INIT(64'h0000FFFE00000002)) 
    \result[58]_i_1 
       (.I0(\g_multi.g_stages[0].g_pair.selected [58]),
        .I1(\g_shift.amount_q [2]),
        .I2(\g_shift.amount_q [3]),
        .I3(\g_shift.amount_q [4]),
        .I4(\g_shift.amount_q [5]),
        .I5(\g_shift.g_right.g_dynamic.fill_q ),
        .O(\result[58]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hF0F0AACC)) 
    \result[58]_i_2 
       (.I0(data_q[59]),
        .I1(data_q[58]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .O(\g_multi.g_stages[0].g_pair.selected [58]));
  LUT2 #(
    .INIT(4'h8)) 
    \result[59]_i_1 
       (.I0(\g_shift.amount_q [5]),
        .I1(\g_shift.g_right.g_dynamic.fill_q ),
        .O(\result[59]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT4 #(
    .INIT(16'h0E02)) 
    \result[59]_i_2 
       (.I0(\g_multi.g_stages[1].g_pair.selected [59]),
        .I1(\g_shift.amount_q [4]),
        .I2(\g_shift.amount_q [5]),
        .I3(\g_shift.g_right.g_dynamic.fill_q ),
        .O(\result[59]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFF00FF00FF00FE10)) 
    \result[59]_i_3 
       (.I0(\g_shift.amount_q [1]),
        .I1(\g_shift.amount_q [0]),
        .I2(data_q[59]),
        .I3(\g_shift.g_right.g_dynamic.fill_q ),
        .I4(\g_shift.amount_q [2]),
        .I5(\g_shift.amount_q [3]),
        .O(\g_multi.g_stages[1].g_pair.selected [59]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[5]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [21]),
        .I1(\g_multi.g_stages[1].g_pair.selected [5]),
        .I2(\g_multi.g_stages[1].g_pair.selected [53]),
        .I3(\g_shift.amount_q [4]),
        .I4(\g_shift.amount_q [5]),
        .I5(\g_multi.g_stages[1].g_pair.selected [37]),
        .O(result_d[5]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[5]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [9]),
        .I1(\g_multi.g_stages[0].g_pair.selected [5]),
        .I2(\g_multi.g_stages[0].g_pair.selected [17]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [13]),
        .O(\g_multi.g_stages[1].g_pair.selected [5]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[5]_i_3 
       (.I0(data_q[6]),
        .I1(data_q[5]),
        .I2(data_q[8]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[7]),
        .O(\g_multi.g_stages[0].g_pair.selected [5]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[6]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [22]),
        .I1(\g_multi.g_stages[1].g_pair.selected [6]),
        .I2(\g_multi.g_stages[1].g_pair.selected [54]),
        .I3(\g_shift.amount_q [4]),
        .I4(\g_shift.amount_q [5]),
        .I5(\g_multi.g_stages[1].g_pair.selected [38]),
        .O(result_d[6]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[6]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [10]),
        .I1(\g_multi.g_stages[0].g_pair.selected [6]),
        .I2(\g_multi.g_stages[0].g_pair.selected [18]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [14]),
        .O(\g_multi.g_stages[1].g_pair.selected [6]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[6]_i_3 
       (.I0(data_q[7]),
        .I1(data_q[6]),
        .I2(data_q[9]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[8]),
        .O(\g_multi.g_stages[0].g_pair.selected [6]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[7]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [23]),
        .I1(\g_multi.g_stages[1].g_pair.selected [7]),
        .I2(\g_multi.g_stages[1].g_pair.selected [55]),
        .I3(\g_shift.amount_q [4]),
        .I4(\g_shift.amount_q [5]),
        .I5(\g_multi.g_stages[1].g_pair.selected [39]),
        .O(result_d[7]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[7]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [11]),
        .I1(\g_multi.g_stages[0].g_pair.selected [7]),
        .I2(\g_multi.g_stages[0].g_pair.selected [19]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [15]),
        .O(\g_multi.g_stages[1].g_pair.selected [7]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[7]_i_3 
       (.I0(data_q[8]),
        .I1(data_q[7]),
        .I2(data_q[10]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[9]),
        .O(\g_multi.g_stages[0].g_pair.selected [7]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[8]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [24]),
        .I1(\g_multi.g_stages[1].g_pair.selected [8]),
        .I2(\g_multi.g_stages[1].g_pair.selected [56]),
        .I3(\g_shift.amount_q [4]),
        .I4(\g_shift.amount_q [5]),
        .I5(\g_multi.g_stages[1].g_pair.selected [40]),
        .O(result_d[8]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[8]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [12]),
        .I1(\g_multi.g_stages[0].g_pair.selected [8]),
        .I2(\g_multi.g_stages[0].g_pair.selected [20]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [16]),
        .O(\g_multi.g_stages[1].g_pair.selected [8]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[8]_i_3 
       (.I0(data_q[9]),
        .I1(data_q[8]),
        .I2(data_q[11]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[10]),
        .O(\g_multi.g_stages[0].g_pair.selected [8]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[9]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [25]),
        .I1(\g_multi.g_stages[1].g_pair.selected [9]),
        .I2(\g_multi.g_stages[1].g_pair.selected [57]),
        .I3(\g_shift.amount_q [4]),
        .I4(\g_shift.amount_q [5]),
        .I5(\g_multi.g_stages[1].g_pair.selected [41]),
        .O(result_d[9]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[9]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [13]),
        .I1(\g_multi.g_stages[0].g_pair.selected [9]),
        .I2(\g_multi.g_stages[0].g_pair.selected [21]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [17]),
        .O(\g_multi.g_stages[1].g_pair.selected [9]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[9]_i_3 
       (.I0(data_q[10]),
        .I1(data_q[9]),
        .I2(data_q[12]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[11]),
        .O(\g_multi.g_stages[0].g_pair.selected [9]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[0] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[0]),
        .Q(result[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[10] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[10]),
        .Q(result[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[11] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[11]),
        .Q(result[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[12] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[12]),
        .Q(result[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[13] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[13]),
        .Q(result[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[14] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[14]),
        .Q(result[14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[15] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[15]),
        .Q(result[15]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[16] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[16]),
        .Q(result[16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[17] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[17]),
        .Q(result[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[18] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[18]),
        .Q(result[18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[19] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[19]),
        .Q(result[19]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[1] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[1]),
        .Q(result[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[20] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[20]),
        .Q(result[20]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[21] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[21]),
        .Q(result[21]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[22] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[22]),
        .Q(result[22]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[23] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[23]),
        .Q(result[23]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[24] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[24]),
        .Q(result[24]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[25] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[25]),
        .Q(result[25]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[26] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[26]),
        .Q(result[26]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[27] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[27]),
        .Q(result[27]),
        .R(1'b0));
  FDSE #(
    .INIT(1'b1)) 
    \result_reg[28] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[28]_i_1_n_0 ),
        .Q(result[28]),
        .S(\result[59]_i_1_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \result_reg[29] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[29]_i_1_n_0 ),
        .Q(result[29]),
        .S(\result[59]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[2] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[2]),
        .Q(result[2]),
        .R(1'b0));
  FDSE #(
    .INIT(1'b1)) 
    \result_reg[30] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[30]_i_1_n_0 ),
        .Q(result[30]),
        .S(\result[59]_i_1_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \result_reg[31] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[31]_i_1_n_0 ),
        .Q(result[31]),
        .S(\result[59]_i_1_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \result_reg[32] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[32]_i_1_n_0 ),
        .Q(result[32]),
        .S(\result[59]_i_1_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \result_reg[33] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[33]_i_1_n_0 ),
        .Q(result[33]),
        .S(\result[59]_i_1_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \result_reg[34] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[34]_i_1_n_0 ),
        .Q(result[34]),
        .S(\result[59]_i_1_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \result_reg[35] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[35]_i_1_n_0 ),
        .Q(result[35]),
        .S(\result[59]_i_1_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \result_reg[36] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[36]_i_1_n_0 ),
        .Q(result[36]),
        .S(\result[59]_i_1_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \result_reg[37] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[37]_i_1_n_0 ),
        .Q(result[37]),
        .S(\result[59]_i_1_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \result_reg[38] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[38]_i_1_n_0 ),
        .Q(result[38]),
        .S(\result[59]_i_1_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \result_reg[39] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[39]_i_1_n_0 ),
        .Q(result[39]),
        .S(\result[59]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[3] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[3]),
        .Q(result[3]),
        .R(1'b0));
  FDSE #(
    .INIT(1'b1)) 
    \result_reg[40] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[40]_i_1_n_0 ),
        .Q(result[40]),
        .S(\result[59]_i_1_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \result_reg[41] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[41]_i_1_n_0 ),
        .Q(result[41]),
        .S(\result[59]_i_1_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \result_reg[42] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[42]_i_1_n_0 ),
        .Q(result[42]),
        .S(\result[59]_i_1_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \result_reg[43] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[43]_i_1_n_0 ),
        .Q(result[43]),
        .S(\result[59]_i_1_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \result_reg[44] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[44]_i_1_n_0 ),
        .Q(result[44]),
        .S(\result[59]_i_1_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \result_reg[45] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[45]_i_1_n_0 ),
        .Q(result[45]),
        .S(\result[59]_i_1_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \result_reg[46] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[46]_i_1_n_0 ),
        .Q(result[46]),
        .S(\result[59]_i_1_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \result_reg[47] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[47]_i_1_n_0 ),
        .Q(result[47]),
        .S(\result[59]_i_1_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \result_reg[48] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[48]_i_1_n_0 ),
        .Q(result[48]),
        .S(\result[59]_i_1_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \result_reg[49] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[49]_i_1_n_0 ),
        .Q(result[49]),
        .S(\result[59]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[4] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[4]),
        .Q(result[4]),
        .R(1'b0));
  FDSE #(
    .INIT(1'b1)) 
    \result_reg[50] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[50]_i_1_n_0 ),
        .Q(result[50]),
        .S(\result[59]_i_1_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \result_reg[51] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[51]_i_1_n_0 ),
        .Q(result[51]),
        .S(\result[59]_i_1_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \result_reg[52] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[52]_i_1_n_0 ),
        .Q(result[52]),
        .S(\result[59]_i_1_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \result_reg[53] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[53]_i_1_n_0 ),
        .Q(result[53]),
        .S(\result[59]_i_1_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \result_reg[54] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[54]_i_1_n_0 ),
        .Q(result[54]),
        .S(\result[59]_i_1_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \result_reg[55] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[55]_i_1_n_0 ),
        .Q(result[55]),
        .S(\result[59]_i_1_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \result_reg[56] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[56]_i_1_n_0 ),
        .Q(result[56]),
        .S(\result[59]_i_1_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \result_reg[57] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[57]_i_1_n_0 ),
        .Q(result[57]),
        .S(\result[59]_i_1_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \result_reg[58] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[58]_i_1_n_0 ),
        .Q(result[58]),
        .S(\result[59]_i_1_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \result_reg[59] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[59]_i_2_n_0 ),
        .Q(result[59]),
        .S(\result[59]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[5] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[5]),
        .Q(result[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[6] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[6]),
        .Q(result[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[7] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[7]),
        .Q(result[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[8] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[8]),
        .Q(result[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[9] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[9]),
        .Q(result[9]),
        .R(1'b0));
endmodule

(* ARITH = "0" *) (* ECO_CHECKSUM = "b2b58195" *) (* FILL_KIND = "1" *) 
(* KIND = "1" *) (* MODE = "0" *) (* N = "60" *) 
(* RESULT_W = "60" *) (* SHIFT_W = "6" *) 
(* NotValidForBitStream *)
(* \DesignAttr:ENABLE_NOC_NETLIST_VIEW  *) 
(* \DesignAttr:ENABLE_AIE_NETLIST_VIEW  *) 
module primitive_v2_top
   (clk,
    data,
    amount,
    fill_val,
    result);
  input clk;
  input [59:0]data;
  input [5:0]amount;
  input fill_val;
  output [59:0]result;

  wire [5:0]amount;
  wire clk;
  wire clk_core;
  wire [59:0]data;
  wire fill_val;
  wire [59:0]result;

  primitive_v2_boundary u_boundary
       (.amount(amount),
        .clk_core(clk_core),
        .data(data),
        .fill_val(fill_val),
        .result(result));
  (* BOX_TYPE = "PRIMITIVE" *) 
  BUFG u_clock
       (.I(clk),
        .O(clk_core));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
