//-----------------------------------------------------------------------------
// File          : opt15_compare.sv
// Author(s)     : Codex, for Dan Huy
// Project       : Posit MAC IP
// Creation Date : 2026-10-19
// Description   : Identical cycle stimulus for frozen NF and OPT-15 variants.
// $Revision: 1.0 $ $Log: Read-only three-way protocol/value comparison. $
//-----------------------------------------------------------------------------
module opt15_compare #(
    parameter int NB = 32,
    parameter int ES = 3,
    parameter int FRAC_W = (NB-3-ES < 12) ? NB-3-ES : 12
)(
    input logic clk,
    input logic rst_n,
    input logic in_valid,
    input logic [NB-1:0] a,
    input logic [NB-1:0] b,
    input logic [NB-1:0] c,
    input logic acc_mode,
    input logic acc_clr,
    input logic cfg_mode,
    input logic [3:0] cfg_n,
    input logic [1:0] cfg_ops,
    input logic out_ready,
    output wire [2:0] ready,
    output wire [2:0] valid,
    output wire [NB-1:0] d_ref,
    output wire [NB-1:0] d_parser,
    output wire [NB-1:0] d_combined,
    output wire [4:0] flags_ref,
    output wire [4:0] flags_parser,
    output wire [4:0] flags_combined
);
    mac_nf_wrapper_reference #(.NB(NB), .ES(ES), .FRAC_W(FRAC_W)) u_reference (
        .clk(clk), .rst_n(rst_n), .in_valid(in_valid), .in_ready(ready[0]),
        .a(a), .b(b), .c(c), .acc_mode(acc_mode), .acc_clr(acc_clr),
        .cfg_mode(cfg_mode), .cfg_n(cfg_n), .cfg_ops(cfg_ops),
        .out_valid(valid[0]), .out_ready(out_ready), .d(d_ref), .flags(flags_ref)
    );
    mac_nf_wrapper_parser2 #(.NB(NB), .ES(ES), .FRAC_W(FRAC_W)) u_parser (
        .clk(clk), .rst_n(rst_n), .in_valid(in_valid), .in_ready(ready[1]),
        .a(a), .b(b), .c(c), .acc_mode(acc_mode), .acc_clr(acc_clr),
        .cfg_mode(cfg_mode), .cfg_n(cfg_n), .cfg_ops(cfg_ops),
        .out_valid(valid[1]), .out_ready(out_ready), .d(d_parser), .flags(flags_parser)
    );
    mac_nf_wrapper_combined #(.NB(NB), .ES(ES), .FRAC_W(FRAC_W)) u_combined (
        .clk(clk), .rst_n(rst_n), .in_valid(in_valid), .in_ready(ready[2]),
        .a(a), .b(b), .c(c), .acc_mode(acc_mode), .acc_clr(acc_clr),
        .cfg_mode(cfg_mode), .cfg_n(cfg_n), .cfg_ops(cfg_ops),
        .out_valid(valid[2]), .out_ready(out_ready), .d(d_combined), .flags(flags_combined)
    );

    logic parser_c_seen_q;
    logic combined_c_seen_q;
    always_ff @(posedge clk or negedge u_reference.meta_sync2) begin
        if (!u_reference.meta_sync2) begin
            parser_c_seen_q <= 1'b0;
            combined_c_seen_q <= 1'b0;
        end else begin
            if (in_valid && ready[0]) begin
                parser_c_seen_q <= 1'b0;
                combined_c_seen_q <= 1'b0;
            end
            if (u_parser.valid_c) begin
                parser_c_seen_q <= 1'b1;
            end
            if (u_combined.valid_c) begin
                combined_c_seen_q <= 1'b1;
            end
            if (u_parser.norm_valid_q && u_parser.add_ready) begin
                assert (parser_c_seen_q) else $fatal(1, "C context late in parser2");
            end
            if (u_combined.norm_valid_q && u_combined.add_ready) begin
                assert (combined_c_seen_q) else $fatal(1, "C context late in combined");
            end
            assert (!(u_combined.core_done && u_combined.add_valid))
                else $fatal(1, "Shared pack request collision");
            if (u_combined.core_done) begin
                assert (u_combined.product_pack_ready)
                    else $fatal(1, "Product pulse backpressured");
            end
            assert (!(u_reference.core_error || u_parser.core_error || u_combined.core_error))
                else $fatal(1, "Multiplier core invariant");
        end
    end
endmodule
// End of opt15_compare.sv
