#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
study="${F_SHARED_STUDY:-results/f_shared_add_20261020}"
[[ "$study" == results/* && "$study" != *..* ]] || exit 2
run="$study/verification"
[[ -f "$run/pilot.json" && ! -e "$run/fast.json" ]]
cp tb/f_shared_add_fast.cpp "$run/src/tb/"
cd "$run"
export TMPDIR="$PWD/tmp"
g++ -O3 -std=c++17 -Iobj -I/usr/share/verilator/include -I/usr/share/verilator/include/vltstd -Isrc/l1/include -Isrc/tb \
    src/tb/f_shared_add_fast.cpp obj/verilated.o obj/verilated_threads.o obj/verilated_dpi.o \
    obj/Vf_shared_add_compare__ALL.a -pthread -latomic -o fast_sim > fast_build.log 2>&1
sha256sum src/tb/f_shared_add_fast.cpp fast_sim > fast.sha256
./fast_sim 100000 fast.json | tee fast.log
