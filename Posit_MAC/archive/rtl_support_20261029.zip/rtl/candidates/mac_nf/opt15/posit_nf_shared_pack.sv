//-----------------------------------------------------------------------------
// File          : posit_nf_shared_pack.sv
// Author(s)     : Codex, for Dan Huy
// Project       : Posit MAC IP
// Creation Date : 2026-10-19
// Description   : Candidate RNE P1/P2 shared by NF product and final sum.
//                 Product output is magnitude; final output is signed Posit.
// $Revision: 1.0 $ $Log: OPT-15 isolated resource sharing experiment. $
//-----------------------------------------------------------------------------
`include "posit_mac.vh"

module posit_nf_shared_pack #(
    parameter int NB = 32,
    parameter int ES = 2,
    parameter int F_IN = 2 * (NB - 3 - ES) + 1,
    parameter int SF_W = $clog2(64'd4 * (longint'(NB) - 64'd2)
                                     * (64'd1 << ES) + 64'd4) + 1
)(
    input  logic clk,
    input  logic reset_n,
    input  logic in_valid,
    output wire in_ready,
    input  logic product_i,
    input  logic sign,
    input  logic is_zero,
    input  logic is_nar,
    input  logic signed [SF_W-1:0] sf,
    input  logic [F_IN-1:0] frac,
    input  logic sticky,
    input  logic [4:0] flags_in,
    output wire out_valid,
    input  logic out_ready,
    output logic product_o,
    output logic [NB-1:0] d,
    output logic [4:0] flags,
    output logic sign_o
);
    (* ASYNC_REG = "TRUE" *) logic meta_sync1;
    (* ASYNC_REG = "TRUE" *) logic meta_sync2;
    wire reset_b_sync_clk;
    wire [NB-2:0] mag_trunc_d;
    wire guard_bit_d;
    wire round_bit_d;
    wire sticky_bit_d;
    wire sign_d;
    wire [2:0] special_sel_d;
    wire [4:0] flags_d;
    wire [NB-1:0] encoded_d;
    wire [4:0] encoded_flags_d;
    wire finish_sign;
    wire p1_ready;
    wire p2_ready;
    logic p1_valid_q;
    logic p2_valid_q;
    logic p1_product_q;
    logic [NB-2:0] p1_mag_q;
    logic p1_guard_q;
    logic p1_round_q;
    logic p1_sticky_q;
    logic p1_sign_q;
    logic [2:0] p1_special_q;
    logic [4:0] p1_flags_q;

    always_ff @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            meta_sync1 <= 1'b0;
            meta_sync2 <= 1'b0;
        end else begin
            meta_sync1 <= `CK2Q 1'b1;
            meta_sync2 <= `CK2Q meta_sync1;
        end
    end

    assign reset_b_sync_clk = meta_sync2;
    assign p2_ready = !p2_valid_q || out_ready;
    assign p1_ready = !p1_valid_q || p2_ready;
    assign in_ready = reset_b_sync_clk && p1_ready;
    assign out_valid = reset_b_sync_clk && p2_valid_q;
    assign finish_sign = p1_sign_q && !p1_product_q;

    posit_pack_prepare #(
        .NB (NB),
        .ES (ES),
        .F_IN (F_IN),
        .SF_W (SF_W)
    ) u_prepare (
        .sign (sign),
        .is_zero (is_zero),
        .is_nar (is_nar),
        .sf (sf),
        .frac (frac),
        .sticky (sticky),
        .flags_in (flags_in),
        .mag_trunc (mag_trunc_d),
        .guard_bit (guard_bit_d),
        .round_bit (round_bit_d),
        .sticky_bit (sticky_bit_d),
        .sign_o (sign_d),
        .special_sel (special_sel_d),
        .flags_o (flags_d)
    );

    posit_pack_finish #(
        .NB (NB),
        .ROUND_MODE ("RNE")
    ) u_finish (
        .mag_trunc (p1_mag_q),
        .guard_bit (p1_guard_q),
        .round_bit (p1_round_q),
        .sticky_bit (p1_sticky_q),
        .sign (finish_sign),
        .special_sel (p1_special_q),
        .flags_in (p1_flags_q),
        .d (encoded_d),
        .flags (encoded_flags_d)
    );

    always_ff @(posedge clk or negedge reset_b_sync_clk) begin
        if (!reset_b_sync_clk) begin
            p1_valid_q <= 1'b0;
            p1_product_q <= 1'b0;
            p1_mag_q <= '0;
            p1_guard_q <= 1'b0;
            p1_round_q <= 1'b0;
            p1_sticky_q <= 1'b0;
            p1_sign_q <= 1'b0;
            p1_special_q <= '0;
            p1_flags_q <= '0;
        end else if (p1_ready) begin
            p1_valid_q <= `CK2Q in_valid;
            if (in_valid) begin
                p1_product_q <= `CK2Q product_i;
                p1_mag_q <= `CK2Q mag_trunc_d;
                p1_guard_q <= `CK2Q guard_bit_d;
                p1_round_q <= `CK2Q round_bit_d;
                p1_sticky_q <= `CK2Q sticky_bit_d;
                p1_sign_q <= `CK2Q sign_d;
                p1_special_q <= `CK2Q special_sel_d;
                p1_flags_q <= `CK2Q flags_d;
            end
        end
    end

    always_ff @(posedge clk or negedge reset_b_sync_clk) begin
        if (!reset_b_sync_clk) begin
            p2_valid_q <= 1'b0;
            product_o <= 1'b0;
            d <= '0;
            flags <= '0;
            sign_o <= 1'b0;
        end else if (p2_ready) begin
            p2_valid_q <= `CK2Q p1_valid_q;
            if (p1_valid_q) begin
                product_o <= `CK2Q p1_product_q;
                d <= `CK2Q encoded_d;
                flags <= `CK2Q encoded_flags_d;
                sign_o <= `CK2Q p1_sign_q;
            end
        end
    end
endmodule
// End of posit_nf_shared_pack.sv
