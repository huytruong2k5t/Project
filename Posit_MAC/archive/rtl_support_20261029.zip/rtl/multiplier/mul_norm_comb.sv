//-----------------------------------------------------------------------------
// File          : mul_norm_comb.sv
// Author(s)     : Dan Huy
// Project       : Posit MAC IP
// Creation Date : 2026-10-09
// Description   : Normalize on the L1 grid, remove hidden, adapt to F_IN.
//                 No rounding. input_cut is NOT numerical RNE sticky.
// $Source: $ $Revision: 1.0 $ $Log: Initial week9 implementation. $
//-----------------------------------------------------------------------------
module mul_norm_comb (
    input logic cfg_mode,
    input logic [53:0] acc,
    input logic sticky_acc,
    input logic signed [10:0] sf,
    output logic signed [10:0] sf_norm,
    output logic [52:0] frac_norm,
    output logic sticky_norm
);
    // Fixed posit32/ES3 elaboration; no public parameters.
    
    
    typedef logic signed [10:0] sf_t;
    always_comb begin
        // FLOOR uses Q12 after dropping the two low accumulator grid bits.
        // Unlike prepack normalization, a carry here discards one bit to sticky.
        if (cfg_mode) begin
            sf_norm = sf + sf_t'(acc[15]);
            frac_norm = acc[15] ? {acc[14:3], 41'b0}
                                : {acc[13:2], 41'b0};
            sticky_norm = sticky_acc || (acc[15] && acc[2]);
        end else begin
            sf_norm = sf + sf_t'(acc[53]);
            frac_norm = acc[53] ? {acc[52:1], 1'b0}
                                : {acc[51:0], 1'b0};
            sticky_norm = sticky_acc || (acc[53] && acc[0]);
        end
    end
endmodule
// End of mul_norm_comb.sv
