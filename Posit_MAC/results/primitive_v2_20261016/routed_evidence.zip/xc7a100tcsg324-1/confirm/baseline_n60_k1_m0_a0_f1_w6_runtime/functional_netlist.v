// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2026.1 (win64) Build 6511674 Tue Jun 16 11:02:23 MDT 2026
// Date        : Fri Oct 16 16:24:21 2026
// Host        : MSI running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim {C:/HCMUT/HK261/Do an
//               2/Posit_MAC/results/primitive_v2_20261016/xc7a100tcsg324-1/confirm/baseline_n60_k1_m0_a0_f1_w6_runtime/functional_netlist.v}
// Design      : primitive_v2_top
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a100tcsg324-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module primitive_v2_boundary
   (result,
    amount,
    CLK,
    data,
    fill_val);
  output [59:0]result;
  input [5:0]amount;
  input CLK;
  input [59:0]data;
  input fill_val;

  wire CLK;
  wire [5:0]amount;
  wire [59:0]data;
  wire [59:0]data_q;
  wire fill_val;
  wire [5:0]\g_shift.amount_q ;
  wire \g_shift.g_right.g_dynamic.fill_q ;
  wire [59:0]result;
  wire \result[0]_i_2_n_0 ;
  wire \result[0]_i_3_n_0 ;
  wire \result[10]_i_2_n_0 ;
  wire \result[10]_i_3_n_0 ;
  wire \result[10]_i_4_n_0 ;
  wire \result[11]_i_2_n_0 ;
  wire \result[11]_i_3_n_0 ;
  wire \result[12]_i_2_n_0 ;
  wire \result[12]_i_3_n_0 ;
  wire \result[13]_i_2_n_0 ;
  wire \result[13]_i_3_n_0 ;
  wire \result[14]_i_2_n_0 ;
  wire \result[14]_i_3_n_0 ;
  wire \result[15]_i_2_n_0 ;
  wire \result[15]_i_3_n_0 ;
  wire \result[16]_i_2_n_0 ;
  wire \result[16]_i_3_n_0 ;
  wire \result[17]_i_2_n_0 ;
  wire \result[17]_i_3_n_0 ;
  wire \result[18]_i_2_n_0 ;
  wire \result[18]_i_3_n_0 ;
  wire \result[19]_i_2_n_0 ;
  wire \result[19]_i_3_n_0 ;
  wire \result[1]_i_2_n_0 ;
  wire \result[1]_i_3_n_0 ;
  wire \result[20]_i_2_n_0 ;
  wire \result[20]_i_3_n_0 ;
  wire \result[21]_i_2_n_0 ;
  wire \result[21]_i_3_n_0 ;
  wire \result[22]_i_2_n_0 ;
  wire \result[22]_i_3_n_0 ;
  wire \result[23]_i_2_n_0 ;
  wire \result[23]_i_3_n_0 ;
  wire \result[23]_i_4_n_0 ;
  wire \result[24]_i_2_n_0 ;
  wire \result[24]_i_3_n_0 ;
  wire \result[24]_i_4_n_0 ;
  wire \result[25]_i_2_n_0 ;
  wire \result[25]_i_3_n_0 ;
  wire \result[25]_i_4_n_0 ;
  wire \result[26]_i_2_n_0 ;
  wire \result[26]_i_3_n_0 ;
  wire \result[26]_i_4_n_0 ;
  wire \result[27]_i_2_n_0 ;
  wire \result[27]_i_3_n_0 ;
  wire \result[28]_i_2_n_0 ;
  wire \result[28]_i_3_n_0 ;
  wire \result[29]_i_2_n_0 ;
  wire \result[29]_i_3_n_0 ;
  wire \result[2]_i_2_n_0 ;
  wire \result[2]_i_3_n_0 ;
  wire \result[30]_i_2_n_0 ;
  wire \result[30]_i_3_n_0 ;
  wire \result[31]_i_2_n_0 ;
  wire \result[31]_i_3_n_0 ;
  wire \result[32]_i_2_n_0 ;
  wire \result[32]_i_3_n_0 ;
  wire \result[33]_i_2_n_0 ;
  wire \result[33]_i_3_n_0 ;
  wire \result[34]_i_2_n_0 ;
  wire \result[34]_i_3_n_0 ;
  wire \result[35]_i_2_n_0 ;
  wire \result[35]_i_3_n_0 ;
  wire \result[36]_i_2_n_0 ;
  wire \result[36]_i_3_n_0 ;
  wire \result[36]_i_4_n_0 ;
  wire \result[37]_i_2_n_0 ;
  wire \result[37]_i_3_n_0 ;
  wire \result[37]_i_4_n_0 ;
  wire \result[38]_i_2_n_0 ;
  wire \result[38]_i_3_n_0 ;
  wire \result[38]_i_4_n_0 ;
  wire \result[39]_i_2_n_0 ;
  wire \result[39]_i_3_n_0 ;
  wire \result[3]_i_2_n_0 ;
  wire \result[3]_i_3_n_0 ;
  wire \result[40]_i_2_n_0 ;
  wire \result[40]_i_3_n_0 ;
  wire \result[40]_i_4_n_0 ;
  wire \result[41]_i_2_n_0 ;
  wire \result[41]_i_3_n_0 ;
  wire \result[41]_i_4_n_0 ;
  wire \result[42]_i_2_n_0 ;
  wire \result[42]_i_3_n_0 ;
  wire \result[43]_i_2_n_0 ;
  wire \result[43]_i_3_n_0 ;
  wire \result[44]_i_2_n_0 ;
  wire \result[44]_i_3_n_0 ;
  wire \result[45]_i_2_n_0 ;
  wire \result[45]_i_3_n_0 ;
  wire \result[46]_i_2_n_0 ;
  wire \result[46]_i_3_n_0 ;
  wire \result[47]_i_2_n_0 ;
  wire \result[47]_i_3_n_0 ;
  wire \result[47]_i_4_n_0 ;
  wire \result[48]_i_2_n_0 ;
  wire \result[48]_i_3_n_0 ;
  wire \result[49]_i_2_n_0 ;
  wire \result[49]_i_3_n_0 ;
  wire \result[4]_i_2_n_0 ;
  wire \result[4]_i_3_n_0 ;
  wire \result[50]_i_2_n_0 ;
  wire \result[50]_i_3_n_0 ;
  wire \result[51]_i_2_n_0 ;
  wire \result[51]_i_3_n_0 ;
  wire \result[51]_i_4_n_0 ;
  wire \result[52]_i_2_n_0 ;
  wire \result[52]_i_3_n_0 ;
  wire \result[53]_i_2_n_0 ;
  wire \result[53]_i_3_n_0 ;
  wire \result[54]_i_2_n_0 ;
  wire \result[54]_i_3_n_0 ;
  wire \result[54]_i_4_n_0 ;
  wire \result[55]_i_2_n_0 ;
  wire \result[55]_i_3_n_0 ;
  wire \result[56]_i_2_n_0 ;
  wire \result[57]_i_2_n_0 ;
  wire \result[58]_i_2_n_0 ;
  wire \result[59]_i_2_n_0 ;
  wire \result[5]_i_2_n_0 ;
  wire \result[5]_i_3_n_0 ;
  wire \result[6]_i_2_n_0 ;
  wire \result[6]_i_3_n_0 ;
  wire \result[7]_i_2_n_0 ;
  wire \result[7]_i_3_n_0 ;
  wire \result[7]_i_4_n_0 ;
  wire \result[8]_i_2_n_0 ;
  wire \result[8]_i_3_n_0 ;
  wire \result[9]_i_2_n_0 ;
  wire \result[9]_i_3_n_0 ;
  wire [59:0]result_d;

  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[0] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[0]),
        .Q(data_q[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[10] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[10]),
        .Q(data_q[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[11] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[11]),
        .Q(data_q[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[12] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[12]),
        .Q(data_q[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[13] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[13]),
        .Q(data_q[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[14] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[14]),
        .Q(data_q[14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[15] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[15]),
        .Q(data_q[15]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[16] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[16]),
        .Q(data_q[16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[17] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[17]),
        .Q(data_q[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[18] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[18]),
        .Q(data_q[18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[19] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[19]),
        .Q(data_q[19]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[1] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[1]),
        .Q(data_q[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[20] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[20]),
        .Q(data_q[20]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[21] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[21]),
        .Q(data_q[21]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[22] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[22]),
        .Q(data_q[22]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[23] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[23]),
        .Q(data_q[23]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[24] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[24]),
        .Q(data_q[24]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[25] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[25]),
        .Q(data_q[25]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[26] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[26]),
        .Q(data_q[26]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[27] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[27]),
        .Q(data_q[27]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[28] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[28]),
        .Q(data_q[28]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[29] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[29]),
        .Q(data_q[29]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[2] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[2]),
        .Q(data_q[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[30] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[30]),
        .Q(data_q[30]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[31] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[31]),
        .Q(data_q[31]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[32] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[32]),
        .Q(data_q[32]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[33] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[33]),
        .Q(data_q[33]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[34] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[34]),
        .Q(data_q[34]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[35] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[35]),
        .Q(data_q[35]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[36] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[36]),
        .Q(data_q[36]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[37] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[37]),
        .Q(data_q[37]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[38] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[38]),
        .Q(data_q[38]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[39] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[39]),
        .Q(data_q[39]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[3] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[3]),
        .Q(data_q[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[40] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[40]),
        .Q(data_q[40]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[41] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[41]),
        .Q(data_q[41]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[42] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[42]),
        .Q(data_q[42]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[43] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[43]),
        .Q(data_q[43]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[44] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[44]),
        .Q(data_q[44]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[45] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[45]),
        .Q(data_q[45]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[46] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[46]),
        .Q(data_q[46]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[47] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[47]),
        .Q(data_q[47]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[48] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[48]),
        .Q(data_q[48]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[49] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[49]),
        .Q(data_q[49]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[4] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[4]),
        .Q(data_q[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[50] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[50]),
        .Q(data_q[50]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[51] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[51]),
        .Q(data_q[51]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[52] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[52]),
        .Q(data_q[52]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[53] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[53]),
        .Q(data_q[53]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[54] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[54]),
        .Q(data_q[54]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[55] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[55]),
        .Q(data_q[55]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[56] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[56]),
        .Q(data_q[56]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[57] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[57]),
        .Q(data_q[57]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[58] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[58]),
        .Q(data_q[58]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[59] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[59]),
        .Q(data_q[59]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[5] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[5]),
        .Q(data_q[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[6] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[6]),
        .Q(data_q[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[7] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[7]),
        .Q(data_q[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[8] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[8]),
        .Q(data_q[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[9] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[9]),
        .Q(data_q[9]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \g_shift.amount_q_reg[0] 
       (.C(CLK),
        .CE(1'b1),
        .D(amount[0]),
        .Q(\g_shift.amount_q [0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \g_shift.amount_q_reg[1] 
       (.C(CLK),
        .CE(1'b1),
        .D(amount[1]),
        .Q(\g_shift.amount_q [1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \g_shift.amount_q_reg[2] 
       (.C(CLK),
        .CE(1'b1),
        .D(amount[2]),
        .Q(\g_shift.amount_q [2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \g_shift.amount_q_reg[3] 
       (.C(CLK),
        .CE(1'b1),
        .D(amount[3]),
        .Q(\g_shift.amount_q [3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \g_shift.amount_q_reg[4] 
       (.C(CLK),
        .CE(1'b1),
        .D(amount[4]),
        .Q(\g_shift.amount_q [4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \g_shift.amount_q_reg[5] 
       (.C(CLK),
        .CE(1'b1),
        .D(amount[5]),
        .Q(\g_shift.amount_q [5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \g_shift.g_right.g_dynamic.fill_q_reg 
       (.C(CLK),
        .CE(1'b1),
        .D(fill_val),
        .Q(\g_shift.g_right.g_dynamic.fill_q ),
        .R(1'b0));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[0]_i_1 
       (.I0(\result[48]_i_2_n_0 ),
        .I1(\result[32]_i_2_n_0 ),
        .I2(\g_shift.amount_q [5]),
        .I3(\result[16]_i_2_n_0 ),
        .I4(\g_shift.amount_q [4]),
        .I5(\result[0]_i_2_n_0 ),
        .O(result_d[0]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[0]_i_2 
       (.I0(\result[12]_i_3_n_0 ),
        .I1(\result[8]_i_3_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[4]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[0]_i_3_n_0 ),
        .O(\result[0]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[0]_i_3 
       (.I0(data_q[3]),
        .I1(data_q[2]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[1]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[0]),
        .O(\result[0]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[10]_i_1 
       (.I0(\result[10]_i_2_n_0 ),
        .I1(\result[42]_i_2_n_0 ),
        .I2(\g_shift.amount_q [5]),
        .I3(\result[26]_i_3_n_0 ),
        .I4(\g_shift.amount_q [4]),
        .I5(\result[10]_i_3_n_0 ),
        .O(result_d[10]));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[10]_i_2 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(\g_shift.amount_q [3]),
        .I2(\result[58]_i_2_n_0 ),
        .O(\result[10]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[10]_i_3 
       (.I0(\result[22]_i_3_n_0 ),
        .I1(\result[18]_i_3_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[14]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[10]_i_4_n_0 ),
        .O(\result[10]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[10]_i_4 
       (.I0(data_q[13]),
        .I1(data_q[12]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[11]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[10]),
        .O(\result[10]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[11]_i_1 
       (.I0(\result[59]_i_2_n_0 ),
        .I1(\result[43]_i_2_n_0 ),
        .I2(\g_shift.amount_q [5]),
        .I3(\result[27]_i_2_n_0 ),
        .I4(\g_shift.amount_q [4]),
        .I5(\result[11]_i_2_n_0 ),
        .O(result_d[11]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[11]_i_2 
       (.I0(\result[23]_i_4_n_0 ),
        .I1(\result[19]_i_3_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[15]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[11]_i_3_n_0 ),
        .O(\result[11]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[11]_i_3 
       (.I0(data_q[14]),
        .I1(data_q[13]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[12]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[11]),
        .O(\result[11]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[12]_i_1 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(\result[44]_i_2_n_0 ),
        .I2(\g_shift.amount_q [5]),
        .I3(\result[28]_i_2_n_0 ),
        .I4(\g_shift.amount_q [4]),
        .I5(\result[12]_i_2_n_0 ),
        .O(result_d[12]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[12]_i_2 
       (.I0(\result[24]_i_4_n_0 ),
        .I1(\result[20]_i_3_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[16]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[12]_i_3_n_0 ),
        .O(\result[12]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[12]_i_3 
       (.I0(data_q[15]),
        .I1(data_q[14]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[13]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[12]),
        .O(\result[12]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[13]_i_1 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(\result[45]_i_2_n_0 ),
        .I2(\g_shift.amount_q [5]),
        .I3(\result[29]_i_2_n_0 ),
        .I4(\g_shift.amount_q [4]),
        .I5(\result[13]_i_2_n_0 ),
        .O(result_d[13]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[13]_i_2 
       (.I0(\result[25]_i_4_n_0 ),
        .I1(\result[21]_i_3_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[17]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[13]_i_3_n_0 ),
        .O(\result[13]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[13]_i_3 
       (.I0(data_q[16]),
        .I1(data_q[15]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[14]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[13]),
        .O(\result[13]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[14]_i_1 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(\result[46]_i_2_n_0 ),
        .I2(\g_shift.amount_q [5]),
        .I3(\result[30]_i_2_n_0 ),
        .I4(\g_shift.amount_q [4]),
        .I5(\result[14]_i_2_n_0 ),
        .O(result_d[14]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[14]_i_2 
       (.I0(\result[26]_i_4_n_0 ),
        .I1(\result[22]_i_3_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[18]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[14]_i_3_n_0 ),
        .O(\result[14]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[14]_i_3 
       (.I0(data_q[17]),
        .I1(data_q[16]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[15]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[14]),
        .O(\result[14]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[15]_i_1 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(\result[47]_i_2_n_0 ),
        .I2(\g_shift.amount_q [5]),
        .I3(\result[31]_i_2_n_0 ),
        .I4(\g_shift.amount_q [4]),
        .I5(\result[15]_i_2_n_0 ),
        .O(result_d[15]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[15]_i_2 
       (.I0(\result[27]_i_3_n_0 ),
        .I1(\result[23]_i_4_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[19]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[15]_i_3_n_0 ),
        .O(\result[15]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[15]_i_3 
       (.I0(data_q[18]),
        .I1(data_q[17]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[16]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[15]),
        .O(\result[15]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[16]_i_1 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(\result[48]_i_2_n_0 ),
        .I2(\g_shift.amount_q [5]),
        .I3(\result[32]_i_2_n_0 ),
        .I4(\g_shift.amount_q [4]),
        .I5(\result[16]_i_2_n_0 ),
        .O(result_d[16]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[16]_i_2 
       (.I0(\result[28]_i_3_n_0 ),
        .I1(\result[24]_i_4_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[20]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[16]_i_3_n_0 ),
        .O(\result[16]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[16]_i_3 
       (.I0(data_q[19]),
        .I1(data_q[18]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[17]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[16]),
        .O(\result[16]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[17]_i_1 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(\result[49]_i_2_n_0 ),
        .I2(\g_shift.amount_q [5]),
        .I3(\result[33]_i_2_n_0 ),
        .I4(\g_shift.amount_q [4]),
        .I5(\result[17]_i_2_n_0 ),
        .O(result_d[17]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[17]_i_2 
       (.I0(\result[29]_i_3_n_0 ),
        .I1(\result[25]_i_4_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[21]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[17]_i_3_n_0 ),
        .O(\result[17]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[17]_i_3 
       (.I0(data_q[20]),
        .I1(data_q[19]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[18]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[17]),
        .O(\result[17]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[18]_i_1 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(\result[50]_i_2_n_0 ),
        .I2(\g_shift.amount_q [5]),
        .I3(\result[34]_i_2_n_0 ),
        .I4(\g_shift.amount_q [4]),
        .I5(\result[18]_i_2_n_0 ),
        .O(result_d[18]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[18]_i_2 
       (.I0(\result[30]_i_3_n_0 ),
        .I1(\result[26]_i_4_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[22]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[18]_i_3_n_0 ),
        .O(\result[18]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[18]_i_3 
       (.I0(data_q[21]),
        .I1(data_q[20]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[19]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[18]),
        .O(\result[18]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[19]_i_1 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(\result[51]_i_2_n_0 ),
        .I2(\g_shift.amount_q [5]),
        .I3(\result[35]_i_2_n_0 ),
        .I4(\g_shift.amount_q [4]),
        .I5(\result[19]_i_2_n_0 ),
        .O(result_d[19]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[19]_i_2 
       (.I0(\result[31]_i_3_n_0 ),
        .I1(\result[27]_i_3_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[23]_i_4_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[19]_i_3_n_0 ),
        .O(\result[19]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[19]_i_3 
       (.I0(data_q[22]),
        .I1(data_q[21]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[20]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[19]),
        .O(\result[19]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[1]_i_1 
       (.I0(\result[49]_i_2_n_0 ),
        .I1(\result[33]_i_2_n_0 ),
        .I2(\g_shift.amount_q [5]),
        .I3(\result[17]_i_2_n_0 ),
        .I4(\g_shift.amount_q [4]),
        .I5(\result[1]_i_2_n_0 ),
        .O(result_d[1]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[1]_i_2 
       (.I0(\result[13]_i_3_n_0 ),
        .I1(\result[9]_i_3_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[5]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[1]_i_3_n_0 ),
        .O(\result[1]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[1]_i_3 
       (.I0(data_q[4]),
        .I1(data_q[3]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[2]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[1]),
        .O(\result[1]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[20]_i_1 
       (.I0(\result[52]_i_2_n_0 ),
        .I1(\g_shift.amount_q [5]),
        .I2(\result[36]_i_3_n_0 ),
        .I3(\g_shift.amount_q [4]),
        .I4(\result[20]_i_2_n_0 ),
        .O(result_d[20]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[20]_i_2 
       (.I0(\result[32]_i_3_n_0 ),
        .I1(\result[28]_i_3_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[24]_i_4_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[20]_i_3_n_0 ),
        .O(\result[20]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[20]_i_3 
       (.I0(data_q[23]),
        .I1(data_q[22]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[21]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[20]),
        .O(\result[20]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[21]_i_1 
       (.I0(\result[53]_i_2_n_0 ),
        .I1(\g_shift.amount_q [5]),
        .I2(\result[37]_i_3_n_0 ),
        .I3(\g_shift.amount_q [4]),
        .I4(\result[21]_i_2_n_0 ),
        .O(result_d[21]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[21]_i_2 
       (.I0(\result[33]_i_3_n_0 ),
        .I1(\result[29]_i_3_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[25]_i_4_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[21]_i_3_n_0 ),
        .O(\result[21]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[21]_i_3 
       (.I0(data_q[24]),
        .I1(data_q[23]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[22]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[21]),
        .O(\result[21]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[22]_i_1 
       (.I0(\result[54]_i_2_n_0 ),
        .I1(\g_shift.amount_q [5]),
        .I2(\result[38]_i_3_n_0 ),
        .I3(\g_shift.amount_q [4]),
        .I4(\result[22]_i_2_n_0 ),
        .O(result_d[22]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[22]_i_2 
       (.I0(\result[34]_i_3_n_0 ),
        .I1(\result[30]_i_3_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[26]_i_4_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[22]_i_3_n_0 ),
        .O(\result[22]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[22]_i_3 
       (.I0(data_q[25]),
        .I1(data_q[24]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[23]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[22]),
        .O(\result[22]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[23]_i_1 
       (.I0(\result[23]_i_2_n_0 ),
        .I1(\g_shift.amount_q [5]),
        .I2(\result[39]_i_2_n_0 ),
        .I3(\g_shift.amount_q [4]),
        .I4(\result[23]_i_3_n_0 ),
        .O(result_d[23]));
  LUT6 #(
    .INIT(64'hCDC8CDCDCDC8C8C8)) 
    \result[23]_i_2 
       (.I0(\g_shift.amount_q [4]),
        .I1(\g_shift.g_right.g_dynamic.fill_q ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[47]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[55]_i_3_n_0 ),
        .O(\result[23]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[23]_i_3 
       (.I0(\result[35]_i_3_n_0 ),
        .I1(\result[31]_i_3_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[27]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[23]_i_4_n_0 ),
        .O(\result[23]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[23]_i_4 
       (.I0(data_q[26]),
        .I1(data_q[25]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[24]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[23]),
        .O(\result[23]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[24]_i_1 
       (.I0(\result[24]_i_2_n_0 ),
        .I1(\g_shift.amount_q [5]),
        .I2(\result[40]_i_3_n_0 ),
        .I3(\g_shift.amount_q [4]),
        .I4(\result[24]_i_3_n_0 ),
        .O(result_d[24]));
  LUT5 #(
    .INIT(32'hF0F1F0E0)) 
    \result[24]_i_2 
       (.I0(\g_shift.amount_q [4]),
        .I1(\g_shift.amount_q [3]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [2]),
        .I4(\result[56]_i_2_n_0 ),
        .O(\result[24]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[24]_i_3 
       (.I0(\result[36]_i_4_n_0 ),
        .I1(\result[32]_i_3_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[28]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[24]_i_4_n_0 ),
        .O(\result[24]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[24]_i_4 
       (.I0(data_q[27]),
        .I1(data_q[26]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[25]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[24]),
        .O(\result[24]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[25]_i_1 
       (.I0(\result[25]_i_2_n_0 ),
        .I1(\g_shift.amount_q [5]),
        .I2(\result[41]_i_3_n_0 ),
        .I3(\g_shift.amount_q [4]),
        .I4(\result[25]_i_3_n_0 ),
        .O(result_d[25]));
  LUT5 #(
    .INIT(32'hF0F1F0E0)) 
    \result[25]_i_2 
       (.I0(\g_shift.amount_q [4]),
        .I1(\g_shift.amount_q [3]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [2]),
        .I4(\result[57]_i_2_n_0 ),
        .O(\result[25]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[25]_i_3 
       (.I0(\result[37]_i_4_n_0 ),
        .I1(\result[33]_i_3_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[29]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[25]_i_4_n_0 ),
        .O(\result[25]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[25]_i_4 
       (.I0(data_q[28]),
        .I1(data_q[27]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[26]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[25]),
        .O(\result[25]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[26]_i_1 
       (.I0(\result[26]_i_2_n_0 ),
        .I1(\g_shift.amount_q [5]),
        .I2(\result[42]_i_2_n_0 ),
        .I3(\g_shift.amount_q [4]),
        .I4(\result[26]_i_3_n_0 ),
        .O(result_d[26]));
  LUT4 #(
    .INIT(16'hCDC8)) 
    \result[26]_i_2 
       (.I0(\g_shift.amount_q [4]),
        .I1(\g_shift.g_right.g_dynamic.fill_q ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[58]_i_2_n_0 ),
        .O(\result[26]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[26]_i_3 
       (.I0(\result[38]_i_4_n_0 ),
        .I1(\result[34]_i_3_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[30]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[26]_i_4_n_0 ),
        .O(\result[26]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[26]_i_4 
       (.I0(data_q[29]),
        .I1(data_q[28]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[27]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[26]),
        .O(\result[26]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[27]_i_1 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(\result[59]_i_2_n_0 ),
        .I2(\g_shift.amount_q [5]),
        .I3(\result[43]_i_2_n_0 ),
        .I4(\g_shift.amount_q [4]),
        .I5(\result[27]_i_2_n_0 ),
        .O(result_d[27]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[27]_i_2 
       (.I0(\result[39]_i_3_n_0 ),
        .I1(\result[35]_i_3_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[31]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[27]_i_3_n_0 ),
        .O(\result[27]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[27]_i_3 
       (.I0(data_q[30]),
        .I1(data_q[29]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[28]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[27]),
        .O(\result[27]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[28]_i_1 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(\g_shift.amount_q [5]),
        .I2(\result[44]_i_2_n_0 ),
        .I3(\g_shift.amount_q [4]),
        .I4(\result[28]_i_2_n_0 ),
        .O(result_d[28]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[28]_i_2 
       (.I0(\result[40]_i_4_n_0 ),
        .I1(\result[36]_i_4_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[32]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[28]_i_3_n_0 ),
        .O(\result[28]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[28]_i_3 
       (.I0(data_q[31]),
        .I1(data_q[30]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[29]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[28]),
        .O(\result[28]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[29]_i_1 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(\g_shift.amount_q [5]),
        .I2(\result[45]_i_2_n_0 ),
        .I3(\g_shift.amount_q [4]),
        .I4(\result[29]_i_2_n_0 ),
        .O(result_d[29]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[29]_i_2 
       (.I0(\result[41]_i_4_n_0 ),
        .I1(\result[37]_i_4_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[33]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[29]_i_3_n_0 ),
        .O(\result[29]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[29]_i_3 
       (.I0(data_q[32]),
        .I1(data_q[31]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[30]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[29]),
        .O(\result[29]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[2]_i_1 
       (.I0(\result[50]_i_2_n_0 ),
        .I1(\result[34]_i_2_n_0 ),
        .I2(\g_shift.amount_q [5]),
        .I3(\result[18]_i_2_n_0 ),
        .I4(\g_shift.amount_q [4]),
        .I5(\result[2]_i_2_n_0 ),
        .O(result_d[2]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[2]_i_2 
       (.I0(\result[14]_i_3_n_0 ),
        .I1(\result[10]_i_4_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[6]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[2]_i_3_n_0 ),
        .O(\result[2]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[2]_i_3 
       (.I0(data_q[5]),
        .I1(data_q[4]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[3]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[2]),
        .O(\result[2]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[30]_i_1 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(\g_shift.amount_q [5]),
        .I2(\result[46]_i_2_n_0 ),
        .I3(\g_shift.amount_q [4]),
        .I4(\result[30]_i_2_n_0 ),
        .O(result_d[30]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[30]_i_2 
       (.I0(\result[42]_i_3_n_0 ),
        .I1(\result[38]_i_4_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[34]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[30]_i_3_n_0 ),
        .O(\result[30]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[30]_i_3 
       (.I0(data_q[33]),
        .I1(data_q[32]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[31]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[30]),
        .O(\result[30]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[31]_i_1 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(\g_shift.amount_q [5]),
        .I2(\result[47]_i_2_n_0 ),
        .I3(\g_shift.amount_q [4]),
        .I4(\result[31]_i_2_n_0 ),
        .O(result_d[31]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[31]_i_2 
       (.I0(\result[43]_i_3_n_0 ),
        .I1(\result[39]_i_3_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[35]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[31]_i_3_n_0 ),
        .O(\result[31]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[31]_i_3 
       (.I0(data_q[34]),
        .I1(data_q[33]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[32]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[31]),
        .O(\result[31]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[32]_i_1 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(\g_shift.amount_q [5]),
        .I2(\result[48]_i_2_n_0 ),
        .I3(\g_shift.amount_q [4]),
        .I4(\result[32]_i_2_n_0 ),
        .O(result_d[32]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[32]_i_2 
       (.I0(\result[44]_i_3_n_0 ),
        .I1(\result[40]_i_4_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[36]_i_4_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[32]_i_3_n_0 ),
        .O(\result[32]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[32]_i_3 
       (.I0(data_q[35]),
        .I1(data_q[34]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[33]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[32]),
        .O(\result[32]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[33]_i_1 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(\g_shift.amount_q [5]),
        .I2(\result[49]_i_2_n_0 ),
        .I3(\g_shift.amount_q [4]),
        .I4(\result[33]_i_2_n_0 ),
        .O(result_d[33]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[33]_i_2 
       (.I0(\result[45]_i_3_n_0 ),
        .I1(\result[41]_i_4_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[37]_i_4_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[33]_i_3_n_0 ),
        .O(\result[33]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[33]_i_3 
       (.I0(data_q[36]),
        .I1(data_q[35]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[34]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[33]),
        .O(\result[33]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[34]_i_1 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(\g_shift.amount_q [5]),
        .I2(\result[50]_i_2_n_0 ),
        .I3(\g_shift.amount_q [4]),
        .I4(\result[34]_i_2_n_0 ),
        .O(result_d[34]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[34]_i_2 
       (.I0(\result[46]_i_3_n_0 ),
        .I1(\result[42]_i_3_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[38]_i_4_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[34]_i_3_n_0 ),
        .O(\result[34]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[34]_i_3 
       (.I0(data_q[37]),
        .I1(data_q[36]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[35]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[34]),
        .O(\result[34]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[35]_i_1 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(\g_shift.amount_q [5]),
        .I2(\result[51]_i_2_n_0 ),
        .I3(\g_shift.amount_q [4]),
        .I4(\result[35]_i_2_n_0 ),
        .O(result_d[35]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[35]_i_2 
       (.I0(\result[47]_i_4_n_0 ),
        .I1(\result[43]_i_3_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[39]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[35]_i_3_n_0 ),
        .O(\result[35]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[35]_i_3 
       (.I0(data_q[38]),
        .I1(data_q[37]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[36]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[35]),
        .O(\result[35]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[36]_i_1 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(\g_shift.amount_q [5]),
        .I2(\result[36]_i_2_n_0 ),
        .I3(\g_shift.amount_q [4]),
        .I4(\result[36]_i_3_n_0 ),
        .O(result_d[36]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[36]_i_2 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(\g_shift.amount_q [3]),
        .I2(\result[56]_i_2_n_0 ),
        .I3(\g_shift.amount_q [2]),
        .I4(\result[52]_i_3_n_0 ),
        .O(\result[36]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[36]_i_3 
       (.I0(\result[48]_i_3_n_0 ),
        .I1(\result[44]_i_3_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[40]_i_4_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[36]_i_4_n_0 ),
        .O(\result[36]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[36]_i_4 
       (.I0(data_q[39]),
        .I1(data_q[38]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[37]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[36]),
        .O(\result[36]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[37]_i_1 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(\g_shift.amount_q [5]),
        .I2(\result[37]_i_2_n_0 ),
        .I3(\g_shift.amount_q [4]),
        .I4(\result[37]_i_3_n_0 ),
        .O(result_d[37]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[37]_i_2 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(\g_shift.amount_q [3]),
        .I2(\result[57]_i_2_n_0 ),
        .I3(\g_shift.amount_q [2]),
        .I4(\result[53]_i_3_n_0 ),
        .O(\result[37]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[37]_i_3 
       (.I0(\result[49]_i_3_n_0 ),
        .I1(\result[45]_i_3_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[41]_i_4_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[37]_i_4_n_0 ),
        .O(\result[37]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[37]_i_4 
       (.I0(data_q[40]),
        .I1(data_q[39]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[38]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[37]),
        .O(\result[37]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[38]_i_1 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(\g_shift.amount_q [5]),
        .I2(\result[38]_i_2_n_0 ),
        .I3(\g_shift.amount_q [4]),
        .I4(\result[38]_i_3_n_0 ),
        .O(result_d[38]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[38]_i_2 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(\g_shift.amount_q [3]),
        .I2(\result[54]_i_3_n_0 ),
        .I3(\g_shift.amount_q [2]),
        .I4(\result[54]_i_4_n_0 ),
        .O(\result[38]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[38]_i_3 
       (.I0(\result[50]_i_3_n_0 ),
        .I1(\result[46]_i_3_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[42]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[38]_i_4_n_0 ),
        .O(\result[38]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[38]_i_4 
       (.I0(data_q[41]),
        .I1(data_q[40]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[39]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[38]),
        .O(\result[38]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hCDC8DDDDCDC88888)) 
    \result[39]_i_1 
       (.I0(\g_shift.amount_q [5]),
        .I1(\g_shift.g_right.g_dynamic.fill_q ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[55]_i_2_n_0 ),
        .I4(\g_shift.amount_q [4]),
        .I5(\result[39]_i_2_n_0 ),
        .O(result_d[39]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[39]_i_2 
       (.I0(\result[51]_i_4_n_0 ),
        .I1(\result[47]_i_4_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[43]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[39]_i_3_n_0 ),
        .O(\result[39]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[39]_i_3 
       (.I0(data_q[42]),
        .I1(data_q[41]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[40]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[39]),
        .O(\result[39]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[3]_i_1 
       (.I0(\result[51]_i_2_n_0 ),
        .I1(\result[35]_i_2_n_0 ),
        .I2(\g_shift.amount_q [5]),
        .I3(\result[19]_i_2_n_0 ),
        .I4(\g_shift.amount_q [4]),
        .I5(\result[3]_i_2_n_0 ),
        .O(result_d[3]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[3]_i_2 
       (.I0(\result[15]_i_3_n_0 ),
        .I1(\result[11]_i_3_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[7]_i_4_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[3]_i_3_n_0 ),
        .O(\result[3]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[3]_i_3 
       (.I0(data_q[6]),
        .I1(data_q[5]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[4]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[3]),
        .O(\result[3]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[40]_i_1 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(\g_shift.amount_q [5]),
        .I2(\result[40]_i_2_n_0 ),
        .I3(\g_shift.amount_q [4]),
        .I4(\result[40]_i_3_n_0 ),
        .O(result_d[40]));
  LUT4 #(
    .INIT(16'hCDC8)) 
    \result[40]_i_2 
       (.I0(\g_shift.amount_q [3]),
        .I1(\g_shift.g_right.g_dynamic.fill_q ),
        .I2(\g_shift.amount_q [2]),
        .I3(\result[56]_i_2_n_0 ),
        .O(\result[40]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[40]_i_3 
       (.I0(\result[52]_i_3_n_0 ),
        .I1(\result[48]_i_3_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[44]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[40]_i_4_n_0 ),
        .O(\result[40]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[40]_i_4 
       (.I0(data_q[43]),
        .I1(data_q[42]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[41]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[40]),
        .O(\result[40]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[41]_i_1 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(\g_shift.amount_q [5]),
        .I2(\result[41]_i_2_n_0 ),
        .I3(\g_shift.amount_q [4]),
        .I4(\result[41]_i_3_n_0 ),
        .O(result_d[41]));
  LUT4 #(
    .INIT(16'hCDC8)) 
    \result[41]_i_2 
       (.I0(\g_shift.amount_q [3]),
        .I1(\g_shift.g_right.g_dynamic.fill_q ),
        .I2(\g_shift.amount_q [2]),
        .I3(\result[57]_i_2_n_0 ),
        .O(\result[41]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[41]_i_3 
       (.I0(\result[53]_i_3_n_0 ),
        .I1(\result[49]_i_3_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[45]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[41]_i_4_n_0 ),
        .O(\result[41]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[41]_i_4 
       (.I0(data_q[44]),
        .I1(data_q[43]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[42]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[41]),
        .O(\result[41]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hCDC8DDDDCDC88888)) 
    \result[42]_i_1 
       (.I0(\g_shift.amount_q [5]),
        .I1(\g_shift.g_right.g_dynamic.fill_q ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[58]_i_2_n_0 ),
        .I4(\g_shift.amount_q [4]),
        .I5(\result[42]_i_2_n_0 ),
        .O(result_d[42]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[42]_i_2 
       (.I0(\result[54]_i_4_n_0 ),
        .I1(\result[50]_i_3_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[46]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[42]_i_3_n_0 ),
        .O(\result[42]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[42]_i_3 
       (.I0(data_q[45]),
        .I1(data_q[44]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[43]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[42]),
        .O(\result[42]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[43]_i_1 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(\g_shift.amount_q [5]),
        .I2(\result[59]_i_2_n_0 ),
        .I3(\g_shift.amount_q [4]),
        .I4(\result[43]_i_2_n_0 ),
        .O(result_d[43]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[43]_i_2 
       (.I0(\result[55]_i_3_n_0 ),
        .I1(\result[51]_i_4_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[47]_i_4_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[43]_i_3_n_0 ),
        .O(\result[43]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[43]_i_3 
       (.I0(data_q[46]),
        .I1(data_q[45]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[44]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[43]),
        .O(\result[43]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT4 #(
    .INIT(16'hCDC8)) 
    \result[44]_i_1 
       (.I0(\g_shift.amount_q [5]),
        .I1(\g_shift.g_right.g_dynamic.fill_q ),
        .I2(\g_shift.amount_q [4]),
        .I3(\result[44]_i_2_n_0 ),
        .O(result_d[44]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[44]_i_2 
       (.I0(\result[56]_i_2_n_0 ),
        .I1(\result[52]_i_3_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[48]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[44]_i_3_n_0 ),
        .O(\result[44]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[44]_i_3 
       (.I0(data_q[47]),
        .I1(data_q[46]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[45]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[44]),
        .O(\result[44]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'hCDC8)) 
    \result[45]_i_1 
       (.I0(\g_shift.amount_q [5]),
        .I1(\g_shift.g_right.g_dynamic.fill_q ),
        .I2(\g_shift.amount_q [4]),
        .I3(\result[45]_i_2_n_0 ),
        .O(result_d[45]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[45]_i_2 
       (.I0(\result[57]_i_2_n_0 ),
        .I1(\result[53]_i_3_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[49]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[45]_i_3_n_0 ),
        .O(\result[45]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[45]_i_3 
       (.I0(data_q[48]),
        .I1(data_q[47]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[46]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[45]),
        .O(\result[45]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT4 #(
    .INIT(16'hCDC8)) 
    \result[46]_i_1 
       (.I0(\g_shift.amount_q [5]),
        .I1(\g_shift.g_right.g_dynamic.fill_q ),
        .I2(\g_shift.amount_q [4]),
        .I3(\result[46]_i_2_n_0 ),
        .O(result_d[46]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[46]_i_2 
       (.I0(\result[54]_i_3_n_0 ),
        .I1(\result[54]_i_4_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[50]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[46]_i_3_n_0 ),
        .O(\result[46]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[46]_i_3 
       (.I0(data_q[49]),
        .I1(data_q[48]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[47]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[46]),
        .O(\result[46]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'hCDC8)) 
    \result[47]_i_1 
       (.I0(\g_shift.amount_q [5]),
        .I1(\g_shift.g_right.g_dynamic.fill_q ),
        .I2(\g_shift.amount_q [4]),
        .I3(\result[47]_i_2_n_0 ),
        .O(result_d[47]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[47]_i_2 
       (.I0(\result[47]_i_3_n_0 ),
        .I1(\result[55]_i_3_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[51]_i_4_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[47]_i_4_n_0 ),
        .O(\result[47]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'hCDC8)) 
    \result[47]_i_3 
       (.I0(\g_shift.amount_q [1]),
        .I1(\g_shift.g_right.g_dynamic.fill_q ),
        .I2(\g_shift.amount_q [0]),
        .I3(data_q[59]),
        .O(\result[47]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[47]_i_4 
       (.I0(data_q[50]),
        .I1(data_q[49]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[48]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[47]),
        .O(\result[47]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT4 #(
    .INIT(16'hCDC8)) 
    \result[48]_i_1 
       (.I0(\g_shift.amount_q [5]),
        .I1(\g_shift.g_right.g_dynamic.fill_q ),
        .I2(\g_shift.amount_q [4]),
        .I3(\result[48]_i_2_n_0 ),
        .O(result_d[48]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[48]_i_2 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(\result[56]_i_2_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[52]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[48]_i_3_n_0 ),
        .O(\result[48]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[48]_i_3 
       (.I0(data_q[51]),
        .I1(data_q[50]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[49]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[48]),
        .O(\result[48]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'hCDC8)) 
    \result[49]_i_1 
       (.I0(\g_shift.amount_q [5]),
        .I1(\g_shift.g_right.g_dynamic.fill_q ),
        .I2(\g_shift.amount_q [4]),
        .I3(\result[49]_i_2_n_0 ),
        .O(result_d[49]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[49]_i_2 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(\result[57]_i_2_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[53]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[49]_i_3_n_0 ),
        .O(\result[49]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[49]_i_3 
       (.I0(data_q[52]),
        .I1(data_q[51]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[50]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[49]),
        .O(\result[49]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[4]_i_1 
       (.I0(\result[36]_i_2_n_0 ),
        .I1(\result[36]_i_3_n_0 ),
        .I2(\g_shift.amount_q [5]),
        .I3(\result[20]_i_2_n_0 ),
        .I4(\g_shift.amount_q [4]),
        .I5(\result[4]_i_2_n_0 ),
        .O(result_d[4]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[4]_i_2 
       (.I0(\result[16]_i_3_n_0 ),
        .I1(\result[12]_i_3_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[8]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[4]_i_3_n_0 ),
        .O(\result[4]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[4]_i_3 
       (.I0(data_q[7]),
        .I1(data_q[6]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[5]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[4]),
        .O(\result[4]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT4 #(
    .INIT(16'hCDC8)) 
    \result[50]_i_1 
       (.I0(\g_shift.amount_q [5]),
        .I1(\g_shift.g_right.g_dynamic.fill_q ),
        .I2(\g_shift.amount_q [4]),
        .I3(\result[50]_i_2_n_0 ),
        .O(result_d[50]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[50]_i_2 
       (.I0(\result[58]_i_2_n_0 ),
        .I1(\g_shift.amount_q [3]),
        .I2(\result[54]_i_4_n_0 ),
        .I3(\g_shift.amount_q [2]),
        .I4(\result[50]_i_3_n_0 ),
        .O(\result[50]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[50]_i_3 
       (.I0(data_q[53]),
        .I1(data_q[52]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[51]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[50]),
        .O(\result[50]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT4 #(
    .INIT(16'hCDC8)) 
    \result[51]_i_1 
       (.I0(\g_shift.amount_q [5]),
        .I1(\g_shift.g_right.g_dynamic.fill_q ),
        .I2(\g_shift.amount_q [4]),
        .I3(\result[51]_i_2_n_0 ),
        .O(result_d[51]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[51]_i_2 
       (.I0(\result[51]_i_3_n_0 ),
        .I1(\g_shift.amount_q [3]),
        .I2(\result[55]_i_3_n_0 ),
        .I3(\g_shift.amount_q [2]),
        .I4(\result[51]_i_4_n_0 ),
        .O(\result[51]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hF0F1F0E0)) 
    \result[51]_i_3 
       (.I0(\g_shift.amount_q [2]),
        .I1(\g_shift.amount_q [1]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [0]),
        .I4(data_q[59]),
        .O(\result[51]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[51]_i_4 
       (.I0(data_q[54]),
        .I1(data_q[53]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[52]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[51]),
        .O(\result[51]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \result[52]_i_1 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(\g_shift.amount_q [5]),
        .I2(\result[52]_i_2_n_0 ),
        .O(result_d[52]));
  LUT6 #(
    .INIT(64'hCDC8CDCDCDC8C8C8)) 
    \result[52]_i_2 
       (.I0(\g_shift.amount_q [4]),
        .I1(\g_shift.g_right.g_dynamic.fill_q ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[56]_i_2_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[52]_i_3_n_0 ),
        .O(\result[52]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[52]_i_3 
       (.I0(data_q[55]),
        .I1(data_q[54]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[53]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[52]),
        .O(\result[52]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \result[53]_i_1 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(\g_shift.amount_q [5]),
        .I2(\result[53]_i_2_n_0 ),
        .O(result_d[53]));
  LUT6 #(
    .INIT(64'hCDC8CDCDCDC8C8C8)) 
    \result[53]_i_2 
       (.I0(\g_shift.amount_q [4]),
        .I1(\g_shift.g_right.g_dynamic.fill_q ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[57]_i_2_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[53]_i_3_n_0 ),
        .O(\result[53]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[53]_i_3 
       (.I0(data_q[56]),
        .I1(data_q[55]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[54]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[53]),
        .O(\result[53]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[54]_i_1 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(\g_shift.amount_q [5]),
        .I2(\result[54]_i_2_n_0 ),
        .O(result_d[54]));
  LUT6 #(
    .INIT(64'hCDC8CDCDCDC8C8C8)) 
    \result[54]_i_2 
       (.I0(\g_shift.amount_q [4]),
        .I1(\g_shift.g_right.g_dynamic.fill_q ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[54]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[54]_i_4_n_0 ),
        .O(\result[54]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[54]_i_3 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(\g_shift.amount_q [1]),
        .I2(data_q[59]),
        .I3(\g_shift.amount_q [0]),
        .I4(data_q[58]),
        .O(\result[54]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[54]_i_4 
       (.I0(data_q[57]),
        .I1(data_q[56]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[55]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[54]),
        .O(\result[54]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'hF0F1F0E0)) 
    \result[55]_i_1 
       (.I0(\g_shift.amount_q [5]),
        .I1(\g_shift.amount_q [4]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [3]),
        .I4(\result[55]_i_2_n_0 ),
        .O(result_d[55]));
  LUT6 #(
    .INIT(64'hCDC8FFFFCDC80000)) 
    \result[55]_i_2 
       (.I0(\g_shift.amount_q [1]),
        .I1(\g_shift.g_right.g_dynamic.fill_q ),
        .I2(\g_shift.amount_q [0]),
        .I3(data_q[59]),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[55]_i_3_n_0 ),
        .O(\result[55]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[55]_i_3 
       (.I0(data_q[58]),
        .I1(data_q[57]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[56]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[55]),
        .O(\result[55]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFF00FF01FF00FE00)) 
    \result[56]_i_1 
       (.I0(\g_shift.amount_q [5]),
        .I1(\g_shift.amount_q [4]),
        .I2(\g_shift.amount_q [3]),
        .I3(\g_shift.g_right.g_dynamic.fill_q ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[56]_i_2_n_0 ),
        .O(result_d[56]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[56]_i_2 
       (.I0(data_q[59]),
        .I1(data_q[58]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[57]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[56]),
        .O(\result[56]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFF00FF01FF00FE00)) 
    \result[57]_i_1 
       (.I0(\g_shift.amount_q [5]),
        .I1(\g_shift.amount_q [4]),
        .I2(\g_shift.amount_q [3]),
        .I3(\g_shift.g_right.g_dynamic.fill_q ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[57]_i_2_n_0 ),
        .O(result_d[57]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[57]_i_2 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(data_q[59]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[58]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[57]),
        .O(\result[57]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hF0F1F0E0)) 
    \result[58]_i_1 
       (.I0(\g_shift.amount_q [5]),
        .I1(\g_shift.amount_q [4]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [3]),
        .I4(\result[58]_i_2_n_0 ),
        .O(result_d[58]));
  LUT6 #(
    .INIT(64'hCDC8CDCDCDC8C8C8)) 
    \result[58]_i_2 
       (.I0(\g_shift.amount_q [2]),
        .I1(\g_shift.g_right.g_dynamic.fill_q ),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[59]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[58]),
        .O(\result[58]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT4 #(
    .INIT(16'hCDC8)) 
    \result[59]_i_1 
       (.I0(\g_shift.amount_q [5]),
        .I1(\g_shift.g_right.g_dynamic.fill_q ),
        .I2(\g_shift.amount_q [4]),
        .I3(\result[59]_i_2_n_0 ),
        .O(result_d[59]));
  LUT6 #(
    .INIT(64'hFF00FF01FF00FE00)) 
    \result[59]_i_2 
       (.I0(\g_shift.amount_q [3]),
        .I1(\g_shift.amount_q [2]),
        .I2(\g_shift.amount_q [1]),
        .I3(\g_shift.g_right.g_dynamic.fill_q ),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[59]),
        .O(\result[59]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[5]_i_1 
       (.I0(\result[37]_i_2_n_0 ),
        .I1(\result[37]_i_3_n_0 ),
        .I2(\g_shift.amount_q [5]),
        .I3(\result[21]_i_2_n_0 ),
        .I4(\g_shift.amount_q [4]),
        .I5(\result[5]_i_2_n_0 ),
        .O(result_d[5]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[5]_i_2 
       (.I0(\result[17]_i_3_n_0 ),
        .I1(\result[13]_i_3_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[9]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[5]_i_3_n_0 ),
        .O(\result[5]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[5]_i_3 
       (.I0(data_q[8]),
        .I1(data_q[7]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[6]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[5]),
        .O(\result[5]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[6]_i_1 
       (.I0(\result[38]_i_2_n_0 ),
        .I1(\result[38]_i_3_n_0 ),
        .I2(\g_shift.amount_q [5]),
        .I3(\result[22]_i_2_n_0 ),
        .I4(\g_shift.amount_q [4]),
        .I5(\result[6]_i_2_n_0 ),
        .O(result_d[6]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[6]_i_2 
       (.I0(\result[18]_i_3_n_0 ),
        .I1(\result[14]_i_3_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[10]_i_4_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[6]_i_3_n_0 ),
        .O(\result[6]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[6]_i_3 
       (.I0(data_q[9]),
        .I1(data_q[8]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[7]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[6]),
        .O(\result[6]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[7]_i_1 
       (.I0(\result[7]_i_2_n_0 ),
        .I1(\result[39]_i_2_n_0 ),
        .I2(\g_shift.amount_q [5]),
        .I3(\result[23]_i_3_n_0 ),
        .I4(\g_shift.amount_q [4]),
        .I5(\result[7]_i_3_n_0 ),
        .O(result_d[7]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[7]_i_2 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(\g_shift.amount_q [3]),
        .I2(\result[47]_i_3_n_0 ),
        .I3(\g_shift.amount_q [2]),
        .I4(\result[55]_i_3_n_0 ),
        .O(\result[7]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[7]_i_3 
       (.I0(\result[19]_i_3_n_0 ),
        .I1(\result[15]_i_3_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[11]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[7]_i_4_n_0 ),
        .O(\result[7]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[7]_i_4 
       (.I0(data_q[10]),
        .I1(data_q[9]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[8]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[7]),
        .O(\result[7]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[8]_i_1 
       (.I0(\result[40]_i_2_n_0 ),
        .I1(\result[40]_i_3_n_0 ),
        .I2(\g_shift.amount_q [5]),
        .I3(\result[24]_i_3_n_0 ),
        .I4(\g_shift.amount_q [4]),
        .I5(\result[8]_i_2_n_0 ),
        .O(result_d[8]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[8]_i_2 
       (.I0(\result[20]_i_3_n_0 ),
        .I1(\result[16]_i_3_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[12]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[8]_i_3_n_0 ),
        .O(\result[8]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[8]_i_3 
       (.I0(data_q[11]),
        .I1(data_q[10]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[9]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[8]),
        .O(\result[8]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[9]_i_1 
       (.I0(\result[41]_i_2_n_0 ),
        .I1(\result[41]_i_3_n_0 ),
        .I2(\g_shift.amount_q [5]),
        .I3(\result[25]_i_3_n_0 ),
        .I4(\g_shift.amount_q [4]),
        .I5(\result[9]_i_2_n_0 ),
        .O(result_d[9]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[9]_i_2 
       (.I0(\result[21]_i_3_n_0 ),
        .I1(\result[17]_i_3_n_0 ),
        .I2(\g_shift.amount_q [3]),
        .I3(\result[13]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[9]_i_3_n_0 ),
        .O(\result[9]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[9]_i_3 
       (.I0(data_q[12]),
        .I1(data_q[11]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[10]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[9]),
        .O(\result[9]_i_3_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[0] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[0]),
        .Q(result[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[10] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[10]),
        .Q(result[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[11] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[11]),
        .Q(result[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[12] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[12]),
        .Q(result[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[13] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[13]),
        .Q(result[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[14] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[14]),
        .Q(result[14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[15] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[15]),
        .Q(result[15]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[16] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[16]),
        .Q(result[16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[17] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[17]),
        .Q(result[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[18] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[18]),
        .Q(result[18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[19] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[19]),
        .Q(result[19]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[1] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[1]),
        .Q(result[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[20] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[20]),
        .Q(result[20]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[21] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[21]),
        .Q(result[21]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[22] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[22]),
        .Q(result[22]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[23] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[23]),
        .Q(result[23]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[24] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[24]),
        .Q(result[24]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[25] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[25]),
        .Q(result[25]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[26] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[26]),
        .Q(result[26]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[27] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[27]),
        .Q(result[27]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[28] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[28]),
        .Q(result[28]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[29] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[29]),
        .Q(result[29]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[2] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[2]),
        .Q(result[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[30] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[30]),
        .Q(result[30]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[31] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[31]),
        .Q(result[31]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[32] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[32]),
        .Q(result[32]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[33] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[33]),
        .Q(result[33]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[34] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[34]),
        .Q(result[34]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[35] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[35]),
        .Q(result[35]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[36] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[36]),
        .Q(result[36]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[37] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[37]),
        .Q(result[37]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[38] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[38]),
        .Q(result[38]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[39] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[39]),
        .Q(result[39]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[3] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[3]),
        .Q(result[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[40] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[40]),
        .Q(result[40]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[41] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[41]),
        .Q(result[41]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[42] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[42]),
        .Q(result[42]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[43] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[43]),
        .Q(result[43]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[44] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[44]),
        .Q(result[44]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[45] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[45]),
        .Q(result[45]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[46] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[46]),
        .Q(result[46]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[47] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[47]),
        .Q(result[47]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[48] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[48]),
        .Q(result[48]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[49] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[49]),
        .Q(result[49]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[4] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[4]),
        .Q(result[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[50] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[50]),
        .Q(result[50]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[51] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[51]),
        .Q(result[51]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[52] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[52]),
        .Q(result[52]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[53] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[53]),
        .Q(result[53]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[54] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[54]),
        .Q(result[54]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[55] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[55]),
        .Q(result[55]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[56] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[56]),
        .Q(result[56]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[57] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[57]),
        .Q(result[57]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[58] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[58]),
        .Q(result[58]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[59] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[59]),
        .Q(result[59]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[5] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[5]),
        .Q(result[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[6] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[6]),
        .Q(result[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[7] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[7]),
        .Q(result[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[8] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[8]),
        .Q(result[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[9] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[9]),
        .Q(result[9]),
        .R(1'b0));
endmodule

(* ARITH = "0" *) (* ECO_CHECKSUM = "3673b225" *) (* FILL_KIND = "1" *) 
(* KIND = "1" *) (* MODE = "0" *) (* N = "60" *) 
(* RESULT_W = "60" *) (* SHIFT_W = "6" *) 
(* NotValidForBitStream *)
(* \DesignAttr:ENABLE_NOC_NETLIST_VIEW  *) 
(* \DesignAttr:ENABLE_AIE_NETLIST_VIEW  *) 
module primitive_v2_top
   (clk,
    data,
    amount,
    fill_val,
    result);
  input clk;
  input [59:0]data;
  input [5:0]amount;
  input fill_val;
  output [59:0]result;

  wire [5:0]amount;
  wire clk;
  wire clk_core;
  wire [59:0]data;
  wire fill_val;
  wire [59:0]result;

  primitive_v2_boundary u_boundary
       (.CLK(clk_core),
        .amount(amount),
        .data(data),
        .fill_val(fill_val),
        .result(result));
  (* BOX_TYPE = "PRIMITIVE" *) 
  BUFG u_clock
       (.I(clk),
        .O(clk_core));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
