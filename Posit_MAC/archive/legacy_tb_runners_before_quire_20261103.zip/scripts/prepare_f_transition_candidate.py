"""One bounded follow-up: decouple regime transitions from carry magnitude."""
import hashlib
import json
import shutil
from pathlib import Path

root=Path(__file__).resolve().parent.parent
experiment=root/'experiments/f_timing_20261101'
source=experiment/'p20'
if source.exists(): raise SystemExit('Preserve p20')
shutil.copytree(experiment/'p00',source)
path=source/'rtl/parser/posit_parser_f.sv'
body=path.read_text()
old='    assign terminator_bits = magnitude[NB-3:0] ^ magnitude[NB-2:1];'
assert old in body
body=body.replace(old,'''    // Direct transition identity, independent of the magnitude carry chain:
    // m[i] = p[i] ^ (s & L[i]), L[i] = |p[i-1:0].
    // L[i] ^ L[i+1] = p[i] & ~L[i], hence
    // m[i] ^ m[i+1] = p[i] ^ p[i+1] ^ (s & p[i] & ~L[i]).
    // Magnitude remains unchanged for FRB/payload; no extra pipeline stage.
    generate
        for (genvar i = 0; i < NB-2; i++) begin : g_direct_transition
            if (i == 0) begin : g_low
                assign terminator_bits[i] = p[i] ^ p[i+1] ^ (s_d & p[i]);
            end else begin : g_rest
                assign terminator_bits[i] = p[i] ^ p[i+1]
                                          ^ (s_d & p[i] & ~(|p[i-1:0]));
            end
        end
    endgenerate''')
path.write_text(body)
tb=source/'tb/tb_parser_f_timing_equiv.sv'
body=tb.read_text()
needle='            if (u_mag.magnitude !== expected_mag) $fatal(1, "Magnitude mismatch %h",mag_p);'
assert needle in body
body=body.replace(needle,needle+'''
            if (u_mag.terminator_bits !== (expected_mag[29:0] ^ expected_mag[30:1]))
                $fatal(1, "Direct transition mismatch %h",mag_p);''')
body=body.replace('$display("PARSER_MAG_DUT_PASS checked=4000000");',
    '$display("PARSER_MAG_DUT_PASS checked=4000000");\n        $display("PARSER_TRANSITION_DUT_PASS checked=4000000");')
tb.write_text(body)
records=json.loads((experiment/'candidates.json').read_text())
records['p20']={'magnitude':'carry + direct raw transition','parser_lod':'group','source':str(source),
    'hypothesis':'Break magnitude-carry dependency of count using proven adjacent-XOR identity',
    'changed_existing_rtl':['rtl/mac_f/mac_f_wrapper.sv'],
    'files':{str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in source.rglob('*') if p.is_file()}}
(experiment/'candidates.json').write_text(json.dumps(records,indent=2)+'\n')
print('Prepared p20: carry payload + direct transition + group LOD')
