// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2026.1 (win64) Build 6511674 Tue Jun 16 11:02:23 MDT 2026
// Date        : Fri Oct 16 16:11:35 2026
// Host        : MSI running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim {C:/HCMUT/HK261/Do an
//               2/Posit_MAC/results/primitive_v2_20261016/xc7a100tcsg324-1/confirm/native_n31_k1_m0_a0_f1_w5_default/functional_netlist.v}
// Design      : primitive_v2_top
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a100tcsg324-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module primitive_v2_boundary
   (result,
    amount,
    clk,
    data,
    fill_val);
  output [30:0]result;
  input [4:0]amount;
  input clk;
  input [30:0]data;
  input fill_val;

  wire [4:0]amount;
  wire clk;
  wire [30:0]data;
  wire [30:0]data_q;
  wire fill_val;
  wire [4:0]\g_shift.amount_q ;
  wire \g_shift.g_right.g_dynamic.fill_q ;
  wire [30:0]result;
  wire \result[0]_i_2_n_0 ;
  wire \result[0]_i_3_n_0 ;
  wire \result[0]_i_4_n_0 ;
  wire \result[10]_i_2_n_0 ;
  wire \result[10]_i_3_n_0 ;
  wire \result[11]_i_2_n_0 ;
  wire \result[11]_i_3_n_0 ;
  wire \result[12]_i_2_n_0 ;
  wire \result[12]_i_3_n_0 ;
  wire \result[13]_i_2_n_0 ;
  wire \result[13]_i_3_n_0 ;
  wire \result[14]_i_2_n_0 ;
  wire \result[14]_i_3_n_0 ;
  wire \result[15]_i_2_n_0 ;
  wire \result[15]_i_3_n_0 ;
  wire \result[16]_i_2_n_0 ;
  wire \result[16]_i_3_n_0 ;
  wire \result[17]_i_2_n_0 ;
  wire \result[17]_i_3_n_0 ;
  wire \result[18]_i_2_n_0 ;
  wire \result[18]_i_3_n_0 ;
  wire \result[19]_i_2_n_0 ;
  wire \result[19]_i_3_n_0 ;
  wire \result[19]_i_4_n_0 ;
  wire \result[1]_i_2_n_0 ;
  wire \result[1]_i_3_n_0 ;
  wire \result[20]_i_2_n_0 ;
  wire \result[20]_i_3_n_0 ;
  wire \result[20]_i_4_n_0 ;
  wire \result[21]_i_2_n_0 ;
  wire \result[21]_i_3_n_0 ;
  wire \result[21]_i_4_n_0 ;
  wire \result[22]_i_2_n_0 ;
  wire \result[22]_i_3_n_0 ;
  wire \result[22]_i_4_n_0 ;
  wire \result[23]_i_2_n_0 ;
  wire \result[24]_i_2_n_0 ;
  wire \result[25]_i_2_n_0 ;
  wire \result[26]_i_2_n_0 ;
  wire \result[27]_i_2_n_0 ;
  wire \result[27]_i_3_n_0 ;
  wire \result[28]_i_2_n_0 ;
  wire \result[28]_i_3_n_0 ;
  wire \result[29]_i_2_n_0 ;
  wire \result[2]_i_2_n_0 ;
  wire \result[2]_i_3_n_0 ;
  wire \result[30]_i_2_n_0 ;
  wire \result[3]_i_2_n_0 ;
  wire \result[3]_i_3_n_0 ;
  wire \result[4]_i_2_n_0 ;
  wire \result[4]_i_3_n_0 ;
  wire \result[5]_i_2_n_0 ;
  wire \result[5]_i_3_n_0 ;
  wire \result[6]_i_2_n_0 ;
  wire \result[6]_i_3_n_0 ;
  wire \result[7]_i_2_n_0 ;
  wire \result[7]_i_3_n_0 ;
  wire \result[8]_i_2_n_0 ;
  wire \result[8]_i_3_n_0 ;
  wire \result[9]_i_2_n_0 ;
  wire \result[9]_i_3_n_0 ;
  wire [30:0]result_d;

  FDRE \data_q_reg[0] 
       (.C(clk),
        .CE(1'b1),
        .D(data[0]),
        .Q(data_q[0]),
        .R(1'b0));
  FDRE \data_q_reg[10] 
       (.C(clk),
        .CE(1'b1),
        .D(data[10]),
        .Q(data_q[10]),
        .R(1'b0));
  FDRE \data_q_reg[11] 
       (.C(clk),
        .CE(1'b1),
        .D(data[11]),
        .Q(data_q[11]),
        .R(1'b0));
  FDRE \data_q_reg[12] 
       (.C(clk),
        .CE(1'b1),
        .D(data[12]),
        .Q(data_q[12]),
        .R(1'b0));
  FDRE \data_q_reg[13] 
       (.C(clk),
        .CE(1'b1),
        .D(data[13]),
        .Q(data_q[13]),
        .R(1'b0));
  FDRE \data_q_reg[14] 
       (.C(clk),
        .CE(1'b1),
        .D(data[14]),
        .Q(data_q[14]),
        .R(1'b0));
  FDRE \data_q_reg[15] 
       (.C(clk),
        .CE(1'b1),
        .D(data[15]),
        .Q(data_q[15]),
        .R(1'b0));
  FDRE \data_q_reg[16] 
       (.C(clk),
        .CE(1'b1),
        .D(data[16]),
        .Q(data_q[16]),
        .R(1'b0));
  FDRE \data_q_reg[17] 
       (.C(clk),
        .CE(1'b1),
        .D(data[17]),
        .Q(data_q[17]),
        .R(1'b0));
  FDRE \data_q_reg[18] 
       (.C(clk),
        .CE(1'b1),
        .D(data[18]),
        .Q(data_q[18]),
        .R(1'b0));
  FDRE \data_q_reg[19] 
       (.C(clk),
        .CE(1'b1),
        .D(data[19]),
        .Q(data_q[19]),
        .R(1'b0));
  FDRE \data_q_reg[1] 
       (.C(clk),
        .CE(1'b1),
        .D(data[1]),
        .Q(data_q[1]),
        .R(1'b0));
  FDRE \data_q_reg[20] 
       (.C(clk),
        .CE(1'b1),
        .D(data[20]),
        .Q(data_q[20]),
        .R(1'b0));
  FDRE \data_q_reg[21] 
       (.C(clk),
        .CE(1'b1),
        .D(data[21]),
        .Q(data_q[21]),
        .R(1'b0));
  FDRE \data_q_reg[22] 
       (.C(clk),
        .CE(1'b1),
        .D(data[22]),
        .Q(data_q[22]),
        .R(1'b0));
  FDRE \data_q_reg[23] 
       (.C(clk),
        .CE(1'b1),
        .D(data[23]),
        .Q(data_q[23]),
        .R(1'b0));
  FDRE \data_q_reg[24] 
       (.C(clk),
        .CE(1'b1),
        .D(data[24]),
        .Q(data_q[24]),
        .R(1'b0));
  FDRE \data_q_reg[25] 
       (.C(clk),
        .CE(1'b1),
        .D(data[25]),
        .Q(data_q[25]),
        .R(1'b0));
  FDRE \data_q_reg[26] 
       (.C(clk),
        .CE(1'b1),
        .D(data[26]),
        .Q(data_q[26]),
        .R(1'b0));
  FDRE \data_q_reg[27] 
       (.C(clk),
        .CE(1'b1),
        .D(data[27]),
        .Q(data_q[27]),
        .R(1'b0));
  FDRE \data_q_reg[28] 
       (.C(clk),
        .CE(1'b1),
        .D(data[28]),
        .Q(data_q[28]),
        .R(1'b0));
  FDRE \data_q_reg[29] 
       (.C(clk),
        .CE(1'b1),
        .D(data[29]),
        .Q(data_q[29]),
        .R(1'b0));
  FDRE \data_q_reg[2] 
       (.C(clk),
        .CE(1'b1),
        .D(data[2]),
        .Q(data_q[2]),
        .R(1'b0));
  FDRE \data_q_reg[30] 
       (.C(clk),
        .CE(1'b1),
        .D(data[30]),
        .Q(data_q[30]),
        .R(1'b0));
  FDRE \data_q_reg[3] 
       (.C(clk),
        .CE(1'b1),
        .D(data[3]),
        .Q(data_q[3]),
        .R(1'b0));
  FDRE \data_q_reg[4] 
       (.C(clk),
        .CE(1'b1),
        .D(data[4]),
        .Q(data_q[4]),
        .R(1'b0));
  FDRE \data_q_reg[5] 
       (.C(clk),
        .CE(1'b1),
        .D(data[5]),
        .Q(data_q[5]),
        .R(1'b0));
  FDRE \data_q_reg[6] 
       (.C(clk),
        .CE(1'b1),
        .D(data[6]),
        .Q(data_q[6]),
        .R(1'b0));
  FDRE \data_q_reg[7] 
       (.C(clk),
        .CE(1'b1),
        .D(data[7]),
        .Q(data_q[7]),
        .R(1'b0));
  FDRE \data_q_reg[8] 
       (.C(clk),
        .CE(1'b1),
        .D(data[8]),
        .Q(data_q[8]),
        .R(1'b0));
  FDRE \data_q_reg[9] 
       (.C(clk),
        .CE(1'b1),
        .D(data[9]),
        .Q(data_q[9]),
        .R(1'b0));
  FDRE \g_shift.amount_q_reg[0] 
       (.C(clk),
        .CE(1'b1),
        .D(amount[0]),
        .Q(\g_shift.amount_q [0]),
        .R(1'b0));
  FDRE \g_shift.amount_q_reg[1] 
       (.C(clk),
        .CE(1'b1),
        .D(amount[1]),
        .Q(\g_shift.amount_q [1]),
        .R(1'b0));
  FDRE \g_shift.amount_q_reg[2] 
       (.C(clk),
        .CE(1'b1),
        .D(amount[2]),
        .Q(\g_shift.amount_q [2]),
        .R(1'b0));
  FDRE \g_shift.amount_q_reg[3] 
       (.C(clk),
        .CE(1'b1),
        .D(amount[3]),
        .Q(\g_shift.amount_q [3]),
        .R(1'b0));
  FDRE \g_shift.amount_q_reg[4] 
       (.C(clk),
        .CE(1'b1),
        .D(amount[4]),
        .Q(\g_shift.amount_q [4]),
        .R(1'b0));
  FDRE \g_shift.g_right.g_dynamic.fill_q_reg 
       (.C(clk),
        .CE(1'b1),
        .D(fill_val),
        .Q(\g_shift.g_right.g_dynamic.fill_q ),
        .R(1'b0));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[0]_i_1 
       (.I0(\result[1]_i_2_n_0 ),
        .I1(\g_shift.amount_q [0]),
        .I2(\result[0]_i_2_n_0 ),
        .I3(\g_shift.amount_q [1]),
        .I4(\result[0]_i_3_n_0 ),
        .O(result_d[0]));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[0]_i_2 
       (.I0(\result[6]_i_3_n_0 ),
        .I1(\g_shift.amount_q [2]),
        .I2(\result[2]_i_3_n_0 ),
        .O(\result[0]_i_2_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[0]_i_3 
       (.I0(\result[4]_i_3_n_0 ),
        .I1(\g_shift.amount_q [2]),
        .I2(\result[0]_i_4_n_0 ),
        .O(\result[0]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[0]_i_4 
       (.I0(data_q[24]),
        .I1(data_q[8]),
        .I2(\g_shift.amount_q [3]),
        .I3(data_q[16]),
        .I4(\g_shift.amount_q [4]),
        .I5(data_q[0]),
        .O(\result[0]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \result[10]_i_1 
       (.I0(\result[11]_i_2_n_0 ),
        .I1(\g_shift.amount_q [0]),
        .I2(\result[10]_i_2_n_0 ),
        .O(result_d[10]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[10]_i_2 
       (.I0(\result[16]_i_3_n_0 ),
        .I1(\result[12]_i_3_n_0 ),
        .I2(\g_shift.amount_q [1]),
        .I3(\result[14]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[10]_i_3_n_0 ),
        .O(\result[10]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[10]_i_3 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(data_q[18]),
        .I2(\g_shift.amount_q [3]),
        .I3(data_q[26]),
        .I4(\g_shift.amount_q [4]),
        .I5(data_q[10]),
        .O(\result[10]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \result[11]_i_1 
       (.I0(\result[12]_i_2_n_0 ),
        .I1(\g_shift.amount_q [0]),
        .I2(\result[11]_i_2_n_0 ),
        .O(result_d[11]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[11]_i_2 
       (.I0(\result[17]_i_3_n_0 ),
        .I1(\result[13]_i_3_n_0 ),
        .I2(\g_shift.amount_q [1]),
        .I3(\result[15]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[11]_i_3_n_0 ),
        .O(\result[11]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[11]_i_3 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(data_q[19]),
        .I2(\g_shift.amount_q [3]),
        .I3(data_q[27]),
        .I4(\g_shift.amount_q [4]),
        .I5(data_q[11]),
        .O(\result[11]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \result[12]_i_1 
       (.I0(\result[13]_i_2_n_0 ),
        .I1(\g_shift.amount_q [0]),
        .I2(\result[12]_i_2_n_0 ),
        .O(result_d[12]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[12]_i_2 
       (.I0(\result[18]_i_3_n_0 ),
        .I1(\result[14]_i_3_n_0 ),
        .I2(\g_shift.amount_q [1]),
        .I3(\result[16]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[12]_i_3_n_0 ),
        .O(\result[12]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[12]_i_3 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(data_q[20]),
        .I2(\g_shift.amount_q [3]),
        .I3(data_q[28]),
        .I4(\g_shift.amount_q [4]),
        .I5(data_q[12]),
        .O(\result[12]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \result[13]_i_1 
       (.I0(\result[14]_i_2_n_0 ),
        .I1(\g_shift.amount_q [0]),
        .I2(\result[13]_i_2_n_0 ),
        .O(result_d[13]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[13]_i_2 
       (.I0(\result[19]_i_4_n_0 ),
        .I1(\result[15]_i_3_n_0 ),
        .I2(\g_shift.amount_q [1]),
        .I3(\result[17]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[13]_i_3_n_0 ),
        .O(\result[13]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[13]_i_3 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(data_q[21]),
        .I2(\g_shift.amount_q [3]),
        .I3(data_q[29]),
        .I4(\g_shift.amount_q [4]),
        .I5(data_q[13]),
        .O(\result[13]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \result[14]_i_1 
       (.I0(\result[15]_i_2_n_0 ),
        .I1(\g_shift.amount_q [0]),
        .I2(\result[14]_i_2_n_0 ),
        .O(result_d[14]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[14]_i_2 
       (.I0(\result[20]_i_4_n_0 ),
        .I1(\result[16]_i_3_n_0 ),
        .I2(\g_shift.amount_q [1]),
        .I3(\result[18]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[14]_i_3_n_0 ),
        .O(\result[14]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[14]_i_3 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(data_q[22]),
        .I2(\g_shift.amount_q [3]),
        .I3(data_q[30]),
        .I4(\g_shift.amount_q [4]),
        .I5(data_q[14]),
        .O(\result[14]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \result[15]_i_1 
       (.I0(\result[16]_i_2_n_0 ),
        .I1(\g_shift.amount_q [0]),
        .I2(\result[15]_i_2_n_0 ),
        .O(result_d[15]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[15]_i_2 
       (.I0(\result[21]_i_4_n_0 ),
        .I1(\result[17]_i_3_n_0 ),
        .I2(\g_shift.amount_q [1]),
        .I3(\result[19]_i_4_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[15]_i_3_n_0 ),
        .O(\result[15]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hF0BBF088)) 
    \result[15]_i_3 
       (.I0(data_q[23]),
        .I1(\g_shift.amount_q [3]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [4]),
        .I4(data_q[15]),
        .O(\result[15]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \result[16]_i_1 
       (.I0(\result[17]_i_2_n_0 ),
        .I1(\g_shift.amount_q [0]),
        .I2(\result[16]_i_2_n_0 ),
        .O(result_d[16]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[16]_i_2 
       (.I0(\result[22]_i_4_n_0 ),
        .I1(\result[18]_i_3_n_0 ),
        .I2(\g_shift.amount_q [1]),
        .I3(\result[20]_i_4_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[16]_i_3_n_0 ),
        .O(\result[16]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hF0BBF088)) 
    \result[16]_i_3 
       (.I0(data_q[24]),
        .I1(\g_shift.amount_q [3]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [4]),
        .I4(data_q[16]),
        .O(\result[16]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \result[17]_i_1 
       (.I0(\result[18]_i_2_n_0 ),
        .I1(\g_shift.amount_q [0]),
        .I2(\result[17]_i_2_n_0 ),
        .O(result_d[17]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[17]_i_2 
       (.I0(\result[19]_i_3_n_0 ),
        .I1(\result[19]_i_4_n_0 ),
        .I2(\g_shift.amount_q [1]),
        .I3(\result[21]_i_4_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[17]_i_3_n_0 ),
        .O(\result[17]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hF0BBF088)) 
    \result[17]_i_3 
       (.I0(data_q[25]),
        .I1(\g_shift.amount_q [3]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [4]),
        .I4(data_q[17]),
        .O(\result[17]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \result[18]_i_1 
       (.I0(\result[19]_i_2_n_0 ),
        .I1(\g_shift.amount_q [0]),
        .I2(\result[18]_i_2_n_0 ),
        .O(result_d[18]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[18]_i_2 
       (.I0(\result[20]_i_3_n_0 ),
        .I1(\result[20]_i_4_n_0 ),
        .I2(\g_shift.amount_q [1]),
        .I3(\result[22]_i_4_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[18]_i_3_n_0 ),
        .O(\result[18]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hF0BBF088)) 
    \result[18]_i_3 
       (.I0(data_q[26]),
        .I1(\g_shift.amount_q [3]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [4]),
        .I4(data_q[18]),
        .O(\result[18]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \result[19]_i_1 
       (.I0(\result[20]_i_2_n_0 ),
        .I1(\g_shift.amount_q [0]),
        .I2(\result[19]_i_2_n_0 ),
        .O(result_d[19]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[19]_i_2 
       (.I0(\result[21]_i_3_n_0 ),
        .I1(\result[21]_i_4_n_0 ),
        .I2(\g_shift.amount_q [1]),
        .I3(\result[19]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[19]_i_4_n_0 ),
        .O(\result[19]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'hCDC8)) 
    \result[19]_i_3 
       (.I0(\g_shift.amount_q [3]),
        .I1(\g_shift.g_right.g_dynamic.fill_q ),
        .I2(\g_shift.amount_q [4]),
        .I3(data_q[23]),
        .O(\result[19]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hF0BBF088)) 
    \result[19]_i_4 
       (.I0(data_q[27]),
        .I1(\g_shift.amount_q [3]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [4]),
        .I4(data_q[19]),
        .O(\result[19]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[1]_i_1 
       (.I0(\result[2]_i_2_n_0 ),
        .I1(\g_shift.amount_q [0]),
        .I2(\result[1]_i_2_n_0 ),
        .O(result_d[1]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[1]_i_2 
       (.I0(\result[7]_i_3_n_0 ),
        .I1(\result[3]_i_3_n_0 ),
        .I2(\g_shift.amount_q [1]),
        .I3(\result[5]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[1]_i_3_n_0 ),
        .O(\result[1]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[1]_i_3 
       (.I0(data_q[25]),
        .I1(data_q[9]),
        .I2(\g_shift.amount_q [3]),
        .I3(data_q[17]),
        .I4(\g_shift.amount_q [4]),
        .I5(data_q[1]),
        .O(\result[1]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \result[20]_i_1 
       (.I0(\result[21]_i_2_n_0 ),
        .I1(\g_shift.amount_q [0]),
        .I2(\result[20]_i_2_n_0 ),
        .O(result_d[20]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[20]_i_2 
       (.I0(\result[22]_i_3_n_0 ),
        .I1(\result[22]_i_4_n_0 ),
        .I2(\g_shift.amount_q [1]),
        .I3(\result[20]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[20]_i_4_n_0 ),
        .O(\result[20]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'hCDC8)) 
    \result[20]_i_3 
       (.I0(\g_shift.amount_q [3]),
        .I1(\g_shift.g_right.g_dynamic.fill_q ),
        .I2(\g_shift.amount_q [4]),
        .I3(data_q[24]),
        .O(\result[20]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hF0BBF088)) 
    \result[20]_i_4 
       (.I0(data_q[28]),
        .I1(\g_shift.amount_q [3]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [4]),
        .I4(data_q[20]),
        .O(\result[20]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \result[21]_i_1 
       (.I0(\result[22]_i_2_n_0 ),
        .I1(\g_shift.amount_q [0]),
        .I2(\result[21]_i_2_n_0 ),
        .O(result_d[21]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[21]_i_2 
       (.I0(\result[23]_i_2_n_0 ),
        .I1(\g_shift.amount_q [1]),
        .I2(\result[21]_i_3_n_0 ),
        .I3(\g_shift.amount_q [2]),
        .I4(\result[21]_i_4_n_0 ),
        .O(\result[21]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'hCDC8)) 
    \result[21]_i_3 
       (.I0(\g_shift.amount_q [3]),
        .I1(\g_shift.g_right.g_dynamic.fill_q ),
        .I2(\g_shift.amount_q [4]),
        .I3(data_q[25]),
        .O(\result[21]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hF0BBF088)) 
    \result[21]_i_4 
       (.I0(data_q[29]),
        .I1(\g_shift.amount_q [3]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [4]),
        .I4(data_q[21]),
        .O(\result[21]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \result[22]_i_1 
       (.I0(\result[25]_i_2_n_0 ),
        .I1(\g_shift.amount_q [1]),
        .I2(\result[23]_i_2_n_0 ),
        .I3(\g_shift.amount_q [0]),
        .I4(\result[22]_i_2_n_0 ),
        .O(result_d[22]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[22]_i_2 
       (.I0(\result[24]_i_2_n_0 ),
        .I1(\g_shift.amount_q [1]),
        .I2(\result[22]_i_3_n_0 ),
        .I3(\g_shift.amount_q [2]),
        .I4(\result[22]_i_4_n_0 ),
        .O(\result[22]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'hCDC8)) 
    \result[22]_i_3 
       (.I0(\g_shift.amount_q [3]),
        .I1(\g_shift.g_right.g_dynamic.fill_q ),
        .I2(\g_shift.amount_q [4]),
        .I3(data_q[26]),
        .O(\result[22]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hF0BBF088)) 
    \result[22]_i_4 
       (.I0(data_q[30]),
        .I1(\g_shift.amount_q [3]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [4]),
        .I4(data_q[22]),
        .O(\result[22]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[23]_i_1 
       (.I0(\result[26]_i_2_n_0 ),
        .I1(\result[24]_i_2_n_0 ),
        .I2(\g_shift.amount_q [0]),
        .I3(\result[25]_i_2_n_0 ),
        .I4(\g_shift.amount_q [1]),
        .I5(\result[23]_i_2_n_0 ),
        .O(result_d[23]));
  LUT6 #(
    .INIT(64'hFF00FB0BFF00F808)) 
    \result[23]_i_2 
       (.I0(data_q[27]),
        .I1(\g_shift.amount_q [2]),
        .I2(\g_shift.amount_q [3]),
        .I3(\g_shift.g_right.g_dynamic.fill_q ),
        .I4(\g_shift.amount_q [4]),
        .I5(data_q[23]),
        .O(\result[23]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[24]_i_1 
       (.I0(\result[27]_i_3_n_0 ),
        .I1(\result[25]_i_2_n_0 ),
        .I2(\g_shift.amount_q [0]),
        .I3(\result[26]_i_2_n_0 ),
        .I4(\g_shift.amount_q [1]),
        .I5(\result[24]_i_2_n_0 ),
        .O(result_d[24]));
  LUT6 #(
    .INIT(64'hFF00FB0BFF00F808)) 
    \result[24]_i_2 
       (.I0(data_q[28]),
        .I1(\g_shift.amount_q [2]),
        .I2(\g_shift.amount_q [3]),
        .I3(\g_shift.g_right.g_dynamic.fill_q ),
        .I4(\g_shift.amount_q [4]),
        .I5(data_q[24]),
        .O(\result[24]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[25]_i_1 
       (.I0(\result[28]_i_3_n_0 ),
        .I1(\result[26]_i_2_n_0 ),
        .I2(\g_shift.amount_q [0]),
        .I3(\result[27]_i_3_n_0 ),
        .I4(\g_shift.amount_q [1]),
        .I5(\result[25]_i_2_n_0 ),
        .O(result_d[25]));
  LUT6 #(
    .INIT(64'hFF00FB0BFF00F808)) 
    \result[25]_i_2 
       (.I0(data_q[29]),
        .I1(\g_shift.amount_q [2]),
        .I2(\g_shift.amount_q [3]),
        .I3(\g_shift.g_right.g_dynamic.fill_q ),
        .I4(\g_shift.amount_q [4]),
        .I5(data_q[25]),
        .O(\result[25]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[26]_i_1 
       (.I0(\result[27]_i_2_n_0 ),
        .I1(\result[27]_i_3_n_0 ),
        .I2(\g_shift.amount_q [0]),
        .I3(\result[28]_i_3_n_0 ),
        .I4(\g_shift.amount_q [1]),
        .I5(\result[26]_i_2_n_0 ),
        .O(result_d[26]));
  LUT6 #(
    .INIT(64'hFF00FB0BFF00F808)) 
    \result[26]_i_2 
       (.I0(data_q[30]),
        .I1(\g_shift.amount_q [2]),
        .I2(\g_shift.amount_q [3]),
        .I3(\g_shift.g_right.g_dynamic.fill_q ),
        .I4(\g_shift.amount_q [4]),
        .I5(data_q[26]),
        .O(\result[26]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[27]_i_1 
       (.I0(\result[28]_i_2_n_0 ),
        .I1(\result[28]_i_3_n_0 ),
        .I2(\g_shift.amount_q [0]),
        .I3(\result[27]_i_2_n_0 ),
        .I4(\g_shift.amount_q [1]),
        .I5(\result[27]_i_3_n_0 ),
        .O(result_d[27]));
  LUT5 #(
    .INIT(32'hF0F1F0E0)) 
    \result[27]_i_2 
       (.I0(\g_shift.amount_q [2]),
        .I1(\g_shift.amount_q [3]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [4]),
        .I4(data_q[29]),
        .O(\result[27]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hF0F1F0E0)) 
    \result[27]_i_3 
       (.I0(\g_shift.amount_q [2]),
        .I1(\g_shift.amount_q [3]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [4]),
        .I4(data_q[27]),
        .O(\result[27]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[28]_i_1 
       (.I0(\result[29]_i_2_n_0 ),
        .I1(\g_shift.amount_q [0]),
        .I2(\result[28]_i_2_n_0 ),
        .I3(\g_shift.amount_q [1]),
        .I4(\result[28]_i_3_n_0 ),
        .O(result_d[28]));
  LUT5 #(
    .INIT(32'hF0F1F0E0)) 
    \result[28]_i_2 
       (.I0(\g_shift.amount_q [2]),
        .I1(\g_shift.amount_q [3]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [4]),
        .I4(data_q[30]),
        .O(\result[28]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hF0F1F0E0)) 
    \result[28]_i_3 
       (.I0(\g_shift.amount_q [2]),
        .I1(\g_shift.amount_q [3]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [4]),
        .I4(data_q[28]),
        .O(\result[28]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \result[29]_i_1 
       (.I0(\result[30]_i_2_n_0 ),
        .I1(\g_shift.amount_q [0]),
        .I2(\result[29]_i_2_n_0 ),
        .O(result_d[29]));
  LUT6 #(
    .INIT(64'hFF00FF01FF00FE00)) 
    \result[29]_i_2 
       (.I0(\g_shift.amount_q [1]),
        .I1(\g_shift.amount_q [2]),
        .I2(\g_shift.amount_q [3]),
        .I3(\g_shift.g_right.g_dynamic.fill_q ),
        .I4(\g_shift.amount_q [4]),
        .I5(data_q[29]),
        .O(\result[29]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \result[2]_i_1 
       (.I0(\result[3]_i_2_n_0 ),
        .I1(\g_shift.amount_q [0]),
        .I2(\result[2]_i_2_n_0 ),
        .O(result_d[2]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[2]_i_2 
       (.I0(\result[8]_i_3_n_0 ),
        .I1(\result[4]_i_3_n_0 ),
        .I2(\g_shift.amount_q [1]),
        .I3(\result[6]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[2]_i_3_n_0 ),
        .O(\result[2]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[2]_i_3 
       (.I0(data_q[26]),
        .I1(data_q[10]),
        .I2(\g_shift.amount_q [3]),
        .I3(data_q[18]),
        .I4(\g_shift.amount_q [4]),
        .I5(data_q[2]),
        .O(\result[2]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \result[30]_i_1 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(\g_shift.amount_q [0]),
        .I2(\result[30]_i_2_n_0 ),
        .O(result_d[30]));
  LUT6 #(
    .INIT(64'hFF00FF01FF00FE00)) 
    \result[30]_i_2 
       (.I0(\g_shift.amount_q [1]),
        .I1(\g_shift.amount_q [2]),
        .I2(\g_shift.amount_q [3]),
        .I3(\g_shift.g_right.g_dynamic.fill_q ),
        .I4(\g_shift.amount_q [4]),
        .I5(data_q[30]),
        .O(\result[30]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \result[3]_i_1 
       (.I0(\result[4]_i_2_n_0 ),
        .I1(\g_shift.amount_q [0]),
        .I2(\result[3]_i_2_n_0 ),
        .O(result_d[3]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[3]_i_2 
       (.I0(\result[9]_i_3_n_0 ),
        .I1(\result[5]_i_3_n_0 ),
        .I2(\g_shift.amount_q [1]),
        .I3(\result[7]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[3]_i_3_n_0 ),
        .O(\result[3]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[3]_i_3 
       (.I0(data_q[27]),
        .I1(data_q[11]),
        .I2(\g_shift.amount_q [3]),
        .I3(data_q[19]),
        .I4(\g_shift.amount_q [4]),
        .I5(data_q[3]),
        .O(\result[3]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \result[4]_i_1 
       (.I0(\result[5]_i_2_n_0 ),
        .I1(\g_shift.amount_q [0]),
        .I2(\result[4]_i_2_n_0 ),
        .O(result_d[4]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[4]_i_2 
       (.I0(\result[10]_i_3_n_0 ),
        .I1(\result[6]_i_3_n_0 ),
        .I2(\g_shift.amount_q [1]),
        .I3(\result[8]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[4]_i_3_n_0 ),
        .O(\result[4]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[4]_i_3 
       (.I0(data_q[28]),
        .I1(data_q[12]),
        .I2(\g_shift.amount_q [3]),
        .I3(data_q[20]),
        .I4(\g_shift.amount_q [4]),
        .I5(data_q[4]),
        .O(\result[4]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \result[5]_i_1 
       (.I0(\result[6]_i_2_n_0 ),
        .I1(\g_shift.amount_q [0]),
        .I2(\result[5]_i_2_n_0 ),
        .O(result_d[5]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[5]_i_2 
       (.I0(\result[11]_i_3_n_0 ),
        .I1(\result[7]_i_3_n_0 ),
        .I2(\g_shift.amount_q [1]),
        .I3(\result[9]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[5]_i_3_n_0 ),
        .O(\result[5]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[5]_i_3 
       (.I0(data_q[29]),
        .I1(data_q[13]),
        .I2(\g_shift.amount_q [3]),
        .I3(data_q[21]),
        .I4(\g_shift.amount_q [4]),
        .I5(data_q[5]),
        .O(\result[5]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \result[6]_i_1 
       (.I0(\result[7]_i_2_n_0 ),
        .I1(\g_shift.amount_q [0]),
        .I2(\result[6]_i_2_n_0 ),
        .O(result_d[6]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[6]_i_2 
       (.I0(\result[12]_i_3_n_0 ),
        .I1(\result[8]_i_3_n_0 ),
        .I2(\g_shift.amount_q [1]),
        .I3(\result[10]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[6]_i_3_n_0 ),
        .O(\result[6]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[6]_i_3 
       (.I0(data_q[30]),
        .I1(data_q[14]),
        .I2(\g_shift.amount_q [3]),
        .I3(data_q[22]),
        .I4(\g_shift.amount_q [4]),
        .I5(data_q[6]),
        .O(\result[6]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \result[7]_i_1 
       (.I0(\result[8]_i_2_n_0 ),
        .I1(\g_shift.amount_q [0]),
        .I2(\result[7]_i_2_n_0 ),
        .O(result_d[7]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[7]_i_2 
       (.I0(\result[13]_i_3_n_0 ),
        .I1(\result[9]_i_3_n_0 ),
        .I2(\g_shift.amount_q [1]),
        .I3(\result[11]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[7]_i_3_n_0 ),
        .O(\result[7]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[7]_i_3 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(data_q[15]),
        .I2(\g_shift.amount_q [3]),
        .I3(data_q[23]),
        .I4(\g_shift.amount_q [4]),
        .I5(data_q[7]),
        .O(\result[7]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \result[8]_i_1 
       (.I0(\result[9]_i_2_n_0 ),
        .I1(\g_shift.amount_q [0]),
        .I2(\result[8]_i_2_n_0 ),
        .O(result_d[8]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[8]_i_2 
       (.I0(\result[14]_i_3_n_0 ),
        .I1(\result[10]_i_3_n_0 ),
        .I2(\g_shift.amount_q [1]),
        .I3(\result[12]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[8]_i_3_n_0 ),
        .O(\result[8]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[8]_i_3 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(data_q[16]),
        .I2(\g_shift.amount_q [3]),
        .I3(data_q[24]),
        .I4(\g_shift.amount_q [4]),
        .I5(data_q[8]),
        .O(\result[8]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \result[9]_i_1 
       (.I0(\result[10]_i_2_n_0 ),
        .I1(\g_shift.amount_q [0]),
        .I2(\result[9]_i_2_n_0 ),
        .O(result_d[9]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[9]_i_2 
       (.I0(\result[15]_i_3_n_0 ),
        .I1(\result[11]_i_3_n_0 ),
        .I2(\g_shift.amount_q [1]),
        .I3(\result[13]_i_3_n_0 ),
        .I4(\g_shift.amount_q [2]),
        .I5(\result[9]_i_3_n_0 ),
        .O(\result[9]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[9]_i_3 
       (.I0(\g_shift.g_right.g_dynamic.fill_q ),
        .I1(data_q[17]),
        .I2(\g_shift.amount_q [3]),
        .I3(data_q[25]),
        .I4(\g_shift.amount_q [4]),
        .I5(data_q[9]),
        .O(\result[9]_i_3_n_0 ));
  FDRE \result_reg[0] 
       (.C(clk),
        .CE(1'b1),
        .D(result_d[0]),
        .Q(result[0]),
        .R(1'b0));
  FDRE \result_reg[10] 
       (.C(clk),
        .CE(1'b1),
        .D(result_d[10]),
        .Q(result[10]),
        .R(1'b0));
  FDRE \result_reg[11] 
       (.C(clk),
        .CE(1'b1),
        .D(result_d[11]),
        .Q(result[11]),
        .R(1'b0));
  FDRE \result_reg[12] 
       (.C(clk),
        .CE(1'b1),
        .D(result_d[12]),
        .Q(result[12]),
        .R(1'b0));
  FDRE \result_reg[13] 
       (.C(clk),
        .CE(1'b1),
        .D(result_d[13]),
        .Q(result[13]),
        .R(1'b0));
  FDRE \result_reg[14] 
       (.C(clk),
        .CE(1'b1),
        .D(result_d[14]),
        .Q(result[14]),
        .R(1'b0));
  FDRE \result_reg[15] 
       (.C(clk),
        .CE(1'b1),
        .D(result_d[15]),
        .Q(result[15]),
        .R(1'b0));
  FDRE \result_reg[16] 
       (.C(clk),
        .CE(1'b1),
        .D(result_d[16]),
        .Q(result[16]),
        .R(1'b0));
  FDRE \result_reg[17] 
       (.C(clk),
        .CE(1'b1),
        .D(result_d[17]),
        .Q(result[17]),
        .R(1'b0));
  FDRE \result_reg[18] 
       (.C(clk),
        .CE(1'b1),
        .D(result_d[18]),
        .Q(result[18]),
        .R(1'b0));
  FDRE \result_reg[19] 
       (.C(clk),
        .CE(1'b1),
        .D(result_d[19]),
        .Q(result[19]),
        .R(1'b0));
  FDRE \result_reg[1] 
       (.C(clk),
        .CE(1'b1),
        .D(result_d[1]),
        .Q(result[1]),
        .R(1'b0));
  FDRE \result_reg[20] 
       (.C(clk),
        .CE(1'b1),
        .D(result_d[20]),
        .Q(result[20]),
        .R(1'b0));
  FDRE \result_reg[21] 
       (.C(clk),
        .CE(1'b1),
        .D(result_d[21]),
        .Q(result[21]),
        .R(1'b0));
  FDRE \result_reg[22] 
       (.C(clk),
        .CE(1'b1),
        .D(result_d[22]),
        .Q(result[22]),
        .R(1'b0));
  FDRE \result_reg[23] 
       (.C(clk),
        .CE(1'b1),
        .D(result_d[23]),
        .Q(result[23]),
        .R(1'b0));
  FDRE \result_reg[24] 
       (.C(clk),
        .CE(1'b1),
        .D(result_d[24]),
        .Q(result[24]),
        .R(1'b0));
  FDRE \result_reg[25] 
       (.C(clk),
        .CE(1'b1),
        .D(result_d[25]),
        .Q(result[25]),
        .R(1'b0));
  FDRE \result_reg[26] 
       (.C(clk),
        .CE(1'b1),
        .D(result_d[26]),
        .Q(result[26]),
        .R(1'b0));
  FDRE \result_reg[27] 
       (.C(clk),
        .CE(1'b1),
        .D(result_d[27]),
        .Q(result[27]),
        .R(1'b0));
  FDRE \result_reg[28] 
       (.C(clk),
        .CE(1'b1),
        .D(result_d[28]),
        .Q(result[28]),
        .R(1'b0));
  FDRE \result_reg[29] 
       (.C(clk),
        .CE(1'b1),
        .D(result_d[29]),
        .Q(result[29]),
        .R(1'b0));
  FDRE \result_reg[2] 
       (.C(clk),
        .CE(1'b1),
        .D(result_d[2]),
        .Q(result[2]),
        .R(1'b0));
  FDRE \result_reg[30] 
       (.C(clk),
        .CE(1'b1),
        .D(result_d[30]),
        .Q(result[30]),
        .R(1'b0));
  FDRE \result_reg[3] 
       (.C(clk),
        .CE(1'b1),
        .D(result_d[3]),
        .Q(result[3]),
        .R(1'b0));
  FDRE \result_reg[4] 
       (.C(clk),
        .CE(1'b1),
        .D(result_d[4]),
        .Q(result[4]),
        .R(1'b0));
  FDRE \result_reg[5] 
       (.C(clk),
        .CE(1'b1),
        .D(result_d[5]),
        .Q(result[5]),
        .R(1'b0));
  FDRE \result_reg[6] 
       (.C(clk),
        .CE(1'b1),
        .D(result_d[6]),
        .Q(result[6]),
        .R(1'b0));
  FDRE \result_reg[7] 
       (.C(clk),
        .CE(1'b1),
        .D(result_d[7]),
        .Q(result[7]),
        .R(1'b0));
  FDRE \result_reg[8] 
       (.C(clk),
        .CE(1'b1),
        .D(result_d[8]),
        .Q(result[8]),
        .R(1'b0));
  FDRE \result_reg[9] 
       (.C(clk),
        .CE(1'b1),
        .D(result_d[9]),
        .Q(result[9]),
        .R(1'b0));
endmodule

(* ARITH = "0" *) (* ECO_CHECKSUM = "e9fb9ffd" *) (* FILL_KIND = "1" *) 
(* KIND = "1" *) (* MODE = "0" *) (* N = "31" *) 
(* RESULT_W = "31" *) (* SHIFT_W = "5" *) 
(* NotValidForBitStream *)
module primitive_v2_top
   (clk,
    data,
    amount,
    fill_val,
    result);
  input clk;
  input [30:0]data;
  input [4:0]amount;
  input fill_val;
  output [30:0]result;

  wire [4:0]amount;
  wire clk;
  wire clk_core;
  wire [30:0]data;
  wire fill_val;
  wire [30:0]result;

  primitive_v2_boundary u_boundary
       (.amount(amount),
        .clk(clk_core),
        .data(data),
        .fill_val(fill_val),
        .result(result));
  (* BOX_TYPE = "PRIMITIVE" *) 
  BUFG u_clock
       (.I(clk),
        .O(clk_core));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
