# Archive compact evidence and discard only this experiment's generated caches.
$ErrorActionPreference='Stop'
$root=(Resolve-Path -LiteralPath (Split-Path $PSScriptRoot -Parent)).Path
$study=(Resolve-Path -LiteralPath (Join-Path $root 'results/opt15_share_20261019')).Path
if(!$study.StartsWith($root+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)) {
    throw 'Study outside project'
}
$summary=Get-Content -LiteralPath "$study/summary.json" -Raw | ConvertFrom-Json
if($summary.status -ne 'TRIAL_COMPLETE_NO_PROMOTION') {throw 'Audit the completed trial first'}
$zipPath=Join-Path $study 'evidence.zip'
if(Test-Path -LiteralPath $zipPath) {throw 'Preserve existing evidence archive'}
$files=@(Get-ChildItem -LiteralPath $study -Recurse -File | Where-Object {
    $_.FullName -notmatch '\\(obj|work|appdata|localappdata|tmp|\.Xil)\\' -and
    $_.Extension -notin @('.wlf','.dcp','.jou','.str','.exe','.dll','.so','.gch','.o','.a','.d')
})
$extras=@(
    'scripts/prepare_opt15.py','scripts/verify_opt15.sh','scripts/verify_opt15_modelsim.ps1',
    'scripts/run_opt15_ppa.ps1','scripts/report_opt15.py','scripts/retain_opt15.ps1',
    'tb/opt15_compare.sv','tb/opt15_harness.cpp'
)
foreach($rel in $extras) {$files+=Get-Item -LiteralPath (Join-Path $root $rel)}
$files+=Get-ChildItem -LiteralPath "$root/rtl/candidates/mac_nf/opt15" -Recurse -File
foreach($format in @('8_0','16_1','32_2','32_3')) {
    foreach($folder in @('fixtures','protocol_fixtures')) {
        $files+=Get-Item -LiteralPath "$root/results/opt02b_20261017/$folder/mac_$format.txt"
    }
}
$files=@($files | Sort-Object FullName -Unique)
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$entries=@()
$archive=[IO.Compression.ZipFile]::Open($zipPath,[IO.Compression.ZipArchiveMode]::Create)
try {
    foreach($file in $files) {
        if(!$file.FullName.StartsWith($root+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)) {
            throw 'Evidence outside project'
        }
        if($file.Attributes -band [IO.FileAttributes]::ReparsePoint) {throw 'Refuse linked evidence'}
        $name=$file.FullName.Substring($root.Length+1).Replace('\','/')
        $digest=(Get-FileHash -LiteralPath $file.FullName).Hash.ToLowerInvariant()
        [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,$file.FullName,$name,[IO.Compression.CompressionLevel]::Optimal) | Out-Null
        $entries+=@{path=$name;bytes=$file.Length;sha256=$digest}
    }
} finally {$archive.Dispose()}
$archive=[IO.Compression.ZipFile]::OpenRead($zipPath)
try {
    if($archive.Entries.Count -ne $entries.Count) {throw 'Archive count mismatch'}
    foreach($item in $entries) {
        $entry=$archive.GetEntry($item.path)
        if(!$entry -or $entry.Length -ne $item.bytes) {throw 'Archive entry missing'}
        $stream=$entry.Open()
        $hasher=[Security.Cryptography.SHA256]::Create()
        try {$actual=([BitConverter]::ToString($hasher.ComputeHash($stream))).Replace('-','').ToLowerInvariant()}
        finally {$stream.Dispose();$hasher.Dispose()}
        if($actual -ne $item.sha256) {throw 'Archive content hash mismatch'}
    }
} finally {$archive.Dispose()}
$cache=@(Get-ChildItem -LiteralPath "$study/verification" -Recurse -File | Where-Object {
    $_.FullName -match '\\obj\\' -and $_.Extension -in @('.gch','.o','.a','.d')
})
$workFolders=@(Get-ChildItem -LiteralPath "$study/event" -Directory -Recurse | Where-Object {$_.Name -eq 'work'})
foreach($dir in $workFolders) {$cache+=Get-ChildItem -LiteralPath $dir.FullName -Recurse -File}
$cache+=Get-ChildItem -LiteralPath "$study/event" -Recurse -File -Filter '*.wlf'
$removed=@($cache | ForEach-Object {
    @{path=$_.FullName.Substring($root.Length+1).Replace('\','/');bytes=$_.Length}
})
@{status='ARCHIVE_VERIFIED';archive_sha256=(Get-FileHash -LiteralPath $zipPath).Hash.ToLowerInvariant();
    archive_bytes=(Get-Item -LiteralPath $zipPath).Length;entries=$entries;cache_removed=$removed;
    omitted='Generated obj/work/cache/wave/DCP/runtime. Native binaries and routed DCPs kept locally, excluded from ZIP/Git evidence.'} |
    ConvertTo-Json -Depth 6 | Set-Content -Encoding utf8 "$study/archive_manifest.json"
foreach($file in $cache) {
    $full=[IO.Path]::GetFullPath($file.FullName)
    if(!$full.StartsWith($study+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)) {
        throw 'Cache outside study'
    }
    if($file.Attributes -band [IO.FileAttributes]::ReparsePoint) {throw 'Refuse linked cache'}
    Remove-Item -LiteralPath $full -Force
}
# Only remove verified empty directories, never recurse over computed deletion roots.
$emptyCandidates=@(Get-ChildItem -LiteralPath "$study/event" -Directory -Recurse |
    Where-Object {$_.FullName -match '\\work($|\\)'})
foreach($dir in $emptyCandidates | Sort-Object {$_.FullName.Length} -Descending) {
    if(@(Get-ChildItem -LiteralPath $dir.FullName -Force).Count -eq 0) {
        if(!$dir.FullName.StartsWith($study+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)) {
            throw 'Empty directory outside study'
        }
        Remove-Item -LiteralPath $dir.FullName -Force
    }
}
foreach($item in $entries) {
    if((Get-FileHash -LiteralPath (Join-Path $root $item.path)).Hash.ToLowerInvariant() -ne $item.sha256) {
        throw 'Preserved evidence changed'
    }
}
Write-Output "OPT15 archive verified: $($entries.Count) entries; removed $($cache.Count) cache files, $([math]::Round(($cache | Measure-Object Length -Sum).Sum/1MB,2)) MiB"
