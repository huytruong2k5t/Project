#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
study="${F_SHARED_STUDY:-results/f_shared_add_20261020}"
[[ "$study" == results/* && "$study" != *..* ]] || exit 2
out="$study/verification"
if [[ "${1:-}" == stress ]]; then
    [[ -f "$out/pilot.json" && ! -e "$out/main.json" ]]
    export TMPDIR="$PWD/$out/tmp"
    "$out/obj/Vf_shared_add_compare" 10000000 "$out/main" 20261021 | tee "$out/main.log"
    exit 0
fi
[[ ! -e "$out" ]] || { echo 'Preserve existing verification evidence' >&2; exit 2; }
mkdir -p "$out/src/rtl" "$out/src/tb" "$out/src/l1/include" "$out/tmp"
export TMPDIR="$PWD/$out/tmp"
verilator --version > "$out/verilator.txt"
g++ --version > "$out/compiler.txt"
F_SHARED_STUDY="$study" python3 - <<'PY'
from pathlib import Path
import os
import shutil
r=Path.cwd(); study=r/os.environ['F_SHARED_STUDY']; o=study/'verification/src'
paths=(study/'source/reference/rtl/production.f').read_text().splitlines()
for rel in paths+['rtl/posit_mac.vh']:
    if Path(rel).name in ('mac_f_wrapper.sv','posit_mac_f.sv'):continue
    shutil.copy2(study/'source/reference'/rel,o/'rtl'/Path(rel).name)
for variant in ('reference','parser2','shared_add'):
    t=(study/'source'/variant/'rtl/mac_f/mac_f_wrapper.sv').read_text()
    (o/'rtl'/f'mac_f_wrapper_{variant}.sv').write_text(t.replace('module mac_f_wrapper #(',f'module mac_f_wrapper_{variant} #('))
for name in ('f_shared_add_compare.sv','f_shared_add_harness.cpp','week12_fused_reference.hpp',
             'nf_coverage_corpus.hpp','week11_model.hpp','week10_add_reference.hpp','week9_exact_reference.hpp'):
    shutil.copy2(r/'tb'/name,o/'tb'/name)
old=(r/'tb/week13_fused_harness.cpp').read_text()
(o/'tb/f_shared_add_corpus.hpp').write_text(old[old.index('struct Input'):old.index('int main(')])
for f in (r/'l1/include').glob('*.hpp'):shutil.copy2(f,o/'l1/include'/f.name)
PY
(
    cd "$out"
    sha256sum src/rtl/* src/tb/* src/l1/include/* > source.sha256
    verilator --lint-only --timing --assert -Wall --top-module f_shared_add_compare \
        -Isrc/rtl src/rtl/*.sv src/tb/f_shared_add_compare.sv > lint.log 2>&1
    verilator --cc --exe --no-timing --assert -Wall -Wno-ASSIGNDLY --top-module f_shared_add_compare \
        -Isrc/rtl --Mdir obj -CFLAGS '-O3 -std=c++17 -I../src/l1/include -I../src/tb' \
        src/rtl/*.sv src/tb/f_shared_add_compare.sv src/tb/f_shared_add_harness.cpp > build.log 2>&1
    make -C obj -f Vf_shared_add_compare.mk CURDIR=. -j4 >> build.log 2>&1
    sha256sum obj/Vf_shared_add_compare > binary.sha256
    ./obj/Vf_shared_add_compare 100000 pilot 20261020 | tee pilot.log
)
