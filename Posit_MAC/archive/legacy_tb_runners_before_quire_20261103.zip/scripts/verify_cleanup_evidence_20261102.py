"""Check preserved measurements/manifests and perform isolated restore self-tests."""
import hashlib
import importlib.util
import json
import sys
import zipfile
from pathlib import Path

root=Path(__file__).resolve().parent.parent
sys.dont_write_bytecode=True
batch=root/'archive/cleanup_20261102'
spec=importlib.util.spec_from_file_location('cleanup',root/'scripts/cleanup_rtl_results_20261102.py')
cleanup=importlib.util.module_from_spec(spec);spec.loader.exec_module(cleanup)
receipt=json.loads((batch/'receipt.json').read_text())
assert receipt['status']=='COMPLETE'
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifests=[]
for name in ['refactored_mac_20261101_r3','readme_refactor_recheck_20261101','parser_lod_refactor_recheck_20261101']:
    manifests.append(root/'results'/name/'manifest.json')
for name in ['p00','p01','p10','p20']:
    manifests.append(root/'results/f_timing_optimization_20261101'/name/'manifest.json')
checked=0
for manifest_path in manifests:
    manifest=json.loads(manifest_path.read_text(encoding='utf-8-sig'))
    for rel,value in manifest['sha256'].items():
        path=manifest_path.parent/'source'/rel
        assert digest(path).upper()==value.upper(),str(path)
        checked+=1
promotion=json.loads((root/'results/f_timing_optimization_20261101/promotion.json').read_text())
for rel,value in promotion['active_rtl_sha256'].items():assert digest(root/rel)==value,rel
for rel,value in promotion['nf_and_shared_rtl_unchanged'].items():assert digest(root/rel)==value,rel

destination='tmp/cleanup_restore_selftest_20261102'
test_root=cleanup.safe(destination)
if test_root.exists():raise RuntimeError('Preserve existing restore test directory')
tests=[]
for label in ['rtl_inactive','results_history','results_support']:
    archive=root/receipt['archives'][label]['file']
    with zipfile.ZipFile(archive) as z:index=json.loads(z.read('ARCHIVE_INDEX.json'))['entries']
    preferred='rtl/mac_f/fused_add_pipe.sv' if label=='rtl_inactive' else 'results/paper_fig3/summary.json' if label=='results_history' else None
    if preferred not in index:
        preferred=next(name for name,row in index.items() if 0<row['bytes']<32768
            and sum(other.startswith(name) for other in index)==1)
    row=index[preferred]
    cleanup.restore(preferred,destination)
    target=cleanup.safe(preferred,test_root)
    assert digest(target)==row['sha256'] and target.stat().st_size==row['bytes']
    tests.append({'archive':label,'file':preferred,'bytes':row['bytes'],'sha256':row['sha256'],'status':'PASS'})
    # Only remove bytes just restored and checked, within the named test root.
    assert target.resolve().is_relative_to(test_root.resolve())
    target.unlink()
for directory in sorted((p for p in test_root.rglob('*') if p.is_dir()),key=lambda p:len(p.parts),reverse=True):
    assert directory.resolve().is_relative_to(test_root.resolve());directory.rmdir()
test_root.rmdir()
report={'status':'PASS','source_manifests_checked':len(manifests),'source_file_hashes_checked':checked,
    'promoted_f_rtl_unchanged':True,'nf_and_shared_rtl_unchanged':True,
    'restore_self_tests':tests,'temporary_restore_copies_removed_after_hash_check':True,
    'simulation_or_synthesis_run':False}
(batch/'evidence_validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report),flush=True)
