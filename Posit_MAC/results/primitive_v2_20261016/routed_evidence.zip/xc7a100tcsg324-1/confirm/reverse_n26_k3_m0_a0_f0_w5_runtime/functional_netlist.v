// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2026.1 (win64) Build 6511674 Tue Jun 16 11:02:23 MDT 2026
// Date        : Fri Oct 16 17:07:30 2026
// Host        : MSI running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim {C:/HCMUT/HK261/Do an
//               2/Posit_MAC/results/primitive_v2_20261016/xc7a100tcsg324-1/confirm/reverse_n26_k3_m0_a0_f0_w5_runtime/functional_netlist.v}
// Design      : primitive_v2_top
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a100tcsg324-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module primitive_v2_boundary
   (result,
    data,
    CLK);
  output [31:0]result;
  input [25:0]data;
  input CLK;

  wire CLK;
  wire [25:0]data;
  wire [25:0]data_q;
  wire [4:0]\g_detector.count ;
  wire \g_detector.found ;
  wire \g_detector.u_lod/p_10_in ;
  wire \g_detector.u_lod/p_13_in ;
  wire \g_detector.u_lod/p_14_in ;
  wire \g_detector.u_lod/p_3_in ;
  wire \g_detector.u_lod/p_7_in ;
  wire \g_detector.u_lod/p_9_in ;
  wire [0:0]\g_detector.u_lod/tree_pos[4][0]__9 ;
  wire [17:16]\g_multi.stage[1] ;
  wire [15:8]\g_multi.stage[2] ;
  wire [23:4]\g_multi.stage[3] ;
  wire [5:2]\g_multi.stage[4] ;
  wire [31:0]result;
  wire \result[0]_i_1_n_0 ;
  wire \result[10]_i_1_n_0 ;
  wire \result[11]_i_1_n_0 ;
  wire \result[12]_i_1_n_0 ;
  wire \result[13]_i_1_n_0 ;
  wire \result[14]_i_1_n_0 ;
  wire \result[15]_i_1_n_0 ;
  wire \result[16]_i_1_n_0 ;
  wire \result[17]_i_1_n_0 ;
  wire \result[18]_i_1_n_0 ;
  wire \result[19]_i_1_n_0 ;
  wire \result[1]_i_1_n_0 ;
  wire \result[20]_i_1_n_0 ;
  wire \result[21]_i_1_n_0 ;
  wire \result[22]_i_1_n_0 ;
  wire \result[23]_i_1_n_0 ;
  wire \result[23]_i_3_n_0 ;
  wire \result[24]_i_1_n_0 ;
  wire \result[24]_i_3_n_0 ;
  wire \result[24]_i_4_n_0 ;
  wire \result[25]_i_10_n_0 ;
  wire \result[25]_i_11_n_0 ;
  wire \result[25]_i_12_n_0 ;
  wire \result[25]_i_13_n_0 ;
  wire \result[25]_i_14_n_0 ;
  wire \result[25]_i_15_n_0 ;
  wire \result[25]_i_16_n_0 ;
  wire \result[25]_i_17_n_0 ;
  wire \result[25]_i_18_n_0 ;
  wire \result[25]_i_1_n_0 ;
  wire \result[25]_i_2_n_0 ;
  wire \result[25]_i_4_n_0 ;
  wire \result[25]_i_6_n_0 ;
  wire \result[25]_i_7_n_0 ;
  wire \result[25]_i_8_n_0 ;
  wire \result[25]_i_9_n_0 ;
  wire \result[26]_i_2_n_0 ;
  wire \result[26]_i_3_n_0 ;
  wire \result[26]_i_5_n_0 ;
  wire \result[26]_i_6_n_0 ;
  wire \result[26]_i_7_n_0 ;
  wire \result[26]_i_8_n_0 ;
  wire \result[27]_i_3_n_0 ;
  wire \result[27]_i_4_n_0 ;
  wire \result[27]_i_5_n_0 ;
  wire \result[27]_i_6_n_0 ;
  wire \result[28]_i_2_n_0 ;
  wire \result[28]_i_3_n_0 ;
  wire \result[2]_i_1_n_0 ;
  wire \result[2]_i_2_n_0 ;
  wire \result[31]_i_5_n_0 ;
  wire \result[31]_i_6_n_0 ;
  wire \result[3]_i_1_n_0 ;
  wire \result[4]_i_1_n_0 ;
  wire \result[5]_i_1_n_0 ;
  wire \result[6]_i_1_n_0 ;
  wire \result[7]_i_1_n_0 ;
  wire \result[8]_i_1_n_0 ;
  wire \result[9]_i_1_n_0 ;
  wire [1:1]\tree_pos[4][1] ;

  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[0] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[0]),
        .Q(data_q[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[10] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[10]),
        .Q(data_q[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[11] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[11]),
        .Q(data_q[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[12] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[12]),
        .Q(data_q[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[13] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[13]),
        .Q(data_q[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[14] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[14]),
        .Q(data_q[14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[15] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[15]),
        .Q(data_q[15]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[16] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[16]),
        .Q(data_q[16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[17] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[17]),
        .Q(data_q[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[18] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[18]),
        .Q(data_q[18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[19] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[19]),
        .Q(data_q[19]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[1] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[1]),
        .Q(data_q[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[20] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[20]),
        .Q(data_q[20]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[21] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[21]),
        .Q(data_q[21]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[22] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[22]),
        .Q(data_q[22]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[23] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[23]),
        .Q(data_q[23]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[24] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[24]),
        .Q(data_q[24]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[25] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[25]),
        .Q(data_q[25]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[2] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[2]),
        .Q(data_q[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[3] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[3]),
        .Q(data_q[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[4] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[4]),
        .Q(data_q[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[5] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[5]),
        .Q(data_q[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[6] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[6]),
        .Q(data_q[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[7] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[7]),
        .Q(data_q[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[8] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[8]),
        .Q(data_q[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[9] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[9]),
        .Q(data_q[9]),
        .R(1'b0));
  LUT5 #(
    .INIT(32'h00001000)) 
    \result[0]_i_1 
       (.I0(\g_detector.count [1]),
        .I1(\g_detector.count [2]),
        .I2(\result[2]_i_2_n_0 ),
        .I3(data_q[0]),
        .I4(\g_detector.count [0]),
        .O(\result[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[10]_i_1 
       (.I0(\g_multi.stage[3] [7]),
        .I1(\g_multi.stage[3] [9]),
        .I2(\g_detector.count [0]),
        .I3(\g_multi.stage[3] [8]),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [10]),
        .O(\result[10]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'hB080)) 
    \result[10]_i_2 
       (.I0(data_q[3]),
        .I1(\g_detector.count [2]),
        .I2(\result[2]_i_2_n_0 ),
        .I3(data_q[7]),
        .O(\g_multi.stage[3] [7]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[11]_i_1 
       (.I0(\g_multi.stage[3] [8]),
        .I1(\g_multi.stage[3] [10]),
        .I2(\g_detector.count [0]),
        .I3(\g_multi.stage[3] [9]),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [11]),
        .O(\result[11]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hBBBBB88830003000)) 
    \result[11]_i_2 
       (.I0(data_q[4]),
        .I1(\g_detector.count [2]),
        .I2(data_q[0]),
        .I3(\result[24]_i_3_n_0 ),
        .I4(data_q[8]),
        .I5(\result[2]_i_2_n_0 ),
        .O(\g_multi.stage[3] [8]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[12]_i_1 
       (.I0(\g_multi.stage[3] [9]),
        .I1(\g_multi.stage[3] [11]),
        .I2(\g_detector.count [0]),
        .I3(\g_multi.stage[3] [10]),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [12]),
        .O(\result[12]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hBBBBB88830003000)) 
    \result[12]_i_2 
       (.I0(data_q[5]),
        .I1(\g_detector.count [2]),
        .I2(data_q[1]),
        .I3(\result[24]_i_3_n_0 ),
        .I4(data_q[9]),
        .I5(\result[2]_i_2_n_0 ),
        .O(\g_multi.stage[3] [9]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[13]_i_1 
       (.I0(\g_multi.stage[3] [10]),
        .I1(\g_multi.stage[3] [12]),
        .I2(\g_detector.count [0]),
        .I3(\g_multi.stage[3] [11]),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [13]),
        .O(\result[13]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hBBBBB88830003000)) 
    \result[13]_i_2 
       (.I0(data_q[6]),
        .I1(\g_detector.count [2]),
        .I2(data_q[2]),
        .I3(\result[24]_i_3_n_0 ),
        .I4(data_q[10]),
        .I5(\result[2]_i_2_n_0 ),
        .O(\g_multi.stage[3] [10]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[14]_i_1 
       (.I0(\g_multi.stage[3] [11]),
        .I1(\g_multi.stage[3] [13]),
        .I2(\g_detector.count [0]),
        .I3(\g_multi.stage[3] [12]),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [14]),
        .O(\result[14]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hBBBBB88830003000)) 
    \result[14]_i_2 
       (.I0(data_q[7]),
        .I1(\g_detector.count [2]),
        .I2(data_q[3]),
        .I3(\result[24]_i_3_n_0 ),
        .I4(data_q[11]),
        .I5(\result[2]_i_2_n_0 ),
        .O(\g_multi.stage[3] [11]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[15]_i_1 
       (.I0(\g_multi.stage[3] [12]),
        .I1(\g_multi.stage[3] [14]),
        .I2(\g_detector.count [0]),
        .I3(\g_multi.stage[3] [13]),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [15]),
        .O(\result[15]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hBBBBB888B888B888)) 
    \result[15]_i_2 
       (.I0(\g_multi.stage[2] [8]),
        .I1(\g_detector.count [2]),
        .I2(data_q[4]),
        .I3(\result[24]_i_3_n_0 ),
        .I4(data_q[12]),
        .I5(\result[2]_i_2_n_0 ),
        .O(\g_multi.stage[3] [12]));
  LUT6 #(
    .INIT(64'hB0B08080B0B0808A)) 
    \result[15]_i_3 
       (.I0(data_q[8]),
        .I1(\g_detector.u_lod/p_10_in ),
        .I2(\g_detector.u_lod/p_14_in ),
        .I3(data_q[1]),
        .I4(data_q[0]),
        .I5(\g_detector.u_lod/p_13_in ),
        .O(\g_multi.stage[2] [8]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[16]_i_1 
       (.I0(\g_multi.stage[3] [13]),
        .I1(\g_multi.stage[3] [15]),
        .I2(\g_detector.count [0]),
        .I3(\g_multi.stage[3] [14]),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [16]),
        .O(\result[16]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hBBBBB888B888B888)) 
    \result[16]_i_2 
       (.I0(\g_multi.stage[2] [9]),
        .I1(\g_detector.count [2]),
        .I2(data_q[5]),
        .I3(\result[24]_i_3_n_0 ),
        .I4(data_q[13]),
        .I5(\result[2]_i_2_n_0 ),
        .O(\g_multi.stage[3] [13]));
  LUT6 #(
    .INIT(64'hB080B080B080B08A)) 
    \result[16]_i_3 
       (.I0(data_q[9]),
        .I1(\g_detector.u_lod/p_10_in ),
        .I2(\g_detector.u_lod/p_14_in ),
        .I3(data_q[1]),
        .I4(data_q[0]),
        .I5(\g_detector.u_lod/p_13_in ),
        .O(\g_multi.stage[2] [9]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[17]_i_1 
       (.I0(\g_multi.stage[3] [14]),
        .I1(\g_multi.stage[3] [16]),
        .I2(\g_detector.count [0]),
        .I3(\g_multi.stage[3] [15]),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [17]),
        .O(\result[17]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF888FFFFF8880000)) 
    \result[17]_i_2 
       (.I0(data_q[2]),
        .I1(\result[24]_i_3_n_0 ),
        .I2(data_q[10]),
        .I3(\result[2]_i_2_n_0 ),
        .I4(\g_detector.count [2]),
        .I5(\g_multi.stage[2] [14]),
        .O(\g_multi.stage[3] [14]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[18]_i_1 
       (.I0(\g_multi.stage[3] [15]),
        .I1(\g_multi.stage[3] [17]),
        .I2(\g_detector.count [0]),
        .I3(\g_multi.stage[3] [16]),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [18]),
        .O(\result[18]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF888FFFFF8880000)) 
    \result[18]_i_2 
       (.I0(data_q[3]),
        .I1(\result[24]_i_3_n_0 ),
        .I2(data_q[11]),
        .I3(\result[2]_i_2_n_0 ),
        .I4(\g_detector.count [2]),
        .I5(\g_multi.stage[2] [15]),
        .O(\g_multi.stage[3] [15]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[19]_i_1 
       (.I0(\g_multi.stage[3] [16]),
        .I1(\g_multi.stage[3] [18]),
        .I2(\g_detector.count [0]),
        .I3(\g_multi.stage[3] [17]),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [19]),
        .O(\result[19]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hB888BBBBB888B888)) 
    \result[19]_i_2 
       (.I0(\g_multi.stage[2] [12]),
        .I1(\g_detector.count [2]),
        .I2(data_q[8]),
        .I3(\result[24]_i_3_n_0 ),
        .I4(\g_detector.count [3]),
        .I5(\g_multi.stage[1] [16]),
        .O(\g_multi.stage[3] [16]));
  LUT5 #(
    .INIT(32'hCA00CACC)) 
    \result[19]_i_3 
       (.I0(data_q[4]),
        .I1(data_q[12]),
        .I2(\g_detector.u_lod/p_10_in ),
        .I3(\g_detector.u_lod/p_14_in ),
        .I4(\result[28]_i_3_n_0 ),
        .O(\g_multi.stage[2] [12]));
  LUT5 #(
    .INIT(32'hFFCD00CC)) 
    \result[19]_i_4 
       (.I0(\g_detector.u_lod/p_13_in ),
        .I1(data_q[0]),
        .I2(data_q[1]),
        .I3(\g_detector.u_lod/p_14_in ),
        .I4(data_q[16]),
        .O(\g_multi.stage[1] [16]));
  LUT6 #(
    .INIT(64'h1011100000000000)) 
    \result[1]_i_1 
       (.I0(\g_detector.count [1]),
        .I1(\g_detector.count [2]),
        .I2(data_q[0]),
        .I3(\g_detector.count [0]),
        .I4(data_q[1]),
        .I5(\result[2]_i_2_n_0 ),
        .O(\result[1]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[20]_i_1 
       (.I0(\g_multi.stage[3] [17]),
        .I1(\g_multi.stage[3] [19]),
        .I2(\g_detector.count [0]),
        .I3(\g_multi.stage[3] [18]),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [20]),
        .O(\result[20]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hB888BBBBB888B888)) 
    \result[20]_i_2 
       (.I0(\g_multi.stage[2] [13]),
        .I1(\g_detector.count [2]),
        .I2(data_q[9]),
        .I3(\result[24]_i_3_n_0 ),
        .I4(\g_detector.count [3]),
        .I5(\g_multi.stage[1] [17]),
        .O(\g_multi.stage[3] [17]));
  LUT5 #(
    .INIT(32'hCA00CACC)) 
    \result[20]_i_3 
       (.I0(data_q[5]),
        .I1(data_q[13]),
        .I2(\g_detector.u_lod/p_10_in ),
        .I3(\g_detector.u_lod/p_14_in ),
        .I4(\result[28]_i_3_n_0 ),
        .O(\g_multi.stage[2] [13]));
  LUT5 #(
    .INIT(32'hFFF100F0)) 
    \result[20]_i_4 
       (.I0(\g_detector.u_lod/p_13_in ),
        .I1(data_q[0]),
        .I2(data_q[1]),
        .I3(\g_detector.u_lod/p_14_in ),
        .I4(data_q[17]),
        .O(\g_multi.stage[1] [17]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[21]_i_1 
       (.I0(\g_multi.stage[3] [18]),
        .I1(\g_multi.stage[3] [20]),
        .I2(\g_detector.count [0]),
        .I3(\g_multi.stage[3] [19]),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [21]),
        .O(\result[21]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hBBB8B8B8)) 
    \result[21]_i_2 
       (.I0(\g_multi.stage[2] [14]),
        .I1(\g_detector.count [2]),
        .I2(\result[25]_i_10_n_0 ),
        .I3(data_q[2]),
        .I4(\result[25]_i_12_n_0 ),
        .O(\g_multi.stage[3] [18]));
  LUT5 #(
    .INIT(32'hCA00CACC)) 
    \result[21]_i_3 
       (.I0(data_q[6]),
        .I1(data_q[14]),
        .I2(\g_detector.u_lod/p_10_in ),
        .I3(\g_detector.u_lod/p_14_in ),
        .I4(\result[28]_i_3_n_0 ),
        .O(\g_multi.stage[2] [14]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[22]_i_1 
       (.I0(\g_multi.stage[3] [19]),
        .I1(\g_multi.stage[3] [21]),
        .I2(\g_detector.count [0]),
        .I3(\g_multi.stage[3] [20]),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [22]),
        .O(\result[22]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hBBB8B8B8)) 
    \result[22]_i_2 
       (.I0(\g_multi.stage[2] [15]),
        .I1(\g_detector.count [2]),
        .I2(\result[25]_i_17_n_0 ),
        .I3(data_q[3]),
        .I4(\result[25]_i_12_n_0 ),
        .O(\g_multi.stage[3] [19]));
  LUT5 #(
    .INIT(32'hCA00CACC)) 
    \result[22]_i_3 
       (.I0(data_q[7]),
        .I1(data_q[15]),
        .I2(\g_detector.u_lod/p_10_in ),
        .I3(\g_detector.u_lod/p_14_in ),
        .I4(\result[28]_i_3_n_0 ),
        .O(\g_multi.stage[2] [15]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[23]_i_1 
       (.I0(\g_multi.stage[3] [20]),
        .I1(\g_multi.stage[3] [22]),
        .I2(\g_detector.count [0]),
        .I3(\g_multi.stage[3] [21]),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [23]),
        .O(\result[23]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF8FFF8FFF8FFF800)) 
    \result[23]_i_2 
       (.I0(data_q[8]),
        .I1(\result[24]_i_3_n_0 ),
        .I2(\result[23]_i_3_n_0 ),
        .I3(\g_detector.count [2]),
        .I4(\result[25]_i_6_n_0 ),
        .I5(\result[25]_i_7_n_0 ),
        .O(\g_multi.stage[3] [20]));
  LUT6 #(
    .INIT(64'hB888B88A30003002)) 
    \result[23]_i_3 
       (.I0(data_q[16]),
        .I1(\g_detector.u_lod/p_14_in ),
        .I2(\g_detector.u_lod/p_13_in ),
        .I3(data_q[0]),
        .I4(data_q[1]),
        .I5(\g_detector.u_lod/p_10_in ),
        .O(\result[23]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFAFCFC0AFA0CFC0)) 
    \result[24]_i_1 
       (.I0(\g_multi.stage[3] [21]),
        .I1(\g_multi.stage[3] [23]),
        .I2(\g_detector.count [0]),
        .I3(\result[25]_i_2_n_0 ),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [22]),
        .O(\result[24]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF8FFF8FFF8FFF800)) 
    \result[24]_i_2 
       (.I0(data_q[9]),
        .I1(\result[24]_i_3_n_0 ),
        .I2(\result[24]_i_4_n_0 ),
        .I3(\g_detector.count [2]),
        .I4(\result[25]_i_13_n_0 ),
        .I5(\result[25]_i_14_n_0 ),
        .O(\g_multi.stage[3] [21]));
  LUT2 #(
    .INIT(4'h4)) 
    \result[24]_i_3 
       (.I0(\g_detector.u_lod/p_10_in ),
        .I1(\g_detector.u_lod/p_14_in ),
        .O(\result[24]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hB8B8888A30300002)) 
    \result[24]_i_4 
       (.I0(data_q[17]),
        .I1(\g_detector.u_lod/p_14_in ),
        .I2(\g_detector.u_lod/p_13_in ),
        .I3(data_q[0]),
        .I4(data_q[1]),
        .I5(\g_detector.u_lod/p_10_in ),
        .O(\result[24]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hEFEFAFA0EFE0AFA0)) 
    \result[25]_i_1 
       (.I0(\result[25]_i_2_n_0 ),
        .I1(\g_multi.stage[3] [22]),
        .I2(\g_detector.count [0]),
        .I3(\result[25]_i_4_n_0 ),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [23]),
        .O(\result[25]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hCA00CACC)) 
    \result[25]_i_10 
       (.I0(data_q[10]),
        .I1(data_q[18]),
        .I2(\g_detector.u_lod/p_10_in ),
        .I3(\g_detector.u_lod/p_14_in ),
        .I4(\result[28]_i_3_n_0 ),
        .O(\result[25]_i_10_n_0 ));
  LUT5 #(
    .INIT(32'hCA00CACC)) 
    \result[25]_i_11 
       (.I0(data_q[14]),
        .I1(data_q[22]),
        .I2(\g_detector.u_lod/p_10_in ),
        .I3(\g_detector.u_lod/p_14_in ),
        .I4(\result[28]_i_3_n_0 ),
        .O(\result[25]_i_11_n_0 ));
  LUT2 #(
    .INIT(4'h4)) 
    \result[25]_i_12 
       (.I0(\g_detector.u_lod/p_14_in ),
        .I1(\g_detector.u_lod/p_13_in ),
        .O(\result[25]_i_12_n_0 ));
  LUT5 #(
    .INIT(32'hCA00CACC)) 
    \result[25]_i_13 
       (.I0(data_q[13]),
        .I1(data_q[21]),
        .I2(\g_detector.u_lod/p_10_in ),
        .I3(\g_detector.u_lod/p_14_in ),
        .I4(\result[28]_i_3_n_0 ),
        .O(\result[25]_i_13_n_0 ));
  LUT3 #(
    .INIT(8'h20)) 
    \result[25]_i_14 
       (.I0(\g_detector.u_lod/p_13_in ),
        .I1(\g_detector.u_lod/p_14_in ),
        .I2(data_q[5]),
        .O(\result[25]_i_14_n_0 ));
  LUT6 #(
    .INIT(64'hCC00A0A0CC00CCCC)) 
    \result[25]_i_15 
       (.I0(data_q[9]),
        .I1(data_q[25]),
        .I2(\g_detector.u_lod/p_13_in ),
        .I3(\g_detector.u_lod/p_10_in ),
        .I4(\g_detector.u_lod/p_14_in ),
        .I5(\result[28]_i_3_n_0 ),
        .O(\result[25]_i_15_n_0 ));
  LUT5 #(
    .INIT(32'h03008B88)) 
    \result[25]_i_16 
       (.I0(data_q[17]),
        .I1(\g_detector.u_lod/p_14_in ),
        .I2(\g_detector.u_lod/p_13_in ),
        .I3(data_q[1]),
        .I4(\g_detector.u_lod/p_10_in ),
        .O(\result[25]_i_16_n_0 ));
  LUT5 #(
    .INIT(32'hCA00CACC)) 
    \result[25]_i_17 
       (.I0(data_q[11]),
        .I1(data_q[19]),
        .I2(\g_detector.u_lod/p_10_in ),
        .I3(\g_detector.u_lod/p_14_in ),
        .I4(\result[28]_i_3_n_0 ),
        .O(\result[25]_i_17_n_0 ));
  LUT5 #(
    .INIT(32'hCA00CACC)) 
    \result[25]_i_18 
       (.I0(data_q[15]),
        .I1(data_q[23]),
        .I2(\g_detector.u_lod/p_10_in ),
        .I3(\g_detector.u_lod/p_14_in ),
        .I4(\result[28]_i_3_n_0 ),
        .O(\result[25]_i_18_n_0 ));
  LUT6 #(
    .INIT(64'h0000EEEE0000FFF0)) 
    \result[25]_i_2 
       (.I0(\result[25]_i_6_n_0 ),
        .I1(\result[25]_i_7_n_0 ),
        .I2(\result[25]_i_8_n_0 ),
        .I3(\result[25]_i_9_n_0 ),
        .I4(\g_detector.count [1]),
        .I5(\g_detector.count [2]),
        .O(\result[25]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hEFEFEFE0AFA0AFA0)) 
    \result[25]_i_3 
       (.I0(\result[25]_i_10_n_0 ),
        .I1(data_q[2]),
        .I2(\g_detector.count [2]),
        .I3(\result[25]_i_11_n_0 ),
        .I4(data_q[6]),
        .I5(\result[25]_i_12_n_0 ),
        .O(\g_multi.stage[3] [22]));
  LUT6 #(
    .INIT(64'h0000EEEE0000FFF0)) 
    \result[25]_i_4 
       (.I0(\result[25]_i_13_n_0 ),
        .I1(\result[25]_i_14_n_0 ),
        .I2(\result[25]_i_15_n_0 ),
        .I3(\result[25]_i_16_n_0 ),
        .I4(\g_detector.count [1]),
        .I5(\g_detector.count [2]),
        .O(\result[25]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hEFEFEFE0AFA0AFA0)) 
    \result[25]_i_5 
       (.I0(\result[25]_i_17_n_0 ),
        .I1(data_q[3]),
        .I2(\g_detector.count [2]),
        .I3(\result[25]_i_18_n_0 ),
        .I4(data_q[7]),
        .I5(\result[25]_i_12_n_0 ),
        .O(\g_multi.stage[3] [23]));
  LUT5 #(
    .INIT(32'hCA00CACC)) 
    \result[25]_i_6 
       (.I0(data_q[12]),
        .I1(data_q[20]),
        .I2(\g_detector.u_lod/p_10_in ),
        .I3(\g_detector.u_lod/p_14_in ),
        .I4(\result[28]_i_3_n_0 ),
        .O(\result[25]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h20)) 
    \result[25]_i_7 
       (.I0(\g_detector.u_lod/p_13_in ),
        .I1(\g_detector.u_lod/p_14_in ),
        .I2(data_q[4]),
        .O(\result[25]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hCC00A0A0CC00CCCC)) 
    \result[25]_i_8 
       (.I0(data_q[8]),
        .I1(data_q[24]),
        .I2(\g_detector.u_lod/p_13_in ),
        .I3(\g_detector.u_lod/p_10_in ),
        .I4(\g_detector.u_lod/p_14_in ),
        .I5(\result[28]_i_3_n_0 ),
        .O(\result[25]_i_8_n_0 ));
  LUT5 #(
    .INIT(32'h03008B88)) 
    \result[25]_i_9 
       (.I0(data_q[16]),
        .I1(\g_detector.u_lod/p_14_in ),
        .I2(\g_detector.u_lod/p_13_in ),
        .I3(data_q[0]),
        .I4(\g_detector.u_lod/p_10_in ),
        .O(\result[25]_i_9_n_0 ));
  LUT5 #(
    .INIT(32'hAA8AA080)) 
    \result[26]_i_1 
       (.I0(\g_detector.found ),
        .I1(\result[26]_i_2_n_0 ),
        .I2(\g_detector.u_lod/p_14_in ),
        .I3(\result[26]_i_3_n_0 ),
        .I4(\g_detector.u_lod/tree_pos[4][0]__9 ),
        .O(\g_detector.count [0]));
  LUT6 #(
    .INIT(64'hAAAAAAAAAAFFAAB8)) 
    \result[26]_i_2 
       (.I0(\result[26]_i_5_n_0 ),
        .I1(data_q[19]),
        .I2(data_q[18]),
        .I3(data_q[21]),
        .I4(data_q[20]),
        .I5(\g_detector.u_lod/p_7_in ),
        .O(\result[26]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000AAAAFFAE)) 
    \result[26]_i_3 
       (.I0(\result[26]_i_6_n_0 ),
        .I1(data_q[14]),
        .I2(data_q[15]),
        .I3(data_q[16]),
        .I4(data_q[17]),
        .I5(\g_detector.u_lod/p_10_in ),
        .O(\result[26]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'hF1)) 
    \result[26]_i_4 
       (.I0(\g_detector.u_lod/p_13_in ),
        .I1(data_q[1]),
        .I2(\result[26]_i_7_n_0 ),
        .O(\g_detector.u_lod/tree_pos[4][0]__9 ));
  LUT4 #(
    .INIT(16'h00F2)) 
    \result[26]_i_5 
       (.I0(data_q[22]),
        .I1(data_q[23]),
        .I2(data_q[24]),
        .I3(data_q[25]),
        .O(\result[26]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'h0031)) 
    \result[26]_i_6 
       (.I0(data_q[11]),
        .I1(\g_detector.u_lod/p_9_in ),
        .I2(data_q[12]),
        .I3(data_q[13]),
        .O(\result[26]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAAAFFAAB8)) 
    \result[26]_i_7 
       (.I0(\result[26]_i_8_n_0 ),
        .I1(data_q[3]),
        .I2(data_q[2]),
        .I3(data_q[5]),
        .I4(data_q[4]),
        .I5(\g_detector.u_lod/p_3_in ),
        .O(\result[26]_i_7_n_0 ));
  LUT4 #(
    .INIT(16'h00F2)) 
    \result[26]_i_8 
       (.I0(data_q[6]),
        .I1(data_q[7]),
        .I2(data_q[8]),
        .I3(data_q[9]),
        .O(\result[26]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAACC000C00)) 
    \result[27]_i_1 
       (.I0(\tree_pos[4][1] ),
        .I1(\result[28]_i_3_n_0 ),
        .I2(\result[27]_i_3_n_0 ),
        .I3(\g_detector.u_lod/p_13_in ),
        .I4(\result[27]_i_4_n_0 ),
        .I5(\g_detector.u_lod/p_14_in ),
        .O(\g_detector.count [1]));
  LUT6 #(
    .INIT(64'hAAAAFFFFAAAAFFF3)) 
    \result[27]_i_2 
       (.I0(\result[27]_i_5_n_0 ),
        .I1(\result[31]_i_5_n_0 ),
        .I2(data_q[19]),
        .I3(data_q[18]),
        .I4(\result[31]_i_6_n_0 ),
        .I5(\result[27]_i_6_n_0 ),
        .O(\tree_pos[4][1] ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \result[27]_i_3 
       (.I0(data_q[9]),
        .I1(data_q[8]),
        .I2(data_q[7]),
        .I3(data_q[6]),
        .I4(data_q[4]),
        .I5(data_q[5]),
        .O(\result[27]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'h000E)) 
    \result[27]_i_4 
       (.I0(data_q[7]),
        .I1(data_q[6]),
        .I2(data_q[8]),
        .I3(data_q[9]),
        .O(\result[27]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'h000E)) 
    \result[27]_i_5 
       (.I0(data_q[23]),
        .I1(data_q[22]),
        .I2(data_q[24]),
        .I3(data_q[25]),
        .O(\result[27]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'h000E)) 
    \result[27]_i_6 
       (.I0(data_q[15]),
        .I1(data_q[14]),
        .I2(data_q[16]),
        .I3(data_q[17]),
        .O(\result[27]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h20EC202020ECECEC)) 
    \result[28]_i_1 
       (.I0(\result[28]_i_2_n_0 ),
        .I1(\g_detector.u_lod/p_14_in ),
        .I2(\result[28]_i_3_n_0 ),
        .I3(\g_detector.u_lod/p_7_in ),
        .I4(\g_detector.u_lod/p_10_in ),
        .I5(\g_detector.u_lod/p_9_in ),
        .O(\g_detector.count [2]));
  LUT5 #(
    .INIT(32'h0000FFFE)) 
    \result[28]_i_2 
       (.I0(data_q[3]),
        .I1(data_q[2]),
        .I2(data_q[5]),
        .I3(data_q[4]),
        .I4(\g_detector.u_lod/p_3_in ),
        .O(\result[28]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    \result[28]_i_3 
       (.I0(data_q[3]),
        .I1(data_q[2]),
        .I2(\result[27]_i_3_n_0 ),
        .I3(data_q[0]),
        .I4(data_q[1]),
        .O(\result[28]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \result[28]_i_4 
       (.I0(data_q[22]),
        .I1(data_q[23]),
        .I2(data_q[24]),
        .I3(data_q[25]),
        .O(\g_detector.u_lod/p_7_in ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \result[28]_i_5 
       (.I0(data_q[14]),
        .I1(data_q[15]),
        .I2(data_q[16]),
        .I3(data_q[17]),
        .O(\g_detector.u_lod/p_9_in ));
  LUT5 #(
    .INIT(32'h555500FC)) 
    \result[29]_i_1 
       (.I0(\g_detector.u_lod/p_10_in ),
        .I1(data_q[1]),
        .I2(data_q[0]),
        .I3(\g_detector.u_lod/p_13_in ),
        .I4(\g_detector.u_lod/p_14_in ),
        .O(\g_detector.count [3]));
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    \result[29]_i_2 
       (.I0(\g_detector.u_lod/p_7_in ),
        .I1(data_q[20]),
        .I2(data_q[21]),
        .I3(data_q[18]),
        .I4(data_q[19]),
        .O(\g_detector.u_lod/p_10_in ));
  LUT6 #(
    .INIT(64'h1000FFFF10000000)) 
    \result[2]_i_1 
       (.I0(\g_detector.count [1]),
        .I1(\g_detector.count [2]),
        .I2(data_q[1]),
        .I3(\result[2]_i_2_n_0 ),
        .I4(\g_detector.count [0]),
        .I5(\g_multi.stage[4] [2]),
        .O(\result[2]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'h8888888B)) 
    \result[2]_i_2 
       (.I0(\g_detector.u_lod/p_10_in ),
        .I1(\g_detector.u_lod/p_14_in ),
        .I2(data_q[1]),
        .I3(data_q[0]),
        .I4(\g_detector.u_lod/p_13_in ),
        .O(\result[2]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'h00FE)) 
    \result[30]_i_1 
       (.I0(\g_detector.u_lod/p_13_in ),
        .I1(data_q[0]),
        .I2(data_q[1]),
        .I3(\g_detector.u_lod/p_14_in ),
        .O(\g_detector.count [4]));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \result[31]_i_1 
       (.I0(data_q[1]),
        .I1(data_q[0]),
        .I2(\g_detector.u_lod/p_13_in ),
        .I3(\g_detector.u_lod/p_14_in ),
        .O(\g_detector.found ));
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    \result[31]_i_2 
       (.I0(\g_detector.u_lod/p_3_in ),
        .I1(data_q[4]),
        .I2(data_q[5]),
        .I3(data_q[2]),
        .I4(data_q[3]),
        .O(\g_detector.u_lod/p_13_in ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \result[31]_i_3 
       (.I0(data_q[11]),
        .I1(data_q[10]),
        .I2(\result[31]_i_5_n_0 ),
        .I3(data_q[19]),
        .I4(data_q[18]),
        .I5(\result[31]_i_6_n_0 ),
        .O(\g_detector.u_lod/p_14_in ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \result[31]_i_4 
       (.I0(data_q[6]),
        .I1(data_q[7]),
        .I2(data_q[8]),
        .I3(data_q[9]),
        .O(\g_detector.u_lod/p_3_in ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \result[31]_i_5 
       (.I0(data_q[17]),
        .I1(data_q[16]),
        .I2(data_q[15]),
        .I3(data_q[14]),
        .I4(data_q[12]),
        .I5(data_q[13]),
        .O(\result[31]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \result[31]_i_6 
       (.I0(data_q[25]),
        .I1(data_q[24]),
        .I2(data_q[23]),
        .I3(data_q[22]),
        .I4(data_q[20]),
        .I5(data_q[21]),
        .O(\result[31]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[3]_i_1 
       (.I0(\g_multi.stage[4] [2]),
        .I1(\g_detector.count [0]),
        .I2(\g_multi.stage[4] [3]),
        .O(\result[3]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'h000088C0)) 
    \result[3]_i_2 
       (.I0(data_q[0]),
        .I1(\result[2]_i_2_n_0 ),
        .I2(data_q[2]),
        .I3(\g_detector.count [1]),
        .I4(\g_detector.count [2]),
        .O(\g_multi.stage[4] [2]));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \result[4]_i_1 
       (.I0(\g_multi.stage[4] [3]),
        .I1(\g_detector.count [0]),
        .I2(\g_multi.stage[4] [4]),
        .O(\result[4]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'h000088C0)) 
    \result[4]_i_2 
       (.I0(data_q[1]),
        .I1(\result[2]_i_2_n_0 ),
        .I2(data_q[3]),
        .I3(\g_detector.count [1]),
        .I4(\g_detector.count [2]),
        .O(\g_multi.stage[4] [3]));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \result[5]_i_1 
       (.I0(\g_multi.stage[4] [4]),
        .I1(\g_detector.count [0]),
        .I2(\g_multi.stage[4] [5]),
        .O(\result[5]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h30BB000030880000)) 
    \result[5]_i_2 
       (.I0(data_q[2]),
        .I1(\g_detector.count [1]),
        .I2(data_q[0]),
        .I3(\g_detector.count [2]),
        .I4(\result[2]_i_2_n_0 ),
        .I5(data_q[4]),
        .O(\g_multi.stage[4] [4]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[6]_i_1 
       (.I0(\g_multi.stage[4] [5]),
        .I1(\g_detector.count [0]),
        .I2(\g_multi.stage[3] [4]),
        .I3(\g_detector.count [1]),
        .I4(\g_multi.stage[3] [6]),
        .O(\result[6]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h30BB000030880000)) 
    \result[6]_i_2 
       (.I0(data_q[3]),
        .I1(\g_detector.count [1]),
        .I2(data_q[1]),
        .I3(\g_detector.count [2]),
        .I4(\result[2]_i_2_n_0 ),
        .I5(data_q[5]),
        .O(\g_multi.stage[4] [5]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[7]_i_1 
       (.I0(\g_multi.stage[3] [4]),
        .I1(\g_multi.stage[3] [6]),
        .I2(\g_detector.count [0]),
        .I3(\g_multi.stage[3] [5]),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [7]),
        .O(\result[7]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'hB080)) 
    \result[7]_i_2 
       (.I0(data_q[0]),
        .I1(\g_detector.count [2]),
        .I2(\result[2]_i_2_n_0 ),
        .I3(data_q[4]),
        .O(\g_multi.stage[3] [4]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[8]_i_1 
       (.I0(\g_multi.stage[3] [5]),
        .I1(\g_multi.stage[3] [7]),
        .I2(\g_detector.count [0]),
        .I3(\g_multi.stage[3] [6]),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [8]),
        .O(\result[8]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'hB080)) 
    \result[8]_i_2 
       (.I0(data_q[1]),
        .I1(\g_detector.count [2]),
        .I2(\result[2]_i_2_n_0 ),
        .I3(data_q[5]),
        .O(\g_multi.stage[3] [5]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[9]_i_1 
       (.I0(\g_multi.stage[3] [6]),
        .I1(\g_multi.stage[3] [8]),
        .I2(\g_detector.count [0]),
        .I3(\g_multi.stage[3] [7]),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [9]),
        .O(\result[9]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'hB080)) 
    \result[9]_i_2 
       (.I0(data_q[2]),
        .I1(\g_detector.count [2]),
        .I2(\result[2]_i_2_n_0 ),
        .I3(data_q[6]),
        .O(\g_multi.stage[3] [6]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[0] 
       (.C(CLK),
        .CE(1'b1),
        .D(\result[0]_i_1_n_0 ),
        .Q(result[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[10] 
       (.C(CLK),
        .CE(1'b1),
        .D(\result[10]_i_1_n_0 ),
        .Q(result[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[11] 
       (.C(CLK),
        .CE(1'b1),
        .D(\result[11]_i_1_n_0 ),
        .Q(result[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[12] 
       (.C(CLK),
        .CE(1'b1),
        .D(\result[12]_i_1_n_0 ),
        .Q(result[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[13] 
       (.C(CLK),
        .CE(1'b1),
        .D(\result[13]_i_1_n_0 ),
        .Q(result[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[14] 
       (.C(CLK),
        .CE(1'b1),
        .D(\result[14]_i_1_n_0 ),
        .Q(result[14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[15] 
       (.C(CLK),
        .CE(1'b1),
        .D(\result[15]_i_1_n_0 ),
        .Q(result[15]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[16] 
       (.C(CLK),
        .CE(1'b1),
        .D(\result[16]_i_1_n_0 ),
        .Q(result[16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[17] 
       (.C(CLK),
        .CE(1'b1),
        .D(\result[17]_i_1_n_0 ),
        .Q(result[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[18] 
       (.C(CLK),
        .CE(1'b1),
        .D(\result[18]_i_1_n_0 ),
        .Q(result[18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[19] 
       (.C(CLK),
        .CE(1'b1),
        .D(\result[19]_i_1_n_0 ),
        .Q(result[19]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[1] 
       (.C(CLK),
        .CE(1'b1),
        .D(\result[1]_i_1_n_0 ),
        .Q(result[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[20] 
       (.C(CLK),
        .CE(1'b1),
        .D(\result[20]_i_1_n_0 ),
        .Q(result[20]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[21] 
       (.C(CLK),
        .CE(1'b1),
        .D(\result[21]_i_1_n_0 ),
        .Q(result[21]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[22] 
       (.C(CLK),
        .CE(1'b1),
        .D(\result[22]_i_1_n_0 ),
        .Q(result[22]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[23] 
       (.C(CLK),
        .CE(1'b1),
        .D(\result[23]_i_1_n_0 ),
        .Q(result[23]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[24] 
       (.C(CLK),
        .CE(1'b1),
        .D(\result[24]_i_1_n_0 ),
        .Q(result[24]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[25] 
       (.C(CLK),
        .CE(1'b1),
        .D(\result[25]_i_1_n_0 ),
        .Q(result[25]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[26] 
       (.C(CLK),
        .CE(1'b1),
        .D(\g_detector.count [0]),
        .Q(result[26]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[27] 
       (.C(CLK),
        .CE(1'b1),
        .D(\g_detector.count [1]),
        .Q(result[27]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[28] 
       (.C(CLK),
        .CE(1'b1),
        .D(\g_detector.count [2]),
        .Q(result[28]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[29] 
       (.C(CLK),
        .CE(1'b1),
        .D(\g_detector.count [3]),
        .Q(result[29]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[2] 
       (.C(CLK),
        .CE(1'b1),
        .D(\result[2]_i_1_n_0 ),
        .Q(result[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[30] 
       (.C(CLK),
        .CE(1'b1),
        .D(\g_detector.count [4]),
        .Q(result[30]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[31] 
       (.C(CLK),
        .CE(1'b1),
        .D(\g_detector.found ),
        .Q(result[31]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[3] 
       (.C(CLK),
        .CE(1'b1),
        .D(\result[3]_i_1_n_0 ),
        .Q(result[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[4] 
       (.C(CLK),
        .CE(1'b1),
        .D(\result[4]_i_1_n_0 ),
        .Q(result[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[5] 
       (.C(CLK),
        .CE(1'b1),
        .D(\result[5]_i_1_n_0 ),
        .Q(result[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[6] 
       (.C(CLK),
        .CE(1'b1),
        .D(\result[6]_i_1_n_0 ),
        .Q(result[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[7] 
       (.C(CLK),
        .CE(1'b1),
        .D(\result[7]_i_1_n_0 ),
        .Q(result[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[8] 
       (.C(CLK),
        .CE(1'b1),
        .D(\result[8]_i_1_n_0 ),
        .Q(result[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[9] 
       (.C(CLK),
        .CE(1'b1),
        .D(\result[9]_i_1_n_0 ),
        .Q(result[9]),
        .R(1'b0));
endmodule

(* ARITH = "0" *) (* ECO_CHECKSUM = "e5983fee" *) (* FILL_KIND = "0" *) 
(* KIND = "3" *) (* MODE = "0" *) (* N = "26" *) 
(* RESULT_W = "32" *) (* SHIFT_W = "5" *) 
(* NotValidForBitStream *)
(* \DesignAttr:ENABLE_NOC_NETLIST_VIEW  *) 
(* \DesignAttr:ENABLE_AIE_NETLIST_VIEW  *) 
module primitive_v2_top
   (clk,
    data,
    amount,
    fill_val,
    result);
  input clk;
  input [25:0]data;
  input [4:0]amount;
  input fill_val;
  output [31:0]result;

  wire clk;
  wire clk_core;
  wire [25:0]data;
  wire [31:0]result;

  primitive_v2_boundary u_boundary
       (.CLK(clk_core),
        .data(data),
        .result(result));
  (* BOX_TYPE = "PRIMITIVE" *) 
  BUFG u_clock
       (.I(clk),
        .O(clk_core));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
