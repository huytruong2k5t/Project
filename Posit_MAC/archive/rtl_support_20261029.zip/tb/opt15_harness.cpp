#include <algorithm>
#include <array>
#include <fstream>
#include <iostream>
#include <random>
#include <stdexcept>
#include <string>
#include "Vopt15_compare.h"
#include "verilated.h"
#include "nf_coverage_corpus.hpp"
#ifndef PROFILE_NB
#define PROFILE_NB 32
#endif
#ifndef PROFILE_ES
#define PROFILE_ES 3
#endif
namespace {
constexpr int NB=PROFILE_NB, ES=PROFILE_ES, FW=NB-3-ES<12?NB-3-ES:12;
constexpr uint32_t MASK=uint32_t((uint64_t(1)<<NB)-1);
using Model=week11::Model<NB,ES,FW>;
void need(bool ok,const std::string& text) { if(!ok)throw std::runtime_error(text); }
}
int main(int argc,char** argv) try {
    need(argc==4,"usage: simulator count report.json seed");
    const uint64_t goal=std::stoull(argv[1]),seed=std::stoull(argv[3]);
    Verilated::commandArgs(argc,argv);
    Vopt15_compare dut;
    std::mt19937_64 rng(seed);
    uint64_t accepted=0,completed=0,aborts=0,cycles=0,stalls=0;
    uint64_t reset_busy=0,reset_stalled=0,commits=0,clears=0,invalid=0;
    uint64_t latency_min=100000,latency_max=0,start=0,cycle_checks=0;
    uint32_t accumulator=0,held_d=0;
    unsigned held_flags=0;
    bool pending=false,source=false,seen=false,held=false,pending_acc=false;
    unsigned reset_left=8;
    std::array<uint64_t,72> bins{};
    unsigned pending_bin=0;
    Model::Result expected{};
    dut.clk=0;dut.rst_n=0;dut.in_valid=0;dut.out_ready=0;
    dut.a=0;dut.b=0;dut.c=0;dut.acc_mode=0;dut.acc_clr=0;
    dut.cfg_mode=0;dut.cfg_n=0;dut.cfg_ops=0;
    while(completed<goal) {
        ++cycles;
        if(!reset_left && cycles%6001==0) {
            reset_left=3;reset_busy+=pending;reset_stalled+=held;
        }
        const bool reset=reset_left!=0;
        if(reset) {
            --reset_left;aborts+=pending;
            pending=false;source=false;held=false;accumulator=0;
        }
        if(!reset && !pending && !source && rng()%5) {
            const auto v=nf_coverage::Corpus<NB,ES>::next(rng,accepted,accumulator);
            dut.a=v.a;dut.b=v.b;dut.c=v.c;
            dut.cfg_mode=v.mode;dut.cfg_n=v.n;dut.cfg_ops=v.ops;
            dut.acc_mode=v.acc_mode;dut.acc_clr=v.acc_clr;
            source=true;
        } else if(pending && !source) {
            // All external operands and controls may change immediately after accept.
            dut.a=uint32_t(rng())&MASK;dut.b=uint32_t(rng())&MASK;dut.c=uint32_t(rng())&MASK;
            dut.cfg_mode=rng()%2;dut.cfg_n=rng()%16;dut.cfg_ops=rng()%4;
            dut.acc_mode=rng()%2;dut.acc_clr=rng()%2;
        }
        const bool invalid_request=!reset && !pending && !source;
        if(invalid_request) {
            dut.cfg_mode=1;
            switch(cycles%3) {
            case 0:dut.cfg_ops=2;dut.acc_clr=0;break;
            case 1:dut.cfg_ops=0;dut.cfg_n=9;dut.acc_clr=0;break;
            default:dut.cfg_ops=0;dut.cfg_n=0;dut.acc_mode=0;dut.acc_clr=1;break;
            }
        }
        dut.rst_n=!reset;
        dut.in_valid=!reset&&(source||invalid_request||pending);
        const bool long_block=cycles%4096>=64 && cycles%4096<160;
        dut.out_ready=!reset&&!long_block&&rng()%4!=0;
        dut.clk=0;dut.eval();
        if(!reset) {
            need(dut.ready==0||dut.ready==7,"ready differs cycle "+std::to_string(cycles));
            need(dut.valid==0||dut.valid==7,"valid/latency differs cycle "+std::to_string(cycles));
            ++cycle_checks;
            if(invalid_request){need(dut.ready==0,"invalid config accepted");++invalid;}
            if(held)need(dut.valid==7&&dut.d_ref==held_d&&dut.flags_ref==held_flags,"stalled output changed");
            if(dut.valid) {
                need(pending,"duplicate output");
                need(dut.d_ref==dut.d_parser&&dut.d_ref==dut.d_combined&&
                     dut.flags_ref==dut.flags_parser&&dut.flags_ref==dut.flags_combined,
                     "candidate value/flags differ, accepted="+std::to_string(accepted));
                need(dut.d_ref==expected.bits&&dut.flags_ref==expected.flags,
                     "reference or candidate differs from checked L1/oracles");
                if(!seen) {
                    const uint64_t latency=cycles-start-1;
                    need(latency==std::max(1u,expected.iterations)+12,"NF latency contract");
                    latency_min=std::min(latency_min,latency);latency_max=std::max(latency_max,latency);
                    if(pending_acc){accumulator=expected.bits;++commits;}
                    seen=true;
                }
            }
            if(dut.valid&&dut.out_ready) {
                ++completed;++bins[pending_bin];pending=false;
                if(completed%1000000==0)std::cout<<"OPT15 checkpoint "<<completed<<std::endl;
            }
            if(dut.in_valid&&dut.ready) {
                need(source&&!pending,"overlapping or invalid acceptance");
                const uint32_t ceff=dut.acc_mode?(dut.acc_clr?0:accumulator):uint32_t(dut.c);
                expected=Model::mac(dut.a,dut.b,ceff,!dut.cfg_mode,dut.cfg_n,dut.cfg_ops);
                pending_bin=unsigned(dut.cfg_n)+9*unsigned(dut.cfg_ops)
                           +18*unsigned(dut.cfg_mode)+36*unsigned(dut.acc_mode);
                pending_acc=dut.acc_mode;
                if(dut.acc_mode&&dut.acc_clr){accumulator=0;++clears;}
                ++accepted;pending=true;source=false;seen=false;start=cycles;
            }
            held=dut.valid&&!dut.out_ready;held_d=dut.d_ref;held_flags=dut.flags_ref;
            stalls+=held;
        }
        dut.clk=1;dut.eval();
        if(reset)need(dut.ready==0&&dut.valid==0,"reset gating");
        need(cycles<goal*150+10000,"deadlock");
    }
    need(accepted==completed+aborts,"reset accounting");
    need(stalls&&reset_busy&&reset_stalled&&commits&&clears&&invalid,"protocol coverage holes");
    for(auto n:bins)need(n!=0,"missing configuration/control bin");
    std::ofstream report(argv[2]);
    report<<"{\"status\":\"PASS\",\"NB\":"<<NB<<",\"ES\":"<<ES<<",\"seed\":"<<seed
          <<",\"completed_per_variant\":"<<completed<<",\"accepted\":"<<accepted
          <<",\"reset_aborts\":"<<aborts<<",\"cycles\":"<<cycles<<",\"cycle_equivalence_checks\":"<<cycle_checks
          <<",\"output_stalls\":"<<stalls<<",\"reset_busy\":"<<reset_busy<<",\"reset_stalled\":"<<reset_stalled
          <<",\"commits\":"<<commits<<",\"clears\":"<<clears<<",\"invalid_requests\":"<<invalid
          <<",\"first_valid_min\":"<<latency_min<<",\"first_valid_max\":"<<latency_max
          <<",\"mismatches\":0,\"bins\":[";
    for(unsigned i=0;i<bins.size();++i)report<<(i?",":"")<<bins[i];
    report<<"]}\n";
    dut.final();
    std::cout<<"OPT15 PASS NB="<<NB<<" ES="<<ES<<" completed_per_variant="<<completed
             <<" cycles="<<cycles<<" aborts="<<aborts<<" mismatches=0\n";
    return 0;
} catch(const std::exception& error) {std::cerr<<"OPT15 FAIL: "<<error.what()<<'\n';return 1;}
