import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {Presentation,PresentationFile} from '@oai/artifact-tool';
import {createCanvas} from '@napi-rs/canvas';

const BUILD=path.dirname(fileURLToPath(import.meta.url));
const ROOT=path.resolve(BUILD,'../..');
const FONT='Times New Roman';
const BLACK='#171717',GRAY='#626262',CTRL='#5F747A',PALE='#EDF1F2',WARM='#F3F0EA';
const p=Presentation.create({slideSize:{width:1920,height:1080}});
const manifest={release:'POSIT_MAC_RTL_20261018_OPT12_120',slides:[],source_sha256:{}};
const lock=JSON.parse(await fs.readFile(path.join(ROOT,'rtl/production_freeze.json'),'utf8'));
for(const [name,digest] of Object.entries(lock.rtl_sha256)){
 const bytes=await fs.readFile(path.join(ROOT,name));
 if(createHash('sha256').update(bytes).digest('hex')!==digest)throw new Error('Frozen RTL changed: '+name);
 manifest.source_sha256[name]=digest;
}
let sid=0,oid=0;let active=null;
const measure=createCanvas(10,10).getContext('2d');const fits=[];
function textWidth(text,size,bold=false){measure.font=`${bold?'bold ':''}${size}px "${FONT}"`;return Math.max(...text.split('\n').map(t=>measure.measureText(t).width));}
function shape(slide,geo,x,y,w,h,fill='none',stroke=BLACK,lw=1.8,name=''){
 return slide.shapes.add({geometry:geo,name:name||`s${sid}-o${++oid}`,position:{left:x,top:y,width:w,height:h},fill,
  line:{fill:stroke,width:lw,style:'solid'}});
}
function txt(s,text,x,y,w,h,size=25,{bold=false,align='center',color=BLACK,italic=false,fill='none'}={}){
 if(align==='right'){const tw=textWidth(text,size,bold);x=x+w-tw;w=tw+2;align='left';}
 if(textWidth(text,size,bold)>w+3)fits.push({slide:sid,text,width:w,measured:textWidth(text,size,bold),size});
 const a=shape(s,'textbox',x,y,w,h,fill,'none',0,`text-${++oid}`);a.text=text;
 a.text.style={typeface:FONT,fontSize:size,bold,color,italic,alignment:align,verticalAlignment:'middle',
  insets:0,autoFit:'none',wrap:'none',lineSpacing:1.06};return a;
}
function box(s,text,x,y,w,h,{size=25,fill='#FFFFFF',stroke=BLACK,bold=false}={}){
 if(textWidth(text,size,bold)>w-8)fits.push({slide:sid,text,width:w-8,measured:textWidth(text,size,bold),size});
 const a=shape(s,'rect',x,y,w,h,fill,stroke);a.text=text;
 a.text.style={typeface:FONT,fontSize:size,bold,color:BLACK,alignment:'center',verticalAlignment:'middle',
  insets:5,autoFit:'none',wrap:'none',lineSpacing:1.06};return a;
}
function custom(s,points,x,y,w,h,fill='#FFFFFF',stroke=BLACK,name=''){
 return s.shapes.add({geometry:'custom',name:name||`custom-${++oid}`,position:{left:x,top:y,width:w,height:h},fill,
  line:{fill:stroke,width:1.8,style:'solid'},customPaths:[{width:w,height:h,commands:[
   {moveTo:{x:points[0][0],y:points[0][1]}},...points.slice(1).map(([x,y])=>({lineTo:{x,y}})),{close:{}}]}]});
}
function seg(s,x1,y1,x2,y2,{arrow=false,color=BLACK,width=2,dash=false}={}){
 if(Math.abs(x1-x2)>0.1&&Math.abs(y1-y2)>0.1)throw new Error('Only orthogonal wires');
 return s.shapes.add({geometry:'connector',kind:'straight',name:`wire-${++oid}`,
  position:{left:Math.min(x1,x2),top:Math.min(y1,y2),width:Math.abs(x2-x1),height:Math.abs(y2-y1),horizontalFlip:x2<x1,verticalFlip:y2<y1},
  line:{fill:color,width,style:dash?'dashed':'solid'},tail:arrow?{type:'arrow',width:'sm',length:'sm'}:{type:'none'}});
}
function wire(s,points,opts={}){for(let i=1;i<points.length;i++)seg(s,...points[i-1],...points[i],{...opts,arrow:!!opts.arrow&&i===points.length-1});}
function dot(s,x,y,color=BLACK){shape(s,'ellipse',x-3,y-3,6,6,color,'none',0);}
function bank(s,x,top,height,label,{size=23,id=null,side='bottom'}={}){
 const tag=id||label;
 shape(s,'rect',x,top,10,height,'#FFFFFF',BLACK,1.8,`BANK-${tag}`);
 const cy=side==='bottom'?top+height:top-18;
 shape(s,'rect',x-4,cy,18,18,'#FFFFFF',BLACK,1.5,`CLOCK-SQUARE-${tag}`);
 custom(s,[[3,13],[9,5],[15,13]],x-4,cy,18,18,'none',BLACK,`CLOCK-EDGE-${tag}`);
 if(label)txt(s,label,x-57,top-48,124,40,size,{bold:true});
 active.banks.push({id:tag,label,x,top,height});
 return {x,left:x,right:x+10,top,bottom:top+height};
}
function mux(s,x,y,w=34,h=90,{left=false,name='MUX'}={}){
 return custom(s,left?[[w,0],[w,h],[0,h*.78],[0,h*.22]]:[[0,0],[w,h*.22],[w,h*.78],[0,h]],x,y,w,h,'#FFFFFF',BLACK,name+'-'+(++oid));
}
function alu(s,x,y,w=100,h=110,label='+ / −'){
 const a=custom(s,[[0,0],[w,h*.2],[w,h*.8],[0,h],[0,h*.63],[w*.16,h*.5],[0,h*.37]],x,y,w,h);
 txt(s,label,x+15,y+20,w-20,h-40,30);return a;
}
function plus(s,x,y,d=58,label='+'){
 const a=shape(s,'ellipse',x,y,d,d,'#FFFFFF');txt(s,label,x,y,d,d,34);return a;
}
function brace(s,label,x1,x2,y){seg(s,x1,y,x2,y,{width:1,color:GRAY});seg(s,x1,y,x1,y+10,{width:1,color:GRAY});seg(s,x2,y,x2,y+10,{width:1,color:GRAY});txt(s,label,x1,y-42,x2-x1,34,25,{bold:true});}
function base(title,subtitle,notes){
 sid++;const s=p.slides.add();s.background.fill='#FFFFFF';active={number:sid,title,banks:[]};manifest.slides.push(active);
 txt(s,title,55,28,1800,70,46,{align:'left',bold:true});
 txt(s,subtitle,57,106,1800,45,27,{align:'left'});seg(s,55,168,1865,168,{width:1,color:'#A4A4A4'});
 txt(s,'RTL OPT12_120 · Posit(32,3)',58,1028,700,30,19,{align:'left',color:GRAY});
 txt(s,String(sid).padStart(2,'0'),1818,1025,48,32,21,{align:'right',color:GRAY});
 s.speakerNotes.text=notes;return s;
}
function noteSources(names,extra=''){
 return ['Nguồn RTL production đã khóa: '+lock.release_id,
  ...names.map(n=>path.join(ROOT,n)),extra].join('\n');
}
function overview(fused){
 const nf=['Parser\nP1','Parser\nP2','OPS','SAC','SBM\nshift','SBM\nacc','Norm +\nProd P1','Prod P2\nRNE','Mag.\nparse','Add A1\nAlign','Add A2\n+ / −','Add A3\nNorm','Pack P1\nGRS','Pack P2\nRNE'];
 const ff=['Parser\nP1','Parser\nP2','OPS','SAC','SBM\nshift','SBM\nacc','F1\nPrepare','F2\nAlign','F3\n+ / −','F4\nABS','F5\nNorm','Pack P1\nGRS','Pack P2\nRNE'];
 const stages=fused?ff:nf;
 const s=base(fused?'MAC fused: toàn bộ 13 tầng RTL':'MAC non-fused: toàn bộ 14 tầng RTL',
  fused?'D = RNE(P̂ + C_eff), FW12, W32/Q29, approximate-only':'D = RNE(RNE(P̂) + C_eff), FW12, FLOOR/RNE; NF còn hỗ trợ exact',
  noteSources([fused?'rtl/mac_f/mac_f_wrapper.sv':'rtl/mac_nf/mac_nf_wrapper.sv','rtl/multiplier/mul_iter_core.sv','rtl/production_freeze.json'],
  'S01..S14 hoặc S01..S13 là nhóm thanh ghi trên đường kết quả. Các bank A/B/C parser chạy song song, không cộng ba lần số tầng. C_context chốt tại pair_retire và giữ nguyên đến cuối giao dịch, cùng cạnh M0. Các FF config/feedback/reset không cộng nối tiếp vào số tầng dữ liệu. q=max(1,số vòng thực hiện), không mặc định q=n. NF: Lvalid=q+12,H=q+13,II=q+14. F:Lvalid=q+11,H=q+12,II=q+13. RNE product NF tính trên magnitude, sign lưu riêng.'));
 const start=100,pitch=fused?130:121,bw=96,ry=402,rh=180,y=480;
 const xs=stages.map((_,i)=>start+i*pitch),rx=xs.map(x=>x+bw+10),end=rx.at(-1)+10;
 txt(s,fused?'13 bank dữ liệu, RNE cuối':'14 bank dữ liệu, 2 lần RNE',58,200,1080,48,32,{align:'left',bold:true});
 txt(s,fused?'L_valid = q + 11     II_min = q + 13':'L_valid = q + 12     II_min = q + 14',1140,200,710,48,28,{align:'right'});
 txt(s,'q = max(1, số vòng fraction thực hiện)',58,252,900,29,23,{align:'left',color:GRAY});
 brace(s,'Parser A / B / C',start,rx[1]+10,330);
 brace(s,'Nhân lặp: SAC / SBM',xs[2],rx[5]+10,330);
 brace(s,fused?'Fused add: F1…F5':'Làm tròn tích + Posit add',xs[6],rx[fused?10:11]+10,330);
 brace(s,'Packer cuối',xs[fused?11:12],end,330);
 for(let i=0;i<stages.length;i++){
  const round=fused?i===12:i===7||i===13;
  box(s,stages[i],xs[i],432,bw,112,{size:24,fill:round?WARM:'#FFFFFF'});
  if(i)seg(s,rx[i-1]+10,y,xs[i],y,{arrow:true});
  seg(s,xs[i]+bw,y,rx[i],y,{arrow:true});
  bank(s,rx[i],ry,rh,`S${String(i+1).padStart(2,'0')}`,{id:`S${String(i+1).padStart(2,'0')}`});
 }
 txt(s,'A, B',14,431,75,35,25);seg(s,30,y,100,y,{arrow:true});
 txt(s,'A / B / C',xs[0]-1,554,101,30,20);txt(s,'sf, frac',xs[1]-4,554,104,30,20);
 seg(s,end,y,1872,y,{arrow:true});txt(s,'D[31:0]',1770,421,135,34,25,{align:'right'});
 seg(s,end,534,1872,534,{arrow:true});txt(s,'flags[4:0]',1770,550,136,35,23,{align:'right'});
 // C_context: a held side bank at the M0 edge, not a chain of dummy registers.
 const cx=rx[2],addx=xs[fused?6:9];
 wire(s,[[rx[1]+10,521],[rx[1]+13,521],[rx[1]+13,679],[cx,679]],{arrow:true});dot(s,rx[1]+10,521);
 bank(s,cx,651,58,'',{id:'C_CONTEXT_AT_M0'});
 wire(s,[[cx+10,679],[addx+48,679],[addx+48,544]],{arrow:true});
 txt(s,'C_context: sign, sf, frac, Zero/NaR',cx+35,687,680,37,24,{align:'left'});
 txt(s,'Giữ trong thời gian nhân lặp',cx+35,725,570,34,23,{align:'left',color:GRAY});
 // SAC uses its state recursively; no path from the accumulator back into SAC.
 wire(s,[[xs[3]+75,544],[xs[3]+75,610],[xs[3]+14,610],[xs[3]+14,544]],{arrow:true,width:1.6});
 txt(s,'q bước',xs[3]+4,618,88,31,21);
 // Result feedback runs right-to-left across the lower page.
 const fy=868,fx=1677;
 wire(s,[[end+29,y],[end+29,fy],[fx+10,fy]],{arrow:true});dot(s,end+29,y);
 bank(s,fx,830,76,'',{id:'ACCUMULATOR_FEEDBACK'});
 wire(s,[[fx,fy],[532,fy],[532,890],[375,890]],{arrow:true});
 txt(s,'accumulator_q[31:0]',1330,922,400,35,25,{align:'right'});
 txt(s,'CE: commit một lần khi kết quả xuất hiện',1045,811,590,35,23,{align:'right',color:CTRL});
 mux(s,340,823,35,90,{left:true,name:'C_CLEAR_MUX'});
 seg(s,495,846,375,846,{arrow:true});txt(s,'0',484,809,35,30,24);
 txt(s,'acc_clr',302,776,110,35,23,{color:CTRL});seg(s,357,811,357,823,{arrow:true,color:CTRL,dash:true});
 seg(s,340,868,214,868,{arrow:true});
 mux(s,180,823,34,90,{left:true,name:'C_MODE_MUX'});
 wire(s,[[316,957],[240,957],[240,890],[214,890]],{arrow:true});txt(s,'C_port[31:0]',266,942,190,36,25,{align:'left'});
 txt(s,'acc_mode',132,776,150,35,23,{color:CTRL});seg(s,197,811,197,823,{arrow:true,color:CTRL,dash:true});
 wire(s,[[180,868],[75,868],[75,519],[100,519]],{arrow:true});txt(s,'C_eff',5,750,107,35,24);
 txt(s,'Nét liền: dữ liệu     Nét đứt: điều khiển     Thanh mảnh có ô clock: bank FF',520,957,1180,36,24,{align:'left',color:GRAY});
 return s;
}
overview(false);overview(true);

// 03: parser and OPS have explicitly separated, parallel count and data lanes.
{
 const s=base('Parser và OPS: các nhánh xử lý song song','S01 / S02 / S03(M0), minh họa một parser; A, B và C có ba instance độc lập',
  noteSources(['rtl/parser/posit_parser.sv','rtl/multiplier/ops_sel_comb.sv','rtl/mac_nf/mac_nf_wrapper.sv'],
  'Production OPT12 dùng adjacent XOR magnitude[29:0]^magnitude[30:1], append sentinel1, một LOD31bit; không dùng bản tail XOR r trước OPT12. P2 payload29bit dịchcnt, e3bit, frac26bit, scale11signed. OPS count high12 trực tiếp, low14 masked !cfg_mode. Hai data candidates chuẩn bị độc lập count. choose_b chỉ điều khiển2 mux hoán đổi song song, X không có hidden1, Y có hidden1. Bypass Zero/NaR ở wrapper đặt X,Y=0, giữ lịch token. Metadata sign/sf/cut chốt cùng M0; C_context chốt cùng pair_retire.'));
 brace(s,'Parser P1',65,646,223);brace(s,'Parser P2',693,1105,223);brace(s,'OPS: control và data độc lập',1170,1797,223);
 txt(s,'p[31:0]',12,442,95,45,25);seg(s,35,500,120,500,{arrow:true});
 box(s,'Bù hai theo dấu\nm = (p XOR s) + s',120,446,196,108,{size:24});
 dot(s,336,500);seg(s,316,500,336,500);
 wire(s,[[336,500],[336,335],[360,335]],{arrow:true});
 box(s,'Adjacent XOR\n+ sentinel 1',360,294,148,82,{size:23});
 box(s,'LOD 31\ncnt[4:0]',530,294,110,82,{size:23});seg(s,508,335,530,335,{arrow:true});seg(s,640,335,660,335,{arrow:true});
 wire(s,[[336,500],[336,654],[660,654]],{arrow:true});txt(s,'payload_seed = m[28:0]',340,610,300,38,23);
 wire(s,[[336,500],[660,500]],{arrow:true});txt(s,'FRB = m[30]',385,455,230,35,23);
 box(s,'Zero / NaR',120,735,196,66,{size:24});wire(s,[[100,500],[100,768],[120,768]],{arrow:true});seg(s,316,768,660,768,{arrow:true});
 bank(s,660,277,540,'S01 / P1',{id:'PARSER_P1',size:25});
 box(s,'Payload << cnt\nk từ cnt và FRB\nsf = signed({k,e})\nfrac = payload[25:0]',750,420,320,196,{size:27});
 wire(s,[[670,335],[721,335],[721,459],[750,459]],{arrow:true});
 wire(s,[[670,654],[712,654],[712,570],[750,570]],{arrow:true});
 wire(s,[[670,500],[750,500]],{arrow:true});seg(s,1070,520,1125,520,{arrow:true});
 wire(s,[[670,768],[1125,768]],{arrow:true});txt(s,'Canonical Zero / NaR',745,710,340,36,24,{color:GRAY});
 bank(s,1125,277,540,'S02 / P2',{id:'PARSER_P2',size:25});
 txt(s,'s, sf[10:0], frac[25:0]',739,648,350,38,24);
 box(s,'High12 trực tiếp\nLow14 & !mode\nPopcount A / B',1223,294,195,95,{size:23});
 box(s,'B < A\nOPS1 enable',1470,294,150,95,{size:24});seg(s,1418,341,1470,341,{arrow:true});
 wire(s,[[1135,520],[1180,520],[1180,341],[1223,341]],{arrow:true});dot(s,1180,520);
 box(s,'Chuẩn bị cả A và B\nxA, xB: high12, không hidden\nyA, yB: {1, high12}\nNF exact dùng đầy đủ 26 bit',1223,568,365,160,{size:25,fill:PALE});
 wire(s,[[1180,520],[1180,648],[1223,648]],{arrow:true});
 mux(s,1648,520,40,200,{name:'OPS_SWAP_PAIR'});
 wire(s,[[1588,620],[1615,620],[1615,563],[1648,563]],{arrow:true});
 wire(s,[[1588,681],[1629,681],[1629,676],[1648,676]],{arrow:true});
 txt(s,'0: xA,yB',1450,486,190,35,23);txt(s,'1: xB,yA',1470,737,170,35,23);
 wire(s,[[1620,341],[1668,341],[1668,520]],{arrow:true,color:CTRL,dash:true});
 txt(s,'choose_b',1621,400,155,35,24,{color:CTRL});
 txt(s,'Hai MUX X/Y song song',1223,433,355,36,24,{align:'left'});
 mux(s,1749,551,36,136,{name:'OPS_BYPASS_ZERO'});seg(s,1688,620,1749,620,{arrow:true});
 wire(s,[[1703,758],[1725,758],[1725,657],[1749,657]],{arrow:true});txt(s,'0',1685,744,35,34,24);
 wire(s,[[1715,842],[1767,842],[1767,687]],{arrow:true,color:CTRL,dash:true});
 txt(s,'bypass Zero/NaR',1565,846,230,33,23,{color:CTRL});
 seg(s,1785,620,1825,620,{arrow:true});bank(s,1825,277,680,'S03 / M0',{id:'OPS_M0',size:25});
 seg(s,1835,620,1890,620,{arrow:true});txt(s,'X / Y',1815,680,94,38,24);
 box(s,'sfA + sfB, sA XOR sB\ninput_cut = OR(low14) ở approx',1223,902,485,70,{size:24});
 wire(s,[[1135,520],[1192,520],[1192,936],[1223,936]],{arrow:true});
 wire(s,[[1708,936],[1825,936]],{arrow:true});
 txt(s,'Cùng cạnh M0: giữ C_context và metadata; không thêm tầng giữa popcount và Swap MUX',65,974,1750,39,26,{align:'left'});
}

// 04: one shared core schematic with visible state loops, token and term banks.
{
 const s=base('Lõi nhân lặp: M0, SAC, SBM dịch và SBM tích lũy','Posit(32,3): NF ACC_W=54 (EXACT_EN1), F ACC_W=16/Q14 (EXACT_EN0)',
  noteSources(['rtl/multiplier/mul_iter_core.sv','rtl/multiplier/iter_ctrl.sv','rtl/multiplier/sac_step_comb.sv','rtl/multiplier/sbm_shift_comb.sv','rtl/multiplier/sbm_accum.sv','rtl/multiplier/sbm_accum_comb.sv'],
  'M0 gồm launch/context và state fx/scale/count của iter_ctrl. fx vàscale cập nhật mỗiSACstep;Y/sign/sf/mode giữ cảtransaction. L1 token;L2 term vàcontrol;L3 accumulator. first chọn y_base thay acc trước cộngterm. init_only đặt term=0, do đó n0 chỉloadY không Y+Y. FLOOR termlo2=0; numerical_tail làstatus,không jam vào số học. SAC fixedpre_shift1 rồi variableclz, scale+clz+1, exhausted zero/one tree song song. Không có feedback từacc vàoSAC. NF32/3EX1ACC_W54; FEX0ACC_W16,Y13,X12.'));
 brace(s,'M0: context',80,255,229);brace(s,'L1: SAC + controller',315,936,229);brace(s,'L2: SBM dịch',1000,1355,229);brace(s,'L3: SBM tích lũy',1415,1800,229);
 bank(s,220,296,580,'S03 / M0',{id:'CORE_M0',size:25});
 txt(s,'X',88,307,95,35,28);seg(s,60,355,220,355,{arrow:true});
 txt(s,'Y, sign, sf, mode',43,570,174,70,24);seg(s,60,656,220,656,{arrow:true});
 box(s,'LOD\nleading_count',330,312,167,89,{size:26});seg(s,230,355,330,355,{arrow:true});
 plus(s,714,319,70,'+');seg(s,497,355,714,355,{arrow:true});
 txt(s,'scale_q',330,407,150,30,24);wire(s,[[230,438],[650,438],[650,386],[714,386]],{arrow:true});
 txt(s,'carry-in = 1',671,274,160,35,23);seg(s,749,308,749,319,{arrow:true});
 seg(s,784,355,930,355,{arrow:true});txt(s,'scale_next',786,300,140,35,23);
 box(s,'Dịch cố định 1\n{fx[W−2:0],0}',330,526,167,89,{size:25});
 box(s,'Barrel << clz\nfx_next',591,526,194,89,{size:26});
 wire(s,[[230,355],[280,355],[280,570],[330,570]],{arrow:true});dot(s,280,355);seg(s,497,570,591,570,{arrow:true});
 wire(s,[[497,355],[540,355],[540,502],[678,502],[678,526]],{arrow:true});dot(s,516,355);
 wire(s,[[785,570],[884,570],[884,902],[195,902],[195,850],[220,850]],{arrow:true});
 txt(s,'fx_next: feedback về state SAC',322,910,460,30,23);
 box(s,'Zero / one-hot\nexhausted',330,741,181,83,{size:25});wire(s,[[280,570],[280,782],[330,782]],{arrow:true});dot(s,280,570);
 box(s,'count + limit\nfirst / last / init_only\ncut / iteration',630,721,230,124,{size:24});seg(s,511,782,630,782,{arrow:true,color:CTRL,dash:true});
 seg(s,860,782,930,782,{arrow:true,color:CTRL,dash:true});
 bank(s,930,296,580,'S04 / L1',{id:'CORE_L1',size:25});
 box(s,'Y_base >> scale\nFLOOR: term[1:0]=0\ninit_only: term=0',1050,400,228,148,{size:25});
 wire(s,[[940,355],[1010,355],[1010,440],[1050,440]],{arrow:true});
 wire(s,[[230,656],[1020,656],[1020,510],[1050,510]],{arrow:true});
 txt(s,'Y_base = Y << 2 (approx)',582,610,412,35,24,{align:'left'});
 txt(s,'NF exact: Y_base = Y << 26',522,673,470,35,24,{align:'left',color:GRAY});
 wire(s,[[1278,476],[1350,476]],{arrow:true});
 wire(s,[[1278,526],[1313,526],[1313,716],[1350,716]],{arrow:true,color:CTRL,dash:true});
 txt(s,'term_tail',1210,672,128,34,23,{color:CTRL});
 wire(s,[[940,782],[1350,782]],{arrow:true,color:CTRL,dash:true});
 bank(s,1350,296,580,'S05 / L2',{id:'CORE_L2',size:25});
 mux(s,1466,434,40,140,{name:'FIRST_SEED_MUX'});
 wire(s,[[1020,656],[1410,656],[1410,468],[1466,468]],{arrow:true});dot(s,1020,656);
 plus(s,1616,455,80,'+');seg(s,1506,504,1616,504,{arrow:true});
 wire(s,[[1360,476],[1390,476],[1390,380],[1656,380],[1656,455]],{arrow:true});
 txt(s,'term',1513,334,150,35,25);
 seg(s,1696,495,1772,495,{arrow:true});bank(s,1772,296,580,'S06 / L3',{id:'CORE_L3',size:25});
 seg(s,1782,495,1892,495,{arrow:true});txt(s,'acc / P̂',1784,440,130,40,25);
 wire(s,[[1782,495],[1840,495],[1840,905],[1428,905],[1428,540],[1466,540]],{arrow:true});dot(s,1840,495);
 txt(s,'acc_q feedback',1467,908,310,36,25);
 wire(s,[[1360,782],[1486,782],[1486,574]],{arrow:true,color:CTRL,dash:true});
 txt(s,'first',1491,653,95,34,24,{color:CTRL});
 txt(s,'last / cut / tail',1465,743,240,35,23,{color:CTRL});
 wire(s,[[1486,782],[1772,782]],{arrow:true,color:CTRL,dash:true});dot(s,1486,782,CTRL);
 txt(s,'first=1: seed=Y_base     first=0: seed=acc_q\ninit_only=1: chỉ nạp Y_base, không cộng Y+Y',485,943,1075,67,27);
}

function rneFinish(s,x,y,regx,{final=false}={}){
 plus(s,x+8,y-30,63,'+');txt(s,'inc',x+8,y-91,70,35,25);seg(s,x+39,y-53,x+39,y-30,{arrow:true,color:CTRL,dash:true});
 mux(s,x+118,y-71,35,142,{name:final?'FINAL_SPECIAL_MUX':'PRODUCT_SPECIAL_MUX'});
 txt(s,'sel',x+115,y-119,47,31,23,{color:CTRL});seg(s,x+135,y-86,x+135,y-71,{arrow:true,color:CTRL,dash:true});
 seg(s,x+71,y,x+118,y,{arrow:true});
 wire(s,[[x+82,y+108],[x+98,y+108],[x+98,y+47],[x+118,y+47]],{arrow:true});
 txt(s,'Zero / NaR\nmin / max',x+11,y+103,164,68,24);
 seg(s,x+153,y,regx,y,{arrow:true});
 txt(s,final?'RNE + sign':'RNE magnitude',x-5,y-157,192,50,26,{bold:true});
}

// 05: every NF-only stage plus the final packer, at a larger scale.
{
 const s=base('MAC non-fused: tích đã làm tròn trước phép cộng','S07…S14, hai lần RNE; Posit(32,3), F=26, SF_W=11, FIN=53',
  noteSources(['rtl/mac_nf/mac_nf_wrapper.sv','rtl/multiplier/mul_prepack_norm_comb.sv','rtl/mac_nf/posit_product_pack.sv','rtl/mac_nf/posit_magnitude_parse.sv','rtl/adder/posit_add.sv','rtl/packer/posit_pack.sv'],
  'S07 gộp mul_prepack_norm_comb vàproductpackerP1;không có bank normalize riêng trướcP1. S08productP2finish sign=0,sign_q lưu riêng. S09magnitudeparsercomb chốt vào norm_*_q/product_frac_q;không dùngparserpipeline2 tầng ởđây. S10A1 align31bits OPT02c;S11A2 arithmetic;S12A3 normalization;S13finalP1 prep;S14P2RNE,special,sign. Flags status loss giữ riêng;product numerical sticky input hằng0 vìP_hat đã làdyadic;không dùngloss như sốhọcsticky.'));
 const labels=['Norm + Prod P1','Prod P2','Parse bank','Add A1','Add A2','Add A3','Pack P1','Pack P2'];
 const xs=labels.map((_,i)=>70+220*i),rx=xs.map(x=>x+192),y=507;
 brace(s,'RNE lần 1: tích P̂',xs[0],rx[1]+10,251);brace(s,'Giải mã tích + cộng C_eff',xs[2],rx[5]+10,251);brace(s,'RNE lần 2: tổng',xs[6],rx[7]+10,251);
 for(let i=0;i<8;i++){
  bank(s,rx[i],367,343,'',{id:`NF_TAIL_S${i+7}`,size:27});
  txt(s,`S${String(i+7).padStart(2,'0')}\n${labels[i]}`,xs[i]-8,279,203,76,26,{bold:true});
  if(i)seg(s,rx[i-1]+10,y,xs[i]+(i===1||i===7?8:0),y,{arrow:true});
 }
 box(s,'Carry: sf+1\nGiữ magnitude\nPack prep\nmag / GRS',xs[0],415,180,184,{size:26});seg(s,24,y,xs[0],y,{arrow:true});seg(s,xs[0]+180,y,rx[0],y,{arrow:true});txt(s,'P̂',11,450,52,45,30);
 rneFinish(s,xs[1],y,rx[1]);
 box(s,'Mag. parse\nKhông bù hai lại\nsign riêng\nsf11, frac26',xs[2],415,180,184,{size:25});seg(s,xs[2]+180,y,rx[2],y,{arrow:true});
 box(s,'Δsf hai chiều\nChọn |lớn / nhỏ|\nShift + jam\nx, y: 31 bit',xs[3],415,180,184,{size:26});seg(s,xs[3]+180,y,rx[3],y,{arrow:true});
 alu(s,xs[4]+22,424,122,163,'+ / −');seg(s,xs[4],y,xs[4]+22,y,{arrow:true});seg(s,xs[4]+144,y,rx[4],y,{arrow:true});
 txt(s,'subtract\n= signA XOR signB',xs[4]-5,764,205,70,24,{color:CTRL});wire(s,[[xs[4]+83,754],[xs[4]+83,587]],{arrow:true,color:CTRL,dash:true});
 box(s,'LOD / normalize\nShift, sf ± count\nfrac[52:0]\nsticky riêng',xs[5],415,180,184,{size:25});seg(s,xs[5]+180,y,rx[5],y,{arrow:true});
 box(s,'Regime / exp\nEncode / shift\nG, R, S\nSpecial select',xs[6],415,180,184,{size:26});seg(s,xs[6]+180,y,rx[6],y,{arrow:true});
 rneFinish(s,xs[7],y,rx[7],{final:true});seg(s,rx[7]+10,y,1890,y,{arrow:true});txt(s,'D',1850,448,54,45,31);
 wire(s,[[xs[3]+80,866],[xs[3]+80,599]],{arrow:true});txt(s,'C_context\nsign, sf11, frac26, Zero/NaR',xs[3]-135,872,440,78,27);
 txt(s,'R(P̂): magnitude + sign',xs[2]-140,726,440,40,27);
 txt(s,'inc = G & (LSB | R | S)',1173,891,650,45,30,{bold:true});
 txt(s,'Loss flags đi kèm dữ liệu; product_sticky=0. Packer cuối nhận sticky số học từ bộ cộng.',67,971,1760,45,27,{align:'left'});
}

// 06: the residual stays a separate lane through the fused pipe.
{
 const s=base('MAC fused: F1…F5 giữ phần dư đến RNE cuối','S07…S13, không pack/parse tích ở giữa; P̂ vào F1 bằng magnitude14 bit và scale riêng',
  noteSources(['rtl/mac_f/mac_f_wrapper.sv','rtl/mac_f/fused_prepare_comb.sv','rtl/mac_f/fused_align_comb.sv','rtl/mac_f/fused_arith_comb.sv','rtl/mac_f/fused_abs_borrow_comb.sv','rtl/mac_f/fused_norm_comb.sv','rtl/mac_f/fused_add_pipe.sv','rtl/packer/posit_pack.sv'],
  'p_magnitude=acc[15:2];Pseed31 theo carryp[13];cseed={0,1,c_frac26,000};p_sf=p_scale+p[13]. F1anchor chỉso sf,hòa chọnP,nênF3có thểsignednegative. F2small>>delta,delta>=31 choalignedsmall0/residualORall. large không dịch. F3signed retained_sum32. F4negative=Z[31],borrow=residual&&(subtract!=negative);magnitude=abs(Z)-borrow,gộp1adder;sign=Z!=0&&(base_sign^negative). F5normalize31 ->frac53,sf11,sticky=residual. Loss statuskhông dùng numerical sticky. FinalP1/P2RNEduynhất.'));
 const xs=[85,325,565,805,1045,1285,1525],rx=xs.map(x=>x+192);
 const labels=['F1 / Prepare','F2 / Align','F3 / Add-sub','F4 / ABS-borrow','F5 / Normalize','Pack P1','Pack P2'];
 for(let i=0;i<7;i++){bank(s,rx[i],350,484,'',{id:`F_TAIL_S${i+7}`,size:27});txt(s,`S${String(i+7).padStart(2,'0')}\n${labels[i]}`,xs[i]-16,255,220,82,26,{bold:true});}
 box(s,'Carry adapt\nsf + carry\nAnchor theo sf\nMUX L / S',xs[0],433,180,186,{size:25});
 txt(s,'P̂14',18,396,70,38,26);seg(s,20,469,85,469,{arrow:true});
 wire(s,[[15,660],[52,660],[52,580],[85,580]],{arrow:true});txt(s,'C_q',4,675,88,38,26);
 seg(s,xs[0]+180,469,rx[0],469,{arrow:true});seg(s,xs[0]+180,580,rx[0],580,{arrow:true});
 // F2: large is a bypass, only small passes through the barrel shifter.
 seg(s,rx[0]+10,469,rx[1],469,{arrow:true});txt(s,'large31 giữ nguyên',xs[1]-6,397,200,38,24);
 box(s,'small >> Δsf\nΔsf ≥ 31: 0',xs[1],535,180,110,{size:25});seg(s,rx[0]+10,580,xs[1],580,{arrow:true});seg(s,xs[1]+180,580,rx[1],580,{arrow:true});
 box(s,'OR bit mất',xs[1]-3,728,186,65,{size:25,fill:PALE});wire(s,[[rx[0]+10,580],[307,580],[307,760],[322,760]],{arrow:true});seg(s,xs[1]+183,760,rx[1],760,{arrow:true,color:CTRL});
 txt(s,'residual',xs[1]-4,810,183,34,24,{color:CTRL});
 alu(s,xs[2]+37,428,102,184,'+ / −');seg(s,rx[1]+10,469,xs[2]+37,469,{arrow:true});seg(s,rx[1]+10,580,xs[2]+37,580,{arrow:true});
 wire(s,[[xs[2]+139,520],[rx[2],520]],{arrow:true});txt(s,'Z_signed[31:0]',xs[2]-14,648,220,40,25);
 seg(s,rx[1]+10,760,rx[2],760,{arrow:true,color:CTRL});
 box(s,'abs(Z) − borrow\nneg = Z[31]\nCập nhật sign',xs[3],454,180,132,{size:25});seg(s,rx[2]+10,520,xs[3],520,{arrow:true});seg(s,xs[3]+180,520,rx[3],520,{arrow:true});
 box(s,'borrow = residual\n& (sub XOR neg)',xs[3]-7,712,192,83,{size:23,fill:PALE});
 seg(s,rx[2]+10,760,xs[3]-7,760,{arrow:true,color:CTRL});wire(s,[[xs[3]+90,712],[xs[3]+90,586]],{arrow:true,color:CTRL});
 wire(s,[[rx[2]+10,760],[xs[3]-22,760],[xs[3]-22,817],[rx[3],817]],{arrow:true,color:CTRL});
 box(s,'LOD / shift\nsf = anchor + d\nd = 1 − clz\nfrac[52:0]',xs[4],454,180,132,{size:24});seg(s,rx[3]+10,520,xs[4],520,{arrow:true});seg(s,xs[4]+180,520,rx[4],520,{arrow:true});
 wire(s,[[rx[3]+10,817],[xs[4]+85,817],[xs[4]+85,760],[rx[4],760]],{arrow:true,color:CTRL});txt(s,'sticky = residual',xs[4]-10,857,210,38,24,{color:CTRL});
 box(s,'Regime / exp\nEncode / shift\nG, R, S\nSpecial select',xs[5],428,180,184,{size:26});seg(s,rx[4]+10,520,xs[5],520,{arrow:true});seg(s,xs[5]+180,520,rx[5],520,{arrow:true});
 wire(s,[[rx[4]+10,760],[xs[5]+62,760],[xs[5]+62,612]],{arrow:true,color:CTRL});
 rneFinish(s,xs[6],520,rx[6],{final:true});seg(s,rx[5]+10,520,xs[6]+8,520,{arrow:true});seg(s,rx[6]+10,520,1880,520,{arrow:true});txt(s,'D[31:0]',1750,458,150,42,28);
 txt(s,'Retained window: W32 / Q29. Residual là phần dư số học; loss flags là thông tin cắt xấp xỉ.',65,956,1770,50,28,{align:'left'});
}

// 07: the feedback is output-P2 commit, not the iterative multiplier accumulator.
{
 const s=base('Điều khiển giao dịch và feedback MAC','accumulator_q là Posit32 sau RNE; khác với accumulator nội bộ của SBM',
  noteSources(['rtl/mac_nf/mac_nf_wrapper.sv','rtl/mac_f/mac_f_wrapper.sv','rtl/parser/posit_parser.sv','rtl/packer/posit_pack.sv'],
  'c_eff = acc_mode ? (acc_clr?0:accumulator_q) : c. pair_accept chốtcfg vàacc_mode,busy1,committed0,clearaccnếucần. pair_retire=parserA/B/Cvalid&&core_ready,chốtC_context vàlaunch. commitkhipack_out_valid&&!committed_q,nếumodeqthìaccumulator_q<=d. commit lầnđầuvalid,không chờout_ready. retire=out_valid&&out_ready chỉgiảiphóngbusy/core;outputstallkhôngcommitlặp. Toponeoutstanding. Parser/add/fused/packerelasticready=!valid||downstreamready;coretokenpipelinekhôngbackpressuregiữkếtquảonebusy. CácFFresetbridge/metasync làcontrolkhông cộngstage.'));
 box(s,'Điều khiển một giao dịch\npair_accept: chốt cfg, acc_mode; busy=1\npair_retire: giữ C_context và launch core',550,208,794,137,{size:28,fill:PALE});
 bank(s,1380,209,135,'',{id:'TRANSACTION_CONTROL'});txt(s,'cfg_q, busy_q\ncommitted_q',1412,226,279,87,27,{align:'left'});
 seg(s,1344,277,1380,277,{arrow:true,color:CTRL,dash:true});
 txt(s,'cfg_mode, cfg_n, cfg_ops\nin_valid / in_ready',65,237,380,87,27,{align:'left'});seg(s,465,277,550,277,{arrow:true,color:CTRL,dash:true});
 // Two C_eff muxes stay visible and separate.
 mux(s,390,446,48,150,{name:'C_CLEAR_SELECT'});mux(s,596,446,48,150,{name:'C_MODE_SELECT'});
 txt(s,'0',253,424,58,39,28);seg(s,279,472,390,472,{arrow:true});
 wire(s,[[438,521],[520,521],[520,484],[596,484]],{arrow:true});
 txt(s,'C_port[31:0]',375,643,226,40,27);
 wire(s,[[456,634],[456,562],[596,562]],{arrow:true});
 wire(s,[[644,521],[785,521]],{arrow:true});txt(s,'C_eff[31:0]',646,551,158,40,25);
 box(s,'Parser C\nP1 / P2',785,458,200,126,{size:30});seg(s,985,521,1080,521,{arrow:true});
 bank(s,1080,420,202,'C_context',{id:'FEEDBACK_C_CONTEXT',size:27});
 box(s,'C_q + R(P̂)  [NF]\nC_q + P̂       [F]',1230,458,278,126,{size:29});seg(s,1090,521,1230,521,{arrow:true});
 txt(s,'Tích từ lõi nhân',1162,367,345,40,27);wire(s,[[1369,412],[1369,458]],{arrow:true});
 box(s,'Packer cuối\nP1 / P2',1610,458,180,126,{size:29,fill:WARM});seg(s,1508,521,1610,521,{arrow:true});seg(s,1790,521,1875,521,{arrow:true});
 txt(s,'D / flags',1775,461,139,42,28);
 // Closed result feedback, via a distinct FF bank with commit CE.
 dot(s,1823,521);wire(s,[[1823,521],[1823,754],[1694,754]],{arrow:true});
 bank(s,1684,707,94,'',{id:'MAC_ACCUMULATOR_FEEDBACK'});
 wire(s,[[1684,754],[258,754],[258,563],[390,563]],{arrow:true});
 txt(s,'accumulator_q[31:0]',1300,823,426,38,28,{align:'right'});
 txt(s,'acc_clr',341,382,145,40,28,{color:CTRL});seg(s,414,426,414,446,{arrow:true,color:CTRL,dash:true});
 txt(s,'acc_mode',542,382,160,40,28,{color:CTRL});seg(s,620,426,620,446,{arrow:true,color:CTRL,dash:true});
 wire(s,[[982,345],[1015,345],[1015,436],[1080,436]],{arrow:true,color:CTRL,dash:true});
 txt(s,'pair_retire',824,373,160,38,25,{color:CTRL});
 box(s,'commit = pack_out_valid & !committed_q\nacc_mode_q=1: lưu D đúng một lần\nClear: pair_accept & acc_mode & acc_clr',1115,871,677,128,{size:28});
 wire(s,[[1792,905],[1850,905],[1850,723],[1694,723]],{arrow:true,color:CTRL,dash:true});
 txt(s,'CE',1708,675,65,34,25,{color:CTRL});
 txt(s,'retire = out_valid & out_ready',1135,648,635,44,29,{color:CTRL});
 txt(s,'Stall đầu ra: giữ D/flags, không commit lặp\nNhả busy chỉ khi retire',465,788,744,79,28,{align:'left'});
 box(s,'Reset bridge + local 2FF release\nStartup barrier trước khi nhận giao dịch\nready = !valid || downstream_ready',65,887,785,108,{size:27});
 txt(s,'Mỗi thanh mảnh biểu diễn một bank FF có cùng clock/enable. Các FF feedback/control không tạo thêm tầng nối tiếp.',65,174,1770,35,25,{align:'left',color:GRAY});
}

// Geometry is authored with attached object names and native primitives only.
// All text uses explicit typeface to preserve the paper-style serif font.
await fs.writeFile(path.join(BUILD,'source_manifest.json'),JSON.stringify(manifest,null,2));
await fs.writeFile(path.join(BUILD,'text_fit.json'),JSON.stringify(fits,null,2));
await fs.writeFile(path.join(BUILD,'deck.json'),JSON.stringify(p.toProto()));
await (await PresentationFile.exportPptx(p)).save(path.join(BUILD,'candidate.pptx'));
for(const [i,s] of p.slides.items.entries()){
 const png=await p.export({slide:s,format:'png',scale:0.8});
 await fs.writeFile(path.join(BUILD,`slide-${String(i+1).padStart(2,'0')}.png`),new Uint8Array(await png.arrayBuffer()));
 console.log('Rendered slide',i+1);
}
console.log('DECK CREATED',p.slides.items.length,'native editable slides');
