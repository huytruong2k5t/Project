//-----------------------------------------------------------------------------
// File          : tb_mul_iter_core_fixed2.sv
// Author(s)     : Verification Suite
// Project       : Posit MAC IP
// Description   : Unit testbench for consolidated mul_iter_core_fixed2 module.
//-----------------------------------------------------------------------------
`timescale 1ns/1ps
module tb_mul_iter_core_fixed2;
    logic        clk = 1'b0;
    logic        reset_n = 1'b0;
    logic        launch_valid = 1'b0;
    wire         launch_ready;
    logic        release_result = 1'b0;
    logic [11:0] x_frac = 12'd0;
    logic [12:0] y_mant = 13'd0;
    logic [3:0]  cfg_n = 4'd0;
    logic        sign_i = 1'b0;
    logic signed [10:0] sf_i = 11'd0;
    logic        input_cut_i = 1'b0;

    wire         run_ready;
    wire         core_done;
    wire [15:0]  acc;
    wire         numerical_tail;
    wire [3:0]   iterations_done;
    wire         approx_cut;
    logic        sign_o;
    logic signed [10:0] sf_o;
    logic        input_cut_o;
    wire         state_error;

    always #5 clk = ~clk;

    mul_iter_core_fixed2 dut (
        .clk             (clk),
        .reset_n         (reset_n),
        .launch_valid    (launch_valid),
        .launch_ready    (launch_ready),
        .release_result  (release_result),
        .x_frac          (x_frac),
        .y_mant          (y_mant),
        .cfg_n           (cfg_n),
        .sign_i          (sign_i),
        .sf_i            (sf_i),
        .input_cut_i     (input_cut_i),
        .run_ready       (run_ready),
        .core_done       (core_done),
        .acc             (acc),
        .numerical_tail  (numerical_tail),
        .iterations_done (iterations_done),
        .approx_cut      (approx_cut),
        .sign_o          (sign_o),
        .sf_o            (sf_o),
        .input_cut_o     (input_cut_o),
        .state_error     (state_error)
    );

    int errors = 0;

    initial begin
        // 1. Reset
        reset_n = 1'b0;
        launch_valid = 1'b0;
        release_result = 1'b0;
        #25;
        @(negedge clk);
        reset_n = 1'b1;

        // Wait for run_ready
        @(posedge clk);
        while (!run_ready) @(posedge clk);
        $display("[TB] Reset synchronized: run_ready = 1, launch_ready = %b", launch_ready);
        if (!launch_ready) begin
            $display("[ERROR] launch_ready should be 1 after reset!");
            errors++;
        end

        // 2. Test Case 1: Zero fraction (is_init = 1)
        @(negedge clk);
        launch_valid = 1'b1;
        x_frac = 12'h000;
        y_mant = 13'h1000; // 1.0 representation
        cfg_n = 4'd3;
        sign_i = 1'b0;
        sf_i = 11'd10;
        input_cut_i = 1'b0;

        @(negedge clk);
        launch_valid = 1'b0;

        // Wait for core_done
        while (!core_done) @(posedge clk);
        $display("[TB] TC1 Done: acc = 0x%04x, expected 0x%04x (y_base), state_error = %b",
                 acc, {1'b0, 13'h1000, 2'b00}, state_error);
        if (acc !== {1'b0, 13'h1000, 2'b00}) begin
            $display("[ERROR] TC1 acc mismatch!");
            errors++;
        end
        if (state_error) begin
            $display("[ERROR] TC1 state_error asserted!");
            errors++;
        end

        // Release result
        @(negedge clk);
        release_result = 1'b1;
        @(negedge clk);
        release_result = 1'b0;
        @(posedge clk);

        // 3. Test Case 2: Multi-step fraction
        // x_frac = 12'b1000_0000_0000 (1 iteration should exhaust)
        @(negedge clk);
        launch_valid = 1'b1;
        x_frac = 12'b1000_0000_0000;
        y_mant = 13'h1000;
        cfg_n = 4'd4;
        sign_i = 1'b1;
        sf_i = -11'd5;
        input_cut_i = 1'b1;

        @(negedge clk);
        launch_valid = 1'b0;

        while (!core_done) @(posedge clk);
        $display("[TB] TC2 Done: acc = 0x%04x, iterations_done = %0d, sign_o = %b, state_error = %b",
                 acc, iterations_done, sign_o, state_error);
        if (sign_o !== 1'b1 || sf_o !== -11'd5 || input_cut_o !== 1'b1) begin
            $display("[ERROR] TC2 context register mismatch!");
            errors++;
        end
        if (state_error) begin
            $display("[ERROR] TC2 state_error asserted!");
            errors++;
        end

        // Release result
        @(negedge clk);
        release_result = 1'b1;
        @(negedge clk);
        release_result = 1'b0;
        @(posedge clk);

        // 4. Test Case 3: Multiple non-zero bits
        // x_frac = 12'b1010_0000_0000 (2 iterations, leading bits at pos 0 and pos 2)
        @(negedge clk);
        launch_valid = 1'b1;
        x_frac = 12'b1010_0000_0000;
        y_mant = 13'h1000;
        cfg_n = 4'd4;

        @(negedge clk);
        launch_valid = 1'b0;

        while (!core_done) @(posedge clk);
        $display("[TB] TC3 Done: acc = 0x%04x, iterations_done = %0d, approx_cut = %b",
                 acc, iterations_done, approx_cut);
        if (iterations_done !== 4'd2) begin
            $display("[ERROR] TC3 iterations_done expected 2, got %0d", iterations_done);
            errors++;
        end
        if (state_error) begin
            $display("[ERROR] TC3 state_error asserted!");
            errors++;
        end

        @(negedge clk);
        release_result = 1'b1;
        @(negedge clk);
        release_result = 1'b0;
        #20;

        if (errors == 0) begin
            $display("=================================================");
            $display("   ALL mul_iter_core_fixed2 TESTS PASSED!       ");
            $display("=================================================");
        end else begin
            $display("=================================================");
            $display("   TESTS FAILED with %0d errors!                ", errors);
            $display("=================================================");
        end
        $finish;
    end
endmodule

