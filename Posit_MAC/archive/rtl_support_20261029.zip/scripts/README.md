## Luồng hiện hành fixed32/ES3 — 23/10/2026

Dùng `verify_fixed32_3.py`, `verify_fixed32_3_modelsim.ps1`,
`verify_fixed32_3_units.ps1` và `audit_rtl_release.py --self-test`.
Không truyền -GNB/-GES hoặc feature generic vào DUT fixed. Makefile lint/smoke/
regress/cov đã chuyển sang luồng này. Hướng dẫn ở docs/HUONG_DAN_CHAY_WSL_MODELSIM.md.
Runner đa format và các lệnh tuần cũ bên dưới chỉ dành cho snapshot tham số hóa cũ;
không chạy trực tiếp chúng với production fixed32/3 hoặc sửa oracle để vượt lỗi.

---

# Thư mục Kịch bản Bổ trợ (`scripts/`)

## Lưu ý sau dọn thư mục — 19/10/2026

Không sửa nội dung hoặc đường dẫn script trong phiên này. Build production vẫn dùng
`rtl/production.f` và release `POSIT_MAC_RTL_20261018_OPT12_120`.
23 file ứng viên cũ đã được lưu ZIP; còn 9 snapshot thuộc gói đã chọn trong
`rtl/candidates/`. Xem [bản đồ hiện hành](../README.md) và
[danh mục/cách phục hồi ứng viên cũ](../archive/README.md).

Các lệnh thí nghiệm ở phần lịch sử, đặc biệt primitive, OPT-02b, prepack OPT-01,
normalization shared/zero và các nhánh SAC a/ab/abc_sub, có thể cần phục hồi
archive vào gốc dự án trước khi chạy. Không đổi runner để bỏ qua nguồn bị thiếu.
Cache W14 `.gch/.o/.a/.d`, thư viện ModelSim event protocol và cache Python đã dọn;
build lại phần cần thiết trước khi replay. Log, raw coverage, fixture, snapshot,
hash và báo cáo timing giữ nguyên. Phiên dọn không chạy lại các lệnh dưới đây.

## Release production đã khóa — 18/10/2026

**Production hiện hành18/10:** đã chọn và promote OPT-12 negate, khóa release
`POSIT_MAC_RTL_20261018_OPT12_120` (`LOCKED_FOR_W14`),38 module trong `rtl/production.f`.
A35T `xc7a35tcpg236-1`, Explore,8,3ns≈120,48MHz: NF WNS/WHS +0,227/+0,053ns;
F +0,093/+0,040ns. Input min=max2,5ns, output min0/max0,5ns, uncertainty0,1ns giữ nguyên.
Gói OPT-02c/05/09/10A + OPT-12; không đổi I/O, precision, latency hoặc L1/oracle.

Trước build W14: `python scripts/audit_rtl_release.py --self-test`.
Recipe120MHz: `syn/opt12_120mhz_release.json`, clock `syn/constraints/a35t_clock_120mhz.xdc`;
XDC100MHz vẫn giữ cho replay lịch sử, không phải clock nghiệm thu120MHz.
870 profile lint parser, equivalence/decoder,10M NF+10M F đều0 mismatch; ModelSim NF/F đạt.
Hai file production là đúng byte đã kiểm, không chạy lại regression lớn khi promote.
Đây là OOC theo profile công bố, chưa board signoff, final per-n/AC04 W14 hoặc paired NF/F PPA.
Old lock OPT02C giữ trong `results/opt120_20261018/reference_freeze.json` và `reference_source.zip`.
Chi tiết Optimization8.31.8; trial8.31.7 và các trạng thái chưa promote trước đó là lịch sử.
Producer lịch sử không dùng để refreeze/ghi đè release mới. W14-01..06 đã đạt: F90M/0 mismatch, pilot/accuracy calibration/matrix freeze; W14-07..12 còn mở (Optimization8.33).




**Tài liệu hiện hành:** [PLAN — kiến trúc/build L1/NF/F](../l1/PLAN.md), [Optimization — tối ưu và kiểm chứng/STA](../../doc/Optimization.md), [tiến độ — việc còn mở](../docs/TIEN_DO_DO_AN.md).

Thư mục này chứa các kịch bản tự động hóa Python và shell script phục vụ kiểm chứng bit-accurate độc lập, tổng hợp PPA và xử lý đồ thị báo cáo đồ án.

---

## 1. Kịch bản Kiểm chứng Thuật toán & Module (Bit-Accurate Verification)

Các kịch bản này mô phỏng độc lập phần cứng ở cấp độ bit, cho phép xác minh tính đúng đắn 100% của giải thuật mà không cần cài đặt các bộ mô phỏng thương mại cồng kềnh:

| File Kịch bản | Module Kiểm chứng | Số lượng Vector đã xác nhận | Cách chạy |
|:---|:---|:---:|:---|
| [`verify_dyn_left_shifter.py`](verify_dyn_left_shifter.py) | [`dyn_left_shifter.sv`](../rtl/common/dyn_left_shifter.sv) | **60,832 vectors (100% Pass)** | `python scripts/verify_dyn_left_shifter.py` |
| [`verify_dyn_right_shifter.py`](verify_dyn_right_shifter.py) | [`dyn_right_shifter.sv`](../rtl/common/dyn_right_shifter.sv) | **146,400 vectors (100% Pass)** | `python scripts/verify_dyn_right_shifter.py` |

---

## 2. Kịch bản Xử lý Kết quả & Báo cáo PPA (§7 SPEC)

Các kịch bản phục vụ trích xuất dữ liệu tự động từ các log công cụ (Vivado / OpenROAD) để bảo đảm tiêu chí tái lập **AC-07** (`make all`):

- **`collect_ppa.py`**:
  - Tự động đọc các file log tổng hợp (`utilization.rpt`, `timing.rpt`, `power.rpt`) từ Vivado và OpenROAD.
  - Trích xuất các chỉ số: LUT, FF, CARRY, DSP, BRAM, WNS, $f_{\max}$, công suất tiêu thụ.
  - Tự động tính toán các chỉ số dẫn xuất: Throughput (Mops/s), Mops/s trên mỗi LUT, tích Diện tích $\times$ Trễ.
  - Xuất bảng kết quả tổng hợp ra [`results/ppa.csv`](../results/README.md) và [`results/ppa.md`](../results/README.md).

- **`plot_error.py`**:
  - Đọc file CSV kiểm tra hồi quy từ tầng L1/RTL.
  - Vẽ biểu đồ sai số Error Rate (%) và NMSE theo từng số vòng lặp $n \in \{1, 2, 3, 4, 5, 6, 8\}$ và theo từng nhóm regime $G_1 \dots G_8$.
  - Xuất biểu đồ đồ thị dưới định dạng vector (`.svg`) và hình ảnh (`.png`) chất lượng cao để chèn vào báo cáo đồ án.

- **`plot_pareto.py`**:
  - Dành cho mục mở rộng DSE (EXT-B).
  - Vẽ không gian thiết kế Pareto tối ưu giữa Diện tích (LUT) $\times$ Trễ (chu kỳ) $\times$ Độ chính xác (NMSE) để khuyến nghị cấu hình phần cứng tối ưu.

## 3. Kiểm chứng và khảo sát packer tuần8

- [`verify_packer_modelsim.ps1`](verify_packer_modelsim.ps1): sinh fixture bằng L1 và encoder bit-list độc lập, kiểm packer tổ hợp/pipeline và chuỗi parser→packer trên ModelSim. Chạy từ thư mục `Posit_MAC`: `./scripts/verify_packer_modelsim.ps1`; dùng `-CollectExisting` để kiểm lại hash và tổng kết log đã có. Kết quả ở `results/packer/summary.json`.
- [`run_packer_ppa.ps1`](run_packer_ppa.ps1): đo RNE/TRUNC trên Quartus, Cyclone IV EP4CE22F17C6, cùng biên thanh ghi vào/ra, seed 1/2/3 và clock 10ns. Kết quả ở `results/packer_ppa/summary.json`; đây là benchmark packer riêng, chưa nghiệm thu timing/PPA toàn MAC. Hướng dẫn và giới hạn ở `rtl/README.md` mục6.

- [`verify_packer_p2_equivalence.ps1`](verify_packer_p2_equivalence.ps1): đối chiếu P2 mới với bản trước tối ưu, 1.448.576 lượt, cả RNE/TRUNC. NB8 vét cạn toàn bundle nhị phân, NB16/32 dùng seed20261007+NB. Tham chiếu nằm trong `results/packer_p2_optimization/`; `comparison.json` so tài nguyên/timing trước–sau, baseline được giữ riêng. Đây là kiểm tương đương, không thay thế oracle L1/bit-list của suite packer.

## 4. Khởi động tuần9

- [`verify_week9_frontend_modelsim.ps1`](verify_week9_frontend_modelsim.ps1): build trước `make -C l1 gen_week9_frontend.exe`, rồi chạy từ Posit_MAC. Sinh fixture Windows, compile/mô phỏng OPS/SAC tổ hợp, kiểm10 marker/count và ghi log/hash tại `results/week9_frontend/windows`.
- [`summarize_week9_frontend.py`](summarize_week9_frontend.py): chạy generator Linux và UBSan trước; so fixture với Windows, xác nhận327.440 dòng kiểm và log không warning/error, ghi `results/week9_frontend/summary.json`. Không dùng summary này nghiệm thu Gate2 hoặc baseline gốc của paper.

## 5. Kiểm chứng tuần9 và giới hạn quyền

Chạy từ Posit_MAC: `verify_week9_arithmetic_modelsim.ps1`, `verify_week9_paper_modelsim.ps1`, `verify_week9_core_modelsim.ps1`; integrated pilot: `verify_week9_multiplier_modelsim.ps1 -PerProfile 2000 -RunName final_pilot`. Lượt lớn: `-PerProfile 630000 -RunName acceptance`; script chỉ đóng ngưỡng số học khi số giao dịch hoàn tất đạt10⁷, không tính reset-abort.

`summarize_week9_implementation.py` kiểm fixture Linux/Windows/UBSan, coverage và hash. `update_week9_status.py` chỉ sửa Markdown hiện có, không tạo Markdown mới. `verify_week9_verilator.sh` chỉ dùng tool đã cài, trả BLOCKED khi thiếu, không sudo/download/install. Mọi file build/log/work/temp đặt dưới Posit_MAC. Quyền cập nhật ngoài dự án chỉ dành đúng doc/TIEN_DO_DO_AN.md.

GitHub đã push checkpoint 0ae39c4 lên main bằng checkout riêng trong Posit_MAC; kết quả lượt lớn được bổ sung cuối phiên.

Lượt phân tầng cuối đạt16.815.920 giao dịch hoàn tất,80.080 reset hủy; control random-bit đạt10.032.224 giao dịch,47.776 reset hủy; cả hai0 mismatch. Audit đối chiếu SHA fixture với log PASS và loại reset-abort trước coverage:16 profile đầy đủ, posit32 đạt256/256 bin regime–dấu, tối thiểu4.104 mẫu/bin và26.241 operands mỗi run/polarity hữu hạn;36 ô mode/OPS/n mỗi profile. Code coverage line/branch/toggle chưa đo.

Corner riêng đạt114.656 so sánh/544 reset hủy,3600 trường hợp khác nhau mỗi profile (100 cặp ×36 config), gồm ±1, ±minpos/maxpos và NaR×0/0×NaR; Linux/Windows/UBSan và replay32.000 dòng uniform cũ khớp. Pilot stall96 chu kỳ đạt31.840 so sánh/160 reset,336 lượt giữ dài;0 mismatch. Chỉ chỉnh khoảng trắng RTL để tách port/parameter, có proof và pilot biên dịch lại; SHA nguồn trước/sau lưu riêng. Logic không đổi, TableI không chạy lại.

Gate2/W9-06 vẫn processing: Verilator chưa có, harness C++ và lint chính thức chưa build/chạy. Không tự cài công cụ hoặc thay tiêu chí. Bằng chứng: results/week9_multiplier/{stratified_acceptance,acceptance_parallel,corners_final_rtl,long_stall_pilot}; snapshot/version/seed/lệnh tại results/week9_implementation/summary.json.

## 6. Tái chạy top paper tự hồi tiếp — 09/10/2026

`paper_mul_iter`/`paper_mul_wrapper`/`paper_norm_comb` đã tự chạy từ A/B đến kết quả; ModelSim17.181 giao dịch và65.710 commit đạt0 mismatch,843 commit corpus cũ giữ nguyên, Fig.4=0x1ae34000. Linux/Windows/UBSan fixture MATCH; reset/stall/context/early-stop/special đạt trong suite. Hợp đồng research cố định posit32ES3/Q12, n_terms1..8, outputTRUNC; chi tiết PLAN L1 §7.5 và results/paper_top/{windows/summary,audit}.json. Không có nguồn mới hoặc thay đổi số học nên không chạy TableI; provenance baseline gốc và Gate2 vẫn processing.

Trong WSL không nạp profile, cd vào Posit_MAC, đặt TMPDIR trong results/paper_top/tmp rồi make -C l1 gen_paper_top gen_paper_top.exe gen_paper_top_ubsan. Sinh fixture Linux/UBSan theo lệnh trong audit.json; PowerShell chạy scripts/verify_paper_top_modelsim.ps1, tiếp đó chạy scripts/audit_paper_top.py bằng Python có sẵn. ModelSim work/transcript/log/wave/temp đều ở results/paper_top; compiler timescale1ns/1ps nằm ở lệnh vlog. Không cài/sửa công cụ hệ thống.

## 7. Audit SAC/n và packer theo nguồn — 09/10/2026

Audit trực tiếp nguồn2019/2021 và kiểm deterministic163.840 cặp cho thấy RND/complement và quét bit1 không tương đương. Fig4 khớp n_fraction2/n_total3 (0x1ae34000), nhưng n_total2 cho0x1ad14000; TableI Proposed chưa khóa cách đếm/recurrence từ nguồn. Giữ nguyên profile normative và top RND nghiên cứu, không đổi n/seed để ép bảng.

Reference cổng Fig5 độc lập khớp L1 trên3.940.352 trường hợp; ModelSim155.648 trường hợp đạt0 mismatch, Linux/Windows/UBSan MATCH.8.448 raw/clamped differences nằm ngoài miền sf−240..240, do range handling đồ án bổ sung; không phải lỗi RTL hoặc xác nhận clamp tác giả. Không chạy pilotTableI, baseline gốc/Gate2 vẫn processing. Chi tiết duy nhất tại README L1 §24; bằng chứng/lệnh/hash/compiler tại results/paper_contract_audit/{summary.json,windows/summary.json}.

## 8. Bộ đo journal2024 — 09/10/2026

Pilot journal2024 dùng Posit32 ES2/Q12/PT2 tuyệt đối, oracle SoftPosit0.4.1; n đếm tổng số hạng. Self-test600.127 đối chiếu/lượt đạt0 mismatch, smoke Linux/Windows MATCH và UBSan đạt. Hai phân bố địa phương10M mỗi loại chưa khớp Fig9: rawPosit n2 Err<0,1%=8,954950%, cột nguồn khoảng53–57%. Cận OPS lý tưởng trong cùng hợp đồng chỉ9,667460%. TableVI khớp output n2 nhưng còn dư; lời văn nói t2=0 bất nhất với bảng. Không kết luận số liệu2021/2024 sai; không đổi n/cut/seed để ép bảng, không chạy full200M hoặc RTL ES2. Baseline gốc/tuần4 và Gate2 vẫn processing. Chi tiết tại README L1 §25, kết quả/compiler/seed/lệnh/hash tại results/paper_journal2024/measurement/summary.json.

Lệnh: make -C l1 test_journal2024_measurement test_journal2024_measurement.exe test_journal2024_measurement_ubsan; chạy hai pilot theo README L1 §25 rồi python scripts/audit_journal2024_measurement.py. Exit0 chỉ là hoàn tất bộ đo; đọc measurement_status/original_baseline_accepted để biết nghiệm thu nguồn.


## Bảo trì đường dẫn và dung lượng — 15/10/2026

- Kiểm di chuyển RTL giữ nguyên byte: `python scripts/audit_rtl_layout.py`.
- Kiểm syntax/lint và smoke NF/F từ WSL: `bash scripts/verify_rtl_layout.sh`.
- Xem trước dữ liệu có thể dọn: `powershell -NoProfile -File scripts/cleanup_results.ps1`.
- Thực hiện dọn: `powershell -NoProfile -File scripts/cleanup_results.ps1 -Apply`.

Cleanup chỉ xóa `obj_dir`, `obj_fast`, `work`, `db`, `incremental_db`, `xsim.dir`, `.Xil`, `tmp`, `__pycache__` bên trong results.
Giữ báo cáo CSV/JSON, hình, raw coverage, log, phiên bản/seed/lệnh/hash, snapshot nguồn và fixture.
Sau cleanup phải build lại thư viện/binary trước mô phỏng; các script verify thực hiện bước này.
Không xóa `output_files` vì chứa báo cáo PPA cần giữ. Script mặc định chỉ xem trước và từ chối reparse point.

Để chạy F vào thư mục riêng, tránh ghi đè bằng chứng W13:
`W13_RESULTS_DIR=results/my_run bash scripts/verify_week13_fused.sh 10000 smoke line`.
Runner Xilinx nhận `-RunRoot results/my_run`; mô phỏng cần fixture `results/my_run/verilator/pilot.vectors`
(sinh bằng runner Verilator với prefix `pilot` và ít nhất 8192 giao dịch).


## Khảo sát primitive v2 — 16/10/2026

Quyết định production: chỉ LOD MODE0,N31/32,S mặc định dùng nhóm4; hai shifter giữ gốc. Các bản thử ở `rtl/candidates/primitives_v2/` không nằm trong `production.f`. Chi tiết tại PLAN L1 §8.18 và `results/primitive_v2_20261016/adoption.json`.

Audit checkpoint hiện có (Python3; khi clone chỉ có archive thì restore trước):

```text
python scripts/archive_primitive_v2.py restore
python scripts/collect_primitive_v2.py --final
python scripts/archive_primitive_v2.py check
```

Archive giữ nguyên bằng chứng gốc. Restore từ chối ghi đè file local khác nội dung. Không dùng `prepare_primitive_v2.py` sau promote: nó cố ý từ chối canonical baseline đã đổi. Để kiểm lại từ snapshot gốc và ghi log mới ở thư mục riêng, từ PowerShell tại Posit_MAC:

```powershell
./scripts/verify_primitive_v2.ps1 -FrozenSources -Variants lod_only -RunRoot results/my_primitive_replay
./scripts/run_primitive_v2_ppa.ps1 -FrozenSources -Phase adoption -Part xc7a35tcpg236-1 -RunRoot results/my_primitive_ppa -PlanOnly
./scripts/run_primitive_v2_ppa.ps1 -FrozenSources -Phase adoption -Part xc7a35tcpg236-1 -RunRoot results/my_primitive_ppa
```

Dùng cùng lệnh PPA với `-Part xc7a100tcsg324-1` để đối chiếu part còn lại. `-PlanOnly` chỉ kiểm đầu vào và hiển thị đường dẫn, không đo. Runner tiếp tục các ID còn thiếu trong RunRoot; ID đã có không được đo lại. Muốn đo mới dùng RunRoot mới, không xóa hoặc sửa bằng chứng đóng băng. Collector mặc định audit checkpoint gốc; báo cáo đo mới nằm tại RunRoot/part/phase/metrics.csv và các report tương ứng.

Trong WSL tại đúng thư mục dự án:

```bash
bash --noprofile --norc scripts/lint_primitive_v2.sh
LAYOUT_RESULTS_DIR=results/my_current_smoke LAYOUT_NF_ES_LIST="2 3" bash --noprofile --norc scripts/verify_rtl_layout.sh
```

Lint primitive kiểm các snapshot đã khóa, không ghi lại hash baseline lịch sử bằng nguồn common mới. Smoke thứ hai dùng nguồn common hiện tại, kiểm NF32 ES2/ES3 và F32 ES3; không phải full10M hoặc STA toàn MAC.

Các phase đã đo: lod/lod_mixed/shift/chain/chain_extra/packer/confirm/release/adoption. Helper chuẩn bị và case list trong study lưu quy trình xây dựng ban đầu; không gọi để ghi đè snapshot sau đo. `review_primitive_v2.py` đối chiếu cùng chiến lược, không tự promote. `verify_primitive_v2_netlists.py` và runner PowerShell cùng tên kiểm chức năng/latency các netlist Default của checkpoint gốc bằng XSim, không SDF. Số MHz là ước lượng R2R từ slack ở period5ns, không phải Fmax sweep/board; ba chiến lược không phải ba random seed.

## Parser XOR — kiểm và đo lại checkpoint 16/10/2026

Hai parser hiện dùng một detector. Bản trước/sau và dependency được giữ tại `results/parser_xor_20261016/source`; PPA dùng đúng nguồn đóng băng, không lấy nguồn thay đổi sau này. Nếu clone chưa có report gốc, chạy `python scripts/archive_parser_xor.py restore` để phục hồi từ evidence.zip; helper kiểm SHA và từ chối ghi đè file khác nội dung.

Trong WSL, tại thư mục Posit_MAC:

```bash
PARSER_XOR_RESULTS_DIR=results/parser_xor_replay bash --noprofile --norc scripts/verify_parser_xor.sh
LAYOUT_RESULTS_DIR=results/parser_xor_integration_replay LAYOUT_NF_ES_LIST="2 3" bash --noprofile --norc scripts/verify_rtl_layout.sh
```

Runner đầu kiểm nguồn parser hiện tại bằng fixture L1 + decoder độc lập; test parameter so chu kỳ với baseline dual-detector đã đóng băng. Nó dùng --timing và CURDIR=. để Make xử lý đúng đường dẫn có khoảng trắng. SoftPosit không được liên kết cho phép so field parser; NF/F dùng oracle của harness tích hợp hiện có.

PowerShell tại thư mục Posit_MAC:

```powershell
./scripts/run_parser_xor_ppa.ps1 -Part xc7a35tcpg236-1 -RunRoot results/parser_xor_ppa_replay
./scripts/run_parser_xor_ppa.ps1 -Part xc7a100tcsg324-1 -RunRoot results/parser_xor_ppa_replay
python scripts/collect_parser_xor.py
```

PPA runner từ chối output đã có metrics; chọn RunRoot mới để tránh ghi đè. Đo32/2 và32/3, ba directive Default/Explore/RuntimeOptimized, input bank34FF, period5ns, uncertainty0,1ns; không có thay đổi latency của production. `p1.rpt` là R2R input bank→parser; `p2.rpt`/`p2_slack.txt` trong driver hiện chứa toàn R2R, không riêng tầng P2. HD.CLK_SRC chưa khóa; số STA không phải Fmax board hoặc toàn MAC. Collector mặc định audit kết quả checkpoint gốc; dữ liệu tái chạy nằm ở RunRoot đã chọn. Regression source hash lịch sử không tự chuyển sang checkpoint mới.

## OPT-01 prepack normalization — checkpoint16/10/2026

Thử refactor riêng `mul_prepack_norm_comb`, lưu tại `rtl/candidates/multiplier/mul_prepack_norm_comb.sv`: bốn ứng viên nối bit hằng exact/approx × carry/no-carry, chọn ở cuối; scale cộng carry trên SF_W bit. Không thêm bank hoặc đổi lịch NF, không sửa pack/parse/SAC/adder. Baseline tại `results/prepack_refactor_20261016/source/baseline` là toàn production sau parser XOR; candidate thay đúng một module. Nguồn/hash/fixture/corpus/công cụ và số đo trước/sau tại thư mục study, kết luận tại [Optimization §8.20](../../doc/Optimization.md#legacy-8-20).

Trên clone mới, phục hồi evidence trước để có fixtures và reports gốc:

```powershell
python scripts/audit_prepack_refactor.py restore
python scripts/audit_prepack_refactor.py collect
```

Trong WSL tại thư mục Posit_MAC, chọn thư mục mới cho mỗi lần replay:

```bash
export PREPACK_RESULTS_DIR=results/prepack_replay
bash --noprofile --norc scripts/verify_prepack_refactor.sh
bash --noprofile --norc scripts/verify_prepack_nf.sh
```

Lệnh đầu lint70 cấu hình và so RTL cũ/mới với oracle mask/shift. Lệnh thứ hai kiểm pilot bốn format (20k/20k/20k/100k), sau đó10M NF32/3 bằng corpus/oracle đã dùng cho Gate3; không phải final mỗi n NF/F. Resume chỉ tái dùng pilot khi SHA của snapshot khớp. Main NF EXACT_EN1 được lint nghiêm ngặt; EXACT_EN0 kiểm riêng ở leaf. Cảnh báo whole NF32/2 EXACT_EN0 của sbm_shift đã tồn tại ở baseline, giữ ngoài nghiệm thu profile mới.

PowerShell, sau khi nguồn replay đã được chuẩn bị bằng lệnh WSL đầu:

```powershell
./scripts/verify_prepack_modelsim.ps1 -RunRoot results/prepack_replay
./scripts/run_prepack_refactor_ppa.ps1 -Part xc7a35tcpg236-1 -RunRoot results/prepack_ppa_replay
./scripts/run_prepack_refactor_ppa.ps1 -Part xc7a100tcsg324-1 -RunRoot results/prepack_ppa_replay
```

ModelSim10.1d dùng bản sao LOD với typedef cast unsigned cùng width để tương thích cú pháp; unit LOD41.024 checks trước corner NF82.944 ca. Không sửa production LOD. PPA runner đo snapshot baseline/candidate gốc đã khóa, không đo nguồn live đã sửa sau này; RunRoot chỉ đổi nơi ghi kết quả và từ chối ghi đè metrics đã có. Toàn NF32/3,FW12,EXACT_EN=OPS_EN1; clock10ns,uncertainty0,1ns, cùng BUFG và I/O budget, ba directive matched. Reports gồm toàn R2R và norm_round riêng; số MHz từ slack là ước lượng STA OOC, không phải board Fmax hoặc paired NF/F. Collector audit checkpoint gốc; kết quả replay nằm trong RunRoot mới.

Kết luận OPT-01: candidate đạt bit-exact nhưng không được chọn thay production do median STA không cải thiện nhất quán; production giữ baseline. Các runner ở trên tái hiện thí nghiệm candidate đã đo, không tự promote hoặc chạy bước pipeline tiếp theo.

<!-- OPT03_REPORT_START:scripts/README.md -->
## OPT-03 NF product pipeline — 17/10/2026

Dùng verify_opt03.sh, verify_opt03_modelsim.ps1, verify_opt03_schedule.ps1 và run_opt03_ppa.ps1. Native replay đặt OPT03_RESULTS_DIR mới; Windows đặt -RunRoot mới. Sources source/candidate được khóa, giữ baseline_reference và calibration riêng. audit_opt03.py restore/collect kiểm raw bằng chứng. Không chạy lại prepare vào checkpoint đã khóa. Chi tiết lệnh và giới hạn tại [Optimization §8.21](../../doc/Optimization.md#legacy-8-21). Runner OPT-01 dùng harness/testbench cũ đã đóng băng, không dùng lịch OPT-03.
<!-- OPT03_REPORT_END:scripts/README.md -->


## Constraint A35T-C2 — mặc định100MHz

run_a35t_sta.ps1 mặc định profile benchmark_100mhz: clock10ns, uncertainty setup/hold0,1ns; input min=max2,5ns và output min0/max0,5ns. Hai XDC trong syn/constraints được nạp trước synthesis. Không tự chạy C1 clock-only hoặc mẫu I/O tích hợp ở mốc100MHz. Ngoại lệ sweep Fmax chỉ thực hiện theo yêu cầu riêng, đọc Internal R2R hoặc dùng budget mới có nhãn/đối chứng matched. Ngoại lệ thứ hai chưa được nêu. Xem [syn/README](../syn/README.md); nguồn và bằng chứng C1 cũ nằm trong archive, không gán cho C2.


### Chạy lại trên release đã khóa (không ghi đè checkpoint)

Từ gốc Posit_MAC, kiểm hash trước:

```powershell
python scripts/audit_rtl_release.py --self-test
./scripts/verify_rtl_release_modelsim.ps1 -RunRoot results/release_event_replay
```

Trong WSL tại `/mnt/c/HCMUT/HK261/Do an 2/Posit_MAC`:

```bash
bash --noprofile --norc scripts/verify_rtl_release.sh results/release_native_replay
```

Dùng RunRoot mới mỗi lần. Native runner cần Verilator/GCC và libsoftposit.so đã build;
không cài hay chỉnh hệ thống. ModelSim runner cần fixture corner/protocol của
opt02b_20261017 và fused/pilot.vectors của opt02c_20261018. Sau clone, giải nén
`evidence.zip` của từng study vào chính thư mục study, kiểm SHA theo archive_manifest.json
trước khi replay; nếu thiếu fixture phải sinh lại bằng generator đã lưu và kiểm hash.
Không suy rằng metadata JSON thay được vector/binary. Archive không chứa executable,
ModelSim work, wave hoặc DCP; build lại từ source đã lưu. Không chạy prepare/promote/lock
cũ trên release hiện hành: chúng là producer của checkpoint, không phải lệnh regression W14.

## OPT-12 candidate120,48MHz — 18/10/2026

Nguồn đề nghị: rtl/candidates/parser/opt12; chưa promote/lock. Verify study bằng
`python scripts/audit_opt12.py`; check reference bằng `python scripts/audit_rtl_release.py`.
Evidence: results/opt120_20261018/summary.json,qualification.json,archive_manifest.json,evidence.zip.
Explore đạt120,48MHz cho cả NF/F; F Default và NF RuntimeOptimized vẫn FAIL, không gọi mọi flow đạt.
Runners prepare/verify/stress/finalize là producer checkpoint, không chạy lại vào output đã có.
PPA replay dùng Attempt mới và đúng nguồn đã restore/kiểm SHA; xem hướng dẫn WSL/ModelSim và Optimization8.31.7.


Khảo sát XCVU9P riêng: prepare_xcvu9p_trial.py / run_xcvu9p_trial.ps1, fixed8,3ns Explore; hiện thiếu device support, xem Optimization8.32. Dùng -Attempt mới sau khi có device; không đổi production/A35T lock.
