"""Audit experimental F sources, independent replay and matched OOC results."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import report_opt15
from audit_rtl_release import validate

R = Path(__file__).resolve().parents[1]
O = R / 'results/f_shared_add_20261020'
def read(path):
    data = path.read_bytes()
    return data.decode('utf-16' if data.startswith((b'\xff\xfe', b'\xfe\xff')) else 'utf-8-sig')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    frozen = json.loads(read(R / 'rtl/production_freeze.json'))
    validate(frozen)
    manifest = json.loads(read(O / 'manifest.json'))
    for variant, row in manifest['variants'].items():
        for rel, digest in row['source_sha256'].items():
            assert sha(O / 'source' / variant / rel) == digest, (variant, rel)
        if variant == 'reference':
            for rel, digest in frozen['rtl_sha256'].items():
                assert row['source_sha256'][rel] == digest
        else:
            assert sha(R / row['wrapper']) == sha(O / 'source' / variant / 'rtl/mac_f/mac_f_wrapper.sv')
        code = read(O / 'source' / variant / 'rtl/mac_f/mac_f_wrapper.sv')
        assert len(re.findall(r'\bposit_parser\s*#', code)) == row['input_parsers']
        assert len(re.findall(r'\bposit_pack\s*#', code)) == 1
    original_signature = read(R / 'rtl/mac_f/mac_f_wrapper.sv').split('module mac_f_wrapper #(', 1)[1].split(');', 1)[0]
    signature = lambda text: re.sub(r'\s+', '', text)
    for variant in ('parser2', 'shared_add'):
        text = read(O / 'source' / variant / 'rtl/mac_f/mac_f_wrapper.sv')
        assert signature(text.split('module mac_f_wrapper #(', 1)[1].split(');', 1)[0]) == signature(original_signature)
    shared = read(O / 'source/shared_add/rtl/mac_f/mac_f_wrapper.sv')
    assert 'fused_add_pipe #(' not in shared and shared.count('posit_add #(') == 1
    assert 'posit_product_pack' not in shared and 'round_unpacked' not in shared
    native = []
    run = O / 'verification'
    assert not re.search(r'%Warning|%Error', read(run / 'lint.log'))
    for filename in ('source.sha256', 'binary.sha256', 'fast.sha256'):
        for line in read(run / filename).splitlines():
            digest, rel = line.split(maxsplit=1)
            assert sha(run / rel) == digest, rel
    for name in ('pilot', 'main', 'fast'):
        row = json.loads(read(run / f'{name}.json'))
        assert row['status'] == 'PASS' and row['mismatches'] == 0
        assert all(row['bins']) and len(row['bins']) == 36
        if name != 'fast':
            assert row['accepted'] == row['completed_per_variant'] + row['reset_aborted']
            assert row['near'] / row['completed_per_variant'] >= .3
            assert row['borrow'] and row['residual'] and row['reset_busy'] and row['reset_stalled']
            # Raw counter increments on every any-valid observation, including
            # one release cycle per completion. Preserve raw evidence and derive
            # actual blocked cycles rather than relabelling the raw counter.
            row['output_valid_observations'] = row['stalled_observations']
            row['stalled_cycles_any_valid'] = row['stalled_observations'] - row['completed_per_variant']
        native.append(dict(name=name, **row))
    assert native[1]['completed_per_variant'] == 10000000
    assert native[2]['ii_checks'] == native[2]['completed'] - 1
    events = {}
    for variant in ('parser2', 'shared_add'):
        event = O / 'event' / variant
        assert read(event / 'status.txt').strip() == 'COMPLETE'
        hashes = json.loads(read(event / 'source_sha256.json'))
        for rel, digest in hashes.items():
            path = run / 'pilot.vectors' if rel == 'vectors' else event / 'source' / rel
            assert sha(path) == digest
        log = read(event / 'event.log')
        assert not re.search(r'\*\*\s+(Error|Fatal):', log)
        hit = re.search(r'F_SHARED_EVENT_PASS completed=(\d+) reset_aborts=(\d+) mismatch=0', log)
        assert hit and int(hit[1]) == 8192 and int(hit[2]) == 24
        events[variant] = dict(completed=int(hit[1]), reset_aborts=int(hit[2]), mismatches=0,
                               version=read(event / 'version.log').strip(), CK2Q_ns=1, clock_ns=8)
    report_opt15.O = O
    physical = [report_opt15.ppa(v) for v in ('reference', 'parser2', 'shared_add')]
    ref = physical[0]
    for row in physical:
        row['lut_change_pct'] = 100 * (row['resources']['Slice LUTs'] / ref['resources']['Slice LUTs'] - 1)
        row['ff_change_pct'] = 100 * (row['resources']['Slice Registers'] / ref['resources']['Slice Registers'] - 1)
    tools = {name: read(run / filename).splitlines()[0] for name, filename in
             (('verilator', 'verilator.txt'), ('compiler', 'compiler.txt'))}
    handoff = {}
    for label, rel in (
        ('opt15_parser2', 'rtl/candidates/mac_f/opt15/parser2/production.f'),
        ('opt16_shared_nf_add', 'rtl/candidates/mac_f/opt16/shared_nf_add/production.f'),
    ):
        filelist = R / rel
        log = O / f'{label}_filelist_lint.log'
        if filelist.exists() and log.exists():
            assert not re.search(r'%Warning|%Error', read(log))
            files = read(filelist).splitlines()
            assert len(files) == 38 and all((R / f).is_file() for f in files)
            assert 'rtl/mac_f/mac_f_wrapper.sv' not in files
            handoff[label] = dict(filelist=rel, sha256=sha(filelist), strict_lint='PASS')
    source_hashes = {}
    for p in list((R / 'scripts').glob('*f_shared_add*')) + list((R / 'tb').glob('f_shared_add*')):
        source_hashes[p.relative_to(R).as_posix()] = sha(p)
    result = dict(status='TRIAL_COMPLETE_NO_PROMOTION', date='2026-10-20',
                  production_unchanged=True, reference_release=frozen['release_id'],
                  source_manifest_sha256=sha(O / 'manifest.json'), runner_sha256=source_hashes,
                  tools=tools, native=native, events=events, ppa=physical, handoff_filelists=handoff,
                  limits=[
                      'Only the admitted approximate 32/3 FW12 N_MAX8 OPS0/1 profile; no exact fused or quire.',
                      'NF adder reuse is an isolated candidate, not an edit to the frozen normative W32 residual pipeline.',
                      'Final bits and all flags are compared; intermediate jam and signed-residual encodings differ.',
                      '10.1M completed per variant plus 100k no-stall shared-add transactions; not exhaustive or formal proof.',
                      'One matched Explore implementation per variant; no maximum-frequency sweep, board signoff or W15 closure.',
                      'OOC Route35-198 partial-I/O warnings preserved; report R2R separately from assumed I/O timing.',
                      'NF OPT15 historical PPA is context only, not a newly matched NF EXACT_EN0/F pair.'])
    (O / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
    print(result['status'])
    for row in physical:
        print(row['variant'], row['resources'], 'WNS/WHS', row['wns_ns'], row['whs_ns'],
              'R2R', row['r2r_setup_ns'], row['r2r_hold_ns'], 'PASS', row['full_timing_pass'])


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--study', default='results/f_shared_add_20261020')
    args = parser.parse_args()
    O = (R / args.study).resolve()
    assert O.is_relative_to((R / 'results').resolve()), 'Study outside project results'
    main()
