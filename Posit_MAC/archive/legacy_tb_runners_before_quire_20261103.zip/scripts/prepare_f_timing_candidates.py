"""Prepare isolated F-only parser experiments; never overwrite live RTL."""
import hashlib
import json
import re
import shutil
from pathlib import Path

root=Path(__file__).resolve().parent.parent
baseline=root/'results/parser_lod_refactor_recheck_20261101/source'
old=root/'results/readme_refactor_recheck_20261101/source'
experiment=root/'experiments/f_timing_20261101'
if experiment.exists():
    raise SystemExit('Preserve existing experiments')
active=(root/'rtl/mac_active.f').read_text().splitlines()
for path in active:
    assert (root/path).read_bytes()==(baseline/path).read_bytes(), f'New RTL requires a new baseline: {path}'

records={}
for label,carry,group in [('p00',True,True),('p01',True,False),('p10',False,True)]:
    source=experiment/label
    shutil.copytree(baseline,source)
    for path in ['scripts/run_refactored_mac.ps1','tb/tb_parser_f_timing_equiv.sv']:
        shutil.copy2(root/path,source/path)
    parser=(root/'rtl/parser/posit_parser.sv').read_text()
    parser=parser.replace('module posit_parser (','module posit_parser_f (')
    parser=parser.replace('lod_lzd_core_fixed2  u_regime_detector','posit_parser_f_regime_lod u_regime_detector')
    if carry:
        parser,n=re.subn(r"    // Carry-free two's-complement magnitude.*?    assign magnitude = .*?;", 
            "    // Carry magnitude retains Artix-7 dedicated carry resources.\n"
            "    assign magnitude = (p ^ {NB{s_d}})\n"
            "                     + {{(NB-1){1'b0}}, s_d};",parser,flags=re.S)
        assert n==1
    (source/'rtl/parser/posit_parser_f.sv').write_text(parser)
    lod=((old if group else root)/'rtl/common/lod_lzd_core_fixed2.sv').read_text()
    lod=lod.replace('module lod_lzd_core_fixed2 (','module posit_parser_f_regime_lod (')
    (source/'rtl/parser/posit_parser_f_regime_lod.sv').write_text(lod)
    wrapper=(root/'rtl/mac_f/mac_f_wrapper.sv').read_text()
    wrapper,n=re.subn(r'\bposit_parser\s+u_([abc])\b',r'posit_parser_f u_\1',wrapper)
    assert n==3
    (source/'rtl/mac_f/mac_f_wrapper.sv').write_text(wrapper)
    sources=active+['rtl/parser/posit_parser_f.sv','rtl/parser/posit_parser_f_regime_lod.sv']
    (source/'rtl/mac_active.f').write_text('\n'.join(sources)+'\n')
    # Prove all original non-F RTL remains identical, including shared adder LOD.
    changes=[]
    for path in active:
        if (source/path).read_bytes()!=(root/path).read_bytes(): changes.append(path)
    assert changes==['rtl/mac_f/mac_f_wrapper.sv']
    records[label]={'magnitude':'carry' if carry else 'prefix','parser_lod':'group' if group else 'flat',
        'source':str(source),'changed_existing_rtl':changes,
        'files':{str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in source.rglob('*') if p.is_file()}}
experiment.mkdir(parents=True,exist_ok=True)
(experiment/'candidates.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({k:{'magnitude':v['magnitude'],'parser_lod':v['parser_lod']} for k,v in records.items()}))
