"""Promote exact measured F-only RTL after verification, preserving original NF."""
import argparse
import hashlib
import json
import shutil
from pathlib import Path

root=Path(__file__).resolve().parent.parent
ap=argparse.ArgumentParser();ap.add_argument('winner');args=ap.parse_args()
run=root/'results/f_timing_optimization_20261101'
summary=json.loads((run/'summary.json').read_text())
assert summary['winner']==args.winner
record=next(r for r in summary['records'] if r['label']==args.winner)
assert record['F2F_ns']<=6.602 and record['WNS_ns']>=2.689 and record['WHS_ns']>=-0.055
selected=run/args.winner
assert (selected/'verify/status.txt').read_text(encoding='utf-8-sig').strip()=='PASS'
assert (selected/'verify_parser_f/status.txt').read_text(encoding='utf-8-sig').strip()=='PASS'
base=root/'results/parser_lod_refactor_recheck_20261101/source'
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=(base/'rtl/mac_active.f').read_text().splitlines()+['rtl/posit_mac.vh']
for path in paths:
    assert digest(root/path)==digest(base/path),f'Live edits found before promotion: {path}'
backup=run/'before_promotion'
if backup.exists(): raise SystemExit('Preserve previous promotion')
changed=['rtl/mac_f/mac_f_wrapper.sv','rtl/mac_active.f','experiments/opt17_20261029/sources.f','tb/tb_parser_f_timing_equiv.sv']
before={}
for path in changed:
    dest=backup/path;dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(root/path,dest);before[path]=digest(root/path)
for path in ['rtl/parser/posit_parser_f.sv','rtl/parser/posit_parser_f_regime_lod.sv']:
    assert not (root/path).exists(),f'Preserve existing {path}'
for path in ['rtl/mac_f/mac_f_wrapper.sv','rtl/mac_active.f','rtl/parser/posit_parser_f.sv',
             'rtl/parser/posit_parser_f_regime_lod.sv','tb/tb_parser_f_timing_equiv.sv']:
    shutil.copy2(selected/'source'/path,root/path)
# Current experiment list builds the live wrappers; the frozen historical
# production.f remains untouched and is not an active-source build recipe.
extra=['rtl/parser/posit_parser_f.sv','rtl/parser/posit_parser_f_regime_lod.sv']
exp=root/'experiments/opt17_20261029/sources.f'
body=exp.read_bytes()
if body and not body.endswith(b'\n'): body+=b'\r\n'
for path in extra:
    if path not in body.decode('utf-8-sig').splitlines(): body+=path.encode()+b'\r\n'
exp.write_bytes(body)
measured={}
for path in (root/'rtl/mac_active.f').read_text().splitlines():
    assert digest(root/path)==digest(selected/'source'/path),path
    measured[path]=digest(root/path)
nf={path:digest(root/path) for path in paths if path!='rtl/mac_f/mac_f_wrapper.sv'}
assert all(value==digest(base/path) for path,value in nf.items())
promotion={'winner':args.winner,'measured_run':str(selected),'before':before,
    'live_rtl_matches_measured_snapshot':True,'active_rtl_sha256':measured,
    'nf_and_shared_rtl_unchanged':nf,'scope':'F only; no change to arithmetic, stage count, top ports or NF dependencies'}
(run/'promotion.json').write_text(json.dumps(promotion,indent=2)+'\n')
line=(f'## Tối ưu MAC F sau refactor — 01/11/2026\n\n'
      f'Đã chọn `{args.winner}`: F2F sau synthesis **7,697 → {record["F2F_ns"]:.3f} ns**, '
      f'LUT **1374 → {record["LUT"]}**, FF **820 → {record["FF"]}** trên A35T, cùng constraints10ns. '
      f'F dùng `posit_parser_f`/`posit_parser_f_regime_lod` riêng; parser NF và LOD của bộ cộng giữ nguyên. '
      f'Không thêm pipeline, không đổi số học FLOOR/Q12 hoặc cổng top. '
      f'MAC F50k accepted, parser4M magnitude, LOD500063 và parser streaming đều PASS. '
      f'Đây là regression hiện hành, chưa là nghiệm thu FULL_TERM; WHS vẫn −0,055ns trước route.\n\n')
for path,link in [('README.md','results/f_timing_optimization_20261101/summary.md'),
                  ('rtl/README.md','../results/f_timing_optimization_20261101/summary.md')]:
    target=root/path
    dest=backup/path;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(target,dest)
    target.write_bytes((line+f'[Báo cáo F2F và các candidate]({link}). Dùng `rtl/mac_active.f` (42 module) cho cây đang làm việc.\n\n---\n\n').encode()+target.read_bytes())
print(json.dumps({'winner':args.winner,'F2F_ns':record['F2F_ns'],'LUT':record['LUT'],
    'FF':record['FF'],'live_rtl_matches_measured_snapshot':True,'nf_and_shared_unchanged':True}))
