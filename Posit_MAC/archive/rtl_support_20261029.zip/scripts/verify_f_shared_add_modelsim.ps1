param(
    [ValidateSet('parser2','shared_add')][string]$Variant='shared_add',
    [ValidatePattern('^results/[a-zA-Z0-9_/-]+$')][string]$StudyRoot='results/f_shared_add_20261020'
)
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
$study=Join-Path $root $StudyRoot
$run=Join-Path $study "event/$Variant"
if(Test-Path -LiteralPath $run) {throw 'Preserve existing event evidence'}
foreach($name in @('source/rtl','source/tb','compat','tmp')) {
    New-Item -ItemType Directory -Force "$run/$name" | Out-Null
}
$env:TEMP="$run/tmp"; $env:TMP=$env:TEMP
$bin='C:/altera/13.0sp1/modelsim_ase/win32aloem'
$sources=@(); $hashes=@{}
foreach($rel in (Get-Content -LiteralPath "$study/source/$Variant/rtl/production.f")) {
    $dst=Join-Path "$run/source" $rel
    New-Item -ItemType Directory -Force (Split-Path $dst -Parent) | Out-Null
    Copy-Item -LiteralPath "$study/source/$Variant/$rel" -Destination $dst
    $hashes[$rel]=(Get-FileHash -LiteralPath $dst).Hash.ToLowerInvariant()
    if((Split-Path $rel -Leaf) -eq 'lod_lzd_core.sv') {
        $text=Get-Content -LiteralPath $dst -Raw
        $text=$text.Replace("POS_W'(group_index)","pos_cast_t'(group_index)").Replace("S'(pos_tree[LEVELS][0])","count_cast_t'(pos_tree[LEVELS][0])")
        $text=$text.Replace('            assign match_bits',"            typedef logic [POS_W-1:0] pos_cast_t;`n            typedef logic [S-1:0] count_cast_t;`n            assign match_bits")
        $dst="$run/compat/lod_lzd_core.sv"
        [IO.File]::WriteAllText($dst,$text)
    } elseif((Split-Path $rel -Leaf) -eq 'mac_f_wrapper.sv') {
        $text=Get-Content -LiteralPath $dst -Raw
        $text=$text.Replace('    localparam int I_W = $clog2(FRAC_W+1);','    localparam int I_W = $clog2(FRAC_W+1); typedef logic [I_W-1:0] iteration_cast_t;')
        $text=$text.Replace("I_W'(N_MAX)","iteration_cast_t'(N_MAX)")
        $dst="$run/compat/mac_f_wrapper.sv"
        [IO.File]::WriteAllText($dst,$text)
    }
    $sources+=$dst
}
Copy-Item -LiteralPath "$study/source/$Variant/rtl/posit_mac.vh" -Destination "$run/source/rtl"
$tb=Get-Content -LiteralPath "$root/tb/tb_week13_fused_event.sv" -Raw
$tb=$tb.Replace('always #5 clk = ~clk;','always #4 clk = ~clk;')
$tb=$tb.Replace('integer elapsed, count = 0;', 'integer elapsed, count = 0; integer latency_add;')
$tb=$tb.Replace('        reset_dut();', '        reset_dut();')
$tb=$tb.Replace('        fd = $fopen(vector_path, "r");','        if (!$value$plusargs("LATENCY_ADD=%d", latency_add)) latency_add = 0;'+"`n"+'        fd = $fopen(vector_path, "r");')
$tb=$tb.Replace('elapsed != latency_i','elapsed != latency_i + latency_add')
$tb=$tb.Replace('W13_EVENT_PASS','F_SHARED_EVENT_PASS')
[IO.File]::WriteAllText("$run/source/tb/tb_week13_fused_event.sv",$tb)
$sources+="$run/source/tb/tb_week13_fused_event.sv"
$vectors="$study/verification/pilot.vectors"
if(!(Test-Path -LiteralPath $vectors)) {throw 'Native pilot vectors missing'}
$hashes['vectors']=(Get-FileHash -LiteralPath $vectors).Hash.ToLowerInvariant()
$hashes | ConvertTo-Json | Set-Content -Encoding utf8 "$run/source_sha256.json"
Push-Location $run
try {
    & "$bin/vsim.exe" -version > version.log
    & "$bin/vlib.exe" work > library.log
    if($LASTEXITCODE) {throw 'vlib failed'}
    & "$bin/vlog.exe" -sv -timescale 1ns/1ps "+incdir+$run/source/rtl" -work work @sources -l compile.log > compile_console.log
    if($LASTEXITCODE) {throw 'vlog failed'}
    @('onerror {quit -code 1}','onbreak {quit -code 1}','run -all','quit -code 0') | Set-Content -Encoding ascii run.do
    $offset=if($Variant -eq 'parser2') {2} else {0}
    & "$bin/vsim.exe" -c work.tb_week13_fused_event "+VECTORS=$vectors" "+LATENCY_ADD=$offset" -do run.do -l event.log -wlf event.wlf > event_console.log
    if($LASTEXITCODE) {throw 'ModelSim replay failed'}
    $text=Get-Content -LiteralPath event.log -Raw
    if($text -notmatch 'F_SHARED_EVENT_PASS' -or $text -match '\*\*\s+(Error|Fatal):') {throw 'Event acceptance missing'}
    Write-Output ($text -split "`n" | Where-Object {$_ -match 'F_SHARED_EVENT_PASS'})
    'COMPLETE' | Set-Content status.txt
} finally {Pop-Location}
