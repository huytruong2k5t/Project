// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2026.1 (win64) Build 6511674 Tue Jun 16 11:02:23 MDT 2026
// Date        : Fri Oct 16 16:06:48 2026
// Host        : MSI running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim {C:/HCMUT/HK261/Do an
//               2/Posit_MAC/results/primitive_v2_20261016/xc7a100tcsg324-1/release/selected_n12_k0_m0_a0_f0_w4_explore/functional_netlist.v}
// Design      : primitive_v2_top
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a100tcsg324-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module dyn_left_shifter
   (D,
    Q,
    \result_reg[11] );
  output [10:0]D;
  input [3:0]Q;
  input [11:0]\result_reg[11] ;

  wire [10:0]D;
  wire [3:0]Q;
  wire \result[10]_i_2_n_0 ;
  wire \result[11]_i_2_n_0 ;
  wire \result[11]_i_3_n_0 ;
  wire \result[11]_i_4_n_0 ;
  wire \result[11]_i_5_n_0 ;
  wire \result[3]_i_2_n_0 ;
  wire \result[4]_i_2_n_0 ;
  wire \result[5]_i_2_n_0 ;
  wire \result[6]_i_2_n_0 ;
  wire \result[7]_i_2_n_0 ;
  wire \result[8]_i_2_n_0 ;
  wire \result[9]_i_2_n_0 ;
  wire [11:0]\result_reg[11] ;

  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[10]_i_1 
       (.I0(\result[10]_i_2_n_0 ),
        .I1(\result[11]_i_4_n_0 ),
        .I2(Q[0]),
        .I3(\result[11]_i_2_n_0 ),
        .I4(Q[1]),
        .I5(\result[11]_i_3_n_0 ),
        .O(D[9]));
  LUT4 #(
    .INIT(16'h00B8)) 
    \result[10]_i_2 
       (.I0(\result_reg[11] [3]),
        .I1(Q[2]),
        .I2(\result_reg[11] [7]),
        .I3(Q[3]),
        .O(\result[10]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[11]_i_1 
       (.I0(\result[11]_i_2_n_0 ),
        .I1(\result[11]_i_3_n_0 ),
        .I2(Q[0]),
        .I3(\result[11]_i_4_n_0 ),
        .I4(Q[1]),
        .I5(\result[11]_i_5_n_0 ),
        .O(D[10]));
  LUT5 #(
    .INIT(32'h30BB3088)) 
    \result[11]_i_2 
       (.I0(\result_reg[11] [4]),
        .I1(Q[2]),
        .I2(\result_reg[11] [0]),
        .I3(Q[3]),
        .I4(\result_reg[11] [8]),
        .O(\result[11]_i_2_n_0 ));
  (* \PinAttr:I0:HOLD_DETOUR  = "179" *) 
  LUT5 #(
    .INIT(32'h30BB3088)) 
    \result[11]_i_3 
       (.I0(\result_reg[11] [6]),
        .I1(Q[2]),
        .I2(\result_reg[11] [2]),
        .I3(Q[3]),
        .I4(\result_reg[11] [10]),
        .O(\result[11]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'h30BB3088)) 
    \result[11]_i_4 
       (.I0(\result_reg[11] [5]),
        .I1(Q[2]),
        .I2(\result_reg[11] [1]),
        .I3(Q[3]),
        .I4(\result_reg[11] [9]),
        .O(\result[11]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'h30BB3088)) 
    \result[11]_i_5 
       (.I0(\result_reg[11] [7]),
        .I1(Q[2]),
        .I2(\result_reg[11] [3]),
        .I3(Q[3]),
        .I4(\result_reg[11] [11]),
        .O(\result[11]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000B08)) 
    \result[1]_i_1 
       (.I0(\result_reg[11] [0]),
        .I1(Q[0]),
        .I2(Q[2]),
        .I3(\result_reg[11] [1]),
        .I4(Q[3]),
        .I5(Q[1]),
        .O(D[0]));
  LUT6 #(
    .INIT(64'h0004FFFF00040000)) 
    \result[2]_i_1 
       (.I0(Q[2]),
        .I1(\result_reg[11] [1]),
        .I2(Q[3]),
        .I3(Q[1]),
        .I4(Q[0]),
        .I5(\result[3]_i_2_n_0 ),
        .O(D[1]));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[3]_i_1 
       (.I0(\result[3]_i_2_n_0 ),
        .I1(Q[0]),
        .I2(\result[4]_i_2_n_0 ),
        .O(D[2]));
  LUT5 #(
    .INIT(32'h00000B08)) 
    \result[3]_i_2 
       (.I0(\result_reg[11] [0]),
        .I1(Q[1]),
        .I2(Q[3]),
        .I3(\result_reg[11] [2]),
        .I4(Q[2]),
        .O(\result[3]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \result[4]_i_1 
       (.I0(\result[4]_i_2_n_0 ),
        .I1(Q[0]),
        .I2(\result[5]_i_2_n_0 ),
        .O(D[3]));
  LUT5 #(
    .INIT(32'h00000B08)) 
    \result[4]_i_2 
       (.I0(\result_reg[11] [1]),
        .I1(Q[1]),
        .I2(Q[3]),
        .I3(\result_reg[11] [3]),
        .I4(Q[2]),
        .O(\result[4]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \result[5]_i_1 
       (.I0(\result[5]_i_2_n_0 ),
        .I1(Q[0]),
        .I2(\result[6]_i_2_n_0 ),
        .O(D[4]));
  LUT6 #(
    .INIT(64'h0000000030BB3088)) 
    \result[5]_i_2 
       (.I0(\result_reg[11] [2]),
        .I1(Q[1]),
        .I2(\result_reg[11] [0]),
        .I3(Q[2]),
        .I4(\result_reg[11] [4]),
        .I5(Q[3]),
        .O(\result[5]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[6]_i_1 
       (.I0(\result[6]_i_2_n_0 ),
        .I1(Q[0]),
        .I2(\result[7]_i_2_n_0 ),
        .I3(Q[1]),
        .I4(\result[9]_i_2_n_0 ),
        .O(D[5]));
  LUT6 #(
    .INIT(64'h0000000030BB3088)) 
    \result[6]_i_2 
       (.I0(\result_reg[11] [3]),
        .I1(Q[1]),
        .I2(\result_reg[11] [1]),
        .I3(Q[2]),
        .I4(\result_reg[11] [5]),
        .I5(Q[3]),
        .O(\result[6]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[7]_i_1 
       (.I0(\result[7]_i_2_n_0 ),
        .I1(\result[9]_i_2_n_0 ),
        .I2(Q[0]),
        .I3(\result[8]_i_2_n_0 ),
        .I4(Q[1]),
        .I5(\result[10]_i_2_n_0 ),
        .O(D[6]));
  LUT4 #(
    .INIT(16'h00B8)) 
    \result[7]_i_2 
       (.I0(\result_reg[11] [0]),
        .I1(Q[2]),
        .I2(\result_reg[11] [4]),
        .I3(Q[3]),
        .O(\result[7]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[8]_i_1 
       (.I0(\result[8]_i_2_n_0 ),
        .I1(\result[10]_i_2_n_0 ),
        .I2(Q[0]),
        .I3(\result[9]_i_2_n_0 ),
        .I4(Q[1]),
        .I5(\result[11]_i_2_n_0 ),
        .O(D[7]));
  LUT4 #(
    .INIT(16'h00B8)) 
    \result[8]_i_2 
       (.I0(\result_reg[11] [1]),
        .I1(Q[2]),
        .I2(\result_reg[11] [5]),
        .I3(Q[3]),
        .O(\result[8]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[9]_i_1 
       (.I0(\result[9]_i_2_n_0 ),
        .I1(\result[11]_i_2_n_0 ),
        .I2(Q[0]),
        .I3(\result[10]_i_2_n_0 ),
        .I4(Q[1]),
        .I5(\result[11]_i_4_n_0 ),
        .O(D[8]));
  (* \PinAttr:I2:HOLD_DETOUR  = "179" *) 
  LUT4 #(
    .INIT(16'h00B8)) 
    \result[9]_i_2 
       (.I0(\result_reg[11] [2]),
        .I1(Q[2]),
        .I2(\result_reg[11] [6]),
        .I3(Q[3]),
        .O(\result[9]_i_2_n_0 ));
endmodule

module primitive_v2_boundary
   (result,
    amount,
    CLK,
    data);
  output [11:0]result;
  input [3:0]amount;
  input CLK;
  input [11:0]data;

  wire CLK;
  wire [3:0]amount;
  wire [11:0]data;
  wire [11:0]data_q;
  wire [3:0]\g_shift.amount_q ;
  wire [11:0]result;
  wire \result[0]_i_1_n_0 ;
  wire [11:1]result_d;

  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[0] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[0]),
        .Q(data_q[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[10] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[10]),
        .Q(data_q[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[11] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[11]),
        .Q(data_q[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[1] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[1]),
        .Q(data_q[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[2] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[2]),
        .Q(data_q[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[3] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[3]),
        .Q(data_q[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[4] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[4]),
        .Q(data_q[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[5] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[5]),
        .Q(data_q[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[6] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[6]),
        .Q(data_q[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[7] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[7]),
        .Q(data_q[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[8] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[8]),
        .Q(data_q[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[9] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[9]),
        .Q(data_q[9]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \g_shift.amount_q_reg[0] 
       (.C(CLK),
        .CE(1'b1),
        .D(amount[0]),
        .Q(\g_shift.amount_q [0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \g_shift.amount_q_reg[1] 
       (.C(CLK),
        .CE(1'b1),
        .D(amount[1]),
        .Q(\g_shift.amount_q [1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \g_shift.amount_q_reg[2] 
       (.C(CLK),
        .CE(1'b1),
        .D(amount[2]),
        .Q(\g_shift.amount_q [2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \g_shift.amount_q_reg[3] 
       (.C(CLK),
        .CE(1'b1),
        .D(amount[3]),
        .Q(\g_shift.amount_q [3]),
        .R(1'b0));
  dyn_left_shifter \g_shift.g_left.u_shift 
       (.D(result_d),
        .Q(\g_shift.amount_q ),
        .\result_reg[11] (data_q));
  LUT5 #(
    .INIT(32'h00000010)) 
    \result[0]_i_1 
       (.I0(\g_shift.amount_q [1]),
        .I1(\g_shift.amount_q [3]),
        .I2(data_q[0]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [0]),
        .O(\result[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[0] 
       (.C(CLK),
        .CE(1'b1),
        .D(\result[0]_i_1_n_0 ),
        .Q(result[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[10] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[10]),
        .Q(result[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[11] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[11]),
        .Q(result[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[1] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[1]),
        .Q(result[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[2] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[2]),
        .Q(result[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[3] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[3]),
        .Q(result[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[4] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[4]),
        .Q(result[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[5] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[5]),
        .Q(result[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[6] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[6]),
        .Q(result[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[7] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[7]),
        .Q(result[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[8] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[8]),
        .Q(result[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[9] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[9]),
        .Q(result[9]),
        .R(1'b0));
endmodule

(* ARITH = "0" *) (* ECO_CHECKSUM = "75f289d2" *) (* FILL_KIND = "0" *) 
(* KIND = "0" *) (* MODE = "0" *) (* N = "12" *) 
(* RESULT_W = "12" *) (* SHIFT_W = "4" *) 
(* NotValidForBitStream *)
(* \DesignAttr:ENABLE_NOC_NETLIST_VIEW  *) 
(* \DesignAttr:ENABLE_AIE_NETLIST_VIEW  *) 
module primitive_v2_top
   (clk,
    data,
    amount,
    fill_val,
    result);
  input clk;
  input [11:0]data;
  input [3:0]amount;
  input fill_val;
  output [11:0]result;

  wire [3:0]amount;
  wire clk;
  wire clk_core;
  wire [11:0]data;
  wire [11:0]result;

  primitive_v2_boundary u_boundary
       (.CLK(clk_core),
        .amount(amount),
        .data(data),
        .result(result));
  (* BOX_TYPE = "PRIMITIVE" *) 
  BUFG u_clock
       (.I(clk),
        .O(clk_core));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
