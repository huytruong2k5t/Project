"""OPT-15: isolated NF resource-sharing experiment; production stays frozen."""
from pathlib import Path
import hashlib
import json
import shutil
from audit_rtl_release import validate

R = Path(__file__).resolve().parents[1]
O = R / 'results/opt15_share_20261019'
C = R / 'rtl/candidates/mac_nf/opt15'


def replace_once(text, before, after):
    assert text.count(before) == 1, before
    return text.replace(before, after, 1)


def parser_shared(text):
    text = replace_once(text, '    wire ready_c;\n', '')
    text = replace_once(text, '    wire nar_c;\n', '')
    text = replace_once(text, '    logic c_sign_q;\n', '''    // Lane A accepts A first, then the atomically captured C_eff.
    logic [NB-1:0] c_raw_q;
    logic c_pending_q;
    logic c_nar_launch_q;
    logic parser_p1_c_q;
    logic parser_p2_c_q;
    wire parser_in_valid;
    wire parser_out_valid;
    wire parser_out_ready;
    wire parser_p2_ready;
    wire [NB-1:0] parser_input;
    logic c_sign_q;
''')
    text = replace_once(text, 'ready_a && ready_b && ready_c && add_ready',
                        'ready_a && ready_b && add_ready')
    text = replace_once(text,
                        'assign pair_retire=valid_a && valid_b && valid_c && core_ready;',
                        'assign pair_retire=valid_a && valid_b && core_ready;')
    text = replace_once(text, 'assign bypass=nar_a || nar_b || nar_c || z_a || z_b;',
                        'assign bypass=nar_a || nar_b || c_nar_launch_q || z_a || z_b;')
    start = text.index('    posit_parser #(\n')
    end = text.index('    ops_sel_comb #(\n', start)
    text = text[:start] + '''    // A and C carry one role bit through the same elastic stages.
    // Consume A at M0 launch; consume C independently into its context bank.
    assign parser_input = c_pending_q ? c_raw_q : a;
    assign parser_in_valid = pair_accept || c_pending_q;
    assign valid_a = parser_out_valid && !parser_p2_c_q;
    assign valid_c = parser_out_valid && parser_p2_c_q;
    assign parser_out_ready = parser_p2_c_q || pair_retire;
    assign parser_p2_ready = !parser_out_valid || parser_out_ready;
    assign s_c = s_a;
    assign z_c = z_a;
    assign sf_c = sf_a;
    assign frac_c = frac_a;

    posit_parser #(
        .NB (NB),
        .ES (ES)
    ) u_a (
        .clk (clk),
        .reset_n (reset_n),
        .in_valid (parser_in_valid),
        .in_ready (ready_a),
        .p (parser_input),
        .out_valid (parser_out_valid),
        .out_ready (parser_out_ready),
        .s (s_a),
        .is_zero (z_a),
        .is_nar (nar_a),
        .sf (sf_a),
        .frac (frac_a)
    );

    posit_parser #(
        .NB (NB),
        .ES (ES)
    ) u_b (
        .clk (clk),
        .reset_n (reset_n),
        .in_valid (pair_accept),
        .in_ready (ready_b),
        .p (b),
        .out_valid (valid_b),
        .out_ready (pair_retire),
        .s (s_b),
        .is_zero (z_b),
        .is_nar (nar_b),
        .sf (sf_b),
        .frac (frac_b)
    );

    always_ff @(posedge clk or negedge meta_sync2) begin
        if (!meta_sync2) begin
            c_raw_q <= '0;
            c_pending_q <= 1'b0;
            c_nar_launch_q <= 1'b0;
            parser_p1_c_q <= 1'b0;
            parser_p2_c_q <= 1'b0;
        end else begin
            if (c_pending_q && ready_a) begin
                c_pending_q <= `CK2Q 1'b0;
            end

            if (pair_accept) begin
                c_raw_q <= `CK2Q c_eff;
                c_pending_q <= `CK2Q 1'b1;
                c_nar_launch_q <= `CK2Q (c_eff == {1'b1, {(NB-1){1'b0}}});
            end

            if (ready_a) begin
                parser_p1_c_q <= `CK2Q c_pending_q;
            end

            if (parser_p2_ready) begin
                parser_p2_c_q <= `CK2Q parser_p1_c_q;
            end
        end
    end

''' + text[end:]
    text = replace_once(text, 'nar_q <= `CK2Q (nar_a || nar_b || nar_c);',
                        'nar_q <= `CK2Q (nar_a || nar_b || c_nar_launch_q);')
    text = replace_once(text, '''                c_sign_q <= `CK2Q s_c;
                c_zero_q <= `CK2Q z_c;
                c_nar_q <= `CK2Q nar_c;
''', '''            end
            if (valid_c) begin
                c_sign_q <= `CK2Q s_c;
                c_zero_q <= `CK2Q z_c;
                c_nar_q <= `CK2Q c_nar_launch_q;
''')
    return text


def pack_shared(text):
    # One outstanding product never needs a simultaneous replace in this bank.
    # Do not feed shared pack ready -> adder ready -> shared pack out ready.
    text = replace_once(text,
                        'assign product_parse_ready = !norm_valid_q || add_ready;',
                        'assign product_parse_ready = !norm_valid_q;')
    text = replace_once(text, '    wire product_sticky;\n', '''    wire product_sticky;
    wire shared_in_valid;
    wire shared_ready;
    wire shared_valid;
    wire shared_out_ready;
    wire shared_product;
    wire select_final;
    wire shared_sign;
    wire shared_zero;
    wire shared_nar;
    wire shared_sticky;
    wire signed [SF_W-1:0] shared_sf;
    wire [FIN-1:0] shared_frac;
    wire [4:0] shared_flags_in;
''')
    start = text.index('    posit_product_pack #(\n')
    end = text.index('    posit_magnitude_parse #(\n', start)
    text = text[:start] + '''    // Product and final-sum requests are separated by parse + three add stages.
    // The output role bit also controls backpressure and the public commit.
    assign select_final = add_valid;
    assign shared_in_valid = core_done || add_valid;
    assign shared_sign = select_final ? sum_sign : core_sign;
    assign shared_zero = select_final ? sum_zero : zero_q;
    assign shared_nar = select_final ? sum_nar : nar_q;
    assign shared_sf = select_final ? sum_sf : sf_norm;
    assign shared_frac = select_final ? sum_frac : frac_norm;
    assign shared_sticky = select_final ? sum_sticky : product_sticky;
    assign shared_flags_in = select_final ? sum_flags : norm_flags;
    assign product_pack_ready = shared_ready && !select_final;
    assign pack_ready = shared_ready;
    assign product_pack_valid = shared_valid && shared_product;
    assign pack_out_valid = shared_valid && !shared_product;
    assign shared_out_ready = shared_product ? product_parse_ready : out_ready;
    assign d = product_magnitude;
    assign flags = product_flags;

    posit_nf_shared_pack #(
        .NB (NB),
        .ES (ES),
        .F_IN (FIN),
        .SF_W (SF_W)
    ) u_shared_pack (
        .clk (clk),
        .reset_n (reset_n),
        .in_valid (shared_in_valid),
        .in_ready (shared_ready),
        .product_i (!select_final),
        .sign (shared_sign),
        .is_zero (shared_zero),
        .is_nar (shared_nar),
        .sf (shared_sf),
        .frac (shared_frac),
        .sticky (shared_sticky),
        .flags_in (shared_flags_in),
        .out_valid (shared_valid),
        .out_ready (shared_out_ready),
        .product_o (shared_product),
        .d (product_magnitude),
        .sign_o (product_sign_encoded),
        .flags (product_flags)
    );
''' + text[end:]
    # Never put an expression in a port map: the role is prepared in parallel.
    text = text.replace('    wire shared_product;\n',
                        '    wire shared_product;\n    wire shared_product_in;\n')
    text = text.replace('    assign select_final = add_valid;\n',
                        '    assign select_final = add_valid;\n    assign shared_product_in = !select_final;\n')
    text = text.replace('.product_i (!select_final)', '.product_i (shared_product_in)')
    start = text.index('    posit_pack #(\n')
    end = text.index('    always_ff @(posedge clk or negedge meta_sync2)', start)
    text = text[:start] + text[end:]
    return text


def main():
    validate(json.loads((R/'rtl/production_freeze.json').read_text()))
    assert not O.exists(), 'Never overwrite an existing experiment'
    O.mkdir(parents=True)
    C.mkdir(parents=True, exist_ok=True)
    base = (R/'rtl/mac_nf/mac_nf_wrapper.sv').read_text()
    variants = {'reference': base, 'parser2': parser_shared(base),
                'combined': pack_shared(parser_shared(base))}
    manifest = {'reference_release': 'POSIT_MAC_RTL_20261018_OPT12_120',
                'variants': {}, 'policy': 'No production promotion; candidate study only'}
    paths = (R/'rtl/production.f').read_text().splitlines()
    for variant, code in variants.items():
        dest = O/'source'/variant
        for rel in paths+['rtl/posit_mac.vh']:
            p = dest/rel
            p.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(R/rel, p)
        (dest/'rtl/mac_nf/mac_nf_wrapper.sv').write_text(code, encoding='utf-8', newline='\n')
        filelist = paths.copy()
        if variant == 'combined':
            p = dest/'rtl/mac_nf/posit_nf_shared_pack.sv'
            shutil.copy2(C/'posit_nf_shared_pack.sv', p)
            filelist.append('rtl/mac_nf/posit_nf_shared_pack.sv')
        (dest/'rtl/production.f').write_text('\n'.join(filelist)+'\n')
        if variant != 'reference':
            p = C/variant/'mac_nf_wrapper.sv'
            p.parent.mkdir(exist_ok=True)
            p.write_text(code, encoding='utf-8', newline='\n')
        manifest['variants'][variant] = {
            p.relative_to(dest).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in dest.rglob('*') if p.is_file()}
    (O/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
    print('OPT15 prepared: reference, parser2, combined; frozen production unchanged')


if __name__ == '__main__':
    main()
