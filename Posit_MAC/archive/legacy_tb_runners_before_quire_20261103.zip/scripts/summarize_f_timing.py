"""Collect measured F-only candidates; retain per-bank and raw timing evidence."""
import argparse
import csv
import hashlib
import json
import re
from pathlib import Path

root=Path(__file__).resolve().parent.parent
ap=argparse.ArgumentParser()
ap.add_argument('--winner')
args=ap.parse_args()
out=root/'results/f_timing_optimization_20261101'
refs=[('before_parser_refactor','carry/group; shared old adder LOD',root/'results/readme_refactor_recheck_20261101'),
      ('p11_current','prefix/flat; current shared adder LOD',root/'results/parser_lod_refactor_recheck_20261101')]
experiments=json.loads((root/'experiments/f_timing_20261101/candidates.json').read_text())
refs += [(k,v['magnitude']+'/'+v['parser_lod']+'; F-only parser',out/k) for k,v in experiments.items()]
records=[]
for label,description,path in refs:
    if not (path/'f2f_f/status.txt').exists(): continue
    assert (path/'f2f_f/status.txt').read_text(encoding='utf-8-sig').strip()=='F2F_REPORT_COMPLETE'
    bank_rows=list(csv.DictReader((path/'f2f_f/stages.csv').open(encoding='utf-8-sig')))
    banks={r['group']:r for r in bank_rows if r['target_kind']==('D_CE' if r['group']=='whole_f2f' else 'D')}
    whole=banks['whole_f2f']
    util=(path/'synth_f_final/synthesis_utilization.rpt').read_text()
    timing=(path/'synth_f_final/synthesis_timing.rpt').read_text()
    w=re.search(r'^\s*(-?\d+\.\d+)\s+(-?\d+\.\d+)\s+\d+\s+\d+\s+(-?\d+\.\d+)',timing[timing.index('WNS(ns)'):],re.M)
    record=dict(label=label,description=description,path=str(path),
        F2F_ns=float(whole['data_delay_ns']),logic_ns=float(whole['logic_delay_ns']),net_ns=float(whole['net_delay_ns']),
        levels=int(whole['levels']),slack_f2f_ns=float(whole['slack_ns']),startpoint=whole['startpoint'],endpoint=whole['endpoint'],
        LUT=int(re.search(r'\| Slice LUTs\*\s*\|\s*(\d+)',util)[1]),
        FF=int(re.search(r'\| Slice Registers\s*\|\s*(\d+)',util)[1]),WNS_ns=float(w[1]),WHS_ns=float(w[3]),banks=banks)
    if label in experiments:
        manifest=json.loads((path/'manifest.json').read_text(encoding='utf-8-sig'))
        for rel,digest in manifest['sha256'].items():
            assert hashlib.sha256((path/'source'/rel).read_bytes()).hexdigest().upper()==digest,rel
        assert (path/'verify/status.txt').read_text(encoding='utf-8-sig').strip()=='PASS'
        assert (path/'verify_parser_f/status.txt').read_text(encoding='utf-8-sig').strip()=='PASS'
        record['verification']={name:re.findall(r'^# (.*_PASS[^\n]*)', (path/rel).read_text(),re.M) for name,rel in
            [('f','verify/f.log'),('adder','verify/adder.log'),('packer','verify/packer.log'),('parser','verify_parser_f/parser.log')]}
        if label=='p20':
            assert any('PARSER_TRANSITION_DUT_PASS checked=4000000' in marker for marker in record['verification']['parser'])
    records.append(record)
assert records
summary={'part':'xc7a35tcpg236-1','period_ns':10,'scope':'F only; FLOOR/Q12; no NF optimization, no place/route/bitstream',
    'winner':args.winner,'records':records}
(out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
columns=['label','description','F2F_ns','logic_ns','net_ns','levels','slack_f2f_ns','LUT','FF','WNS_ns','WHS_ns','startpoint','endpoint','path']
with (out/'comparison.csv').open('w',newline='',encoding='utf-8-sig') as f:
    writer=csv.DictWriter(f,fieldnames=columns,extrasaction='ignore');writer.writeheader();writer.writerows(records)
lines=['# Tối ưu timing MAC F — 01/11/2026','',
    'Thử nghiệm chỉ MAC F. Nguồn NF, parser dùng cho NF, bộ cộng và LOD dùng chung được giữ nguyên. Các candidate dùng posit_parser_f riêng tại A/B/C của F; không thêm tầng, không đổi số học FLOOR/Q12, không thay golden.','',
    '## Điều kiện đo','',
    'Vivado2026.1; xc7a35tcpg236-1; OOC synthesis; clock10ns, setup/hold uncertainty0.1ns; input min=max2.5ns, output min0/max0.5ns; rebuilt hierarchy; DSP/BRAM0. Không chạy place/route/bitstream. Net delay là ước lượng unplaced; WHS chưa đóng hold.','',
    '## So sánh','',
    '| Candidate | Magnitude/LOD parser | F2F (ns) | Logic (ns) | Net (ns) | Levels | LUT | FF | WNS (ns) | WHS (ns) |',
    '| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
for r in records:
    lines.append(f"| {r['label']} | {r['description']} | {r['F2F_ns']:.3f} | {r['logic_ns']:.3f} | {r['net_ns']:.3f} | {r['levels']} | {r['LUT']} | {r['FF']} | {r['WNS_ns']:.3f} | {r['WHS_ns']:.3f} |")
lines += ['', 'P11 là snapshot đầu phiên đã verify/synthesis trước đó, không phải RTL được chọn sau tối ưu; số đo được tái dùng vì nguồn ban đầu và recipe trùng snapshot. Baseline before_parser_refactor còn dùng LOD cũ cho adder, vì vậy P00 giữ adder flat không hoàn toàn giống baseline đó. Các số setup WNS toàn top có cả I/O; F2F là Data Path Delay trên đường FF→D/CE có setup slack xấu nhất, không phải Fmax.', '']
lines += ['P20 là thử nghiệm bổ sung sau ma trận: giữ carry magnitude cho payload/FRB nhưng tính transition regime trực tiếp từ mã p. Với L[i]=OR các bit dưới i, m[i]=p[i] XOR (s AND L[i]); suy ra transition[i]=p[i] XOR p[i+1] XOR (s AND p[i] AND NOT L[i]). Đã kiểm riêng30 bit transition thực sự của DUT trên4M mẫu trước khi synthesis. Đây là một thay đổi topology tổ hợp, không thêm pipeline.', '',
          'Worst endpoint/source có thể đổi giữa candidate; không cộng tuyến tính chênh lệch timing để quy riêng từng cấu trúc RTL. Đọc thêm parser_c_count_bits.csv và raw path để đối chiếu cùng đích. P10 có cảnh báo Synth8-3936 trim một bit lower_any không được dùng; giữ nguyên log để kiểm chứng.', '']
if args.winner:
    selected=next(r for r in records if r['label']==args.winner)
    original=next(r for r in records if r['label']=='p11_current')
    old=records[0]
    lines += ['## Phương án được chọn','',
        f"Chọn {args.winner}: {selected['description']}. F2F {original['F2F_ns']:.3f}→{selected['F2F_ns']:.3f} ns, giảm {100*(original['F2F_ns']-selected['F2F_ns'])/original['F2F_ns']:.2f}% so bản trước phiên tối ưu; so baseline trước refactor {old['F2F_ns']:.3f} ns là {selected['F2F_ns']-old['F2F_ns']:+.3f} ns.", '',
        f"Worst path mới: `{selected['startpoint']}` → `{selected['endpoint']}`; {selected['levels']} levels, logic {selected['logic_ns']:.3f} ns + net {selected['net_ns']:.3f} ns. LUT {original['LUT']}→{selected['LUT']}; FF {original['FF']}→{selected['FF']}.", '']
    if (out/'promotion.json').exists():
        promotion=json.loads((out/'promotion.json').read_text())
        assert promotion['winner']==args.winner and promotion['live_rtl_matches_measured_snapshot']
        lines += ['Đã đưa đúng byte RTL của candidate được chọn vào cây làm việc; [promotion.json](promotion.json) lưu hash toàn active RTL, chứng minh NF và shared RTL giữ nguyên. [before_promotion/](before_promotion/) giữ các file trước khi thay đổi. File list active và opt17 đã bổ sung hai module parser riêng cho F; production.f lịch sử không sửa.', '']
for r in records:
    if r['label'] not in experiments: continue
    label=r['label']
    lines += [f"## {label}: nguồn và verification",'',
        f"- [Manifest nguồn]({label}/manifest.json), [snapshot RTL]({label}/source/rtl/mac_f/mac_f_wrapper.sv), [DCP synthesis]({label}/synth_f_final/synthesis.dcp)",
        f"- [MAC F log]({label}/verify/f.log), [parser/LOD log]({label}/verify_parser_f/parser.log)",
        f"- [F2F từng bank CSV]({label}/f2f_f/stages.csv), [worst F2F]({label}/f2f_f/whole_f2f_D_CE.rpt), [top20 F2F]({label}/f2f_f/whole_f2f_top20.rpt), [I/O→FF]({label}/f2f_f/input_to_register_top10.rpt)", '']
    for markers in r['verification'].values():
        lines += ['- '+marker.strip() for marker in markers]
    lines += ['', '| Bank đích | Delay (ns) | Logic (ns) | Net (ns) | Levels |', '| --- | ---: | ---: | ---: | ---: |']
    for name,bank in r['banks'].items():
        if bank['data_delay_ns']=='NA': continue
        lines.append(f"| {name} | {bank['data_delay_ns']} | {bank['logic_delay_ns']} | {bank['net_delay_ns']} | {bank['levels']} |")
    lines += ['']
lines += ['## Giới hạn và tái chạy','',
    'MAC regression dùng cfg_mode=1, n0..12, OPS0/1 với golden Python integer Posit32/es3 cho FLOOR hiện hành; 50000 accepted gồm reset-aborted được hạch toán. Parser kiểm4M magnitude trên RTL thật, LOD serial500063 vector, parser đầy đủ có stalls/reset và đối chiếu baseline. Không là nghiệm thu FULL_TERM26/Q24 hay ma trận52 điểm/520M của SPEC.','',
    'Tái chạy một candidate bằng RunRoot mới; chọn SourceRoot từ experiments/f_timing_20261101/<candidate>. Các source thí nghiệm và manifest được giữ nguyên.','',
    '```powershell',
    './scripts/run_refactored_mac.ps1 -Stage Verify -RunRoot results/<run_moi> -VerifyScope F -VectorCount 50000 -SourceRoot experiments/f_timing_20261101/<candidate>',
    './scripts/run_f_parser_equiv.ps1 -RunRoot results/<run_moi>',
    './scripts/run_refactored_mac.ps1 -Stage SynthF -RunRoot results/<run_moi> -SynthSuffix _final',
    './scripts/report_refactored_mac_f2f.ps1 -Variant f -RunRoot results/<run_moi>', '```', '']
(out/'summary.md').write_text('\n'.join(lines),encoding='utf-8')
print(json.dumps([{k:r[k] for k in ['label','F2F_ns','LUT','FF','WNS_ns','WHS_ns']} for r in records],indent=2))
