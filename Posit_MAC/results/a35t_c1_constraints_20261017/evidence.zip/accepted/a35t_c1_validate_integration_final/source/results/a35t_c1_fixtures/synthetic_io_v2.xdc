# SYNTHETIC VALIDATION ONLY; NOT FOR PPA/BOARD
# A35T-C1 SYSTEM-SYNCHRONOUS I/O TEMPLATE. NOT BOARD TIMING.
# Copy inside this project and replace ALL @...@ tokens with real facts.
# One command per line; clk is defined by a35t_clock.xdc.
# Values are ns at the IP boundary, including the source/receiver and relative
# data/clock connection timing. Do not choose min to remove hold violations.
# Output min may be negative. Another clock/phase needs another interface flow.
# Pinout/IOSTANDARD are separate; this file does not establish board signoff.
# TIMING_REFERENCE: TEST_ONLY_NOT_BOARD
# INPUT_DATA_REFERENCE: TEST_ONLY_NOT_BOARD
# INPUT_CONTROL_REFERENCE: TEST_ONLY_NOT_BOARD
# OUTPUT_DATA_REFERENCE: TEST_ONLY_NOT_BOARD
# OUTPUT_CONTROL_REFERENCE: TEST_ONLY_NOT_BOARD
set_input_delay -clock clk -min 0.100 [get_ports {a[*] b[*] c[*]}]
set_input_delay -clock clk -max 1.000 [get_ports {a[*] b[*] c[*]}]
set_input_delay -clock clk -min 0.100 [get_ports {rst_n in_valid acc_mode acc_clr cfg_mode cfg_n[*] cfg_ops[*] out_ready}]
set_input_delay -clock clk -max 1.000 [get_ports {rst_n in_valid acc_mode acc_clr cfg_mode cfg_n[*] cfg_ops[*] out_ready}]
set_output_delay -clock clk -min -0.200 [get_ports {d[*] flags[*]}]
set_output_delay -clock clk -max 0.600 [get_ports {d[*] flags[*]}]
set_output_delay -clock clk -min -0.200 [get_ports {in_ready out_valid}]
set_output_delay -clock clk -max 0.600 [get_ports {in_ready out_valid}]
