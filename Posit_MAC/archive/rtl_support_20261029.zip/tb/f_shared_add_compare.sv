// Verification-only wrapper; no observers are present on the production top.
module f_shared_add_compare (
    input logic clk,
    input logic rst_n,
    input logic in_valid,
    output wire [2:0] ready,
    input logic [31:0] a,
    input logic [31:0] b,
    input logic [31:0] c,
    input logic acc_mode,
    input logic acc_clr,
    input logic cfg_mode,
    input logic [3:0] cfg_n,
    input logic [1:0] cfg_ops,
    output wire [2:0] valid,
    input logic out_ready,
    output wire [31:0] d_ref,
    output wire [31:0] d_parser,
    output wire [31:0] d_shared,
    output wire [4:0] flags_ref,
    output wire [4:0] flags_parser,
    output wire [4:0] flags_shared,
    output wire [31:0] acc_ref,
    output wire [31:0] acc_parser,
    output wire [31:0] acc_shared
);
    mac_f_wrapper_reference u_ref (
        .clk(clk), .rst_n(rst_n), .in_valid(in_valid), .in_ready(ready[0]),
        .a(a), .b(b), .c(c), .acc_mode(acc_mode), .acc_clr(acc_clr),
        .cfg_mode(cfg_mode), .cfg_n(cfg_n), .cfg_ops(cfg_ops),
        .out_valid(valid[0]), .out_ready(out_ready), .d(d_ref), .flags(flags_ref)
    );
    mac_f_wrapper_parser2 u_parser (
        .clk(clk), .rst_n(rst_n), .in_valid(in_valid), .in_ready(ready[1]),
        .a(a), .b(b), .c(c), .acc_mode(acc_mode), .acc_clr(acc_clr),
        .cfg_mode(cfg_mode), .cfg_n(cfg_n), .cfg_ops(cfg_ops),
        .out_valid(valid[1]), .out_ready(out_ready), .d(d_parser), .flags(flags_parser)
    );
    mac_f_wrapper_shared_add u_shared (
        .clk(clk), .rst_n(rst_n), .in_valid(in_valid), .in_ready(ready[2]),
        .a(a), .b(b), .c(c), .acc_mode(acc_mode), .acc_clr(acc_clr),
        .cfg_mode(cfg_mode), .cfg_n(cfg_n), .cfg_ops(cfg_ops),
        .out_valid(valid[2]), .out_ready(out_ready), .d(d_shared), .flags(flags_shared)
    );
    assign acc_ref = u_ref.accumulator_q;
    assign acc_parser = u_parser.accumulator_q;
    assign acc_shared = u_shared.accumulator_q;
endmodule
