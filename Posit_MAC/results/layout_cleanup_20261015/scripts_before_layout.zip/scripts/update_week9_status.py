"""Update existing Markdown status files; do not create Markdown files."""
import json
import re
from pathlib import Path

root = Path(__file__).resolve().parents[1]
summary = json.loads((root / "results/week9_implementation/summary.json").read_text(encoding="utf-8"))
accepted = summary["components"].get("multiplier_acceptance")
numerical = (f"ModelSim đối chiếu {accepted['comparedTransactions']:,} giao dịch, "
             f"hủy {accepted['resetAborts']:,} giao dịch bằng reset,0 mismatch."
             if accepted else "Kiểm 10⁷ RTL đang chạy; chưa có kết quả nghiệm thu lượt lớn.")
if accepted:
    numerical=numerical.replace(f"{accepted['comparedTransactions']:,}",f"{accepted['comparedTransactions']:,}".replace(",","."))
    numerical=numerical.replace(f"{accepted['resetAborts']:,}",f"{accepted['resetAborts']:,}".replace(",","."))

def read(path):
    if not path.exists():
        raise RuntimeError(f"refuse to create Markdown: {path}")
    return path.read_text(encoding="utf-8-sig")

def write(path, text):
    if accepted:
        text=re.sub(r"ModelSim đối chiếu [\d.,]+ giao dịch[,.] hủy [\d.,]+ giao dịch bằng reset[,.]\s*0 mismatch\.",numerical,text)
    text=text.replace("Corpus lớn10.080.000 dòng,16 profile,36 ô mode/ops/n mỗi profile; generator exact/RNE so SoftPosit1.890.000 lượt và oracle ES3 độc lập630.000 lượt.",
        "Corpus random-bit10.080.000 dòng chỉ kiểm số học, không đủ coverage regime dài. Đã bổ sung corpus phân tầng16.896.000 dòng/16 profile, có36 ô mode/ops/n, nhóm regime–dấu và fraction đặc thù theo §6.3. Generator phân tầng kiểm3.168.256 exact/RNE với L0 và1.056.256 với oracle ES3 độc lập; chỉ số này chưa thay kiểm RTL. Chạy riêng từng profile bằng verify_week9_multiplier_parallel.ps1; pilot đối chuẩn cùng checker đạt31.840 giao dịch/0 mismatch. Lượt16-DUT cũ đã dừng và không được tính nghiệm thu.")
    text=text.replace("Output force-X=0x1ae34000. Không có bằng chứng mới", "Output force-X=0x1ae34000; kiểm thêm đủ128 entry PT2 và tie-A đạt. Không có bằng chứng mới")
    text=text.replace("Gate2/tuần9 processing: thiếu lint Verilator chính thức.","Gate2/tuần9 processing: cần lint/harness Verilator chính thức và review coverage phân tầng §6.3; random bit đủ số lượng không thay coverage.")
    text=text.replace("Gate2/tuần9 vẫn processing do lint chính thức còn thiếu;", "Gate2/tuần9 vẫn processing do lint/harness chính thức còn thiếu và cần review coverage phân tầng;")
    if summary.get("structural_coverage_review", "").startswith("PASS"):
        text=text.replace("còn nghiệm thu lớn/lint Gate2", "đã đạt lượt lớn/coverage chức năng; còn lint/harness chính thức Gate2")
        text=text.replace("Còn nghiệm thu lớn/lint Gate2", "Đạt lượt lớn/coverage chức năng; còn lint/harness chính thức Gate2")
        text=text.replace("và cần review coverage phân tầng", "(coverage chức năng phân tầng đã đạt)")
        text=text.replace("và review coverage phân tầng §6.3; random bit đủ số lượng không thay coverage", "; coverage chức năng §6.3 đã kiểm đạt, line/branch/toggle chưa đo")
        text=text.replace("Gate2 còn kiểm lớn/lint theo PLAN L1 mục7", "Gate2 đã đạt lượt lớn/coverage chức năng, còn lint/harness chính thức theo PLAN L1 mục7")
        text=text.replace("core/bridge và multiplier standalone đã triển khai, kiểm pilot và đang nghiệm thu lớn theo mục7", "core/bridge và multiplier standalone đã kiểm lượt lớn/coverage chức năng theo mục7")
        text=text.replace("Core/bridge và multiplier standalone đã triển khai, kiểm pilot và đang nghiệm thu lớn09/10", "Core/bridge và multiplier standalone đã kiểm lượt lớn/coverage chức năng09/10")
        text=text.replace("lượt lớn/lint theo PLAN mục7", "lint/harness chính thức theo PLAN mục7; lượt lớn/coverage chức năng đã đạt")
    backup=summary.get("git_push", {})
    if backup.get("status") == "PUSHED":
        message=f"GitHub đã push checkpoint {backup['commit'][:7]} lên {backup['branch']} bằng checkout riêng trong Posit_MAC; kết quả lượt lớn được bổ sung cuối phiên."
        text=text.replace("Git push bị chặn vì thư mục không phải Git checkout; không tự init/force/reset hoặc sửa thư mục khác.",message)
        text=text.replace("GitHub backup đang vướng do thư mục không có Git checkout.",message)
        text=text.replace("Git không có checkout: push chưa thực hiện; không tự init, thay remote, force hoặc sửa thư mục khác. Nguồn + hash được lưu local, không gọi đó là GitHub backup.",message)
        text=text.replace("Verilator/lint thiếu và Git checkout không có là hai trở ngại vận hành, không đổi mô hình để né tiêu chí.","Verilator/lint còn thiếu; GitHub backup đã có checkout riêng trong dự án. Không đổi mô hình để né tiêu chí.")
        text=text.replace("GitHub backup còn vướng do chưa có Git checkout","Đã push checkpoint code/log lên GitHub; kết quả Gate2 sẽ bổ sung cuối phiên")
    path.write_text(text, encoding="utf-8")

def append_once(path, marker, body, before=None):
    text = read(path)
    if marker not in text:
        section=marker+"\n\n"+body.strip()+"\n\n"
        if before is not None:
            if before not in text:
                raise RuntimeError(f"missing section anchor: {before}")
            text=text.replace(before,section+before,1)
        else:
            text = text.rstrip()+"\n\n"+section
    elif accepted:
        text = text.replace("Kiểm 10⁷ RTL đang chạy; chưa có kết quả nghiệm thu lượt lớn.", numerical)
    write(path, text)

plan_path = root / "l1/PLAN.md"
plan = read(plan_path)
for milestone in ("W9-03", "W9-R1", "W9-R2", "W9-04", "W9-05"):
    plan = re.sub(rf"(?m)^(\| {milestone} \|.*\| )(?:không|processing)( \|)$", r"\1✅\2", plan)
plan = re.sub(r"(?m)^(\| W9-06 \|.*\| )(?:không|processing)( \|)$", r"\1processing\2", plan)
plan = plan.replace("**Bước thực thi tiếp theo là W9-03:**", "**Mốc W9-03 đã được thực hiện 09/10/2026; hợp đồng vẫn giữ:**")
plan = plan.replace("Parser/packer đã nghiệm thu đơn vị; tuần9 bắt đầu với giao diện và OPS/SAC tổ hợp. Core/bridge/MAC RTL chưa nghiệm thu.",
    "Parser/packer đã nghiệm thu đơn vị; core/bridge và multiplier standalone đã triển khai, kiểm pilot và đang nghiệm thu lớn theo mục7 (trạng thái09/10/2026). Gate2 còn processing; MAC RTL chưa nghiệm thu.")
write(plan_path, plan)
detail = f"""W9-03 đã kiểm shifter, cộng tổ hợp, normalize/adapter:252.455 commit trên width1/5/12/26/27, hai scheme,0 mismatch. Bank `sbm_accum` được kiểm trong core; FLOOR bỏ padding trước normalize, không đưa input_cut vào numerical sticky.

W9-R1 chốt interface `paper_ops_comb`/`paper_step_comb`: Q12/prefix7 đệm0, tie-A, anchor số hạng đầu và payload13+carry1 là giả định tái dựng; RND/complement, coefficient âm và cut trước cộng/trừ ghi riêng. W9-R2 đạt843 commit,293 bản ghi (292 bản ghi corpus/206 trường hợp phân biệt + một fixture Fig.4),0 mismatch. Output force-X=0x1ae34000. Không có bằng chứng mới để chạy R3 hoặc xác nhận RTL tác giả.

W9-04 đạt39.580 giao dịch hoàn tất và420 lượt reset hủy; width1/5/12/26/27, exact vượt N_MAX, n=0/early-stop, done=t+2 hoặc3, drain và context cố định đều được kiểm. W9-05 tích hợp parser A/B → M0/core → norm → packer với một slot dự trữ; pilot bản cuối31.840 giao dịch +160 reset hủy,0 mismatch. Reset bridge lấy mẫu rst_n; out_valid bị chặn tại cạnh reset, mỗi leaf nhả qua hai FF. RNE: L_valid=max(1,t)+7, TRUNC:max(1,t)+6; handshake khi không stall sau đó một cạnh. Thử config reserved/n>N_MAX, NaR/zero, stall dài, cạnh reset và giữ thứ tự.

{numerical}

Corpus lớn10.080.000 dòng,16 profile,36 ô mode/ops/n mỗi profile; generator exact/RNE so SoftPosit1.890.000 lượt và oracle ES3 độc lập630.000 lượt. Generator/fixture không thay nghiệm thu RTL. Verilator chưa có; `make lint` hiện trả lỗi khi thiếu công cụ thay vì skip rồi báo thành công. Harness C++ và `scripts/verify_week9_verilator.sh` đã chuẩn bị nhưng chưa build/chạy, cần đối chuẩn pilot khi có công cụ. Không tự cài công cụ ngoài quyền đã cấp.

Quartus13 phân tích/tổng hợp NB32/ES2/FLOOR/RNE đạt0 lỗi,14 warning đã phân loại (license parallel, attribute ASYNC_REG của Xilinx và constant resize có giới hạn); không có cảnh báo latch. Đây không thay strict lint, STA, CDC, PPA hay Gate4. Chỉ đổi generate/genvar để hỗ trợ compiler cũ trong hai shifter/OPS, không đổi phương trình; đã chạy lại327.440 frontend vector và843 paper commit đạt.

Bằng chứng, compiler, seed20261009, SoftPosit library hash, lệnh và SHA256: `results/week9_implementation/summary.json`; các log ở `results/week9_arithmetic`, `week9_paper`, `week9_core`, `week9_multiplier`. Gate2/tuần9 vẫn processing do lint chính thức còn thiếu; tuần4/provenance paper giữ processing. Git push bị chặn vì thư mục không phải Git checkout; không tự init/force/reset hoặc sửa thư mục khác.
"""
append_once(plan_path, "### 7.4. Triển khai và kiểm chứng — 09/10/2026", detail)
if summary.get("structural_coverage_review", "").startswith("PASS"):
    acceptance_note="""Lượt phân tầng cuối đạt16.815.920 giao dịch hoàn tất,80.080 reset hủy; control random-bit đạt10.032.224 giao dịch,47.776 reset hủy; cả hai0 mismatch. Audit đối chiếu SHA fixture với log PASS và loại reset-abort trước coverage:16 profile đầy đủ, posit32 đạt256/256 bin regime–dấu, tối thiểu4.104 mẫu/bin và26.241 operands mỗi run/polarity hữu hạn;36 ô mode/OPS/n mỗi profile. Code coverage line/branch/toggle chưa đo.

Corner riêng đạt114.656 so sánh/544 reset hủy,3600 trường hợp khác nhau mỗi profile (100 cặp ×36 config), gồm ±1, ±minpos/maxpos và NaR×0/0×NaR; Linux/Windows/UBSan và replay32.000 dòng uniform cũ khớp. Pilot stall96 chu kỳ đạt31.840 so sánh/160 reset,336 lượt giữ dài;0 mismatch. Chỉ chỉnh khoảng trắng RTL để tách port/parameter, có proof và pilot biên dịch lại; SHA nguồn trước/sau lưu riêng. Logic không đổi, TableI không chạy lại.

Gate2/W9-06 vẫn processing: Verilator chưa có, harness C++ và lint chính thức chưa build/chạy. Không tự cài công cụ hoặc thay tiêu chí. Bằng chứng: results/week9_multiplier/{stratified_acceptance,acceptance_parallel,corners_final_rtl,long_stall_pilot}; snapshot/version/seed/lệnh tại results/week9_implementation/summary.json."""
    for target in (plan_path, root / "tb/README.md", root / "scripts/README.md"):
        body=read(target)
        marker="Lượt phân tầng cuối đạt16.815.920 giao dịch"
        if marker not in body:
            write(target,body.rstrip()+"\n\n"+acceptance_note+"\n")

spec_path = root / "SPEC_Posit_MAC_IP.md"
spec = read(spec_path)
spec = spec.replace("Giao diện thanh ghi/token bên dưới đã chốt cho code tiếp theo; mới có OPS/SAC tổ hợp được triển khai.",
                    "Giao diện thanh ghi/token bên dưới đã chốt và đã có RTL đến multiplier standalone; nghiệm thu Gate2 còn processing.")
spec = spec.replace("Controller tương lai", "Controller")
spec = spec.replace("Đây là yêu cầu triển khai, chưa có nghiệm thu handshake/reset ở core.",
                    "Core đã kiểm lịch done/reset/context 09/10; multiplier standalone đã kiểm pilot handshake. Không suy thành Gate2 hoặc RTL MAC.")
spec = spec.replace("RTL tích hợp (hợp đồng, chưa triển khai)", "RTL tích hợp (standalone multiplier đã triển khai; MAC còn theo kế hoạch)")
spec = spec.replace("SBM/core/top/Gate2 còn triển khai theo PLAN L1 mục7.",
                    "SBM/core/top standalone đã triển khai và kiểm pilot 09/10; Gate2 còn kiểm lớn/lint theo PLAN L1 mục7. Paper RTL843 commit/Fig.4 đạt trong profile tái dựng, không xác nhận baseline gốc.")
spec = spec.replace("**Lịch core baseline không chồng lấn, chưa triển khai RTL:**",
                    "**Lịch core baseline không chồng lấn — đã triển khai và kiểm đơn vị 09/10/2026:**")
write(spec_path, spec)
append_once(spec_path, "### 11.4 Bằng chứng RTL tuần9 — 09/10/2026", f"""SBM/normalize/adapter đã kiểm252.455 lượt; core đạt39.580 giao dịch và420 reset hủy; standalone multiplier pilot31.840 giao dịch và160 reset hủy. Cả ba suite0 mismatch. Nghiên cứu paper riêng đạt843 commit/293 bản ghi, Fig.4 force-X=0x1ae34000; không xác nhận tie/padding/guard hoặc RTL gốc. Hợp đồng normative giữ §5.5-A/§5.7/§5.9-D.

{numerical}

Gate2/tuần9 processing: thiếu lint Verilator chính thức. Quartus13 Analysis & Synthesis NB32/ES2 đạt0 lỗi,14 warning đã phân loại, không có cảnh báo latch; không thay STA/CDC/PPA. TableI không chạy lại vì chưa có thay đổi có căn cứ. Kế hoạch/bằng chứng chi tiết: PLAN L1 §7.4 và results/week9_implementation/summary.json. GitHub backup đang vướng do thư mục không có Git checkout.
""", before="## 12. Báo cáo và bảo vệ")

append_once(root / "l1/README.md", "## 22. RTL multiplier tuần9 — 09/10/2026", detail+"\nBuild generator bằng các target `gen_week9_arithmetic`, `gen_week9_core`, `gen_week9_paper`, `gen_week9_multiplier` trong Makefile L1, cùng hậu tố `.exe` và `_ubsan`. `gen_week9_paper` dùng corpus có sẵn, không đổi vector/seed. ES3 exact/RNE dùng decode + product nguyên + encoder bit-list độc lập, không gọi parser/packer L1. SoftPosit chỉ dùng ở ES0/1/2.")
rtl_readme=root / "rtl/README.md"
rtl_text=read(rtl_readme).replace("Hợp đồng tích hợp cập nhật 06/10/2026 — SPEC v1.4", "Hợp đồng tích hợp cập nhật 08/10/2026 — SPEC v1.5")
rtl_text=rtl_text.replace("Đây là hợp đồng triển khai, chưa nghiệm thu core/bridge/MAC RTL.","Core/bridge và multiplier standalone đã triển khai, kiểm pilot và đang nghiệm thu lớn09/10; Gate2 processing, MAC RTL chưa nghiệm thu.")
rtl_text=rtl_text.replace("Bước tiếp theo: packer tuần8, rồi core và tích hợp; chồng lấn sau baseline.","Bước tiếp theo: đóng Gate2 tuần9 theo PLAN L1 mục7; chồng lấn sau baseline.")
rtl_text=rtl_text.replace("Context M0 trong `mul_iter_core` (kế hoạch)","Context M0 trong `mul_iter_core`")
rtl_text=rtl_text.replace("| Tuần9, chưa triển khai |","| Đã triển khai/kiểm core09/10; chưa đóng Gate2 |")
rtl_text=rtl_text.replace("Controller tương lai sở hữu count/token", "`iter_ctrl` sở hữu count/token")
write(rtl_readme,rtl_text)
append_once(rtl_readme, "## 8. Multiplier standalone và research paper — 09/10/2026", detail+"\n`posit_mul_iter` là top chỉ ghép instance. `mul_iter_wrapper` chốt cfg ở handshake E0, nhận cặp parser nguyên tử, giữ slot đến retire. `mul_iter_core` chốt context ở launch L0, `iter_ctrl` phát L1, bank term L2, `sbm_accum` commit L3. `mul_norm_comb` đồng thời thực hiện adapter không làm tròn; wrapper có một bank norm trước packer. Ports top:clk/rst_n/in_valid/in_ready/a/b/cfg_mode/cfg_n/cfg_ops/out_valid/out_ready/d/flags. ROUND_SCHEME và ROUND_MODE là tham số compile; cfg_mode/cfg_n/cfg_ops được chốt mỗi giao dịch. Baseline test EXACT_EN=OPS_EN=1; disable policy đã kiểm ở OPS đơn vị, không tuyên bố coverage full top mọi tham số tùy biến.")
append_once(root / "tb/README.md", "## 6. Kiểm chứng multiplier tuần9 — 09/10/2026", """Các suite mới: `tb_week9_arithmetic` (term/acc/norm/adapter), `tb_week9_paper` (score/commit/pack paper), `tb_week9_core` (latency/reset/context/drain) và `tb_week9_multiplier` (baseline top,16 profile, cả d và flags).

ModelSim chạy fixture trong thư mục kết quả riêng; scripts fail khi thiếu vector/marker hoặc gặp Fatal/Error. Vector bị reset hủy được đếm riêng, không tính vào ngưỡng10⁷ so RTL=L1. Lượt pilot bản cuối31.840 so sánh và160 reset,0 mismatch. Competing input được giữ trong lúc busy; output bị stall; reset quay qua parser/core/drain/output. Nguồn phải đặt config hợp lệ trước chờ in_ready vì wrapper từ chối reserved/n>N_MAX.

Harness `week9_multiplier_harness.cpp` và script Verilator đã chuẩn bị, chưa có bằng chứng build/chạy do công cụ thiếu. Verilator --no-timing bỏ CK2Q cho kiểm chức năng theo cạnh; ModelSim là bằng chứng có CK2Q. Cần đối chuẩn pilot hai engine trước nhận lượt lớn Verilator. Bằng chứng hiện tại ở `results/week9_implementation/summary.json`.

"""+numerical)
append_once(root / "scripts/README.md", "## 5. Kiểm chứng tuần9 và giới hạn quyền", """Chạy từ Posit_MAC: `verify_week9_arithmetic_modelsim.ps1`, `verify_week9_paper_modelsim.ps1`, `verify_week9_core_modelsim.ps1`; integrated pilot: `verify_week9_multiplier_modelsim.ps1 -PerProfile 2000 -RunName final_pilot`. Lượt lớn: `-PerProfile 630000 -RunName acceptance`; script chỉ đóng ngưỡng số học khi số giao dịch hoàn tất đạt10⁷, không tính reset-abort.

`summarize_week9_implementation.py` kiểm fixture Linux/Windows/UBSan, coverage và hash. `update_week9_status.py` chỉ sửa Markdown hiện có, không tạo Markdown mới. `verify_week9_verilator.sh` chỉ dùng tool đã cài, trả BLOCKED khi thiếu, không sudo/download/install. Mọi file build/log/work/temp đặt dưới Posit_MAC. Quyền cập nhật ngoài dự án chỉ dành đúng doc/TIEN_DO_DO_AN.md.

Git không có checkout: push chưa thực hiện; không tự init, thay remote, force hoặc sửa thư mục khác. Nguồn + hash được lưu local, không gọi đó là GitHub backup.
""")
ambiguity_path = root / "docs/ambiguity.md"
ambiguity = read(ambiguity_path)
ambiguity = ambiguity.replace("| RTL nhân tuần9 | processing; OPS/SAC tổ hợp đạt |", "| RTL nhân tuần9 | processing; standalone đã kiểm pilot, Gate2 còn thiếu |")
ambiguity = ambiguity.replace("còn SBM/core/top/Gate2 và lõi paper riêng theo PLAN mục7", "SBM/core/top standalone và paper trace đã kiểm; lượt lớn/lint theo PLAN mục7")
ambiguity = ambiguity.replace("| Core/MAC RTL | Chưa nghiệm thu | Reset bridge, token/drain, scoreboard và Gate2/3 còn triển khai |",
    "| Core/MAC RTL | Core và standalone đã kiểm pilot; MAC chưa triển khai | Reset/token/drain/slot đạt phạm vi pilot; Gate2/lint và Gate3 còn mở |")
write(ambiguity_path, ambiguity)
append_once(ambiguity_path, "## 4. Trạng thái sau RTL paper và core — 09/10/2026", "Paper843 commit/Fig.4 đạt cùng giả định fig3; chưa có bằng chứng mới cho tie/prefix/internal guard hoặc generator gốc, nên không chạy lại TableI. W9-03..05 đã có code/test; Gate2/tuần9 processing. Verilator/lint thiếu và Git checkout không có là hai trở ngại vận hành, không đổi mô hình để né tiêu chí.\n\n"+numerical)

progress_path = root.parent / "doc/TIEN_DO_DO_AN.md"
progress = read(progress_path)
progress = progress.replace("**Ngày cập nhật:** 08/10/2026", "**Ngày cập nhật:** 09/10/2026")
progress = progress.replace("Đã chốt giao diện lõi nhân và kiểm OPS/SAC tổ hợp; còn SBM, điều khiển lặp, tích hợp và harness/coverage", "Đã triển khai và kiểm core/multiplier standalone; còn nghiệm thu lớn/lint Gate2 và RTL MAC/Gate3")
progress = progress.replace("**Thứ tự tiếp theo:** SBM/chuẩn hóa tuần9 → lõi paper tối thiểu và đối chiếu trace → controller/multiplier top/Gate2", "**Thứ tự tiếp theo:** Hoàn tất kiểm lớn/lint multiplier tuần9 — Gate2")
progress = progress.replace("Giao diện và OPS/SAC tổ hợp đã kiểm; còn SBM, core tuần tự, top và Gate2. Lõi paper nghiên cứu giữ riêng", "Đã triển khai SBM/core/multiplier và kiểm pilot; paper trace đạt phạm vi tái dựng. Còn nghiệm thu lớn/lint Gate2; chưa chốt baseline gốc")
write(progress_path, progress)
append_once(progress_path, "### 4.8. Ngày 09/10/2026", """| STT | Mốc / nhóm công việc | Kết quả chính | Trạng thái |
| --- | --- | --- | --- |
| 1 | Lõi nhân RTL và tích hợp standalone — tuần9 | Hoàn thiện số học, controller và multiplier; kiểm core, reset/stall/latency và pilot đạt. Còn ngưỡng nghiệm thu/lint Gate2 | processing |
| 2 | Đối chiếu paper bằng RTL tối thiểu | Trace phân biệt và Fig.4 khớp profile tái dựng; chưa có bằng chứng mới để chốt baseline gốc hoặc đổi kết quả TableI | ✅ |
| 3 | Hồ sơ kiểm chứng và bảo toàn dữ liệu | Đồng bộ tài liệu, lưu corpus/log/hash; GitHub backup còn vướng do chưa có Git checkout | processing |
""", before="### 4.9. Mẫu cập nhật tiếp theo")
if accepted:
    progress = read(progress_path).replace("Còn ngưỡng nghiệm thu/lint Gate2", "Đạt ngưỡng số học10⁷; còn lint chính thức để đóng Gate2")
    write(progress_path, progress)
print("Updated existing week9 documents; Gate2 remains processing")
