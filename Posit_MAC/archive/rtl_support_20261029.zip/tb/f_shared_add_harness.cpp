#include <algorithm>
#include <array>
#include <fstream>
#include <iostream>
#include <random>
#include <stdexcept>
#include <string>
#include "Vf_shared_add_compare.h"
#include "verilated.h"
#include "posit_fused_window.hpp"
#include "week12_fused_reference.hpp"
#include "nf_coverage_corpus.hpp"

using Model = l1::FusedWindow<32,3,12,32>;
using Oracle = week12_reference::Oracle<32,3>;
using Mul = l1::L1MultiplierIter<32,3,12>;
// The build extracts the unchanged, established W13 directed F generator.
#include "f_shared_add_corpus.hpp"

void need(bool value, const std::string& message) {
    if (!value) throw std::runtime_error(message);
}

int main(int argc, char** argv) try {
    need(argc == 4, "usage: simulator count prefix seed");
    const uint64_t goal = std::stoull(argv[1]);
    const std::string prefix = argv[2];
    const uint64_t seed = std::stoull(argv[3]);
    Verilated::commandArgs(argc, argv);
    Vf_shared_add_compare dut;
    std::mt19937_64 rng(seed), traffic(seed + 1);
    uint64_t cycles = 0, accepted = 0, completed = 0, aborted = 0;
    uint64_t invalid = 0, stalls = 0, near = 0, tails = 0, borrows = 0;
    uint64_t reset_busy = 0, reset_held = 0, clears = 0, commits = 0;
    std::array<uint64_t, 36> bins{};
    std::array<uint64_t, 3> lat_min{{1000,1000,1000}}, lat_max{};
    uint32_t state = 0;
    auto tick = [&]() {
        dut.clk = 0; dut.eval(); dut.clk = 1; dut.eval(); ++cycles;
    };
    auto reset = [&]() {
        dut.rst_n = 0; dut.in_valid = 0; dut.out_ready = 0;
        for (unsigned j = 0; j < 4; ++j) {
            tick(); need(!dut.valid && !dut.ready, "reset gating");
        }
        state = 0; dut.rst_n = 1;
        for (unsigned j = 0; j < 8; ++j) tick();
        need(!dut.valid && dut.acc_ref == 0 && dut.acc_parser == 0 && dut.acc_shared == 0,
             "stale token or state after reset");
    };
    dut.a = dut.b = dut.c = 0;
    dut.cfg_mode = 1; dut.cfg_n = 0; dut.cfg_ops = 0;
    dut.acc_mode = 0; dut.acc_clr = 0;
    reset();
    std::ofstream failure(prefix + ".failure.json");
    while (completed < goal) {
        if (accepted % 127 == 0) {
            for (unsigned bad = 0; bad < 4; ++bad) {
                dut.in_valid = 1; dut.acc_mode = 0; dut.acc_clr = bad == 3;
                dut.cfg_mode = bad != 0; dut.cfg_n = bad == 1 ? 9 : 0;
                dut.cfg_ops = bad == 2 ? 2 : 0;
                dut.clk = 0; dut.eval();
                need(!dut.ready && !dut.valid, "invalid config accepted");
                tick(); ++invalid;
            }
        }
        const Input row = generate(rng, accepted, state);
        const uint32_t ceff = row.mode ? (row.clear ? 0 : state) : row.c;
        const auto mul = Mul::mul(row.a, row.b, config(row));
        const auto exp = Model::add(mul.prepack, ceff);
        const auto oracle = Oracle::add(mul.prepack, ceff, incoming(mul.prepack));
        need(exp.bits == oracle.bits && exp.flags == oracle.flags, "L1/full-grid oracle mismatch");
        dut.a = row.a; dut.b = row.b; dut.c = row.c;
        dut.cfg_mode = 1; dut.cfg_n = row.n; dut.cfg_ops = row.ops;
        dut.acc_mode = row.mode; dut.acc_clr = row.clear;
        dut.out_ready = 0; dut.in_valid = 0;
        unsigned wait = 0;
        do {
            dut.clk = 0; dut.eval();
            if (dut.ready == 7) break;
            tick(); need(++wait < 100, "input ready timeout");
        } while (true);
        dut.in_valid = 1; tick(); dut.in_valid = 0; ++accepted;
        if (row.mode && row.clear) { state = 0; ++clears; }
        std::array<bool, 3> seen{};
        bool abort = false;
        const unsigned q = std::max(1u, (exp.flags & 16) ? 0u : mul.iterations);
        for (unsigned elapsed = 0; elapsed < 200; ++elapsed) {
            // Change every external operand/control after the atomic handshake.
            dut.a = uint32_t(traffic()); dut.b = uint32_t(traffic()); dut.c = uint32_t(traffic());
            dut.acc_mode = traffic() % 2; dut.acc_clr = traffic() % 2;
            dut.cfg_mode = traffic() % 2; dut.cfg_n = traffic() % 16; dut.cfg_ops = traffic() % 4;
            dut.clk = 0; dut.eval();
            const unsigned v = dut.valid;
            need((v & 3) == 0 || (v & 3) == 3, "parser-sharing changed F reference latency");
            const std::array<uint32_t,3> values{{dut.d_ref,dut.d_parser,dut.d_shared}};
            const std::array<unsigned,3> flags{{dut.flags_ref,dut.flags_parser,dut.flags_shared}};
            const std::array<uint32_t,3> accum{{dut.acc_ref,dut.acc_parser,dut.acc_shared}};
            for (unsigned k = 0; k < 3; ++k) {
                if (v & (1u << k)) {
                    if (values[k] != exp.bits || flags[k] != exp.flags) {
                        failure << "{\"serial\":" << accepted << ",\"variant\":" << k
                            << ",\"a\":" << row.a << ",\"b\":" << row.b << ",\"ceff\":" << ceff
                            << ",\"n\":" << row.n << ",\"ops\":" << row.ops
                            << ",\"expected\":" << exp.bits << ",\"actual\":" << values[k]
                            << ",\"expected_flags\":" << exp.flags << ",\"actual_flags\":" << flags[k] << "}\n";
                        failure.flush();
                        throw std::runtime_error("RTL value/flags mismatch, variant " + std::to_string(k));
                    }
                    if (!seen[k]) {
                        need(elapsed == q + (k == 2 ? 9 : 11), "first-valid latency mismatch");
                        lat_min[k] = std::min(lat_min[k], uint64_t(elapsed));
                        lat_max[k] = std::max(lat_max[k], uint64_t(elapsed));
                    }
                    seen[k] = true;
                } else {
                    need(!seen[k], "valid dropped while stalled");
                }
                // Wrapper commits on the edge following first presentation.
                const bool committed = seen[k] && elapsed > q + (k == 2 ? 9 : 11);
                const uint32_t expected_acc = row.mode && committed ? exp.bits : state;
                need(accum[k] == expected_acc, "accumulator commit timing/data mismatch");
            }
            if (accepted % 997 == 0 && elapsed == unsigned(accepted % 10)) {
                ++aborted; ++reset_busy; reset(); abort = true; break;
            }
            if (accepted % 991 == 0 && v == 7) {
                ++aborted; ++reset_held; reset(); abort = true; break;
            }
            const bool release = v == 7 && (traffic() % 4 != 0)
                              && !(accepted % 31 == 0 && elapsed < q + 45);
            dut.out_ready = release;
            if (v) ++stalls;
            tick();
            if (release) {
                need(!dut.valid, "duplicate token after retire");
                if (row.mode) { state = exp.bits; ++commits; }
                ++completed;
                ++bins[row.n + 9 * row.ops + 18 * row.mode];
                near += exp.trace.near_before; tails += exp.trace.residual; borrows += exp.trace.borrow;
                break;
            }
            need(elapsed < 199, "output timeout");
        }
        if (abort) continue;
        if (completed && completed % 1000000 == 0) std::cout << "F_SHARED checkpoint " << completed << std::endl;
    }
    std::ofstream report(prefix + ".json");
    report << "{\"status\":\"PASS\",\"seed\":" << seed << ",\"completed_per_variant\":" << completed
        << ",\"accepted\":" << accepted << ",\"reset_aborted\":" << aborted << ",\"cycles\":" << cycles
        << ",\"mismatches\":0,\"oracle_checks\":" << accepted << ",\"invalid_checks\":" << invalid
        << ",\"stalled_observations\":" << stalls << ",\"reset_busy\":" << reset_busy
        << ",\"reset_stalled\":" << reset_held << ",\"commits\":" << commits << ",\"clears\":" << clears
        << ",\"near\":" << near << ",\"residual\":" << tails << ",\"borrow\":" << borrows;
    auto array = [&](const char* name, const auto& a) {
        report << ",\"" << name << "\":[";
        for (unsigned i = 0; i < a.size(); ++i) report << (i ? "," : "") << a[i];
        report << ']';
    };
    array("latency_min", lat_min); array("latency_max", lat_max); array("bins", bins);
    report << "}\n";
    // Bound 8192 event vectors to the same independent oracle and state semantics.
    std::ofstream vectors(prefix + ".vectors"); state = 0;
    for (unsigned i = 0; i < 8192; ++i) {
        const bool rst = i % 127 == 0; if (rst) state = 0;
        auto row = generate(rng, i, state);
        const auto mul = Mul::mul(row.a, row.b, config(row));
        auto result = Oracle::add(mul.prepack, row.mode ? (row.clear ? 0 : state) : row.c, incoming(mul.prepack));
        if (row.mode) state = result.bits;
        const unsigned latency = std::max(1u, (result.flags & 16) ? 0u : mul.iterations) + 9;
        vectors << std::hex << row.a << ' ' << row.b << ' ' << row.c << ' ' << result.bits << ' ' << result.flags
                << std::dec << ' ' << row.n << ' ' << row.ops << ' ' << row.mode << ' ' << row.clear << ' ' << rst << ' ' << latency << '\n';
    }
    dut.final();
    std::cout << "F_SHARED PASS completed_per_variant=" << completed << " mismatches=0\n";
    return 0;
} catch (const std::exception& error) {
    std::cerr << "F_SHARED FAIL " << error.what() << '\n'; return 1;
}
