# SYNTHETIC VALIDATION ONLY; DO NOT USE FOR PPA OR BOARD.
# A35T-C1 SYSTEM-SYNCHRONOUS integration template, NOT a runnable board XDC.
# Copy inside this project, then fill EVERY min/max and source/reference field.
# Values are boundary arrival/required-time budgets relative to clk, in ns.
# Derive them from the launching/receiving circuit and data/clock connections.
# Output min may be negative; do not copy an input or max value into min.
# If the real interface uses another clock/phase, write that clock/interface
# contract instead of using this template. Pinout/IOSTANDARD are separate.
# The driver reads a35t_clock.xdc first; do not recreate clk in this file.

set input_groups [list \
    [dict create ports {a[*] b[*] c[*]} min 0.100 max 1.000 reference {TEST_ONLY_NOT_BOARD}] \
    [dict create ports {rst_n in_valid acc_mode acc_clr cfg_mode cfg_n[*] cfg_ops[*] out_ready} min 0.100 max 1.000 reference {TEST_ONLY_NOT_BOARD}]]
set output_groups [list \
    [dict create ports {d[*] flags[*]} min -0.200 max 0.600 reference {TEST_ONLY_NOT_BOARD}] \
    [dict create ports {in_ready out_valid} min -0.200 max 0.600 reference {TEST_ONLY_NOT_BOARD}]]

# Validate ALL groups before applying any I/O delay. Missing facts must fail,
# never silently fall back to historical 2.500/2.500 ns assumptions.
set io_seen [dict create]
set io_resolved [list]
foreach direction {IN OUT} groups [list $input_groups $output_groups] {
    foreach group $groups {
        set lo [dict get $group min]
        set hi [dict get $group max]
        if {![string is double -strict $lo] || ![string is double -strict $hi] ||
            [string trim [dict get $group reference]] eq {}} {
            error "A35T_IO_UNCONFIGURED: fill independent min/max and timing reference for [dict get $group ports]"
        }
        if {$hi < $lo} {error "A35T_IO_INVALID: max is less than min"}
        set ports [get_ports -quiet [dict get $group ports]]
        if {![llength $ports]} {error "A35T_IO_INVALID: no matching ports"}
        foreach port $ports {
            set name [get_property NAME $port]
            if {[get_property DIRECTION $port] ne $direction || $name eq "clk"} {
                error "A35T_IO_INVALID: wrong direction or clock selected: $name"
            }
            if {[dict exists $io_seen $name]} {error "A35T_IO_INVALID: duplicate port $name"}
            dict set io_seen $name 1
        }
        lappend io_resolved [list $direction $lo $hi $ports]
    }
}
foreach port [get_ports -filter {NAME != clk}] {
    if {![dict exists $io_seen [get_property NAME $port]]} {
        error "A35T_IO_INVALID: uncovered port [get_property NAME $port]"
    }
}
foreach group $io_resolved {
    lassign $group direction lo hi ports
    if {$direction eq "IN"} {
        set_input_delay -clock clk -min $lo $ports
        set_input_delay -clock clk -max $hi $ports
    } else {
        set_output_delay -clock clk -min $lo $ports
        set_output_delay -clock clk -max $hi $ports
    }
}
