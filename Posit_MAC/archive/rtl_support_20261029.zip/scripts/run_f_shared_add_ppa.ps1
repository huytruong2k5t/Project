param(
    [ValidateSet('reference','parser2','shared_add')][string]$Variant='shared_add',
    [ValidatePattern('^results/[a-zA-Z0-9_/-]+$')][string]$StudyRoot='results/f_shared_add_20261020'
)
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
$study=Join-Path $root $StudyRoot
$pilot=Get-Content -LiteralPath "$study/verification/pilot.json" -Raw | ConvertFrom-Json
if($pilot.status -ne 'PASS') {throw 'Native pilot must pass'}
foreach($candidate in @('parser2','shared_add')) {
    if((Get-Content -LiteralPath "$study/event/$candidate/status.txt" -Raw).Trim() -ne 'COMPLETE') {
        throw 'Both CK2Q event checks must pass'
    }
}
$run=Join-Path $study "ppa/$Variant/p8300/Explore_r1"
if(Test-Path -LiteralPath $run) {throw 'Preserve existing PPA evidence'}
foreach($dir in @('tmp','appdata','localappdata','source/rtl','source/syn/constraints','source/tb')) {
    New-Item -ItemType Directory -Force "$run/$dir" | Out-Null
}
foreach($rel in (Get-Content -LiteralPath "$study/source/$Variant/rtl/production.f")) {
    $dst=Join-Path "$run/source" $rel
    New-Item -ItemType Directory -Force (Split-Path $dst -Parent) | Out-Null
    Copy-Item -LiteralPath "$study/source/$Variant/$rel" -Destination $dst
}
Copy-Item -LiteralPath "$study/source/$Variant/rtl/production.f" -Destination "$run/source/rtl"
Copy-Item -LiteralPath "$study/source/$Variant/rtl/posit_mac.vh" -Destination "$run/source/rtl"
Copy-Item -LiteralPath "$root/tb/week13_fused_ppa_top.sv" -Destination "$run/source/tb"
Copy-Item -LiteralPath "$root/syn/constraints/a35t_clock_120mhz.xdc" -Destination "$run/source/syn/constraints/a35t_clock.xdc"
Copy-Item -LiteralPath "$root/syn/constraints/a35t_benchmark_100mhz.xdc" -Destination "$run/source/syn/constraints"
$flow=Get-Content -LiteralPath "$root/syn/run_a35t.tcl" -Raw
$flow=$flow.Replace('benchmark_100mhz','f_shared_add_fixedio')
$flow=$flow.Replace('a35t_f_shared_add_fixedio.xdc','a35t_benchmark_100mhz.xdc')
$flow=$flow.Replace('- 10.0)','- 8.3)').Replace('clock_period_ns=10 ','clock_period_ns=8.3 ')
$flow=$flow.Replace('place_design -directive Default','place_design -directive Explore')
$flow=$flow.Replace('route_design -directive Default','route_design -directive Explore')
$banks=Get-Content -LiteralPath "$root/scripts/nf_all_stages_sta.tcl" -Raw
$banks=$banks.Substring($banks.IndexOf('proc classify'))
$banks=$banks.Substring(0,$banks.IndexOf('set f [open status.txt'))
$extra=@'
    if {[string match "*/u_fused/*" $name]} {
        foreach stage {1 2 3 4 5} {
            if {[string match "*/f${stage}_q_reg*" $name]} {return fused_f${stage}}
        }
        return fused_control
    }
    if {[regexp {/(parser_p[12]_c_q)_reg} $name]} {return parser_role}
'@
$banks=$banks.Replace('    if {[string match "*/u_core/u_ctrl/*" $name]} {', $extra+"`n"+'    if {[string match "*/u_core/u_ctrl/*" $name]} {')
$banks="set outputs [get_ports -filter {DIRECTION == OUT}]`n"+$banks
$flow=$flow.Replace('# COMPLETE means execution complete, not timing PASS. Inspect timing/coverage.',
    $banks+"`nreport_cdc -details -file cdc.rpt`n# COMPLETE means execution complete, not timing PASS. Inspect timing/coverage.")
[IO.File]::WriteAllText("$run/source/syn/run_a35t.tcl",$flow)
$hashes=@{}
Get-ChildItem -LiteralPath "$run/source" -Recurse -File | ForEach-Object {
    $hashes[$_.FullName.Substring(("$run/source/").Length)]=(Get-FileHash -LiteralPath $_.FullName).Hash.ToLowerInvariant()
}
@{variant=$Variant;part='xc7a35tcpg236-1';strategy='Explore';clock_ns=8.3;
  input_min_ns=2.5;input_max_ns=2.5;output_min_ns=0;output_max_ns=0.5;
  uncertainty_setup_ns=0.1;uncertainty_hold_ns=0.1;source_sha256=$hashes;
  command="powershell -NoProfile -File scripts/run_f_shared_add_ppa.ps1 -Variant $Variant"} |
  ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 "$run/manifest.json"
$env:TEMP="$run/tmp"; $env:TMP=$env:TEMP
$env:APPDATA="$run/appdata"; $env:LOCALAPPDATA="$run/localappdata"; $env:XILINX_LOCAL_USER_DATA='no'
Push-Location $run
try {
    & 'C:/AMDDesignTools/2026.1/Vivado/bin/vivado.bat' -mode batch -notrace -source "$run/source/syn/run_a35t.tcl" -log vivado.log -journal vivado.jou -tclargs f f_shared_add_fixedio implement > console.log
    if($LASTEXITCODE) {throw 'Vivado failed'}
    $log=Get-Content -LiteralPath vivado.log -Raw
    if($log -match '(?m)^ERROR:') {throw 'Tool error'}
    foreach($warning in [regex]::Matches($log,'(?m)^CRITICAL WARNING:.*$')) {
        if($warning.Value -notmatch '\[Route 35-39\] The design did not meet timing requirements.') {
            throw "Unexplained critical warning: $($warning.Value)"
        }
    }
    if((Get-Content -LiteralPath status.txt -Raw).Trim() -ne 'COMPLETE') {throw 'Missing completion marker'}
    Write-Output "F_SHARED PPA EXECUTION COMPLETE $Variant (inspect setup/hold for PASS/FAIL)"
} finally {Pop-Location}
