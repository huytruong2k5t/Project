"""Lossless, indexed RTL/results cleanup with checked archive-before-removal.

All mutations stay within the project, reject symlinks, and never recursively
delete trees. Restores preflight every destination and refuse conflicting edits.
"""
import argparse
import hashlib
import json
import os
import re
import time
import zipfile
from pathlib import Path, PurePosixPath

ROOT=Path(__file__).resolve().parent.parent
BATCH=ROOT/'archive/cleanup_20261102'
PLAN=BATCH/'plan.json'
RECEIPT=BATCH/'receipt.json'
KEEP_RESULTS={
    'f_timing_optimization_20261101':'Current promoted F, four measured candidates and source/hash evidence',
    'parser_lod_refactor_recheck_20261101':'NF/F before optimization, completed critical-path diagnosis',
    'readme_refactor_recheck_20261101':'Prior NF/F baseline and independent OPS regression',
    'refactored_mac_20261101_r3':'Earlier refactored NF/F baseline and stage comparisons',
    'fixed32_3_20261022':'Frozen historical release evidence, sources and reference hashes',
    'week14':'Historical acceptance/coverage/accuracy evidence; not current-RTL signoff',
    'opt17_20261029':'Recent algorithm/RTL experiment, source freeze and comparison evidence',
    'l1_floor_rne_freeze':'Historical FLOOR/RNE contract and model evidence',
}
REFERENCES={
    'rtl/adder/posit_add_comb.sv','rtl/adder/posit_add_align.sv',
    'rtl/adder/posit_add_arith.sv','rtl/adder/posit_add_normalize.sv',
    'rtl/common/dyn_right_shifter.sv','rtl/common/lod_lzd_core.sv',
    'rtl/common/dyn_left_shifter_fixed2.sv',
}
CACHE_DIRS={'work','obj_dir','__pycache__','.Xil','.cache','appdata','localappdata','tmp','temp'}
SOURCE_DIRS={'source','sources','reference','before_promotion','fixed'}
CACHE_EXT={'.gch','.pch','.o','.obj','.pyc','.pyo','.psm','.dbs','.prw','.wlf','.wdb','.vcd','.fst'}
INCOMPLETE={
    'results/parser_lod_refactor_recheck_20261101/critical_path_diagnosis',
    'results/parser_lod_refactor_recheck_20261101/critical_path_diagnosis_r2',
    *{'results/refactored_mac_20261101_r3/'+name for name in
      ['synth_nf','synth_f','synth_nf_isolated','synth_f_isolated']},
}
META=['README.md','rtl/README.md','results/README.md','archive/README.md','scripts/README.md']

def safe(relative,base=ROOT):
    relative=str(relative).replace('\\','/')
    parts=PurePosixPath(relative)
    if parts.is_absolute() or '..' in parts.parts or ':' in relative:
        raise ValueError('Unsafe path: '+relative)
    target=base.joinpath(*parts.parts)
    if not target.resolve().is_relative_to(ROOT.resolve()):
        raise ValueError('Path escapes project: '+str(target))
    current=target
    while current!=ROOT:
        if current.is_symlink(): raise ValueError('Refuse symlink: '+str(current))
        current=current.parent
    return target

def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()

def dump(path,value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def files_under(folder):
    for parent,dirs,names in os.walk(folder,followlinks=False):
        for name in sorted(names):
            p=Path(parent)/name
            safe(p.relative_to(ROOT).as_posix())
            yield p

def make_plan():
    if PLAN.exists(): return json.loads(PLAN.read_text(encoding='utf-8'))
    if BATCH.exists(): raise RuntimeError('Preserve unexpected existing cleanup directory')
    BATCH.mkdir(parents=True)
    active=(ROOT/'rtl/mac_active.f').read_text().splitlines()
    assert len(active)==len(set(active))==42
    for name in set(active)|REFERENCES:
        assert safe(name).is_file(),name
    groups={'rtl_inactive':[],'results_history':[],'results_support':[],'metadata_before':META.copy()}
    protected={}
    counts={'rtl_sv_before':len(list((ROOT/'rtl').rglob('*.sv'))),
        'results_dirs_before':len([p for p in (ROOT/'results').iterdir() if p.is_dir()])}
    sizes={'rtl_before':0,'results_before':0}
    for p in files_under(ROOT/'rtl'):
        rel=p.relative_to(ROOT).as_posix();sizes['rtl_before']+=p.stat().st_size
        if p.suffix=='.sv' and rel not in set(active)|REFERENCES:
            groups['rtl_inactive'].append(rel)
        elif p.parent!=ROOT/'rtl' and rel not in set(active)|REFERENCES:
            groups['rtl_inactive'].append(rel)
        elif rel not in META:protected[rel]=digest(p)
    for p in files_under(ROOT/'results'):
        rel=p.relative_to(ROOT).as_posix();sizes['results_before']+=p.stat().st_size
        parts=PurePosixPath(rel).parts
        if rel in {'results/README.md','results/.gitkeep'}:continue
        if len(parts)<3 or parts[1] not in KEEP_RESULTS:
            groups['results_history'].append(rel);continue
        under_source=bool(set(parts[2:-1])&SOURCE_DIRS)
        incomplete=any(rel.startswith(prefix+'/') for prefix in INCOMPLETE)
        cache=(not under_source and
            (bool(set(parts[2:-1])&CACHE_DIRS) or p.suffix.lower() in CACHE_EXT or
             (any(part.startswith('build') for part in parts[2:-1]) and p.suffix.lower() in {'.exe','.so','.dll','.a'})))
        if incomplete or cache:groups['results_support'].append(rel)
        else:protected[rel]=digest(p)
    removed=groups['rtl_inactive']+groups['results_history']+groups['results_support']
    assert len(removed)==len(set(removed))
    assert not (set(active)|REFERENCES)&set(removed)
    freeze=json.loads((ROOT/'rtl/production_freeze.json').read_text())
    frozen_reports=[row['report'] for row in freeze['verification'].values() if isinstance(row,dict) and 'report' in row]
    assert not set(frozen_reports)&set(removed),'Protect historical frozen reports'
    plan={'date':'2026-11-02','active':active,'reference_files':sorted(REFERENCES),
        'keep_results':KEEP_RESULTS,'groups':{k:sorted(v) for k,v in groups.items()},
        'protected_sha256':protected,'frozen_reports':frozen_reports,'before_counts':counts,'before_bytes':sizes,
        'notes':['No RTL content changes, no simulation/synthesis/place/route.',
                 'Every removed file is preserved byte-for-byte in a verified ZIP.',
                 'Generated libraries/cache and incomplete runs are separate from evidence.',
                 'Historical scripts may require restoring archived paths before replay.']}
    dump(PLAN,plan)
    print(json.dumps({'plan':str(PLAN),'groups':{k:len(v) for k,v in groups.items()},'protected_files':len(protected)},ensure_ascii=False),flush=True)
    return plan

def verify_zip(path,entries=None):
    with zipfile.ZipFile(path) as z:
        index=json.loads(z.read('ARCHIVE_INDEX.json'))
        if entries is not None:assert set(index['entries'])==set(entries)
        assert set(z.namelist())==set(index['entries'])|{'ARCHIVE_INDEX.json'}
        for name,info in index['entries'].items():
            safe(name)
            h=hashlib.sha256();size=0
            with z.open(name) as f:
                for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk);size+=len(chunk)
            assert size==info['bytes'] and h.hexdigest()==info['sha256'],name
    return index

def archive_group(label,names):
    path=BATCH/(label+'.zip')
    if path.exists():
        index=verify_zip(path,names)
    else:
        partial=BATCH/(label+'.zip.partial')
        if partial.exists():raise RuntimeError('Preserve incomplete archive: '+str(partial))
        index={'date':'2026-11-02','group':label,'entries':{}}
        start=time.monotonic();last=start
        with zipfile.ZipFile(partial,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True) as z:
            for n,name in enumerate(names,1):
                src=safe(name);before=src.stat();h=hashlib.sha256();size=0
                with src.open('rb') as f,z.open(name,'w',force_zip64=True) as target:
                    for chunk in iter(lambda:f.read(1024*1024),b''):
                        target.write(chunk);h.update(chunk);size+=len(chunk)
                after=src.stat()
                assert before.st_size==after.st_size==size and before.st_mtime_ns==after.st_mtime_ns,'File changed during archive: '+name
                index['entries'][name]={'bytes':size,'sha256':h.hexdigest(),'mtime_ns':before.st_mtime_ns}
                if time.monotonic()-last>8 or n==len(names):
                    print(f'ARCHIVING {label}: {n}/{len(names)} files',flush=True);last=time.monotonic()
            z.writestr('ARCHIVE_INDEX.json',json.dumps(index,ensure_ascii=False,indent=2))
        verify_zip(partial,names)
        assert not path.exists();partial.rename(path)
    result={'file':path.relative_to(ROOT).as_posix(),'sha256':digest(path),'bytes':path.stat().st_size,
        'original_bytes':sum(row['bytes'] for row in index['entries'].values()),'files':len(index['entries'])}
    print(f'ARCHIVE_VERIFIED {label}: {result["files"]} files, {result["bytes"]} bytes',flush=True)
    return result,index

def remove_empty():
    for name in ['rtl','results']:
        boundary=safe(name)
        folders=sorted((p for p in boundary.rglob('*') if p.is_dir()),key=lambda p:len(p.parts),reverse=True)
        for folder in folders:
            safe(folder.relative_to(ROOT).as_posix())
            try:folder.rmdir()
            except OSError:pass # Nonempty directories and unexpected files are preserved.

def apply():
    if RECEIPT.exists() and json.loads(RECEIPT.read_text()).get('status')=='COMPLETE':
        raise RuntimeError('Cleanup already complete; use audit')
    plan=make_plan();receipt={'date':'2026-11-02','status':'ARCHIVING','archives':{},'removed_files':0}
    # Verify every archive before any source removal begins.
    indices={}
    for label,names in plan['groups'].items():
        result,index=archive_group(label,names)
        receipt['archives'][label]=result;indices[label]=index
        dump(RECEIPT,receipt)
    receipt['status']='REMOVING_VERIFIED_COPIES';dump(RECEIPT,receipt)
    for label,index in indices.items():
        if label=='metadata_before':continue
        for name,info in index['entries'].items():
            target=safe(name)
            if not target.exists():continue
            assert target.is_file() and target.stat().st_size==info['bytes'] and digest(target)==info['sha256'],'Preserve modified file: '+name
            target.unlink();receipt['removed_files']+=1
        print(f'REMOVED_VERIFIED {label}: {len(index["entries"])} paths',flush=True)
    remove_empty()
    receipt['status']='COMPLETE';dump(RECEIPT,receipt)
    audit()

def audit(quick=False):
    plan=json.loads(PLAN.read_text(encoding='utf-8'));receipt=json.loads(RECEIPT.read_text(encoding='utf-8'))
    assert receipt['status']=='COMPLETE'
    for label,record in receipt['archives'].items():
        path=safe(record['file']);assert digest(path)==record['sha256']
        if not quick:verify_zip(path,plan['groups'][label])
    migration_file=BATCH/'reference_migration.json'
    migration=json.loads(migration_file.read_text()) if migration_file.exists() else None
    relocated={name:row['new_path'] for name,row in migration['mapping'].items()} if migration else {}
    if migration:
        assert digest(safe(migration['backup']))==migration['archive_sha256']
    for name,h in plan['protected_sha256'].items():
        current=safe(relocated.get(name,name))
        assert current.is_file() and digest(current)==h,'Protected file changed: '+name
    active=(ROOT/'rtl/mac_active.f').read_text().splitlines()
    assert active==plan['active'] and len(active)==42
    expected=set(active) if migration else set(active)|REFERENCES
    assert {p.relative_to(ROOT).as_posix() for p in (ROOT/'rtl').rglob('*.sv')}==expected
    # Check actual module closure from both live tops, not merely file existence.
    codes={}
    for name in active:
        text=re.sub(r'/\*.*?\*/|//[^\n]*','',safe(name).read_text(),flags=re.S)
        module=re.search(r'\bmodule\s+(\w+)\s*\(',text)[1];codes[module]=text
    seen=set();todo=['posit_mac_nf','posit_mac_f']
    while todo:
        module=todo.pop()
        if module in seen:continue
        seen.add(module)
        for child in codes:
            if re.search(r'(?<!module )\b'+re.escape(child)+r'\s+\w+\s*\(',codes[module]):todo.append(child)
    assert len(seen)==42
    kept={p.name for p in (ROOT/'results').iterdir() if p.is_dir()}
    assert kept==set(KEEP_RESULTS)
    metrics={'status':'PASS','date':'2026-11-02','active_modules':42,'verification_reference_modules':7,
        'rtl_sv_before':plan['before_counts']['rtl_sv_before'],'rtl_sv_after':len(expected),
        'verification_reference_location':'tb/reference/rtl' if migration else 'rtl',
        'results_dirs_before':plan['before_counts']['results_dirs_before'],'results_dirs_after':len(kept),
        'protected_files_unchanged':len(plan['protected_sha256']),
        'removed_files_archived':receipt['removed_files'],
        'archive_bytes':sum(row['bytes'] for row in receipt['archives'].values()),
        'results_bytes_before':plan['before_bytes']['results_before'],
        'results_bytes_after':sum(p.stat().st_size for p in files_under(ROOT/'results')),
        'rtl_and_mac_behavior_unchanged':True,'simulation_or_synthesis_run':False,
        'archive_verification_mode':'unchanged ZIP SHA256; member verification already passed' if quick else 'ZIP SHA256 and every member CRC/SHA256'}
    dump(BATCH/'validation.json',metrics)
    print(json.dumps(metrics),flush=True)
    return metrics

def restore(prefix,destination):
    receipt=json.loads(RECEIPT.read_text(encoding='utf-8'))
    prefix=prefix.replace('\\','/');safe(prefix)
    target_root=safe(destination) if destination else ROOT
    selected=[]
    for label,record in receipt['archives'].items():
        if label=='metadata_before':continue
        path=safe(record['file']);assert digest(path)==record['sha256']
        with zipfile.ZipFile(path) as z:
            index=json.loads(z.read('ARCHIVE_INDEX.json'))
        for name,info in index['entries'].items():
            if not name.startswith(prefix):continue
            target=safe(name,target_root)
            if target.exists() and (not target.is_file() or digest(target)!=info['sha256']):
                raise RuntimeError('Refuse overwrite: '+str(target))
            selected.append((path,name,info,target))
    if not selected:raise RuntimeError('No archived paths match prefix')
    # All destinations checked before any write. Never extractall a ZIP.
    for path,name,info,target in selected:
        if target.exists():continue
        target.parent.mkdir(parents=True,exist_ok=True)
        with zipfile.ZipFile(path) as z,z.open(name) as src,target.open('xb') as dst:
            for chunk in iter(lambda:src.read(1024*1024),b''):dst.write(chunk)
        assert target.stat().st_size==info['bytes'] and digest(target)==info['sha256']
    print(f'RESTORE_PASS {len(selected)} files to {target_root}',flush=True)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('command',choices=['plan','apply','audit','restore'])
    ap.add_argument('--prefix');ap.add_argument('--destination');ap.add_argument('--quick',action='store_true');args=ap.parse_args()
    if args.command=='plan':make_plan()
    elif args.command=='apply':apply()
    elif args.command=='audit':audit(args.quick)
    else:
        if not args.prefix:ap.error('restore requires --prefix')
        restore(args.prefix,args.destination)

if __name__=='__main__':main()
