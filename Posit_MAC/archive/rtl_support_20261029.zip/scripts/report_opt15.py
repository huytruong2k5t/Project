"""Audit OPT-15 trial inputs and collect actual, matched A35T post-route data."""
from pathlib import Path
import csv
import hashlib
import json
import re
from audit_rtl_release import validate

R=Path(__file__).resolve().parents[1]
O=R/'results/opt15_share_20261019'
read=lambda p:p.read_text(encoding='utf-8-sig')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()


def ppa(variant):
    run=O/'ppa'/variant/'p8300/Explore_r1'
    assert read(run/'status.txt').strip()=='COMPLETE'
    manifest=json.loads(read(run/'manifest.json'))
    for name,digest in manifest['source_sha256'].items():
        assert sha(run/'source'/name.replace('\\','/'))==digest,name
    for p in (run/'source/rtl').rglob('*'):
        if p.suffix in ('.sv','.vh'):
            assert sha(p)==sha(O/'source'/variant/p.relative_to(run/'source'))
    assert manifest['part']=='xc7a35tcpg236-1'
    assert manifest['strategy']=='Explore' and manifest['clock_ns']==8.3
    assert [manifest[k] for k in ('input_min_ns','input_max_ns','output_min_ns','output_max_ns')]==[2.5,2.5,0,0.5]
    assert sha(run/'source/syn/constraints/a35t_benchmark_100mhz.xdc')==sha(R/'syn/constraints/a35t_benchmark_100mhz.xdc')
    flow=read(run/'source/syn/run_a35t.tcl')
    assert flow.index('read_xdc')<flow.index('    synth_design')
    text=read(run/'timing.rpt')
    hit=re.search(r'WNS\(ns\).*?\n\s*-.*?\n\s*([-\d.]+)\s+([-\d.]+)\s+\d+\s+\d+\s+([-\d.]+)\s+([-\d.]+)',text,re.S)
    assert hit,'Missing global timing'
    metrics=dict(zip(('wns_ns','tns_ns','whs_ns','ths_ns'),map(float,hit.groups())))
    for line in ('There are 0 register/latch pins with no clock.',
                 'There are 0 pins that are not constrained for maximum delay.'):
        assert line in text,line
    resources={}
    for name in ('Slice LUTs','Slice Registers','CARRY4','DSPs','RAMB36/FIFO*','RAMB18','Register as Latch'):
        footnote=r'\*?' if name=='Slice LUTs' else ''
        hit=re.search(r'^\|\s*'+re.escape(name)+footnote+r'\s*\|\s*(\d+)',read(run/'utilization.rpt'),re.M)
        if hit:resources[name]=int(hit[1])
    assert resources.get('Register as Latch',0)==0
    for kind in ('setup','hold'):
        path=read(run/f'r2r_{kind}.rpt')
        hit=re.search(r'Slack\s*\([^)]*\)\s*:\s*([-\d.]+)ns',path)
        assert hit
        metrics[f'r2r_{kind}_ns']=float(hit[1])
        if kind=='setup':
            for label in ('Source','Destination'):
                hit=re.search(r'^\s*'+label+r':\s*(.*)$',path,re.M)
                metrics['r2r_'+label.lower()]=hit[1].strip() if hit else None
    structure=dict(line.split('=',1) for line in read(run/'structural.txt').splitlines())
    assert structure['latches']==structure['unrouted']==structure['unclassified']=='0',structure
    log=read(run/'vivado.log')
    assert not re.search(r'^ERROR:',log,re.M)
    critical=re.findall(r'^CRITICAL WARNING:.*$',log,re.M)
    assert all('[Route 35-39] The design did not meet timing requirements.' in x for x in critical),critical
    return dict(variant=variant,path=run.relative_to(R).as_posix(),**metrics,resources=resources,
                structure=structure,stages=list(csv.DictReader((run/'stages.csv').open())),
                full_timing_pass=min(metrics['wns_ns'],metrics['whs_ns'])>=0
                                 and metrics['tns_ns']==metrics['ths_ns']==0,
                r2r_sta_estimate_mhz=1000/(8.3-metrics['r2r_setup_ns']),
                ooc_partial_io_route_warning_count=len(re.findall(r'WARNING: \[Route 35-198\]',log)),
                critical_warnings=critical,
                tool=read(run/'scope.txt').splitlines()[0])


def main():
    frozen=json.loads(read(R/'rtl/production_freeze.json'))
    validate(frozen)
    source=json.loads(read(O/'manifest.json'))
    for variant,hashes in source['variants'].items():
        for name,digest in hashes.items():assert sha(O/'source'/variant/name)==digest
    for name,digest in frozen['rtl_sha256'].items():
        assert sha(O/'source/reference'/name)==digest
    signature=lambda p:re.sub(r'\s+','',read(p).split('module mac_nf_wrapper #(',1)[1].split(');',1)[0])
    for variant in ('parser2','combined'):
        assert signature(O/'source'/variant/'rtl/mac_nf/mac_nf_wrapper.sv')==signature(R/'rtl/mac_nf/mac_nf_wrapper.sv')
        assert sha(R/'rtl/candidates/mac_nf/opt15'/variant/'mac_nf_wrapper.sv')==sha(O/'source'/variant/'rtl/mac_nf/mac_nf_wrapper.sv')
    assert sha(R/'rtl/candidates/mac_nf/opt15/posit_nf_shared_pack.sv')==sha(O/'source/combined/rtl/mac_nf/posit_nf_shared_pack.sv')
    assert read(O/'verification/status.txt').strip()=='COMPLETE'
    native=[]
    for fmt in ('32_3','8_0','16_1','32_2'):
        run=O/'verification'/fmt
        assert not re.search(r'%Warning|%Error',read(run/'lint.log'))
        for line in read(run/'source.sha256').splitlines():
            digest,name=line.split(maxsplit=1)
            assert sha(run/name)==digest,name
        for line in read(run/'binary.sha256').splitlines():
            digest,name=line.split(maxsplit=1)
            assert sha(run/name)==digest,name
        for name in ('pilot.json',)+ (('main.json','acceptance_10m.json') if fmt=='32_3' else ()):
            row=json.loads(read(run/name));assert row['status']=='PASS' and row['mismatches']==0
            assert all(row['bins']) and row['accepted']==row['completed_per_variant']+row['reset_aborts']
            native.append(dict(report=(run/name).relative_to(R).as_posix(),**row))
    events={}
    for variant in ('parser2','combined'):
        run=O/'event'/variant
        assert read(run/'status.txt').strip()=='COMPLETE'
        for name,digest in json.loads(read(run/'source_sha256.json')).items():
            assert sha(run/'source'/name.replace('\\','/'))==digest,name
        for name,digest in json.loads(read(run/'fixture_sha256.json')).items():
            assert sha(R/name.replace('\\','/'))==digest,name
        rows=[]
        for fmt in ('8_0','16_1','32_2','32_3'):
            for kind in ('corner','protocol'):
                log=read(run/f'{kind}_{fmt}.log')
                assert not re.search(r'\*\*\s+(Error|Fatal):',log)
                match=re.search(r'W11 MODELSIM PASS NB=(\d+) ES=(\d+) rows=(\d+) completed=(\d+) aborted=(\d+) stalls=(\d+) mismatches=(\d+)',log)
                assert match and match[7]=='0'
                rows.append(dict(zip(('NB','ES','rows','completed','aborted','stalls','mismatches'),map(int,match.groups()))))
        events[variant]=dict(completed=sum(x['completed'] for x in rows),aborted=sum(x['aborted'] for x in rows),runs=rows)
    physical=[ppa(v) for v in ('reference','parser2','combined')]
    ref=physical[0]
    for x in physical:
        x['lut_change_pct']=100*(x['resources']['Slice LUTs']/ref['resources']['Slice LUTs']-1)
        x['ff_change_pct']=100*(x['resources']['Slice Registers']/ref['resources']['Slice Registers']-1)
    result=dict(status='TRIAL_COMPLETE_NO_PROMOTION',reference_release=frozen['release_id'],
                production_unchanged=True,source_manifest_sha256=sha(O/'manifest.json'),native=native,
                native_completed_per_variant=sum(x['completed_per_variant'] for x in native),
                native_cycle_equivalence_checks=sum(x['cycle_equivalence_checks'] for x in native),events=events,ppa=physical,
                limits=['Main hardware measurement: NB32 ES3 FW12 EXACT_EN1 OPS_EN1, dynamic mode/n/OPS.',
                        'Four-format numeric/protocol replay is not exhaustive AC02, formal proof or new W14 signoff.',
                        'One matched Explore run per variant; no board result, maximum-frequency sweep or W15 statistical closure.',
                        'R2R STA estimate derives from current implemented timing; not a measured higher-frequency run.',
                        'All three OOC runs warn Route 35-198 about partial I/O routes; assumed-budget I/O STA is not board-interface timing.',
                        'No NF EXACT_EN0 derivative qualification and no fused candidate in this experiment.'])
    (O/'summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:result[k] for k in ('status','native_completed_per_variant','native_cycle_equivalence_checks')},indent=2))
    for x in physical:
        print(x['variant'],x['resources'],'WNS',x['wns_ns'],'WHS',x['whs_ns'],
              'R2R',x['r2r_setup_ns'],x['r2r_hold_ns'],'pass',x['full_timing_pass'])


if __name__=='__main__':main()
