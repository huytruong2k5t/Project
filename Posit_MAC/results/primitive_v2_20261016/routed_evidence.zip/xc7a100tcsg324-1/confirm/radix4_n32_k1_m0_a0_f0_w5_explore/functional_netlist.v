// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2026.1 (win64) Build 6511674 Tue Jun 16 11:02:23 MDT 2026
// Date        : Fri Oct 16 16:19:49 2026
// Host        : MSI running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim {C:/HCMUT/HK261/Do an
//               2/Posit_MAC/results/primitive_v2_20261016/xc7a100tcsg324-1/confirm/radix4_n32_k1_m0_a0_f0_w5_explore/functional_netlist.v}
// Design      : primitive_v2_top
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a100tcsg324-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module dyn_right_shifter
   (D,
    \g_multi.g_stages[1].g_pair.selected ,
    \g_shift.amount_q_reg[2] ,
    \g_shift.amount_q_reg[2]_0 ,
    \g_shift.amount_q_reg[2]_1 ,
    \g_shift.amount_q_reg[2]_2 ,
    Q,
    \result_reg[27] );
  output [15:0]D;
  output [11:0]\g_multi.g_stages[1].g_pair.selected ;
  output \g_shift.amount_q_reg[2] ;
  output \g_shift.amount_q_reg[2]_0 ;
  output \g_shift.amount_q_reg[2]_1 ;
  output \g_shift.amount_q_reg[2]_2 ;
  input [4:0]Q;
  input [31:0]\result_reg[27] ;

  wire [15:0]D;
  wire [4:0]Q;
  wire [31:0]\g_multi.g_stages[0].g_pair.selected ;
  wire [11:0]\g_multi.g_stages[1].g_pair.selected ;
  wire \g_shift.amount_q_reg[2] ;
  wire \g_shift.amount_q_reg[2]_0 ;
  wire \g_shift.amount_q_reg[2]_1 ;
  wire \g_shift.amount_q_reg[2]_2 ;
  wire \result[0]_i_2_n_0 ;
  wire \result[10]_i_2_n_0 ;
  wire \result[11]_i_2_n_0 ;
  wire \result[12]_i_2_n_0 ;
  wire \result[12]_i_3_n_0 ;
  wire \result[13]_i_2_n_0 ;
  wire \result[13]_i_3_n_0 ;
  wire \result[14]_i_2_n_0 ;
  wire \result[14]_i_3_n_0 ;
  wire \result[15]_i_2_n_0 ;
  wire \result[15]_i_3_n_0 ;
  wire \result[1]_i_2_n_0 ;
  wire \result[26]_i_3_n_0 ;
  wire \result[29]_i_2_n_0 ;
  wire \result[2]_i_2_n_0 ;
  wire \result[3]_i_2_n_0 ;
  wire \result[4]_i_2_n_0 ;
  wire \result[5]_i_2_n_0 ;
  wire \result[6]_i_2_n_0 ;
  wire \result[7]_i_2_n_0 ;
  wire \result[8]_i_2_n_0 ;
  wire \result[9]_i_2_n_0 ;
  wire [31:0]\result_reg[27] ;

  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[0]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [0]),
        .I1(Q[4]),
        .I2(\result[4]_i_2_n_0 ),
        .I3(Q[2]),
        .I4(\result[0]_i_2_n_0 ),
        .O(D[0]));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[0]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [8]),
        .I1(Q[3]),
        .I2(\g_multi.g_stages[0].g_pair.selected [0]),
        .O(\result[0]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[0]_i_3 
       (.I0(\result_reg[27] [3]),
        .I1(\result_reg[27] [1]),
        .I2(Q[0]),
        .I3(\result_reg[27] [2]),
        .I4(Q[1]),
        .I5(\result_reg[27] [0]),
        .O(\g_multi.g_stages[0].g_pair.selected [0]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[10]_i_1 
       (.I0(\g_shift.amount_q_reg[2]_1 ),
        .I1(Q[4]),
        .I2(\result[14]_i_3_n_0 ),
        .I3(Q[2]),
        .I4(\result[10]_i_2_n_0 ),
        .O(D[10]));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[10]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [18]),
        .I1(Q[3]),
        .I2(\g_multi.g_stages[0].g_pair.selected [10]),
        .O(\result[10]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[10]_i_3 
       (.I0(\result_reg[27] [13]),
        .I1(\result_reg[27] [11]),
        .I2(Q[0]),
        .I3(\result_reg[27] [12]),
        .I4(Q[1]),
        .I5(\result_reg[27] [10]),
        .O(\g_multi.g_stages[0].g_pair.selected [10]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[11]_i_1 
       (.I0(\g_shift.amount_q_reg[2]_2 ),
        .I1(Q[4]),
        .I2(\result[15]_i_3_n_0 ),
        .I3(Q[2]),
        .I4(\result[11]_i_2_n_0 ),
        .O(D[11]));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[11]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [19]),
        .I1(Q[3]),
        .I2(\g_multi.g_stages[0].g_pair.selected [11]),
        .O(\result[11]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[11]_i_3 
       (.I0(\result_reg[27] [14]),
        .I1(\result_reg[27] [12]),
        .I2(Q[0]),
        .I3(\result_reg[27] [13]),
        .I4(Q[1]),
        .I5(\result_reg[27] [11]),
        .O(\g_multi.g_stages[0].g_pair.selected [11]));
  LUT6 #(
    .INIT(64'h0F002F2F0F002020)) 
    \result[12]_i_1 
       (.I0(\g_multi.g_stages[0].g_pair.selected [28]),
        .I1(Q[3]),
        .I2(Q[4]),
        .I3(\result[12]_i_2_n_0 ),
        .I4(Q[2]),
        .I5(\result[12]_i_3_n_0 ),
        .O(D[12]));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[12]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [24]),
        .I1(Q[3]),
        .I2(\g_multi.g_stages[0].g_pair.selected [16]),
        .O(\result[12]_i_2_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[12]_i_3 
       (.I0(\g_multi.g_stages[0].g_pair.selected [20]),
        .I1(Q[3]),
        .I2(\g_multi.g_stages[0].g_pair.selected [12]),
        .O(\result[12]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[12]_i_4 
       (.I0(\result_reg[27] [15]),
        .I1(\result_reg[27] [13]),
        .I2(Q[0]),
        .I3(\result_reg[27] [14]),
        .I4(Q[1]),
        .I5(\result_reg[27] [12]),
        .O(\g_multi.g_stages[0].g_pair.selected [12]));
  LUT6 #(
    .INIT(64'h0F002F2F0F002020)) 
    \result[13]_i_1 
       (.I0(\g_multi.g_stages[0].g_pair.selected [29]),
        .I1(Q[3]),
        .I2(Q[4]),
        .I3(\result[13]_i_2_n_0 ),
        .I4(Q[2]),
        .I5(\result[13]_i_3_n_0 ),
        .O(D[13]));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[13]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [25]),
        .I1(Q[3]),
        .I2(\g_multi.g_stages[0].g_pair.selected [17]),
        .O(\result[13]_i_2_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[13]_i_3 
       (.I0(\g_multi.g_stages[0].g_pair.selected [21]),
        .I1(Q[3]),
        .I2(\g_multi.g_stages[0].g_pair.selected [13]),
        .O(\result[13]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[13]_i_4 
       (.I0(\result_reg[27] [16]),
        .I1(\result_reg[27] [14]),
        .I2(Q[0]),
        .I3(\result_reg[27] [15]),
        .I4(Q[1]),
        .I5(\result_reg[27] [13]),
        .O(\g_multi.g_stages[0].g_pair.selected [13]));
  LUT6 #(
    .INIT(64'h0F002F2F0F002020)) 
    \result[14]_i_1 
       (.I0(\result[26]_i_3_n_0 ),
        .I1(Q[3]),
        .I2(Q[4]),
        .I3(\result[14]_i_2_n_0 ),
        .I4(Q[2]),
        .I5(\result[14]_i_3_n_0 ),
        .O(D[14]));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[14]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [26]),
        .I1(Q[3]),
        .I2(\g_multi.g_stages[0].g_pair.selected [18]),
        .O(\result[14]_i_2_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[14]_i_3 
       (.I0(\g_multi.g_stages[0].g_pair.selected [22]),
        .I1(Q[3]),
        .I2(\g_multi.g_stages[0].g_pair.selected [14]),
        .O(\result[14]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[14]_i_4 
       (.I0(\result_reg[27] [17]),
        .I1(\result_reg[27] [15]),
        .I2(Q[0]),
        .I3(\result_reg[27] [16]),
        .I4(Q[1]),
        .I5(\result_reg[27] [14]),
        .O(\g_multi.g_stages[0].g_pair.selected [14]));
  LUT6 #(
    .INIT(64'h0F002F2F0F002020)) 
    \result[15]_i_1 
       (.I0(\g_multi.g_stages[0].g_pair.selected [31]),
        .I1(Q[3]),
        .I2(Q[4]),
        .I3(\result[15]_i_2_n_0 ),
        .I4(Q[2]),
        .I5(\result[15]_i_3_n_0 ),
        .O(D[15]));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[15]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [27]),
        .I1(Q[3]),
        .I2(\g_multi.g_stages[0].g_pair.selected [19]),
        .O(\result[15]_i_2_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[15]_i_3 
       (.I0(\g_multi.g_stages[0].g_pair.selected [23]),
        .I1(Q[3]),
        .I2(\g_multi.g_stages[0].g_pair.selected [15]),
        .O(\result[15]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[15]_i_4 
       (.I0(\result_reg[27] [18]),
        .I1(\result_reg[27] [16]),
        .I2(Q[0]),
        .I3(\result_reg[27] [17]),
        .I4(Q[1]),
        .I5(\result_reg[27] [15]),
        .O(\g_multi.g_stages[0].g_pair.selected [15]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[16]_i_1 
       (.I0(\g_multi.g_stages[0].g_pair.selected [28]),
        .I1(\g_multi.g_stages[0].g_pair.selected [20]),
        .I2(Q[2]),
        .I3(\g_multi.g_stages[0].g_pair.selected [24]),
        .I4(Q[3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [16]),
        .O(\g_multi.g_stages[1].g_pair.selected [0]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[16]_i_2 
       (.I0(\result_reg[27] [19]),
        .I1(\result_reg[27] [17]),
        .I2(Q[0]),
        .I3(\result_reg[27] [18]),
        .I4(Q[1]),
        .I5(\result_reg[27] [16]),
        .O(\g_multi.g_stages[0].g_pair.selected [16]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[17]_i_1 
       (.I0(\g_multi.g_stages[0].g_pair.selected [29]),
        .I1(\g_multi.g_stages[0].g_pair.selected [21]),
        .I2(Q[2]),
        .I3(\g_multi.g_stages[0].g_pair.selected [25]),
        .I4(Q[3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [17]),
        .O(\g_multi.g_stages[1].g_pair.selected [1]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[17]_i_2 
       (.I0(\result_reg[27] [20]),
        .I1(\result_reg[27] [18]),
        .I2(Q[0]),
        .I3(\result_reg[27] [19]),
        .I4(Q[1]),
        .I5(\result_reg[27] [17]),
        .O(\g_multi.g_stages[0].g_pair.selected [17]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[18]_i_1 
       (.I0(\result[26]_i_3_n_0 ),
        .I1(\g_multi.g_stages[0].g_pair.selected [22]),
        .I2(Q[2]),
        .I3(\g_multi.g_stages[0].g_pair.selected [26]),
        .I4(Q[3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [18]),
        .O(\g_multi.g_stages[1].g_pair.selected [2]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[18]_i_2 
       (.I0(\result_reg[27] [21]),
        .I1(\result_reg[27] [19]),
        .I2(Q[0]),
        .I3(\result_reg[27] [20]),
        .I4(Q[1]),
        .I5(\result_reg[27] [18]),
        .O(\g_multi.g_stages[0].g_pair.selected [18]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[19]_i_1 
       (.I0(\g_multi.g_stages[0].g_pair.selected [31]),
        .I1(\g_multi.g_stages[0].g_pair.selected [23]),
        .I2(Q[2]),
        .I3(\g_multi.g_stages[0].g_pair.selected [27]),
        .I4(Q[3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [19]),
        .O(\g_multi.g_stages[1].g_pair.selected [3]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[19]_i_2 
       (.I0(\result_reg[27] [22]),
        .I1(\result_reg[27] [20]),
        .I2(Q[0]),
        .I3(\result_reg[27] [21]),
        .I4(Q[1]),
        .I5(\result_reg[27] [19]),
        .O(\g_multi.g_stages[0].g_pair.selected [19]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[1]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [1]),
        .I1(Q[4]),
        .I2(\result[5]_i_2_n_0 ),
        .I3(Q[2]),
        .I4(\result[1]_i_2_n_0 ),
        .O(D[1]));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[1]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [9]),
        .I1(Q[3]),
        .I2(\g_multi.g_stages[0].g_pair.selected [1]),
        .O(\result[1]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[1]_i_3 
       (.I0(\result_reg[27] [4]),
        .I1(\result_reg[27] [2]),
        .I2(Q[0]),
        .I3(\result_reg[27] [3]),
        .I4(Q[1]),
        .I5(\result_reg[27] [1]),
        .O(\g_multi.g_stages[0].g_pair.selected [1]));
  LUT5 #(
    .INIT(32'h30BB3088)) 
    \result[20]_i_1 
       (.I0(\g_multi.g_stages[0].g_pair.selected [24]),
        .I1(Q[2]),
        .I2(\g_multi.g_stages[0].g_pair.selected [28]),
        .I3(Q[3]),
        .I4(\g_multi.g_stages[0].g_pair.selected [20]),
        .O(\g_multi.g_stages[1].g_pair.selected [4]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[20]_i_2 
       (.I0(\result_reg[27] [23]),
        .I1(\result_reg[27] [21]),
        .I2(Q[0]),
        .I3(\result_reg[27] [22]),
        .I4(Q[1]),
        .I5(\result_reg[27] [20]),
        .O(\g_multi.g_stages[0].g_pair.selected [20]));
  LUT5 #(
    .INIT(32'h30BB3088)) 
    \result[21]_i_1 
       (.I0(\g_multi.g_stages[0].g_pair.selected [25]),
        .I1(Q[2]),
        .I2(\g_multi.g_stages[0].g_pair.selected [29]),
        .I3(Q[3]),
        .I4(\g_multi.g_stages[0].g_pair.selected [21]),
        .O(\g_multi.g_stages[1].g_pair.selected [5]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[21]_i_2 
       (.I0(\result_reg[27] [24]),
        .I1(\result_reg[27] [22]),
        .I2(Q[0]),
        .I3(\result_reg[27] [23]),
        .I4(Q[1]),
        .I5(\result_reg[27] [21]),
        .O(\g_multi.g_stages[0].g_pair.selected [21]));
  LUT5 #(
    .INIT(32'h30BB3088)) 
    \result[22]_i_1 
       (.I0(\g_multi.g_stages[0].g_pair.selected [26]),
        .I1(Q[2]),
        .I2(\result[26]_i_3_n_0 ),
        .I3(Q[3]),
        .I4(\g_multi.g_stages[0].g_pair.selected [22]),
        .O(\g_multi.g_stages[1].g_pair.selected [6]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[22]_i_2 
       (.I0(\result_reg[27] [25]),
        .I1(\result_reg[27] [23]),
        .I2(Q[0]),
        .I3(\result_reg[27] [24]),
        .I4(Q[1]),
        .I5(\result_reg[27] [22]),
        .O(\g_multi.g_stages[0].g_pair.selected [22]));
  LUT5 #(
    .INIT(32'h30BB3088)) 
    \result[23]_i_1 
       (.I0(\g_multi.g_stages[0].g_pair.selected [27]),
        .I1(Q[2]),
        .I2(\g_multi.g_stages[0].g_pair.selected [31]),
        .I3(Q[3]),
        .I4(\g_multi.g_stages[0].g_pair.selected [23]),
        .O(\g_multi.g_stages[1].g_pair.selected [7]));
  LUT3 #(
    .INIT(8'h02)) 
    \result[23]_i_2 
       (.I0(\result_reg[27] [31]),
        .I1(Q[0]),
        .I2(Q[1]),
        .O(\g_multi.g_stages[0].g_pair.selected [31]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[23]_i_3 
       (.I0(\result_reg[27] [26]),
        .I1(\result_reg[27] [24]),
        .I2(Q[0]),
        .I3(\result_reg[27] [25]),
        .I4(Q[1]),
        .I5(\result_reg[27] [23]),
        .O(\g_multi.g_stages[0].g_pair.selected [23]));
  LUT4 #(
    .INIT(16'h00E2)) 
    \result[24]_i_1 
       (.I0(\g_multi.g_stages[0].g_pair.selected [24]),
        .I1(Q[2]),
        .I2(\g_multi.g_stages[0].g_pair.selected [28]),
        .I3(Q[3]),
        .O(\g_shift.amount_q_reg[2] ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[24]_i_2 
       (.I0(\result_reg[27] [27]),
        .I1(\result_reg[27] [25]),
        .I2(Q[0]),
        .I3(\result_reg[27] [26]),
        .I4(Q[1]),
        .I5(\result_reg[27] [24]),
        .O(\g_multi.g_stages[0].g_pair.selected [24]));
  LUT4 #(
    .INIT(16'h00E2)) 
    \result[25]_i_1 
       (.I0(\g_multi.g_stages[0].g_pair.selected [25]),
        .I1(Q[2]),
        .I2(\g_multi.g_stages[0].g_pair.selected [29]),
        .I3(Q[3]),
        .O(\g_shift.amount_q_reg[2]_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[25]_i_2 
       (.I0(\result_reg[27] [28]),
        .I1(\result_reg[27] [26]),
        .I2(Q[0]),
        .I3(\result_reg[27] [27]),
        .I4(Q[1]),
        .I5(\result_reg[27] [25]),
        .O(\g_multi.g_stages[0].g_pair.selected [25]));
  LUT5 #(
    .INIT(32'h30BB3088)) 
    \result[25]_i_3 
       (.I0(\result_reg[27] [30]),
        .I1(Q[0]),
        .I2(\result_reg[27] [31]),
        .I3(Q[1]),
        .I4(\result_reg[27] [29]),
        .O(\g_multi.g_stages[0].g_pair.selected [29]));
  LUT4 #(
    .INIT(16'h00E2)) 
    \result[26]_i_1 
       (.I0(\g_multi.g_stages[0].g_pair.selected [26]),
        .I1(Q[2]),
        .I2(\result[26]_i_3_n_0 ),
        .I3(Q[3]),
        .O(\g_shift.amount_q_reg[2]_1 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[26]_i_2 
       (.I0(\result_reg[27] [29]),
        .I1(\result_reg[27] [27]),
        .I2(Q[0]),
        .I3(\result_reg[27] [28]),
        .I4(Q[1]),
        .I5(\result_reg[27] [26]),
        .O(\g_multi.g_stages[0].g_pair.selected [26]));
  LUT4 #(
    .INIT(16'h00E2)) 
    \result[26]_i_3 
       (.I0(\result_reg[27] [30]),
        .I1(Q[0]),
        .I2(\result_reg[27] [31]),
        .I3(Q[1]),
        .O(\result[26]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h00000000222E2222)) 
    \result[27]_i_1 
       (.I0(\g_multi.g_stages[0].g_pair.selected [27]),
        .I1(Q[2]),
        .I2(Q[1]),
        .I3(Q[0]),
        .I4(\result_reg[27] [31]),
        .I5(Q[3]),
        .O(\g_shift.amount_q_reg[2]_2 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[27]_i_2 
       (.I0(\result_reg[27] [30]),
        .I1(\result_reg[27] [28]),
        .I2(Q[0]),
        .I3(\result_reg[27] [29]),
        .I4(Q[1]),
        .I5(\result_reg[27] [27]),
        .O(\g_multi.g_stages[0].g_pair.selected [27]));
  LUT3 #(
    .INIT(8'h02)) 
    \result[28]_i_1 
       (.I0(\g_multi.g_stages[0].g_pair.selected [28]),
        .I1(Q[2]),
        .I2(Q[3]),
        .O(\g_multi.g_stages[1].g_pair.selected [8]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[28]_i_2 
       (.I0(\result_reg[27] [31]),
        .I1(\result_reg[27] [29]),
        .I2(Q[0]),
        .I3(\result_reg[27] [30]),
        .I4(Q[1]),
        .I5(\result_reg[27] [28]),
        .O(\g_multi.g_stages[0].g_pair.selected [28]));
  LUT6 #(
    .INIT(64'h33E200E200000000)) 
    \result[29]_i_1 
       (.I0(\result_reg[27] [29]),
        .I1(Q[1]),
        .I2(\result_reg[27] [31]),
        .I3(Q[0]),
        .I4(\result_reg[27] [30]),
        .I5(\result[29]_i_2_n_0 ),
        .O(\g_multi.g_stages[1].g_pair.selected [9]));
  LUT2 #(
    .INIT(4'h1)) 
    \result[29]_i_2 
       (.I0(Q[3]),
        .I1(Q[2]),
        .O(\result[29]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[2]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [2]),
        .I1(Q[4]),
        .I2(\result[6]_i_2_n_0 ),
        .I3(Q[2]),
        .I4(\result[2]_i_2_n_0 ),
        .O(D[2]));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[2]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [10]),
        .I1(Q[3]),
        .I2(\g_multi.g_stages[0].g_pair.selected [2]),
        .O(\result[2]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[2]_i_3 
       (.I0(\result_reg[27] [5]),
        .I1(\result_reg[27] [3]),
        .I2(Q[0]),
        .I3(\result_reg[27] [4]),
        .I4(Q[1]),
        .I5(\result_reg[27] [2]),
        .O(\g_multi.g_stages[0].g_pair.selected [2]));
  LUT6 #(
    .INIT(64'h0000000000004540)) 
    \result[30]_i_1 
       (.I0(Q[1]),
        .I1(\result_reg[27] [31]),
        .I2(Q[0]),
        .I3(\result_reg[27] [30]),
        .I4(Q[2]),
        .I5(Q[3]),
        .O(\g_multi.g_stages[1].g_pair.selected [10]));
  LUT5 #(
    .INIT(32'h00000010)) 
    \result[31]_i_1 
       (.I0(Q[1]),
        .I1(Q[0]),
        .I2(\result_reg[27] [31]),
        .I3(Q[2]),
        .I4(Q[3]),
        .O(\g_multi.g_stages[1].g_pair.selected [11]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[3]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [3]),
        .I1(Q[4]),
        .I2(\result[7]_i_2_n_0 ),
        .I3(Q[2]),
        .I4(\result[3]_i_2_n_0 ),
        .O(D[3]));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[3]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [11]),
        .I1(Q[3]),
        .I2(\g_multi.g_stages[0].g_pair.selected [3]),
        .O(\result[3]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[3]_i_3 
       (.I0(\result_reg[27] [6]),
        .I1(\result_reg[27] [4]),
        .I2(Q[0]),
        .I3(\result_reg[27] [5]),
        .I4(Q[1]),
        .I5(\result_reg[27] [3]),
        .O(\g_multi.g_stages[0].g_pair.selected [3]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[4]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [4]),
        .I1(Q[4]),
        .I2(\result[8]_i_2_n_0 ),
        .I3(Q[2]),
        .I4(\result[4]_i_2_n_0 ),
        .O(D[4]));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[4]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [12]),
        .I1(Q[3]),
        .I2(\g_multi.g_stages[0].g_pair.selected [4]),
        .O(\result[4]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[4]_i_3 
       (.I0(\result_reg[27] [7]),
        .I1(\result_reg[27] [5]),
        .I2(Q[0]),
        .I3(\result_reg[27] [6]),
        .I4(Q[1]),
        .I5(\result_reg[27] [4]),
        .O(\g_multi.g_stages[0].g_pair.selected [4]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[5]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [5]),
        .I1(Q[4]),
        .I2(\result[9]_i_2_n_0 ),
        .I3(Q[2]),
        .I4(\result[5]_i_2_n_0 ),
        .O(D[5]));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[5]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [13]),
        .I1(Q[3]),
        .I2(\g_multi.g_stages[0].g_pair.selected [5]),
        .O(\result[5]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[5]_i_3 
       (.I0(\result_reg[27] [8]),
        .I1(\result_reg[27] [6]),
        .I2(Q[0]),
        .I3(\result_reg[27] [7]),
        .I4(Q[1]),
        .I5(\result_reg[27] [5]),
        .O(\g_multi.g_stages[0].g_pair.selected [5]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[6]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [6]),
        .I1(Q[4]),
        .I2(\result[10]_i_2_n_0 ),
        .I3(Q[2]),
        .I4(\result[6]_i_2_n_0 ),
        .O(D[6]));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[6]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [14]),
        .I1(Q[3]),
        .I2(\g_multi.g_stages[0].g_pair.selected [6]),
        .O(\result[6]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[6]_i_3 
       (.I0(\result_reg[27] [9]),
        .I1(\result_reg[27] [7]),
        .I2(Q[0]),
        .I3(\result_reg[27] [8]),
        .I4(Q[1]),
        .I5(\result_reg[27] [6]),
        .O(\g_multi.g_stages[0].g_pair.selected [6]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[7]_i_1 
       (.I0(\g_multi.g_stages[1].g_pair.selected [7]),
        .I1(Q[4]),
        .I2(\result[11]_i_2_n_0 ),
        .I3(Q[2]),
        .I4(\result[7]_i_2_n_0 ),
        .O(D[7]));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[7]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [15]),
        .I1(Q[3]),
        .I2(\g_multi.g_stages[0].g_pair.selected [7]),
        .O(\result[7]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[7]_i_3 
       (.I0(\result_reg[27] [10]),
        .I1(\result_reg[27] [8]),
        .I2(Q[0]),
        .I3(\result_reg[27] [9]),
        .I4(Q[1]),
        .I5(\result_reg[27] [7]),
        .O(\g_multi.g_stages[0].g_pair.selected [7]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[8]_i_1 
       (.I0(\g_shift.amount_q_reg[2] ),
        .I1(Q[4]),
        .I2(\result[12]_i_3_n_0 ),
        .I3(Q[2]),
        .I4(\result[8]_i_2_n_0 ),
        .O(D[8]));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[8]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [16]),
        .I1(Q[3]),
        .I2(\g_multi.g_stages[0].g_pair.selected [8]),
        .O(\result[8]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[8]_i_3 
       (.I0(\result_reg[27] [11]),
        .I1(\result_reg[27] [9]),
        .I2(Q[0]),
        .I3(\result_reg[27] [10]),
        .I4(Q[1]),
        .I5(\result_reg[27] [8]),
        .O(\g_multi.g_stages[0].g_pair.selected [8]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[9]_i_1 
       (.I0(\g_shift.amount_q_reg[2]_0 ),
        .I1(Q[4]),
        .I2(\result[13]_i_3_n_0 ),
        .I3(Q[2]),
        .I4(\result[9]_i_2_n_0 ),
        .O(D[9]));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[9]_i_2 
       (.I0(\g_multi.g_stages[0].g_pair.selected [17]),
        .I1(Q[3]),
        .I2(\g_multi.g_stages[0].g_pair.selected [9]),
        .O(\result[9]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[9]_i_3 
       (.I0(\result_reg[27] [12]),
        .I1(\result_reg[27] [10]),
        .I2(Q[0]),
        .I3(\result_reg[27] [11]),
        .I4(Q[1]),
        .I5(\result_reg[27] [9]),
        .O(\g_multi.g_stages[0].g_pair.selected [9]));
endmodule

module primitive_v2_boundary
   (result,
    data,
    clk_core,
    amount);
  output [31:0]result;
  input [31:0]data;
  input clk_core;
  input [4:0]amount;

  wire [4:0]amount;
  wire clk_core;
  wire [31:0]data;
  wire [31:0]data_q;
  wire [31:16]\g_multi.g_stages[1].g_pair.selected ;
  wire [4:0]\g_shift.amount_q ;
  wire \g_shift.g_right.u_shift_n_28 ;
  wire \g_shift.g_right.u_shift_n_29 ;
  wire \g_shift.g_right.u_shift_n_30 ;
  wire \g_shift.g_right.u_shift_n_31 ;
  wire [31:0]result;
  wire [15:0]result_d;

  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[0] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[0]),
        .Q(data_q[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[10] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[10]),
        .Q(data_q[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[11] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[11]),
        .Q(data_q[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[12] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[12]),
        .Q(data_q[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[13] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[13]),
        .Q(data_q[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[14] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[14]),
        .Q(data_q[14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[15] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[15]),
        .Q(data_q[15]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[16] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[16]),
        .Q(data_q[16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[17] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[17]),
        .Q(data_q[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[18] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[18]),
        .Q(data_q[18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[19] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[19]),
        .Q(data_q[19]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[1] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[1]),
        .Q(data_q[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[20] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[20]),
        .Q(data_q[20]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[21] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[21]),
        .Q(data_q[21]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[22] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[22]),
        .Q(data_q[22]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[23] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[23]),
        .Q(data_q[23]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[24] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[24]),
        .Q(data_q[24]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[25] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[25]),
        .Q(data_q[25]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[26] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[26]),
        .Q(data_q[26]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[27] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[27]),
        .Q(data_q[27]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[28] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[28]),
        .Q(data_q[28]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[29] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[29]),
        .Q(data_q[29]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[2] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[2]),
        .Q(data_q[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[30] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[30]),
        .Q(data_q[30]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[31] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[31]),
        .Q(data_q[31]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[3] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[3]),
        .Q(data_q[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[4] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[4]),
        .Q(data_q[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[5] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[5]),
        .Q(data_q[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[6] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[6]),
        .Q(data_q[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[7] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[7]),
        .Q(data_q[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[8] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[8]),
        .Q(data_q[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[9] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[9]),
        .Q(data_q[9]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \g_shift.amount_q_reg[0] 
       (.C(clk_core),
        .CE(1'b1),
        .D(amount[0]),
        .Q(\g_shift.amount_q [0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \g_shift.amount_q_reg[1] 
       (.C(clk_core),
        .CE(1'b1),
        .D(amount[1]),
        .Q(\g_shift.amount_q [1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \g_shift.amount_q_reg[2] 
       (.C(clk_core),
        .CE(1'b1),
        .D(amount[2]),
        .Q(\g_shift.amount_q [2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \g_shift.amount_q_reg[3] 
       (.C(clk_core),
        .CE(1'b1),
        .D(amount[3]),
        .Q(\g_shift.amount_q [3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \g_shift.amount_q_reg[4] 
       (.C(clk_core),
        .CE(1'b1),
        .D(amount[4]),
        .Q(\g_shift.amount_q [4]),
        .R(1'b0));
  dyn_right_shifter \g_shift.g_right.u_shift 
       (.D(result_d),
        .Q(\g_shift.amount_q ),
        .\g_multi.g_stages[1].g_pair.selected ({\g_multi.g_stages[1].g_pair.selected [31:28],\g_multi.g_stages[1].g_pair.selected [23:16]}),
        .\g_shift.amount_q_reg[2] (\g_shift.g_right.u_shift_n_28 ),
        .\g_shift.amount_q_reg[2]_0 (\g_shift.g_right.u_shift_n_29 ),
        .\g_shift.amount_q_reg[2]_1 (\g_shift.g_right.u_shift_n_30 ),
        .\g_shift.amount_q_reg[2]_2 (\g_shift.g_right.u_shift_n_31 ),
        .\result_reg[27] (data_q));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[0] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[0]),
        .Q(result[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[10] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[10]),
        .Q(result[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[11] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[11]),
        .Q(result[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[12] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[12]),
        .Q(result[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[13] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[13]),
        .Q(result[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[14] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[14]),
        .Q(result[14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[15] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[15]),
        .Q(result[15]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[16] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\g_multi.g_stages[1].g_pair.selected [16]),
        .Q(result[16]),
        .R(\g_shift.amount_q [4]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[17] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\g_multi.g_stages[1].g_pair.selected [17]),
        .Q(result[17]),
        .R(\g_shift.amount_q [4]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[18] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\g_multi.g_stages[1].g_pair.selected [18]),
        .Q(result[18]),
        .R(\g_shift.amount_q [4]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[19] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\g_multi.g_stages[1].g_pair.selected [19]),
        .Q(result[19]),
        .R(\g_shift.amount_q [4]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[1] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[1]),
        .Q(result[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[20] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\g_multi.g_stages[1].g_pair.selected [20]),
        .Q(result[20]),
        .R(\g_shift.amount_q [4]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[21] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\g_multi.g_stages[1].g_pair.selected [21]),
        .Q(result[21]),
        .R(\g_shift.amount_q [4]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[22] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\g_multi.g_stages[1].g_pair.selected [22]),
        .Q(result[22]),
        .R(\g_shift.amount_q [4]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[23] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\g_multi.g_stages[1].g_pair.selected [23]),
        .Q(result[23]),
        .R(\g_shift.amount_q [4]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[24] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\g_shift.g_right.u_shift_n_28 ),
        .Q(result[24]),
        .R(\g_shift.amount_q [4]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[25] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\g_shift.g_right.u_shift_n_29 ),
        .Q(result[25]),
        .R(\g_shift.amount_q [4]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[26] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\g_shift.g_right.u_shift_n_30 ),
        .Q(result[26]),
        .R(\g_shift.amount_q [4]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[27] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\g_shift.g_right.u_shift_n_31 ),
        .Q(result[27]),
        .R(\g_shift.amount_q [4]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[28] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\g_multi.g_stages[1].g_pair.selected [28]),
        .Q(result[28]),
        .R(\g_shift.amount_q [4]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[29] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\g_multi.g_stages[1].g_pair.selected [29]),
        .Q(result[29]),
        .R(\g_shift.amount_q [4]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[2] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[2]),
        .Q(result[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[30] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\g_multi.g_stages[1].g_pair.selected [30]),
        .Q(result[30]),
        .R(\g_shift.amount_q [4]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[31] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\g_multi.g_stages[1].g_pair.selected [31]),
        .Q(result[31]),
        .R(\g_shift.amount_q [4]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[3] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[3]),
        .Q(result[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[4] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[4]),
        .Q(result[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[5] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[5]),
        .Q(result[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[6] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[6]),
        .Q(result[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[7] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[7]),
        .Q(result[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[8] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[8]),
        .Q(result[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[9] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[9]),
        .Q(result[9]),
        .R(1'b0));
endmodule

(* ARITH = "0" *) (* ECO_CHECKSUM = "5f00d2b0" *) (* FILL_KIND = "0" *) 
(* KIND = "1" *) (* MODE = "0" *) (* N = "32" *) 
(* RESULT_W = "32" *) (* SHIFT_W = "5" *) 
(* NotValidForBitStream *)
(* \DesignAttr:ENABLE_NOC_NETLIST_VIEW  *) 
(* \DesignAttr:ENABLE_AIE_NETLIST_VIEW  *) 
module primitive_v2_top
   (clk,
    data,
    amount,
    fill_val,
    result);
  input clk;
  input [31:0]data;
  input [4:0]amount;
  input fill_val;
  output [31:0]result;

  wire [4:0]amount;
  wire clk;
  wire clk_core;
  wire [31:0]data;
  wire [31:0]result;

  primitive_v2_boundary u_boundary
       (.amount(amount),
        .clk_core(clk_core),
        .data(data),
        .result(result));
  (* BOX_TYPE = "PRIMITIVE" *) 
  BUFG u_clock
       (.I(clk),
        .O(clk_core));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
