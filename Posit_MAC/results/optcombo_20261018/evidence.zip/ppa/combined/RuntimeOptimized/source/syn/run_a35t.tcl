# A35T-C2 flow: nf|f benchmark_100mhz validate|synth|implement.
# Fixed 10 ns benchmark budget; no historical snapshot is modified.
if {[llength $argv] != 3} {error "Expected variant benchmark_100mhz action"}
lassign $argv variant profile action
if {$variant ni {nf f} || $profile ne "benchmark_100mhz" ||
    $action ni {validate synth implement}} {error "Unsupported flow arguments"}
set root [file normalize [file join [file dirname [info script]] ..]]
set part xc7a35tcpg236-1
set_param general.maxThreads 4
create_project -in_memory -part $part
set_property include_dirs [list [file join $root rtl]] [current_fileset]
set f [open [file join $root rtl production.f] r]
foreach path [split [read $f] \n] {
    set path [string trim $path]
    if {$path ne {}} {read_verilog -sv [list [file join $root $path]]}
}
close $f
if {$variant eq "nf"} {
    set top prepack_nf_ppa_top
    read_verilog -sv [list [file join $root tb prepack_nf_ppa_top.sv]]
} else {
    set top week13_fused_ppa_top
    read_verilog -sv [list [file join $root tb week13_fused_ppa_top.sv]]
}
# Load constraints BEFORE synthesis, so the synthesis optimizer sees the clock.
read_xdc [list [file join $root syn constraints a35t_clock.xdc]]
read_xdc [list [file join $root syn constraints a35t_benchmark_100mhz.xdc]]
if {$action eq "validate"} {
    synth_design -rtl -top $top -part $part
} else {
    synth_design -top $top -part $part -mode out_of_context -flatten_hierarchy rebuilt
}
set clocks [get_clocks]
if {[llength $clocks] != 1 || [get_property NAME $clocks] ne "clk" ||
    abs([get_property PERIOD $clocks] - 10.0) > 0.000001} {error "Clock contract did not load"}
report_clocks -file clocks.rpt
write_xdc effective_constraints.xdc
set f [open scope.txt w]
puts $f [version]
puts $f "contract=A35T-C2 part=$part variant=$variant profile=$profile action=$action"
puts $f "clock_period_ns=10 setup_uncertainty_ns=0.100 hold_uncertainty_ns=0.100"
puts $f "NF=32/3 FW12 EXACT_EN1 OPS_EN1; F=32/3 FW12 W32 EXACT_EN0 OPS_EN1"
puts $f "No paired NF/F claim: NF EXACT_EN0 comparator still needs separate verification."
puts $f "BENCHMARK_IO_ASSUMPTIONS: input min=max 2.500 ns; output min=0.000 max=0.500 ns."
puts $f "Fixed 100 MHz benchmark budget, NOT measured board/interface timing."
puts $f "Report Internal R2R separately from assumed-budget I/O timing."
puts $f "Higher-frequency sweeps need a separate declared contract; no automatic I/O scaling."
close $f
if {$action eq "validate"} {
    set f [open status.txt w]; puts $f VALIDATED; close $f
    puts A35T_CONSTRAINTS_VALIDATED
    close_project
    exit
}
report_utilization -file synthesis_utilization.rpt
report_timing_summary -delay_type min_max -report_unconstrained -check_timing_verbose -file synthesis_timing.rpt
write_checkpoint synthesis.dcp
if {$action eq "implement"} {
    opt_design
    place_design -directive RuntimeOptimized
    route_design -directive Default
    write_checkpoint routed.dcp
    write_xdc effective_constraints_routed.xdc
    report_timing_summary -delay_type min_max -report_unconstrained -check_timing_verbose -file timing.rpt
    report_utilization -file utilization.rpt
    report_utilization -hierarchical -file hierarchy.rpt
    report_route_status -file route.rpt
    report_drc -file drc.rpt
    report_methodology -file methodology.rpt
    set targets [get_pins -of_objects [all_registers] -filter {REF_PIN_NAME == D || REF_PIN_NAME == CE}]
    report_timing -from [all_registers] -to $targets -delay_type max -max_paths 10 -file r2r_setup.rpt
    report_timing -from [all_registers] -to $targets -delay_type min -max_paths 10 -file r2r_hold.rpt
}
set outputs [get_ports -filter {DIRECTION == OUT}]
proc classify {name} {
    if {[regexp {/(meta_sync[12]|reset_bridge_q)_reg} $name]} {return reset_sync}
    foreach operand {a b c} {
        foreach stage {1 2} {
            if {[string match "*/u_${operand}/p${stage}_*" $name]} {return parser_${operand}_p${stage}}
        }
    }
    if {[string match "*/u_core/u_ctrl/*" $name]} {
        if {[regexp {/(emitting_q|mode_q|fx_q|scale_q|count_q|limit_q)_reg} $name]} {return sac_state}
        return sac_token_l1
    }
    if {[string match "*/u_core/u_acc/*" $name]} {return accumulator_l3}
    if {[string match "*/u_core/t2_*" $name]} {return sbm_shift_l2}
    if {[string match "*/u_core/*" $name]} {return ops_m0_core_context}
    foreach pack {product_pack pack} {
        set label [expr {$pack eq "pack" ? "final" : "product"}]
        if {[string match "*/u_${pack}/g_rne.p1_*" $name]} {return ${label}_packer_p1}
        if {[string match "*/u_${pack}/*" $name]} {return ${label}_packer_p2}
    }
    if {[string match "*/u_add/*" $name]} {
        if {[regexp {/(a1_q|valid1_q)_reg} $name]} {return adder_a1}
        if {[regexp {/(a2_q|valid2_q)_reg} $name]} {return adder_a2}
        return adder_a3
    }
    if {[regexp {/(product_frac_q|norm_[a-z_]+_q)_reg} $name]} {return product_parse_bank}
    if {[regexp {/(c_[a-z_]+_q|zero_q|nar_q)_reg} $name]} {return c_context}
    if {[regexp {/accumulator_q_reg} $name]} {return accumulator_feedback}
    if {[regexp {/(mode_q|acc_mode_q|n_q|ops_q|busy_q|committed_q)_reg} $name]} {return transaction_control}
    return unclassified
}

set groups [dict create]
foreach cell [all_registers] {
    dict lappend groups [classify [get_property NAME $cell]] $cell
}
set csv [open stages.csv w]
puts $csv "group,register_count,setup_slack_ns,hold_slack_ns,data_delay_ns,logic_delay_ns,route_delay_ns,levels,startpoint,endpoint,hold_startpoint,hold_endpoint"
proc report_bank {name targets} {
    global csv
    set f [open ${name}_registers.txt w]
    foreach cell $targets {puts $f [get_property NAME $cell]}
    close $f
    # Data and synchronous enable only: exclude CLR/PRE recovery/removal.
    set pins [get_pins -quiet -of_objects $targets -filter {REF_PIN_NAME == D || REF_PIN_NAME == CE}]
    set row [list $name [llength $targets]]
    set setup [get_timing_paths -quiet -to $pins -delay_type max -max_paths 1]
    set hold [get_timing_paths -quiet -to $pins -delay_type min -max_paths 1]
    if {[llength $setup] && [llength $hold]} {
        foreach prop {SLACK} {lappend row [get_property $prop $setup]}
        lappend row [get_property SLACK $hold]
        foreach prop {DATAPATH_DELAY DATAPATH_LOGIC_DELAY DATAPATH_NET_DELAY LOGIC_LEVELS STARTPOINT_PIN ENDPOINT_PIN} {
            lappend row [get_property $prop $setup]
        }
        lappend row [get_property STARTPOINT_PIN $hold] [get_property ENDPOINT_PIN $hold]
        report_timing -to $pins -delay_type max -max_paths 3 -file ${name}_setup.rpt
        report_timing -to $pins -delay_type min -max_paths 3 -file ${name}_hold.rpt
    } else {
        for {set k 0} {$k < 10} {incr k} {lappend row NA}
    }
    puts $csv [join $row ,]
    flush $csv
}
foreach name [lsort [dict keys $groups]] {report_bank $name [dict get $groups $name]}
report_bank whole_data [all_registers]
close $csv
report_timing -to $outputs -delay_type max -max_paths 3 -file output_setup.rpt
report_timing -to $outputs -delay_type min -max_paths 3 -file output_hold.rpt
set f [open structural.txt w]
puts $f "registers=[llength [all_registers]]"
puts $f "latches=[llength [get_cells -quiet -hier -filter {REF_NAME =~ LD*}]]"
puts $f "unrouted=[llength [get_nets -quiet -hier -filter {ROUTE_STATUS == UNROUTED}]]"
puts $f "unclassified=[expr {[dict exists $groups unclassified] ? [llength [dict get $groups unclassified]] : 0}]"
close $f

# COMPLETE means execution complete, not timing PASS. Inspect timing/coverage.
set f [open status.txt w]; puts $f COMPLETE; close $f
puts A35T_FLOW_COMPLETE
close_project
exit
