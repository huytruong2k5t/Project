# Multiplier đang sử dụng — 02/11/2026

Đã truy vết instance từ hai top `posit_mac_nf` và `posit_mac_f`, đối chiếu `../mac_active.f`. Cả **14/14 file SV** đều còn sử dụng; không có file dư để loại bỏ.

| File | Nhánh | Instance gọi trực tiếp |
|---|---|---|
| [iter_ctrl.sv](iter_ctrl.sv) | NF | `mul_iter_core.u_ctrl` |
| [mul_iter_core.sv](mul_iter_core.sv) | NF | `mac_nf_wrapper.u_core` |
| [mul_iter_core_fixed2.sv](mul_iter_core_fixed2.sv) | F | `mac_f_wrapper.u_core` |
| [mul_prepack_norm_comb.sv](mul_prepack_norm_comb.sv) | NF | `mac_nf_wrapper.u_norm` |
| [ops_sel_comb.sv](ops_sel_comb.sv) | NF | `mac_nf_wrapper.u_ops` |
| [ops_sel_comb_fixed2.sv](ops_sel_comb_fixed2.sv) | F | `mac_f_wrapper.u_ops` |
| [sac_step_comb.sv](sac_step_comb.sv) | NF | `iter_ctrl.u_exact` |
| [sac_step_comb_fixed2.sv](sac_step_comb_fixed2.sv) | NF | `iter_ctrl.u_approx` |
| [sac_step_comb_fixed3.sv](sac_step_comb_fixed3.sv) | F | `mul_iter_core_fixed2.u_sac` |
| [sbm_accum.sv](sbm_accum.sv) | NF | `mul_iter_core.u_acc` |
| [sbm_accum_comb.sv](sbm_accum_comb.sv) | NF | `sbm_accum.u_add` |
| [sbm_accum_comb_fixed2.sv](sbm_accum_comb_fixed2.sv) | F | `mul_iter_core_fixed2.u_accum` |
| [sbm_shift_comb.sv](sbm_shift_comb.sv) | NF | `mul_iter_core.u_shift` |
| [sbm_shift_comb_fixed2.sv](sbm_shift_comb_fixed2.sv) | F | `mul_iter_core_fixed2.u_shift` |

Các hậu tố `fixed2`/`fixed3` không biểu thị file đã hết dùng. Hai SAC approximate cùng xử lý fraction 12 bit nhưng dùng scale 5 bit (NF) và 4 bit (F). Bộ tích lũy và term của NF rộng 54 bit, của F rộng 16 bit; các bản này có khác biệt thực sự về giao diện và chức năng.

RTL NF hiện vẫn chứa nhánh exact-capable. Chuyển sang đặc tả approximate-only là thay đổi kiến trúc riêng, không thuộc lần dọn file này.

[Bảng truy vết và SHA-256](../../archive/cleanup_20261102/multiplier_usage_audit.json): cả 14 file giữ nguyên byte so với snapshot p00 đã đo F2F. Lần rà soát này chỉ đọc RTL và bổ sung tài liệu; không chạy mô phỏng hoặc synthesis.
