`timescale 1ns/1ps
module tb_fused_nar_contract;
    logic clk = 0;
    always #5 clk = !clk;
    logic reset_n = 0;
    logic in_valid = 0;
    wire in_ready, out_valid;
    logic out_ready = 1;
    logic [13:0] p_magnitude = 0;
    logic signed [10:0] p_scale = 0;
    logic p_sign = 0, p_zero = 1, is_nar_in = 1;
    logic [1:0] loss_in = 0;
    logic signed [10:0] c_sf = 0;
    logic [25:0] c_frac = 0;
    logic c_sign = 0, c_zero = 1;
    wire sign, is_zero, is_nar, sticky;
    wire signed [10:0] sf;
    wire [52:0] frac;
    wire [4:0] flags_out;
    integer checked = 0;
    fused_add_pipe dut (.*);

    task check_nar;
        begin
            if ({sign, is_zero, is_nar, sf, frac, sticky, flags_out}
                !== {1'b1, 1'b0, 1'b1, 11'b0, 53'b0, 1'b0, 5'b10000})
                $fatal(1, "Noncanonical NaR at fused pipeline output");
        end
    endtask

    // One transaction at a time, including loss metadata and output stalls.
    initial begin
        repeat (4) @(negedge clk);
        reset_n = 1;
        for (integer row = 0; row < 32; row = row + 1) begin
            while (!in_ready) @(negedge clk);
            c_zero = !(row & 4);
            c_sign = (row & 8) != 0;
            c_frac = (row & 16) ? 26'h2abcdef : 0;
            c_sf = (row & 16) ? -11'sd21 : 11'sd9;
            loss_in = row[1:0];
            in_valid = 1;
            @(negedge clk);
            in_valid = 0;
            out_ready = 0;
            while (!out_valid) @(negedge clk);
            repeat (3) begin
                check_nar();
                @(negedge clk);
                if (!out_valid) $fatal(1, "Dropped output during stall");
            end
            check_nar();
            out_ready = 1;
            @(negedge clk);
            checked = checked + 1;
        end

        // A finite zero after NaR must clear the prior special-case metadata.
        while (!in_ready) @(negedge clk);
        is_nar_in = 0;
        c_zero = 1;
        c_frac = 0;
        c_sf = 0;
        loss_in = 0;
        in_valid = 1;
        @(negedge clk);
        in_valid = 0;
        while (!out_valid) @(negedge clk);
        if (is_nar || !is_zero || sign || sf || frac || sticky || flags_out)
            $fatal(1, "Finite zero after NaR is not canonical");
        $display("FUSED_NAR_CONTRACT_PASS nar_cases=%0d finite_zero=1 stalled_checks=%0d", checked, 4*checked);
        $finish;
    end
    initial begin
        #100000;
        $fatal(1, "Timeout");
    end
endmodule
