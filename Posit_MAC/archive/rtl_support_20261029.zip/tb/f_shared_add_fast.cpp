#include <algorithm>
#include <array>
#include <fstream>
#include <iostream>
#include <random>
#include <stdexcept>
#include <string>
#include "Vf_shared_add_compare.h"
#include "verilated.h"
#include "posit_fused_window.hpp"
#include "week12_fused_reference.hpp"
#include "nf_coverage_corpus.hpp"
using Model = l1::FusedWindow<32,3,12,32>;
using Oracle = week12_reference::Oracle<32,3>;
using Mul = l1::L1MultiplierIter<32,3,12>;
#include "f_shared_add_corpus.hpp"

int main(int argc, char** argv) try {
    check(argc == 3, "usage: fast_sim completed report.json");
    const uint64_t goal = std::stoull(argv[1]);
    Verilated::commandArgs(argc, argv);
    Vf_shared_add_compare dut;
    std::mt19937_64 rng(20261022);
    uint64_t cycles = 0, completed = 0, accepted = 0, ii_checks = 0;
    uint64_t start = 0, previous_start = 0, previous_latency = 0;
    uint32_t state = 0;
    unsigned expected_latency = 0;
    bool pending = false, source = false, pending_acc = false;
    Model::Result expected;
    auto tick = [&]() {dut.clk=0;dut.eval();dut.clk=1;dut.eval();++cycles;};
    dut.rst_n=0; dut.in_valid=0; dut.out_ready=1;
    dut.a=0; dut.b=0; dut.c=0; dut.acc_mode=0; dut.acc_clr=0;
    dut.cfg_mode=1; dut.cfg_ops=0; dut.cfg_n=0;
    for (unsigned j=0;j<4;++j) tick();
    dut.rst_n=1;
    for (unsigned j=0;j<8;++j) tick();
    std::array<uint64_t,36> bins{};
    while (completed < goal) {
        if (!source && !pending) {
            const auto row=generate(rng,accepted,state);
            dut.a=row.a;dut.b=row.b;dut.c=row.c;
            dut.acc_mode=row.mode;dut.acc_clr=row.clear;
            dut.cfg_n=row.n;dut.cfg_ops=row.ops;dut.cfg_mode=1;
            source=true;
        }
        dut.in_valid=source;
        dut.clk=0;dut.eval();
        if (dut.valid&4) {
            check(pending,"unexpected fast output");
            check(dut.d_shared==expected.bits && dut.flags_shared==expected.flags,"fast oracle mismatch");
            check(cycles-start-1==expected_latency,"fast valid latency");
            if(pending_acc)state=expected.bits;
            ++completed;pending=false;
        }
        if(source && (dut.ready&4)) {
            check(!pending,"overlap fast input");
            const Input row{dut.a,dut.b,dut.c,unsigned(dut.cfg_n),unsigned(dut.cfg_ops),bool(dut.acc_mode),bool(dut.acc_clr)};
            auto mul=Mul::mul(row.a,row.b,config(row));
            const uint32_t ceff=row.mode?(row.clear?0:state):row.c;
            expected=Model::add(mul.prepack,ceff);
            auto oracle=Oracle::add(mul.prepack,ceff,incoming(mul.prepack));
            check(expected.bits==oracle.bits && expected.flags==oracle.flags,"fast independent oracle");
            if(accepted){check(cycles-previous_start==previous_latency+2,"fast II changed");++ii_checks;}
            expected_latency=std::max(1u,(expected.flags&16)?0u:mul.iterations)+9;
            start=cycles;previous_start=start;previous_latency=expected_latency;
            pending_acc=row.mode;
            if(row.mode&&row.clear)state=0;
            ++bins[row.n+9*row.ops+18*row.mode];
            ++accepted;pending=true;source=false;
        }
        tick();
        check(cycles<goal*100+1000,"fast watchdog");
    }
    std::ofstream out(argv[2]);
    out<<"{\"status\":\"PASS\",\"completed\":"<<completed<<",\"mismatches\":0,\"seed\":20261022,\"ii_checks\":"<<ii_checks
       <<",\"first_valid\":\"q+9\",\"handshake\":\"q+10\",\"ii\":\"q+11\",\"bins\":[";
    for(unsigned i=0;i<bins.size();++i)out<<(i?",":"")<<bins[i];
    out<<"]}\n";
    dut.final();std::cout<<"F_SHARED FAST PASS completed="<<completed<<" mismatches=0\n";
} catch(const std::exception& e) {std::cerr<<"FAST FAIL "<<e.what()<<'\n';return 1;}
