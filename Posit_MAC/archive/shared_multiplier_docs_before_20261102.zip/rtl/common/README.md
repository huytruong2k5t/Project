# Các helper common đang dùng — 02/11/2026

Thư mục đã giảm từ14 xuống10 file SV. Cả10 module còn lại đều reachable từ `posit_mac_nf`/`posit_mac_f` trong `../mac_active.f`; không còn file SV ngoài file list đang dùng. Tên `fixed2/3/...` phân biệt các cấu hình cố định, không biểu thị thứ tự phiên bản để tự động bỏ bản số nhỏ.

| File | Độ rộng | Nơi gọi trực tiếp |
| --- | ---: | --- |
| `dyn_left_shifter.sv` | 29 bit | Parser NF/F và decode tích NF |
| `dyn_left_shifter_fixed3.sv` | 26 bit | SAC đường exact hiện còn trong NF |
| `dyn_left_shifter_fixed5.sv` | 12 bit | SAC approximate NF/F |
| `dyn_left_shifter_fixed6.sv` | 30 bit | Normalize S5 của bộ cộng5 tầng |
| `dyn_right_shifter_fixed2.sv` | 59 bit, có fill | Prepare P1 của Packer |
| `dyn_right_shifter_fixed3.sv` | 16 bit, có fill | SBM shift của F |
| `dyn_right_shifter_fixed4.sv` | 31 bit, zero fill | Align S2 của bộ cộng5 tầng |
| `lod_lzd_core_fixed2.sv` | 31 bit | Parser NF, decode tích NF và LOD S4 bộ cộng |
| `lod_lzd_core_fixed3.sv` | 26 bit | SAC đường exact hiện còn trong NF |
| `lod_lzd_core_fixed4.sv` | 12 bit | SAC approximate NF/F |

NF vẫn có đường exact ở RTL hiện hành. Việc bỏ đường này thuộc thay đổi kiến trúc NF approximate-only và cần verification/synthesis riêng; không được xóa helper26 bit chỉ vì các test gần nhất chạy cfg_mode=1.

Các file đã đưa ra khỏi common:

- `dyn_left_shifter_fixed2.sv`, `dyn_right_shifter.sv`, `lod_lzd_core.sv`: chuyển nguyên byte sang `../../tb/reference/rtl/common/` vì reference bộ cộng còn cần.
- `dyn_left_shifter_fixed4.sv`: không nằm trong dependency MAC hiện tại, đã lưu tại `../../archive/cleanup_20261102/rtl_inactive.zip`.

[Bảng truy vết/hash từng module](../../archive/cleanup_20261102/common_usage_audit.json). Không sửa nội dung SV, không gộp các độ rộng khác nhau hoặc chạy synthesis trong lượt rà soát common.
