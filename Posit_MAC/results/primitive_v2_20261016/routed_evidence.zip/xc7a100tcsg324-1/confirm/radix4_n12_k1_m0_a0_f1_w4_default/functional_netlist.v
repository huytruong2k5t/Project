// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2026.1 (win64) Build 6511674 Tue Jun 16 11:02:23 MDT 2026
// Date        : Fri Oct 16 15:57:26 2026
// Host        : MSI running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim {C:/HCMUT/HK261/Do an
//               2/Posit_MAC/results/primitive_v2_20261016/xc7a100tcsg324-1/confirm/radix4_n12_k1_m0_a0_f1_w4_default/functional_netlist.v}
// Design      : primitive_v2_top
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a100tcsg324-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module primitive_v2_boundary
   (result,
    amount,
    clk_core,
    fill_val,
    data);
  output [11:0]result;
  input [3:0]amount;
  input clk_core;
  input fill_val;
  input [11:0]data;

  wire [3:0]amount;
  wire clk_core;
  wire [11:0]data;
  wire [11:0]data_q;
  wire fill_val;
  wire [11:0]\g_multi.g_stages[0].g_pair.selected ;
  wire [3:0]\g_shift.amount_q ;
  wire \g_shift.g_right.g_dynamic.fill_q ;
  wire [11:0]result;
  wire \result[10]_i_1_n_0 ;
  wire \result[11]_i_1_n_0 ;
  wire \result[11]_i_2_n_0 ;
  wire \result[4]_i_1_n_0 ;
  wire \result[5]_i_1_n_0 ;
  wire \result[6]_i_1_n_0 ;
  wire \result[7]_i_1_n_0 ;
  wire \result[8]_i_1_n_0 ;
  wire \result[9]_i_1_n_0 ;
  wire [3:0]result_d;

  FDRE \data_q_reg[0] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[0]),
        .Q(data_q[0]),
        .R(1'b0));
  FDRE \data_q_reg[10] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[10]),
        .Q(data_q[10]),
        .R(1'b0));
  FDRE \data_q_reg[11] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[11]),
        .Q(data_q[11]),
        .R(1'b0));
  FDRE \data_q_reg[1] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[1]),
        .Q(data_q[1]),
        .R(1'b0));
  FDRE \data_q_reg[2] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[2]),
        .Q(data_q[2]),
        .R(1'b0));
  FDRE \data_q_reg[3] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[3]),
        .Q(data_q[3]),
        .R(1'b0));
  FDRE \data_q_reg[4] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[4]),
        .Q(data_q[4]),
        .R(1'b0));
  FDRE \data_q_reg[5] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[5]),
        .Q(data_q[5]),
        .R(1'b0));
  FDRE \data_q_reg[6] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[6]),
        .Q(data_q[6]),
        .R(1'b0));
  FDRE \data_q_reg[7] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[7]),
        .Q(data_q[7]),
        .R(1'b0));
  FDRE \data_q_reg[8] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[8]),
        .Q(data_q[8]),
        .R(1'b0));
  FDRE \data_q_reg[9] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[9]),
        .Q(data_q[9]),
        .R(1'b0));
  FDRE \g_shift.amount_q_reg[0] 
       (.C(clk_core),
        .CE(1'b1),
        .D(amount[0]),
        .Q(\g_shift.amount_q [0]),
        .R(1'b0));
  FDRE \g_shift.amount_q_reg[1] 
       (.C(clk_core),
        .CE(1'b1),
        .D(amount[1]),
        .Q(\g_shift.amount_q [1]),
        .R(1'b0));
  FDRE \g_shift.amount_q_reg[2] 
       (.C(clk_core),
        .CE(1'b1),
        .D(amount[2]),
        .Q(\g_shift.amount_q [2]),
        .R(1'b0));
  FDRE \g_shift.amount_q_reg[3] 
       (.C(clk_core),
        .CE(1'b1),
        .D(amount[3]),
        .Q(\g_shift.amount_q [3]),
        .R(1'b0));
  FDRE \g_shift.g_right.g_dynamic.fill_q_reg 
       (.C(clk_core),
        .CE(1'b1),
        .D(fill_val),
        .Q(\g_shift.g_right.g_dynamic.fill_q ),
        .R(1'b0));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[0]_i_1 
       (.I0(\g_multi.g_stages[0].g_pair.selected [4]),
        .I1(\g_multi.g_stages[0].g_pair.selected [0]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [8]),
        .O(result_d[0]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[0]_i_2 
       (.I0(data_q[1]),
        .I1(data_q[0]),
        .I2(data_q[3]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[2]),
        .O(\g_multi.g_stages[0].g_pair.selected [0]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'h0E02)) 
    \result[10]_i_1 
       (.I0(\g_multi.g_stages[0].g_pair.selected [10]),
        .I1(\g_shift.amount_q [2]),
        .I2(\g_shift.amount_q [3]),
        .I3(\g_shift.g_right.g_dynamic.fill_q ),
        .O(\result[10]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hF0F0AACC)) 
    \result[10]_i_2 
       (.I0(data_q[11]),
        .I1(data_q[10]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .O(\g_multi.g_stages[0].g_pair.selected [10]));
  LUT2 #(
    .INIT(4'h8)) 
    \result[11]_i_1 
       (.I0(\g_shift.amount_q [3]),
        .I1(\g_shift.g_right.g_dynamic.fill_q ),
        .O(\result[11]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000FFFE00000002)) 
    \result[11]_i_2 
       (.I0(data_q[11]),
        .I1(\g_shift.amount_q [0]),
        .I2(\g_shift.amount_q [1]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_shift.g_right.g_dynamic.fill_q ),
        .O(\result[11]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[1]_i_1 
       (.I0(\g_multi.g_stages[0].g_pair.selected [5]),
        .I1(\g_multi.g_stages[0].g_pair.selected [1]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [9]),
        .O(result_d[1]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[1]_i_2 
       (.I0(data_q[2]),
        .I1(data_q[1]),
        .I2(data_q[4]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[3]),
        .O(\g_multi.g_stages[0].g_pair.selected [1]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[2]_i_1 
       (.I0(\g_multi.g_stages[0].g_pair.selected [6]),
        .I1(\g_multi.g_stages[0].g_pair.selected [2]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [10]),
        .O(result_d[2]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[2]_i_2 
       (.I0(data_q[3]),
        .I1(data_q[2]),
        .I2(data_q[5]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[4]),
        .O(\g_multi.g_stages[0].g_pair.selected [2]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[3]_i_1 
       (.I0(\g_multi.g_stages[0].g_pair.selected [7]),
        .I1(\g_multi.g_stages[0].g_pair.selected [3]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_shift.amount_q [3]),
        .I5(\g_multi.g_stages[0].g_pair.selected [11]),
        .O(result_d[3]));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[3]_i_2 
       (.I0(data_q[4]),
        .I1(data_q[3]),
        .I2(data_q[6]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[5]),
        .O(\g_multi.g_stages[0].g_pair.selected [3]));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'h0E02)) 
    \result[4]_i_1 
       (.I0(\g_multi.g_stages[0].g_pair.selected [4]),
        .I1(\g_shift.amount_q [2]),
        .I2(\g_shift.amount_q [3]),
        .I3(\g_multi.g_stages[0].g_pair.selected [8]),
        .O(\result[4]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[4]_i_2 
       (.I0(data_q[5]),
        .I1(data_q[4]),
        .I2(data_q[7]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[6]),
        .O(\g_multi.g_stages[0].g_pair.selected [4]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'h0E02)) 
    \result[5]_i_1 
       (.I0(\g_multi.g_stages[0].g_pair.selected [5]),
        .I1(\g_shift.amount_q [2]),
        .I2(\g_shift.amount_q [3]),
        .I3(\g_multi.g_stages[0].g_pair.selected [9]),
        .O(\result[5]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[5]_i_2 
       (.I0(data_q[6]),
        .I1(data_q[5]),
        .I2(data_q[8]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[7]),
        .O(\g_multi.g_stages[0].g_pair.selected [5]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'h0E02)) 
    \result[6]_i_1 
       (.I0(\g_multi.g_stages[0].g_pair.selected [6]),
        .I1(\g_shift.amount_q [2]),
        .I2(\g_shift.amount_q [3]),
        .I3(\g_multi.g_stages[0].g_pair.selected [10]),
        .O(\result[6]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[6]_i_2 
       (.I0(data_q[7]),
        .I1(data_q[6]),
        .I2(data_q[9]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[8]),
        .O(\g_multi.g_stages[0].g_pair.selected [6]));
  LUT4 #(
    .INIT(16'h0E02)) 
    \result[7]_i_1 
       (.I0(\g_multi.g_stages[0].g_pair.selected [7]),
        .I1(\g_shift.amount_q [2]),
        .I2(\g_shift.amount_q [3]),
        .I3(\g_multi.g_stages[0].g_pair.selected [11]),
        .O(\result[7]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[7]_i_2 
       (.I0(data_q[8]),
        .I1(data_q[7]),
        .I2(data_q[10]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[9]),
        .O(\g_multi.g_stages[0].g_pair.selected [7]));
  LUT4 #(
    .INIT(16'hCCCA)) 
    \result[7]_i_3 
       (.I0(data_q[11]),
        .I1(\g_shift.g_right.g_dynamic.fill_q ),
        .I2(\g_shift.amount_q [0]),
        .I3(\g_shift.amount_q [1]),
        .O(\g_multi.g_stages[0].g_pair.selected [11]));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'h0E02)) 
    \result[8]_i_1 
       (.I0(\g_multi.g_stages[0].g_pair.selected [8]),
        .I1(\g_shift.amount_q [2]),
        .I2(\g_shift.amount_q [3]),
        .I3(\g_shift.g_right.g_dynamic.fill_q ),
        .O(\result[8]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[8]_i_2 
       (.I0(data_q[9]),
        .I1(data_q[8]),
        .I2(data_q[11]),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[10]),
        .O(\g_multi.g_stages[0].g_pair.selected [8]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'h0E02)) 
    \result[9]_i_1 
       (.I0(\g_multi.g_stages[0].g_pair.selected [9]),
        .I1(\g_shift.amount_q [2]),
        .I2(\g_shift.amount_q [3]),
        .I3(\g_shift.g_right.g_dynamic.fill_q ),
        .O(\result[9]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0FFAACCF000AACC)) 
    \result[9]_i_2 
       (.I0(data_q[10]),
        .I1(data_q[9]),
        .I2(\g_shift.g_right.g_dynamic.fill_q ),
        .I3(\g_shift.amount_q [0]),
        .I4(\g_shift.amount_q [1]),
        .I5(data_q[11]),
        .O(\g_multi.g_stages[0].g_pair.selected [9]));
  FDRE \result_reg[0] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[0]),
        .Q(result[0]),
        .R(1'b0));
  FDSE \result_reg[10] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[10]_i_1_n_0 ),
        .Q(result[10]),
        .S(\result[11]_i_1_n_0 ));
  FDSE \result_reg[11] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[11]_i_2_n_0 ),
        .Q(result[11]),
        .S(\result[11]_i_1_n_0 ));
  FDRE \result_reg[1] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[1]),
        .Q(result[1]),
        .R(1'b0));
  FDRE \result_reg[2] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[2]),
        .Q(result[2]),
        .R(1'b0));
  FDRE \result_reg[3] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[3]),
        .Q(result[3]),
        .R(1'b0));
  FDSE \result_reg[4] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[4]_i_1_n_0 ),
        .Q(result[4]),
        .S(\result[11]_i_1_n_0 ));
  FDSE \result_reg[5] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[5]_i_1_n_0 ),
        .Q(result[5]),
        .S(\result[11]_i_1_n_0 ));
  FDSE \result_reg[6] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[6]_i_1_n_0 ),
        .Q(result[6]),
        .S(\result[11]_i_1_n_0 ));
  FDSE \result_reg[7] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[7]_i_1_n_0 ),
        .Q(result[7]),
        .S(\result[11]_i_1_n_0 ));
  FDSE \result_reg[8] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[8]_i_1_n_0 ),
        .Q(result[8]),
        .S(\result[11]_i_1_n_0 ));
  FDSE \result_reg[9] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[9]_i_1_n_0 ),
        .Q(result[9]),
        .S(\result[11]_i_1_n_0 ));
endmodule

(* ARITH = "0" *) (* ECO_CHECKSUM = "f7a3e9a1" *) (* FILL_KIND = "1" *) 
(* KIND = "1" *) (* MODE = "0" *) (* N = "12" *) 
(* RESULT_W = "12" *) (* SHIFT_W = "4" *) 
(* NotValidForBitStream *)
module primitive_v2_top
   (clk,
    data,
    amount,
    fill_val,
    result);
  input clk;
  input [11:0]data;
  input [3:0]amount;
  input fill_val;
  output [11:0]result;

  wire [3:0]amount;
  wire clk;
  wire clk_core;
  wire [11:0]data;
  wire fill_val;
  wire [11:0]result;

  primitive_v2_boundary u_boundary
       (.amount(amount),
        .clk_core(clk_core),
        .data(data),
        .fill_val(fill_val),
        .result(result));
  (* BOX_TYPE = "PRIMITIVE" *) 
  BUFG u_clock
       (.I(clk),
        .O(clk_core));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
