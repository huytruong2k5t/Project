// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2026.1 (win64) Build 6511674 Tue Jun 16 11:02:23 MDT 2026
// Date        : Fri Oct 16 17:12:48 2026
// Host        : MSI running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim {C:/HCMUT/HK261/Do an
//               2/Posit_MAC/results/primitive_v2_20261016/xc7a100tcsg324-1/confirm/combined_reverse_n26_k3_m0_a0_f0_w5_runtime/functional_netlist.v}
// Design      : primitive_v2_top
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a100tcsg324-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module primitive_v2_boundary
   (result,
    data,
    clk_core);
  output [31:0]result;
  input [25:0]data;
  input clk_core;

  wire clk_core;
  wire [25:0]data;
  wire [25:0]data_q;
  wire [3:0]\g_detector.count ;
  wire \g_detector.found ;
  wire [3:1]\g_detector.u_lod/g_levels[1].g_nodes[2].valid_child ;
  wire [3:1]\g_detector.u_lod/g_levels[1].g_nodes[3].valid_child ;
  wire [3:1]\g_detector.u_lod/g_levels[2].g_nodes[0].selected_pos__7 ;
  wire \g_detector.u_lod/p_41_in ;
  wire [17:16]\g_multi.stage[1] ;
  wire [15:8]\g_multi.stage[2] ;
  wire [23:4]\g_multi.stage[3] ;
  wire [5:2]\g_multi.stage[4] ;
  wire [31:0]result;
  wire \result[23]_i_3_n_0 ;
  wire \result[24]_i_3_n_0 ;
  wire \result[24]_i_4_n_0 ;
  wire \result[25]_i_10_n_0 ;
  wire \result[25]_i_11_n_0 ;
  wire \result[25]_i_12_n_0 ;
  wire \result[25]_i_13_n_0 ;
  wire \result[25]_i_14_n_0 ;
  wire \result[25]_i_15_n_0 ;
  wire \result[25]_i_16_n_0 ;
  wire \result[25]_i_17_n_0 ;
  wire \result[25]_i_18_n_0 ;
  wire \result[25]_i_19_n_0 ;
  wire \result[25]_i_20_n_0 ;
  wire \result[25]_i_2_n_0 ;
  wire \result[25]_i_4_n_0 ;
  wire \result[25]_i_7_n_0 ;
  wire \result[25]_i_8_n_0 ;
  wire \result[25]_i_9_n_0 ;
  wire \result[26]_i_2_n_0 ;
  wire \result[26]_i_3_n_0 ;
  wire \result[26]_i_4_n_0 ;
  wire \result[26]_i_5_n_0 ;
  wire \result[26]_i_6_n_0 ;
  wire \result[26]_i_7_n_0 ;
  wire \result[27]_i_3_n_0 ;
  wire \result[27]_i_4_n_0 ;
  wire \result[27]_i_5_n_0 ;
  wire \result[27]_i_6_n_0 ;
  wire \result[27]_i_8_n_0 ;
  wire \result[28]_i_2_n_0 ;
  wire \result[29]_i_2_n_0 ;
  wire \result[2]_i_3_n_0 ;
  wire \result[30]_i_1_n_0 ;
  wire \result[30]_i_2_n_0 ;
  wire \result[31]_i_5_n_0 ;
  wire [25:0]result_d;

  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[0] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[0]),
        .Q(data_q[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[10] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[10]),
        .Q(data_q[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[11] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[11]),
        .Q(data_q[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[12] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[12]),
        .Q(data_q[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[13] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[13]),
        .Q(data_q[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[14] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[14]),
        .Q(data_q[14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[15] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[15]),
        .Q(data_q[15]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[16] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[16]),
        .Q(data_q[16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[17] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[17]),
        .Q(data_q[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[18] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[18]),
        .Q(data_q[18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[19] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[19]),
        .Q(data_q[19]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[1] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[1]),
        .Q(data_q[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[20] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[20]),
        .Q(data_q[20]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[21] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[21]),
        .Q(data_q[21]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[22] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[22]),
        .Q(data_q[22]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[23] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[23]),
        .Q(data_q[23]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[24] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[24]),
        .Q(data_q[24]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[25] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[25]),
        .Q(data_q[25]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[2] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[2]),
        .Q(data_q[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[3] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[3]),
        .Q(data_q[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[4] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[4]),
        .Q(data_q[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[5] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[5]),
        .Q(data_q[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[6] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[6]),
        .Q(data_q[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[7] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[7]),
        .Q(data_q[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[8] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[8]),
        .Q(data_q[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[9] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[9]),
        .Q(data_q[9]),
        .R(1'b0));
  LUT5 #(
    .INIT(32'h00001000)) 
    \result[0]_i_1 
       (.I0(\g_detector.count [2]),
        .I1(\g_detector.count [1]),
        .I2(\result[2]_i_3_n_0 ),
        .I3(data_q[0]),
        .I4(\g_detector.count [0]),
        .O(result_d[0]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[10]_i_1 
       (.I0(\g_multi.stage[3] [7]),
        .I1(\g_multi.stage[3] [9]),
        .I2(\g_detector.count [0]),
        .I3(\g_multi.stage[3] [8]),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [10]),
        .O(result_d[10]));
  LUT4 #(
    .INIT(16'hB080)) 
    \result[10]_i_2 
       (.I0(data_q[3]),
        .I1(\g_detector.count [2]),
        .I2(\result[2]_i_3_n_0 ),
        .I3(data_q[7]),
        .O(\g_multi.stage[3] [7]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[11]_i_1 
       (.I0(\g_multi.stage[3] [8]),
        .I1(\g_multi.stage[3] [10]),
        .I2(\g_detector.count [0]),
        .I3(\g_multi.stage[3] [9]),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [11]),
        .O(result_d[11]));
  LUT6 #(
    .INIT(64'hBBBBB88830003000)) 
    \result[11]_i_2 
       (.I0(data_q[4]),
        .I1(\g_detector.count [2]),
        .I2(data_q[0]),
        .I3(\result[24]_i_3_n_0 ),
        .I4(data_q[8]),
        .I5(\result[2]_i_3_n_0 ),
        .O(\g_multi.stage[3] [8]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[12]_i_1 
       (.I0(\g_multi.stage[3] [9]),
        .I1(\g_multi.stage[3] [11]),
        .I2(\g_detector.count [0]),
        .I3(\g_multi.stage[3] [10]),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [12]),
        .O(result_d[12]));
  LUT6 #(
    .INIT(64'hBBBBB88830003000)) 
    \result[12]_i_2 
       (.I0(data_q[5]),
        .I1(\g_detector.count [2]),
        .I2(data_q[1]),
        .I3(\result[24]_i_3_n_0 ),
        .I4(data_q[9]),
        .I5(\result[2]_i_3_n_0 ),
        .O(\g_multi.stage[3] [9]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[13]_i_1 
       (.I0(\g_multi.stage[3] [10]),
        .I1(\g_multi.stage[3] [12]),
        .I2(\g_detector.count [0]),
        .I3(\g_multi.stage[3] [11]),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [13]),
        .O(result_d[13]));
  LUT6 #(
    .INIT(64'hBBBBB88830003000)) 
    \result[13]_i_2 
       (.I0(data_q[6]),
        .I1(\g_detector.count [2]),
        .I2(data_q[2]),
        .I3(\result[24]_i_3_n_0 ),
        .I4(data_q[10]),
        .I5(\result[2]_i_3_n_0 ),
        .O(\g_multi.stage[3] [10]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[14]_i_1 
       (.I0(\g_multi.stage[3] [11]),
        .I1(\g_multi.stage[3] [13]),
        .I2(\g_detector.count [0]),
        .I3(\g_multi.stage[3] [12]),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [14]),
        .O(result_d[14]));
  LUT6 #(
    .INIT(64'hBBBBB88830003000)) 
    \result[14]_i_2 
       (.I0(data_q[7]),
        .I1(\g_detector.count [2]),
        .I2(data_q[3]),
        .I3(\result[24]_i_3_n_0 ),
        .I4(data_q[11]),
        .I5(\result[2]_i_3_n_0 ),
        .O(\g_multi.stage[3] [11]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[15]_i_1 
       (.I0(\g_multi.stage[3] [12]),
        .I1(\g_multi.stage[3] [14]),
        .I2(\g_detector.count [0]),
        .I3(\g_multi.stage[3] [13]),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [15]),
        .O(result_d[15]));
  LUT6 #(
    .INIT(64'hBBBBB888B888B888)) 
    \result[15]_i_2 
       (.I0(\g_multi.stage[2] [8]),
        .I1(\g_detector.count [2]),
        .I2(data_q[4]),
        .I3(\result[24]_i_3_n_0 ),
        .I4(data_q[12]),
        .I5(\result[2]_i_3_n_0 ),
        .O(\g_multi.stage[3] [12]));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT6 #(
    .INIT(64'h00020002AAAACCCC)) 
    \result[15]_i_3 
       (.I0(data_q[8]),
        .I1(data_q[0]),
        .I2(data_q[1]),
        .I3(\result[25]_i_20_n_0 ),
        .I4(\result[29]_i_2_n_0 ),
        .I5(\result[30]_i_2_n_0 ),
        .O(\g_multi.stage[2] [8]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[16]_i_1 
       (.I0(\g_multi.stage[3] [13]),
        .I1(\g_multi.stage[3] [15]),
        .I2(\g_detector.count [0]),
        .I3(\g_multi.stage[3] [14]),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [16]),
        .O(result_d[16]));
  LUT6 #(
    .INIT(64'hBBBBB888B888B888)) 
    \result[16]_i_2 
       (.I0(\g_multi.stage[2] [9]),
        .I1(\g_detector.count [2]),
        .I2(data_q[5]),
        .I3(\result[24]_i_3_n_0 ),
        .I4(data_q[13]),
        .I5(\result[2]_i_3_n_0 ),
        .O(\g_multi.stage[3] [13]));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT6 #(
    .INIT(64'h00020002AAAAF0F0)) 
    \result[16]_i_3 
       (.I0(data_q[9]),
        .I1(data_q[0]),
        .I2(data_q[1]),
        .I3(\result[25]_i_20_n_0 ),
        .I4(\result[29]_i_2_n_0 ),
        .I5(\result[30]_i_2_n_0 ),
        .O(\g_multi.stage[2] [9]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[17]_i_1 
       (.I0(\g_multi.stage[3] [14]),
        .I1(\g_multi.stage[3] [16]),
        .I2(\g_detector.count [0]),
        .I3(\g_multi.stage[3] [15]),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [17]),
        .O(result_d[17]));
  LUT6 #(
    .INIT(64'hF888FFFFF8880000)) 
    \result[17]_i_2 
       (.I0(data_q[2]),
        .I1(\result[24]_i_3_n_0 ),
        .I2(data_q[10]),
        .I3(\result[2]_i_3_n_0 ),
        .I4(\g_detector.count [2]),
        .I5(\g_multi.stage[2] [14]),
        .O(\g_multi.stage[3] [14]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[18]_i_1 
       (.I0(\g_multi.stage[3] [15]),
        .I1(\g_multi.stage[3] [17]),
        .I2(\g_detector.count [0]),
        .I3(\g_multi.stage[3] [16]),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [18]),
        .O(result_d[18]));
  LUT6 #(
    .INIT(64'hF888FFFFF8880000)) 
    \result[18]_i_2 
       (.I0(data_q[3]),
        .I1(\result[24]_i_3_n_0 ),
        .I2(data_q[11]),
        .I3(\result[2]_i_3_n_0 ),
        .I4(\g_detector.count [2]),
        .I5(\g_multi.stage[2] [15]),
        .O(\g_multi.stage[3] [15]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[19]_i_1 
       (.I0(\g_multi.stage[3] [16]),
        .I1(\g_multi.stage[3] [18]),
        .I2(\g_detector.count [0]),
        .I3(\g_multi.stage[3] [17]),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [19]),
        .O(result_d[19]));
  LUT6 #(
    .INIT(64'hB888BBBBB888B888)) 
    \result[19]_i_2 
       (.I0(\g_multi.stage[2] [12]),
        .I1(\g_detector.count [2]),
        .I2(data_q[8]),
        .I3(\result[24]_i_3_n_0 ),
        .I4(\g_detector.count [3]),
        .I5(\g_multi.stage[1] [16]),
        .O(\g_multi.stage[3] [16]));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT5 #(
    .INIT(32'h0C0CCCAA)) 
    \result[19]_i_3 
       (.I0(data_q[4]),
        .I1(data_q[12]),
        .I2(\g_detector.u_lod/p_41_in ),
        .I3(\result[29]_i_2_n_0 ),
        .I4(\result[30]_i_2_n_0 ),
        .O(\g_multi.stage[2] [12]));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT6 #(
    .INIT(64'hFF01FFFFFF000000)) 
    \result[19]_i_4 
       (.I0(\g_detector.u_lod/g_levels[1].g_nodes[2].valid_child [3]),
        .I1(\g_detector.u_lod/g_levels[1].g_nodes[2].valid_child [2]),
        .I2(data_q[1]),
        .I3(data_q[0]),
        .I4(\result[30]_i_2_n_0 ),
        .I5(data_q[16]),
        .O(\g_multi.stage[1] [16]));
  LUT6 #(
    .INIT(64'h1011100000000000)) 
    \result[1]_i_1 
       (.I0(\g_detector.count [2]),
        .I1(\g_detector.count [1]),
        .I2(data_q[0]),
        .I3(\g_detector.count [0]),
        .I4(data_q[1]),
        .I5(\result[2]_i_3_n_0 ),
        .O(result_d[1]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[20]_i_1 
       (.I0(\g_multi.stage[3] [17]),
        .I1(\g_multi.stage[3] [19]),
        .I2(\g_detector.count [0]),
        .I3(\g_multi.stage[3] [18]),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [20]),
        .O(result_d[20]));
  LUT6 #(
    .INIT(64'hB888BBBBB888B888)) 
    \result[20]_i_2 
       (.I0(\g_multi.stage[2] [13]),
        .I1(\g_detector.count [2]),
        .I2(data_q[9]),
        .I3(\result[24]_i_3_n_0 ),
        .I4(\g_detector.count [3]),
        .I5(\g_multi.stage[1] [17]),
        .O(\g_multi.stage[3] [17]));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT5 #(
    .INIT(32'h0C0CCCAA)) 
    \result[20]_i_3 
       (.I0(data_q[5]),
        .I1(data_q[13]),
        .I2(\g_detector.u_lod/p_41_in ),
        .I3(\result[29]_i_2_n_0 ),
        .I4(\result[30]_i_2_n_0 ),
        .O(\g_multi.stage[2] [13]));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT6 #(
    .INIT(64'h111B111B111B1111)) 
    \result[20]_i_4 
       (.I0(\result[30]_i_2_n_0 ),
        .I1(\result[29]_i_2_n_0 ),
        .I2(\g_detector.u_lod/g_levels[1].g_nodes[2].valid_child [3]),
        .I3(\g_detector.u_lod/g_levels[1].g_nodes[2].valid_child [2]),
        .I4(data_q[1]),
        .I5(data_q[0]),
        .O(\g_detector.count [3]));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT6 #(
    .INIT(64'hF0F1FFFFF0F00000)) 
    \result[20]_i_5 
       (.I0(\g_detector.u_lod/g_levels[1].g_nodes[2].valid_child [3]),
        .I1(\g_detector.u_lod/g_levels[1].g_nodes[2].valid_child [2]),
        .I2(data_q[1]),
        .I3(data_q[0]),
        .I4(\result[30]_i_2_n_0 ),
        .I5(data_q[17]),
        .O(\g_multi.stage[1] [17]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[21]_i_1 
       (.I0(\g_multi.stage[3] [18]),
        .I1(\g_multi.stage[3] [20]),
        .I2(\g_detector.count [0]),
        .I3(\g_multi.stage[3] [19]),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [21]),
        .O(result_d[21]));
  LUT5 #(
    .INIT(32'hBBB8B8B8)) 
    \result[21]_i_2 
       (.I0(\g_multi.stage[2] [14]),
        .I1(\g_detector.count [2]),
        .I2(\result[25]_i_11_n_0 ),
        .I3(data_q[2]),
        .I4(\result[25]_i_13_n_0 ),
        .O(\g_multi.stage[3] [18]));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT5 #(
    .INIT(32'h0C0CCCAA)) 
    \result[21]_i_3 
       (.I0(data_q[6]),
        .I1(data_q[14]),
        .I2(\g_detector.u_lod/p_41_in ),
        .I3(\result[29]_i_2_n_0 ),
        .I4(\result[30]_i_2_n_0 ),
        .O(\g_multi.stage[2] [14]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[22]_i_1 
       (.I0(\g_multi.stage[3] [19]),
        .I1(\g_multi.stage[3] [21]),
        .I2(\g_detector.count [0]),
        .I3(\g_multi.stage[3] [20]),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [22]),
        .O(result_d[22]));
  LUT5 #(
    .INIT(32'hBBB8B8B8)) 
    \result[22]_i_2 
       (.I0(\g_multi.stage[2] [15]),
        .I1(\g_detector.count [2]),
        .I2(\result[25]_i_18_n_0 ),
        .I3(data_q[3]),
        .I4(\result[25]_i_13_n_0 ),
        .O(\g_multi.stage[3] [19]));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT5 #(
    .INIT(32'h0C0CCCAA)) 
    \result[22]_i_3 
       (.I0(data_q[7]),
        .I1(data_q[15]),
        .I2(\g_detector.u_lod/p_41_in ),
        .I3(\result[29]_i_2_n_0 ),
        .I4(\result[30]_i_2_n_0 ),
        .O(\g_multi.stage[2] [15]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[23]_i_1 
       (.I0(\g_multi.stage[3] [20]),
        .I1(\g_multi.stage[3] [22]),
        .I2(\g_detector.count [0]),
        .I3(\g_multi.stage[3] [21]),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [23]),
        .O(result_d[23]));
  LUT6 #(
    .INIT(64'hF8FFF8FFF8FFF800)) 
    \result[23]_i_2 
       (.I0(data_q[8]),
        .I1(\result[24]_i_3_n_0 ),
        .I2(\result[23]_i_3_n_0 ),
        .I3(\g_detector.count [2]),
        .I4(\result[25]_i_7_n_0 ),
        .I5(\result[25]_i_8_n_0 ),
        .O(\g_multi.stage[3] [20]));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT6 #(
    .INIT(64'hCC02CC02AAAA0000)) 
    \result[23]_i_3 
       (.I0(data_q[16]),
        .I1(data_q[0]),
        .I2(data_q[1]),
        .I3(\result[25]_i_20_n_0 ),
        .I4(\result[29]_i_2_n_0 ),
        .I5(\result[30]_i_2_n_0 ),
        .O(\result[23]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFAFCFC0AFA0CFC0)) 
    \result[24]_i_1 
       (.I0(\g_multi.stage[3] [21]),
        .I1(\g_multi.stage[3] [23]),
        .I2(\g_detector.count [0]),
        .I3(\result[25]_i_2_n_0 ),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [22]),
        .O(result_d[24]));
  LUT6 #(
    .INIT(64'hF8FFF8FFF8FFF800)) 
    \result[24]_i_2 
       (.I0(data_q[9]),
        .I1(\result[24]_i_3_n_0 ),
        .I2(\result[24]_i_4_n_0 ),
        .I3(\g_detector.count [2]),
        .I4(\result[25]_i_14_n_0 ),
        .I5(\result[25]_i_15_n_0 ),
        .O(\g_multi.stage[3] [21]));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \result[24]_i_3 
       (.I0(\result[29]_i_2_n_0 ),
        .I1(\result[30]_i_2_n_0 ),
        .O(\result[24]_i_3_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT6 #(
    .INIT(64'hF002F002AAAA0000)) 
    \result[24]_i_4 
       (.I0(data_q[17]),
        .I1(data_q[0]),
        .I2(data_q[1]),
        .I3(\result[25]_i_20_n_0 ),
        .I4(\result[29]_i_2_n_0 ),
        .I5(\result[30]_i_2_n_0 ),
        .O(\result[24]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hEFEFAFA0EFE0AFA0)) 
    \result[25]_i_1 
       (.I0(\result[25]_i_2_n_0 ),
        .I1(\g_multi.stage[3] [22]),
        .I2(\g_detector.count [0]),
        .I3(\result[25]_i_4_n_0 ),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [23]),
        .O(result_d[25]));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT5 #(
    .INIT(32'h0C0C00AA)) 
    \result[25]_i_10 
       (.I0(data_q[16]),
        .I1(data_q[0]),
        .I2(\result[25]_i_20_n_0 ),
        .I3(\result[29]_i_2_n_0 ),
        .I4(\result[30]_i_2_n_0 ),
        .O(\result[25]_i_10_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT5 #(
    .INIT(32'h0C0CCCAA)) 
    \result[25]_i_11 
       (.I0(data_q[10]),
        .I1(data_q[18]),
        .I2(\g_detector.u_lod/p_41_in ),
        .I3(\result[29]_i_2_n_0 ),
        .I4(\result[30]_i_2_n_0 ),
        .O(\result[25]_i_11_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT5 #(
    .INIT(32'h0C0CCCAA)) 
    \result[25]_i_12 
       (.I0(data_q[14]),
        .I1(data_q[22]),
        .I2(\g_detector.u_lod/p_41_in ),
        .I3(\result[29]_i_2_n_0 ),
        .I4(\result[30]_i_2_n_0 ),
        .O(\result[25]_i_12_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT3 #(
    .INIT(8'hE0)) 
    \result[25]_i_13 
       (.I0(\g_detector.u_lod/g_levels[1].g_nodes[2].valid_child [2]),
        .I1(\g_detector.u_lod/g_levels[1].g_nodes[2].valid_child [3]),
        .I2(\result[30]_i_2_n_0 ),
        .O(\result[25]_i_13_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT5 #(
    .INIT(32'h0C0CCCAA)) 
    \result[25]_i_14 
       (.I0(data_q[13]),
        .I1(data_q[21]),
        .I2(\g_detector.u_lod/p_41_in ),
        .I3(\result[29]_i_2_n_0 ),
        .I4(\result[30]_i_2_n_0 ),
        .O(\result[25]_i_14_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT3 #(
    .INIT(8'h80)) 
    \result[25]_i_15 
       (.I0(\result[30]_i_2_n_0 ),
        .I1(\result[25]_i_20_n_0 ),
        .I2(data_q[5]),
        .O(\result[25]_i_15_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT6 #(
    .INIT(64'hAC0CAC0CCCCC0000)) 
    \result[25]_i_16 
       (.I0(data_q[9]),
        .I1(data_q[25]),
        .I2(\g_detector.u_lod/p_41_in ),
        .I3(\result[25]_i_20_n_0 ),
        .I4(\result[29]_i_2_n_0 ),
        .I5(\result[30]_i_2_n_0 ),
        .O(\result[25]_i_16_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT5 #(
    .INIT(32'h0C0C00AA)) 
    \result[25]_i_17 
       (.I0(data_q[17]),
        .I1(data_q[1]),
        .I2(\result[25]_i_20_n_0 ),
        .I3(\result[29]_i_2_n_0 ),
        .I4(\result[30]_i_2_n_0 ),
        .O(\result[25]_i_17_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT5 #(
    .INIT(32'h0C0CCCAA)) 
    \result[25]_i_18 
       (.I0(data_q[11]),
        .I1(data_q[19]),
        .I2(\g_detector.u_lod/p_41_in ),
        .I3(\result[29]_i_2_n_0 ),
        .I4(\result[30]_i_2_n_0 ),
        .O(\result[25]_i_18_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT5 #(
    .INIT(32'h0C0CCCAA)) 
    \result[25]_i_19 
       (.I0(data_q[15]),
        .I1(data_q[23]),
        .I2(\g_detector.u_lod/p_41_in ),
        .I3(\result[29]_i_2_n_0 ),
        .I4(\result[30]_i_2_n_0 ),
        .O(\result[25]_i_19_n_0 ));
  LUT6 #(
    .INIT(64'h00000000EEEEFFF0)) 
    \result[25]_i_2 
       (.I0(\result[25]_i_7_n_0 ),
        .I1(\result[25]_i_8_n_0 ),
        .I2(\result[25]_i_9_n_0 ),
        .I3(\result[25]_i_10_n_0 ),
        .I4(\g_detector.count [2]),
        .I5(\g_detector.count [1]),
        .O(\result[25]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    \result[25]_i_20 
       (.I0(data_q[2]),
        .I1(data_q[3]),
        .I2(data_q[4]),
        .I3(data_q[5]),
        .I4(\g_detector.u_lod/g_levels[1].g_nodes[2].valid_child [3]),
        .O(\result[25]_i_20_n_0 ));
  LUT6 #(
    .INIT(64'hEFEFEFE0AFA0AFA0)) 
    \result[25]_i_3 
       (.I0(\result[25]_i_11_n_0 ),
        .I1(data_q[2]),
        .I2(\g_detector.count [2]),
        .I3(\result[25]_i_12_n_0 ),
        .I4(data_q[6]),
        .I5(\result[25]_i_13_n_0 ),
        .O(\g_multi.stage[3] [22]));
  LUT6 #(
    .INIT(64'h00000000EEEEFFF0)) 
    \result[25]_i_4 
       (.I0(\result[25]_i_14_n_0 ),
        .I1(\result[25]_i_15_n_0 ),
        .I2(\result[25]_i_16_n_0 ),
        .I3(\result[25]_i_17_n_0 ),
        .I4(\g_detector.count [2]),
        .I5(\g_detector.count [1]),
        .O(\result[25]_i_4_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT6 #(
    .INIT(64'hF7F4070407040704)) 
    \result[25]_i_5 
       (.I0(\result[27]_i_5_n_0 ),
        .I1(\g_detector.u_lod/g_levels[1].g_nodes[3].valid_child [3]),
        .I2(\result[30]_i_2_n_0 ),
        .I3(\result[27]_i_4_n_0 ),
        .I4(\result[27]_i_3_n_0 ),
        .I5(\g_detector.u_lod/p_41_in ),
        .O(\g_detector.count [1]));
  LUT6 #(
    .INIT(64'hEFEFEFE0AFA0AFA0)) 
    \result[25]_i_6 
       (.I0(\result[25]_i_18_n_0 ),
        .I1(data_q[3]),
        .I2(\g_detector.count [2]),
        .I3(\result[25]_i_19_n_0 ),
        .I4(data_q[7]),
        .I5(\result[25]_i_13_n_0 ),
        .O(\g_multi.stage[3] [23]));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT5 #(
    .INIT(32'h0C0CCCAA)) 
    \result[25]_i_7 
       (.I0(data_q[12]),
        .I1(data_q[20]),
        .I2(\g_detector.u_lod/p_41_in ),
        .I3(\result[29]_i_2_n_0 ),
        .I4(\result[30]_i_2_n_0 ),
        .O(\result[25]_i_7_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT3 #(
    .INIT(8'h80)) 
    \result[25]_i_8 
       (.I0(\result[30]_i_2_n_0 ),
        .I1(\result[25]_i_20_n_0 ),
        .I2(data_q[4]),
        .O(\result[25]_i_8_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT6 #(
    .INIT(64'hAC0CAC0CCCCC0000)) 
    \result[25]_i_9 
       (.I0(data_q[8]),
        .I1(data_q[24]),
        .I2(\g_detector.u_lod/p_41_in ),
        .I3(\result[25]_i_20_n_0 ),
        .I4(\result[29]_i_2_n_0 ),
        .I5(\result[30]_i_2_n_0 ),
        .O(\result[25]_i_9_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'hF000EE00)) 
    \result[26]_i_1 
       (.I0(\result[26]_i_2_n_0 ),
        .I1(\result[26]_i_3_n_0 ),
        .I2(\result[26]_i_4_n_0 ),
        .I3(\g_detector.found ),
        .I4(\result[30]_i_2_n_0 ),
        .O(\g_detector.count [0]));
  LUT4 #(
    .INIT(16'h00F2)) 
    \result[26]_i_2 
       (.I0(data_q[22]),
        .I1(data_q[23]),
        .I2(data_q[24]),
        .I3(data_q[25]),
        .O(\result[26]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h000000000000FF0E)) 
    \result[26]_i_3 
       (.I0(\result[26]_i_5_n_0 ),
        .I1(data_q[18]),
        .I2(data_q[19]),
        .I3(data_q[20]),
        .I4(data_q[21]),
        .I5(\g_detector.u_lod/g_levels[1].g_nodes[3].valid_child [3]),
        .O(\result[26]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h7577757775777575)) 
    \result[26]_i_4 
       (.I0(\g_detector.u_lod/p_41_in ),
        .I1(data_q[9]),
        .I2(data_q[8]),
        .I3(data_q[7]),
        .I4(data_q[6]),
        .I5(\result[26]_i_6_n_0 ),
        .O(\result[26]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'hFF51)) 
    \result[26]_i_5 
       (.I0(\result[31]_i_5_n_0 ),
        .I1(data_q[11]),
        .I2(data_q[12]),
        .I3(\result[26]_i_7_n_0 ),
        .O(\result[26]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'h30333031)) 
    \result[26]_i_6 
       (.I0(data_q[1]),
        .I1(data_q[5]),
        .I2(data_q[4]),
        .I3(data_q[3]),
        .I4(data_q[2]),
        .O(\result[26]_i_6_n_0 ));
  LUT4 #(
    .INIT(16'h00F2)) 
    \result[26]_i_7 
       (.I0(data_q[14]),
        .I1(data_q[15]),
        .I2(data_q[16]),
        .I3(data_q[17]),
        .O(\result[26]_i_7_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT6 #(
    .INIT(64'hDD00DDF0DDFFDDF0)) 
    \result[27]_i_1 
       (.I0(\g_detector.u_lod/p_41_in ),
        .I1(\result[27]_i_3_n_0 ),
        .I2(\result[27]_i_4_n_0 ),
        .I3(\result[30]_i_2_n_0 ),
        .I4(\g_detector.u_lod/g_levels[1].g_nodes[3].valid_child [3]),
        .I5(\result[27]_i_5_n_0 ),
        .O(\g_detector.u_lod/g_levels[2].g_nodes[0].selected_pos__7 [1]));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \result[27]_i_2 
       (.I0(\g_detector.u_lod/g_levels[1].g_nodes[2].valid_child [3]),
        .I1(\g_detector.u_lod/g_levels[1].g_nodes[2].valid_child [2]),
        .I2(data_q[1]),
        .I3(data_q[0]),
        .O(\g_detector.u_lod/p_41_in ));
  LUT6 #(
    .INIT(64'h1010101010101F10)) 
    \result[27]_i_3 
       (.I0(data_q[8]),
        .I1(data_q[9]),
        .I2(\g_detector.u_lod/g_levels[1].g_nodes[2].valid_child [3]),
        .I3(\g_detector.u_lod/g_levels[1].g_nodes[2].valid_child [2]),
        .I4(data_q[5]),
        .I5(data_q[4]),
        .O(\result[27]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0000FFFF57555755)) 
    \result[27]_i_4 
       (.I0(\result[27]_i_6_n_0 ),
        .I1(data_q[17]),
        .I2(data_q[16]),
        .I3(\g_detector.u_lod/g_levels[1].g_nodes[3].valid_child [1]),
        .I4(\result[27]_i_8_n_0 ),
        .I5(\g_detector.u_lod/g_levels[1].g_nodes[3].valid_child [2]),
        .O(\result[27]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \result[27]_i_5 
       (.I0(data_q[24]),
        .I1(data_q[25]),
        .O(\result[27]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \result[27]_i_6 
       (.I0(data_q[12]),
        .I1(data_q[13]),
        .I2(data_q[17]),
        .I3(data_q[16]),
        .I4(data_q[15]),
        .I5(data_q[14]),
        .O(\result[27]_i_6_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \result[27]_i_7 
       (.I0(data_q[17]),
        .I1(data_q[16]),
        .I2(data_q[15]),
        .I3(data_q[14]),
        .O(\g_detector.u_lod/g_levels[1].g_nodes[3].valid_child [1]));
  LUT2 #(
    .INIT(4'hE)) 
    \result[27]_i_8 
       (.I0(data_q[20]),
        .I1(data_q[21]),
        .O(\result[27]_i_8_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT6 #(
    .INIT(64'h0202F2F2020202F2)) 
    \result[28]_i_1 
       (.I0(\result[28]_i_2_n_0 ),
        .I1(\g_detector.u_lod/g_levels[1].g_nodes[3].valid_child [3]),
        .I2(\result[30]_i_2_n_0 ),
        .I3(\g_detector.u_lod/g_levels[1].g_nodes[2].valid_child [1]),
        .I4(\g_detector.u_lod/g_levels[1].g_nodes[2].valid_child [3]),
        .I5(\g_detector.u_lod/g_levels[1].g_nodes[2].valid_child [2]),
        .O(\g_detector.u_lod/g_levels[2].g_nodes[0].selected_pos__7 [2]));
  LUT5 #(
    .INIT(32'hAAAAAAAB)) 
    \result[28]_i_2 
       (.I0(\g_detector.u_lod/g_levels[1].g_nodes[3].valid_child [2]),
        .I1(data_q[14]),
        .I2(data_q[15]),
        .I3(data_q[16]),
        .I4(data_q[17]),
        .O(\result[28]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \result[28]_i_3 
       (.I0(data_q[25]),
        .I1(data_q[24]),
        .I2(data_q[23]),
        .I3(data_q[22]),
        .O(\g_detector.u_lod/g_levels[1].g_nodes[3].valid_child [3]));
  LUT2 #(
    .INIT(4'hE)) 
    \result[28]_i_4 
       (.I0(data_q[0]),
        .I1(data_q[1]),
        .O(\g_detector.u_lod/g_levels[1].g_nodes[2].valid_child [1]));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT4 #(
    .INIT(16'h110F)) 
    \result[29]_i_1 
       (.I0(\g_detector.u_lod/g_levels[1].g_nodes[2].valid_child [2]),
        .I1(\g_detector.u_lod/g_levels[1].g_nodes[2].valid_child [3]),
        .I2(\result[29]_i_2_n_0 ),
        .I3(\result[30]_i_2_n_0 ),
        .O(\g_detector.u_lod/g_levels[2].g_nodes[0].selected_pos__7 [3]));
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    \result[29]_i_2 
       (.I0(data_q[18]),
        .I1(data_q[19]),
        .I2(data_q[20]),
        .I3(data_q[21]),
        .I4(\g_detector.u_lod/g_levels[1].g_nodes[3].valid_child [3]),
        .O(\result[29]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h1000FFFF10000000)) 
    \result[2]_i_1 
       (.I0(\g_detector.count [2]),
        .I1(\g_detector.count [1]),
        .I2(data_q[1]),
        .I3(\result[2]_i_3_n_0 ),
        .I4(\g_detector.count [0]),
        .I5(\g_multi.stage[4] [2]),
        .O(result_d[2]));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT5 #(
    .INIT(32'h202F2020)) 
    \result[2]_i_2 
       (.I0(\g_detector.u_lod/g_levels[1].g_nodes[2].valid_child [2]),
        .I1(\g_detector.u_lod/g_levels[1].g_nodes[2].valid_child [3]),
        .I2(\result[30]_i_2_n_0 ),
        .I3(\g_detector.u_lod/g_levels[1].g_nodes[3].valid_child [3]),
        .I4(\result[28]_i_2_n_0 ),
        .O(\g_detector.count [2]));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT6 #(
    .INIT(64'h00010001FFFF0000)) 
    \result[2]_i_3 
       (.I0(data_q[0]),
        .I1(data_q[1]),
        .I2(\g_detector.u_lod/g_levels[1].g_nodes[2].valid_child [2]),
        .I3(\g_detector.u_lod/g_levels[1].g_nodes[2].valid_child [3]),
        .I4(\result[29]_i_2_n_0 ),
        .I5(\result[30]_i_2_n_0 ),
        .O(\result[2]_i_3_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \result[30]_i_1 
       (.I0(\g_detector.found ),
        .O(\result[30]_i_1_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT5 #(
    .INIT(32'hFFFEFFFF)) 
    \result[31]_i_1 
       (.I0(data_q[0]),
        .I1(data_q[1]),
        .I2(\g_detector.u_lod/g_levels[1].g_nodes[2].valid_child [2]),
        .I3(\g_detector.u_lod/g_levels[1].g_nodes[2].valid_child [3]),
        .I4(\result[30]_i_2_n_0 ),
        .O(\g_detector.found ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \result[31]_i_2 
       (.I0(data_q[5]),
        .I1(data_q[4]),
        .I2(data_q[3]),
        .I3(data_q[2]),
        .O(\g_detector.u_lod/g_levels[1].g_nodes[2].valid_child [2]));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \result[31]_i_3 
       (.I0(data_q[9]),
        .I1(data_q[8]),
        .I2(data_q[7]),
        .I3(data_q[6]),
        .O(\g_detector.u_lod/g_levels[1].g_nodes[2].valid_child [3]));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    \result[31]_i_4 
       (.I0(data_q[10]),
        .I1(data_q[11]),
        .I2(data_q[12]),
        .I3(\result[31]_i_5_n_0 ),
        .I4(\g_detector.u_lod/g_levels[1].g_nodes[3].valid_child [3]),
        .I5(\g_detector.u_lod/g_levels[1].g_nodes[3].valid_child [2]),
        .O(\result[30]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    \result[31]_i_5 
       (.I0(data_q[14]),
        .I1(data_q[15]),
        .I2(data_q[16]),
        .I3(data_q[17]),
        .I4(data_q[13]),
        .O(\result[31]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \result[31]_i_6 
       (.I0(data_q[21]),
        .I1(data_q[20]),
        .I2(data_q[19]),
        .I3(data_q[18]),
        .O(\g_detector.u_lod/g_levels[1].g_nodes[3].valid_child [2]));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \result[3]_i_1 
       (.I0(\g_multi.stage[4] [2]),
        .I1(\g_detector.count [0]),
        .I2(\g_multi.stage[4] [3]),
        .O(result_d[3]));
  LUT5 #(
    .INIT(32'h008800C0)) 
    \result[3]_i_2 
       (.I0(data_q[0]),
        .I1(\result[2]_i_3_n_0 ),
        .I2(data_q[2]),
        .I3(\g_detector.count [2]),
        .I4(\g_detector.count [1]),
        .O(\g_multi.stage[4] [2]));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \result[4]_i_1 
       (.I0(\g_multi.stage[4] [3]),
        .I1(\g_detector.count [0]),
        .I2(\g_multi.stage[4] [4]),
        .O(result_d[4]));
  LUT5 #(
    .INIT(32'h008800C0)) 
    \result[4]_i_2 
       (.I0(data_q[1]),
        .I1(\result[2]_i_3_n_0 ),
        .I2(data_q[3]),
        .I3(\g_detector.count [2]),
        .I4(\g_detector.count [1]),
        .O(\g_multi.stage[4] [3]));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[5]_i_1 
       (.I0(\g_multi.stage[4] [4]),
        .I1(\g_detector.count [0]),
        .I2(\g_multi.stage[4] [5]),
        .O(result_d[5]));
  LUT6 #(
    .INIT(64'h30BB000030880000)) 
    \result[5]_i_2 
       (.I0(data_q[2]),
        .I1(\g_detector.count [1]),
        .I2(data_q[0]),
        .I3(\g_detector.count [2]),
        .I4(\result[2]_i_3_n_0 ),
        .I5(data_q[4]),
        .O(\g_multi.stage[4] [4]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[6]_i_1 
       (.I0(\g_multi.stage[4] [5]),
        .I1(\g_detector.count [0]),
        .I2(\g_multi.stage[3] [4]),
        .I3(\g_detector.count [1]),
        .I4(\g_multi.stage[3] [6]),
        .O(result_d[6]));
  LUT6 #(
    .INIT(64'h30BB000030880000)) 
    \result[6]_i_2 
       (.I0(data_q[3]),
        .I1(\g_detector.count [1]),
        .I2(data_q[1]),
        .I3(\g_detector.count [2]),
        .I4(\result[2]_i_3_n_0 ),
        .I5(data_q[5]),
        .O(\g_multi.stage[4] [5]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[7]_i_1 
       (.I0(\g_multi.stage[3] [4]),
        .I1(\g_multi.stage[3] [6]),
        .I2(\g_detector.count [0]),
        .I3(\g_multi.stage[3] [5]),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [7]),
        .O(result_d[7]));
  LUT4 #(
    .INIT(16'hB080)) 
    \result[7]_i_2 
       (.I0(data_q[0]),
        .I1(\g_detector.count [2]),
        .I2(\result[2]_i_3_n_0 ),
        .I3(data_q[4]),
        .O(\g_multi.stage[3] [4]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[8]_i_1 
       (.I0(\g_multi.stage[3] [5]),
        .I1(\g_multi.stage[3] [7]),
        .I2(\g_detector.count [0]),
        .I3(\g_multi.stage[3] [6]),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [8]),
        .O(result_d[8]));
  LUT4 #(
    .INIT(16'hB080)) 
    \result[8]_i_2 
       (.I0(data_q[1]),
        .I1(\g_detector.count [2]),
        .I2(\result[2]_i_3_n_0 ),
        .I3(data_q[5]),
        .O(\g_multi.stage[3] [5]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[9]_i_1 
       (.I0(\g_multi.stage[3] [6]),
        .I1(\g_multi.stage[3] [8]),
        .I2(\g_detector.count [0]),
        .I3(\g_multi.stage[3] [7]),
        .I4(\g_detector.count [1]),
        .I5(\g_multi.stage[3] [9]),
        .O(result_d[9]));
  LUT4 #(
    .INIT(16'hB080)) 
    \result[9]_i_2 
       (.I0(data_q[2]),
        .I1(\g_detector.count [2]),
        .I2(\result[2]_i_3_n_0 ),
        .I3(data_q[6]),
        .O(\g_multi.stage[3] [6]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[0] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[0]),
        .Q(result[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[10] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[10]),
        .Q(result[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[11] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[11]),
        .Q(result[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[12] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[12]),
        .Q(result[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[13] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[13]),
        .Q(result[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[14] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[14]),
        .Q(result[14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[15] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[15]),
        .Q(result[15]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[16] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[16]),
        .Q(result[16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[17] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[17]),
        .Q(result[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[18] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[18]),
        .Q(result[18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[19] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[19]),
        .Q(result[19]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[1] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[1]),
        .Q(result[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[20] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[20]),
        .Q(result[20]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[21] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[21]),
        .Q(result[21]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[22] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[22]),
        .Q(result[22]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[23] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[23]),
        .Q(result[23]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[24] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[24]),
        .Q(result[24]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[25] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[25]),
        .Q(result[25]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[26] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\g_detector.count [0]),
        .Q(result[26]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[27] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\g_detector.u_lod/g_levels[2].g_nodes[0].selected_pos__7 [1]),
        .Q(result[27]),
        .R(\result[30]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[28] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\g_detector.u_lod/g_levels[2].g_nodes[0].selected_pos__7 [2]),
        .Q(result[28]),
        .R(\result[30]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[29] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\g_detector.u_lod/g_levels[2].g_nodes[0].selected_pos__7 [3]),
        .Q(result[29]),
        .R(\result[30]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[2] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[2]),
        .Q(result[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[30] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[30]_i_2_n_0 ),
        .Q(result[30]),
        .R(\result[30]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[31] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\g_detector.found ),
        .Q(result[31]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[3] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[3]),
        .Q(result[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[4] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[4]),
        .Q(result[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[5] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[5]),
        .Q(result[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[6] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[6]),
        .Q(result[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[7] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[7]),
        .Q(result[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[8] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[8]),
        .Q(result[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[9] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[9]),
        .Q(result[9]),
        .R(1'b0));
endmodule

(* ARITH = "0" *) (* ECO_CHECKSUM = "1d9cd366" *) (* FILL_KIND = "0" *) 
(* KIND = "3" *) (* MODE = "0" *) (* N = "26" *) 
(* RESULT_W = "32" *) (* SHIFT_W = "5" *) 
(* NotValidForBitStream *)
(* \DesignAttr:ENABLE_NOC_NETLIST_VIEW  *) 
(* \DesignAttr:ENABLE_AIE_NETLIST_VIEW  *) 
module primitive_v2_top
   (clk,
    data,
    amount,
    fill_val,
    result);
  input clk;
  input [25:0]data;
  input [4:0]amount;
  input fill_val;
  output [31:0]result;

  wire clk;
  wire clk_core;
  wire [25:0]data;
  wire [31:0]result;

  primitive_v2_boundary u_boundary
       (.clk_core(clk_core),
        .data(data),
        .result(result));
  (* BOX_TYPE = "PRIMITIVE" *) 
  BUFG u_clock
       (.I(clk),
        .O(clk_core));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
