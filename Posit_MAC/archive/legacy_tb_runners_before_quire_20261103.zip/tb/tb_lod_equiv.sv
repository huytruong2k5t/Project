module tb_lod_equiv;
    logic [30:0] in;
    logic [4:0]  k_ref, k_dut1, k_dut2, k_dut3;
    logic        vld_ref, vld_dut1, vld_dut2, vld_dut3;
    int errors;

    lod_lzd_core_fixed2 u_ref (
        .in  (in),
        .K   (k_ref),
        .vld (vld_ref)
    );

    lod_lzd_core_candidate u_dut1 (
        .in  (in),
        .K   (k_dut1),
        .vld (vld_dut1)
    );

    lod_lzd_core_candidate2 u_dut2 (
        .in  (in),
        .K   (k_dut2),
        .vld (vld_dut2)
    );

    lod_lzd_core_casez u_dut3 (
        .in  (in),
        .K   (k_dut3),
        .vld (vld_dut3)
    );

    task automatic check_eq(input string label, input int iter);
        if (k_ref !== k_dut1 || vld_ref !== vld_dut1 ||
            k_ref !== k_dut2 || vld_ref !== vld_dut2 ||
            k_ref !== k_dut3 || vld_ref !== vld_dut3) begin
            $display("ERROR [%s iter %0d]: ref=(%0d,%b), dut1=(%0d,%b), dut2=(%0d,%b), dut3=(%0d,%b)",
                     label, iter, k_ref, vld_ref, k_dut1, vld_dut1, k_dut2, vld_dut2, k_dut3, vld_dut3);
            errors++;
        end
    endtask

    initial begin
        errors = 0;

        // 1. Zero check
        in = 31'd0;
        #1;
        check_eq("ZERO", 0);

        // 2. Walking 1s (single bit set across all 31 positions)
        for (int i = 0; i < 31; i++) begin
            in = (31'd1 << i);
            #1;
            check_eq("WALK1", i);
        end

        // 3. Walking 0s (single bit cleared)
        for (int i = 0; i < 31; i++) begin
            in = ~(31'd1 << i);
            #1;
            check_eq("WALK0", i);
        end

        // 4. Random patterns (500,000 vectors)
        for (int n = 0; n < 500000; n++) begin
            in = $urandom & 31'h7FFFFFFF;
            #1;
            check_eq("RANDOM", n);
            if (errors > 10) break;
        end

        if (errors == 0) begin
            $display("TB_LOD_EQUIV: 100%% PASS! 500,000+ vectors, 0 errors for BOTH candidates.");
        end else begin
            $display("TB_LOD_EQUIV: FAIL with %0d errors!", errors);
        end
        $finish;
    end
endmodule
