"""Publish explicit candidate filelists without changing production.f."""
from pathlib import Path
import copy
import hashlib
import json

root = Path(__file__).resolve().parents[1]
study = root / 'results/f_shared_add_20261020'
summary = json.loads((study / 'summary.json').read_text())
assert summary['status'] == 'TRIAL_COMPLETE_NO_PROMOTION'
path = root / 'rtl/candidates/opt15_sources.json'
data = json.loads(path.read_text())
reference = data['f_reference']
for key, variant, rel in (
    ('f_opt15', 'parser2', 'rtl/candidates/mac_f/opt15/parser2/mac_f_wrapper.sv'),
    ('f_opt16_shared_add', 'shared_add', 'rtl/candidates/mac_f/opt16/shared_nf_add/mac_f_wrapper.sv'),
):
    entry = copy.deepcopy(reference)
    entry.update(status='VERIFIED_CANDIDATE_NOT_PROMOTED', build_ready=True, variant=variant,
                 wrapper=str(root / rel).replace('\\', '/'), input_parsers=2, packer_instances=1,
                 adder_stages=3 if variant == 'shared_add' else 5,
                 verification_and_sta_report=str(study / 'summary.json').replace('\\', '/'),
                 tested_snapshot_root=str(study / 'source' / variant).replace('\\', '/'),
                 candidate_file_sha256={rel: hashlib.sha256((root / rel).read_bytes()).hexdigest()})
    entry['active_module_paths']['mac_f_wrapper'] = entry['wrapper']
    entry['compile_files'] = [entry['wrapper'] if p == reference['wrapper'] else p for p in reference['compile_files']]
    if variant == 'shared_add':
        for name in tuple(entry['active_module_paths']):
            if name.startswith('fused_'):
                del entry['active_module_paths'][name]
        for name in ('posit_add', 'posit_add_align', 'posit_add_arith', 'posit_add_normalize'):
            entry['active_module_paths'][name] = data['nf_opt15']['active_module_paths'][name]
        entry['parent_candidate'] = 'f_opt15'
        entry['numeric_contract'] = 'RNE(P_hat+C_eff); lossless product adapter, no intermediate product rounding'
        entry['latency'] = {'L_valid': 'q+9', 'L_handshake': 'q+10', 'II_min': 'q+11', 'q': 'max(1,actual_iterations)'}
    else:
        entry['latency'] = {'L_valid': 'q+11', 'L_handshake': 'q+12', 'II_min': 'q+13', 'q': 'max(1,actual_iterations)'}
    filelist = (root / rel).parent / 'production.f'
    relative = [str(Path(p).relative_to(root)).replace('\\', '/') for p in entry['compile_files']]
    filelist.write_text('\n'.join(relative) + '\n', newline='\n')
    entry['candidate_filelist'] = str(filelist).replace('\\', '/')
    for name in ('wrapper', 'candidate_filelist'):
        assert Path(entry[name]).is_file()
    for filename in entry['compile_files']:
        assert Path(filename).is_file(), filename
    data[key] = entry
data['date'] = '2026-10-20'
data['notes'] = [line for line in data['notes'] if not line.startswith('F OPT-15')]
note = 'F OPT-15 parser2 và OPT-16 shared_add đã kiểm/đo riêng; đều chưa promote hoặc thay release OPT12_120.'
if note not in data['notes']:
    data['notes'].append(note)
path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(path)
