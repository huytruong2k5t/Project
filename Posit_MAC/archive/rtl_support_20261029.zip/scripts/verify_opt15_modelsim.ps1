param(
    [ValidateSet('parser2','combined')][string]$Variant='combined'
)
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
$study=Join-Path $root 'results/opt15_share_20261019'
$run=Join-Path $study "event/$Variant"
if(Test-Path -LiteralPath $run) {throw 'Preserve existing event evidence'}
foreach($folder in @('source/rtl','source/tb','compat','tmp')) {
    New-Item -ItemType Directory -Force "$run/$folder" | Out-Null
}
$env:TEMP="$run/tmp"
$env:TMP=$env:TEMP
$bin='C:/altera/13.0sp1/modelsim_ase/win32aloem'
$sources=@()
$hashes=@{}
foreach($path in (Get-Content "$study/source/$Variant/rtl/production.f")) {
    $dst=Join-Path "$run/source" $path
    New-Item -ItemType Directory -Force (Split-Path $dst -Parent) | Out-Null
    Copy-Item -LiteralPath "$study/source/$Variant/$path" -Destination $dst
    $hashes[$path]=(Get-FileHash -LiteralPath $dst).Hash.ToLowerInvariant()
    if((Split-Path $path -Leaf) -eq 'lod_lzd_core.sv') {
        $text=Get-Content -LiteralPath $dst -Raw
        $text=$text.Replace("POS_W'(group_index)","pos_cast_t'(group_index)")
        $text=$text.Replace("S'(pos_tree[LEVELS][0])","count_cast_t'(pos_tree[LEVELS][0])")
        $text=$text.Replace('            assign match_bits',"            typedef logic [POS_W-1:0] pos_cast_t;`n            typedef logic [S-1:0] count_cast_t;`n            assign match_bits")
        $dst="$run/compat/lod_lzd_core.sv"
        [IO.File]::WriteAllText($dst,$text)
    } elseif((Split-Path $path -Leaf) -eq 'mac_f_wrapper.sv') {
        $text=Get-Content -LiteralPath $dst -Raw
        $text=$text.Replace('    localparam int I_W = $clog2(FRAC_W+1);','    localparam int I_W = $clog2(FRAC_W+1); typedef logic [I_W-1:0] iteration_cast_t;')
        $text=$text.Replace("I_W'(N_MAX)","iteration_cast_t'(N_MAX)")
        $dst="$run/compat/mac_f_wrapper.sv"
        [IO.File]::WriteAllText($dst,$text)
    }
    $sources+=$dst
}
Copy-Item "$study/source/$Variant/rtl/posit_mac.vh" "$run/source/rtl"
$hashes['rtl/posit_mac.vh']=(Get-FileHash "$run/source/rtl/posit_mac.vh").Hash.ToLowerInvariant()
$hashes | ConvertTo-Json | Set-Content -Encoding utf8 "$run/source_sha256.json"
Copy-Item "$root/tb/tb_week11_mac.sv" "$run/source/tb"
$test=Get-Content "$run/source/tb/tb_week11_mac.sv" -Raw
$test=$test.Replace('always #5 clk = ~clk;','always #4.15 clk = ~clk;')
[IO.File]::WriteAllText("$run/source/tb/tb_week11_mac.sv",$test)
$sources+="$run/source/tb/tb_week11_mac.sv"
$fixtures="$root/results/opt02b_20261017/fixtures"
$protocol="$root/results/opt02b_20261017/protocol_fixtures"
$fixtureHashes=@{}
foreach($format in @(@(8,0),@(16,1),@(32,2),@(32,3))) {
    foreach($dir in @($fixtures,$protocol)) {
        $p="$dir/mac_$($format[0])_$($format[1]).txt"
        $fixtureHashes[$p.Substring($root.Length+1)]=(Get-FileHash $p).Hash.ToLowerInvariant()
    }
}
$fixtureHashes | ConvertTo-Json | Set-Content -Encoding utf8 "$run/fixture_sha256.json"
'clock=8.300ns CK2Q=1.000ns; four-state RTL replay, not SDF/physical timing' | Set-Content "$run/scope.txt"
Push-Location $run
try {
    & "$bin/vsim.exe" -version > version.log
    & "$bin/vlib.exe" work > library.log
    if($LASTEXITCODE) {throw 'vlib failed'}
    & "$bin/vlog.exe" -sv -timescale 1ns/1ps "+incdir+$run/source/rtl" -work work @sources -l compile.log > compile_console.log
    if($LASTEXITCODE) {throw 'vlog failed'}
    @('onerror {quit -code 1}','onbreak {quit -code 1}','run -all','quit -code 0') | Set-Content -Encoding ascii run.do
    foreach($format in @(@(8,0),@(16,1),@(32,2),@(32,3))) {
        $nb=$format[0]
        $es=$format[1]
        foreach($kind in @('corner','protocol')) {
            $fixtureDir=if($kind -eq 'corner') {$fixtures} else {$protocol}
            $log="${kind}_${nb}_${es}.log"
            & "$bin/vsim.exe" -c work.tb_week11_mac "-gNB=$nb" "-gES=$es" "+VECTOR_DIR=$fixtureDir" -do run.do -l $log -wlf "${kind}_${nb}_${es}.wlf" > "${kind}_${nb}_${es}_console.log"
            if($LASTEXITCODE) {throw "NF event failed $Variant $nb $es $kind"}
            $content=Get-Content $log -Raw
            if($content -notmatch 'W11 MODELSIM PASS' -or $content -match '\*\*\s+(Error|Fatal):') {
                throw 'NF event acceptance missing'
            }
            Write-Output ($content -split "`n" | Where-Object {$_ -match 'W11 MODELSIM PASS'})
        }
    }
    'COMPLETE' | Set-Content status.txt
} finally {Pop-Location}
