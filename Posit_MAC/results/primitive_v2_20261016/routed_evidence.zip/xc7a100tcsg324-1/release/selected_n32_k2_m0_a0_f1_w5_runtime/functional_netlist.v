// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2026.1 (win64) Build 6511674 Tue Jun 16 11:02:23 MDT 2026
// Date        : Fri Oct 16 16:21:41 2026
// Host        : MSI running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim {C:/HCMUT/HK261/Do an
//               2/Posit_MAC/results/primitive_v2_20261016/xc7a100tcsg324-1/release/selected_n32_k2_m0_a0_f1_w5_runtime/functional_netlist.v}
// Design      : primitive_v2_top
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a100tcsg324-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module primitive_v2_boundary
   (result,
    data,
    CLK);
  output [5:0]result;
  input [31:0]data;
  input CLK;

  wire CLK;
  wire [31:0]data;
  wire [31:0]data_q;
  wire [5:0]result;
  wire \result[0]_i_10_n_0 ;
  wire \result[0]_i_11_n_0 ;
  wire \result[0]_i_2_n_0 ;
  wire \result[0]_i_3_n_0 ;
  wire \result[0]_i_4_n_0 ;
  wire \result[0]_i_5_n_0 ;
  wire \result[0]_i_6_n_0 ;
  wire \result[0]_i_7_n_0 ;
  wire \result[0]_i_8_n_0 ;
  wire \result[0]_i_9_n_0 ;
  wire \result[1]_i_2_n_0 ;
  wire \result[1]_i_3_n_0 ;
  wire \result[1]_i_4_n_0 ;
  wire \result[1]_i_5_n_0 ;
  wire \result[1]_i_6_n_0 ;
  wire \result[1]_i_7_n_0 ;
  wire \result[1]_i_8_n_0 ;
  wire \result[1]_i_9_n_0 ;
  wire \result[2]_i_2_n_0 ;
  wire \result[2]_i_3_n_0 ;
  wire \result[2]_i_4_n_0 ;
  wire \result[2]_i_5_n_0 ;
  wire \result[3]_i_2_n_0 ;
  wire \result[3]_i_3_n_0 ;
  wire \result[5]_i_2_n_0 ;
  wire \result[5]_i_3_n_0 ;
  wire \result[5]_i_4_n_0 ;
  wire \result[5]_i_5_n_0 ;
  wire \result[5]_i_6_n_0 ;
  wire \result[5]_i_7_n_0 ;
  wire \result[5]_i_8_n_0 ;
  wire [5:0]result_d;

  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[0] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[0]),
        .Q(data_q[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[10] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[10]),
        .Q(data_q[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[11] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[11]),
        .Q(data_q[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[12] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[12]),
        .Q(data_q[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[13] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[13]),
        .Q(data_q[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[14] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[14]),
        .Q(data_q[14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[15] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[15]),
        .Q(data_q[15]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[16] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[16]),
        .Q(data_q[16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[17] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[17]),
        .Q(data_q[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[18] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[18]),
        .Q(data_q[18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[19] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[19]),
        .Q(data_q[19]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[1] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[1]),
        .Q(data_q[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[20] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[20]),
        .Q(data_q[20]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[21] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[21]),
        .Q(data_q[21]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[22] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[22]),
        .Q(data_q[22]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[23] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[23]),
        .Q(data_q[23]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[24] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[24]),
        .Q(data_q[24]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[25] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[25]),
        .Q(data_q[25]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[26] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[26]),
        .Q(data_q[26]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[27] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[27]),
        .Q(data_q[27]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[28] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[28]),
        .Q(data_q[28]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[29] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[29]),
        .Q(data_q[29]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[2] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[2]),
        .Q(data_q[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[30] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[30]),
        .Q(data_q[30]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[31] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[31]),
        .Q(data_q[31]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[3] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[3]),
        .Q(data_q[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[4] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[4]),
        .Q(data_q[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[5] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[5]),
        .Q(data_q[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[6] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[6]),
        .Q(data_q[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[7] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[7]),
        .Q(data_q[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[8] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[8]),
        .Q(data_q[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[9] 
       (.C(CLK),
        .CE(1'b1),
        .D(data[9]),
        .Q(data_q[9]),
        .R(1'b0));
  LUT6 #(
    .INIT(64'h0000BBBBFF0FBBBB)) 
    \result[0]_i_1 
       (.I0(\result[0]_i_2_n_0 ),
        .I1(\result[0]_i_3_n_0 ),
        .I2(\result[0]_i_4_n_0 ),
        .I3(\result[0]_i_5_n_0 ),
        .I4(\result[5]_i_2_n_0 ),
        .I5(\result[1]_i_5_n_0 ),
        .O(result_d[0]));
  LUT3 #(
    .INIT(8'hBA)) 
    \result[0]_i_10 
       (.I0(data_q[7]),
        .I1(data_q[6]),
        .I2(data_q[5]),
        .O(\result[0]_i_10_n_0 ));
  LUT4 #(
    .INIT(16'h00F2)) 
    \result[0]_i_11 
       (.I0(data_q[8]),
        .I1(data_q[9]),
        .I2(data_q[10]),
        .I3(data_q[11]),
        .O(\result[0]_i_11_n_0 ));
  LUT5 #(
    .INIT(32'h22332232)) 
    \result[0]_i_2 
       (.I0(data_q[30]),
        .I1(data_q[31]),
        .I2(data_q[28]),
        .I3(data_q[29]),
        .I4(\result[0]_i_6_n_0 ),
        .O(\result[0]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFFFE2)) 
    \result[0]_i_3 
       (.I0(\result[0]_i_7_n_0 ),
        .I1(\result[5]_i_8_n_0 ),
        .I2(\result[0]_i_8_n_0 ),
        .I3(\result[5]_i_5_n_0 ),
        .I4(\result[5]_i_6_n_0 ),
        .O(\result[0]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hFFFEEEFE)) 
    \result[0]_i_4 
       (.I0(\result[2]_i_4_n_0 ),
        .I1(\result[2]_i_5_n_0 ),
        .I2(\result[0]_i_9_n_0 ),
        .I3(\result[2]_i_3_n_0 ),
        .I4(\result[0]_i_10_n_0 ),
        .O(\result[0]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'h22332232)) 
    \result[0]_i_5 
       (.I0(data_q[14]),
        .I1(data_q[15]),
        .I2(data_q[12]),
        .I3(data_q[13]),
        .I4(\result[0]_i_11_n_0 ),
        .O(\result[0]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'h00F2)) 
    \result[0]_i_6 
       (.I0(data_q[24]),
        .I1(data_q[25]),
        .I2(data_q[26]),
        .I3(data_q[27]),
        .O(\result[0]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'hBA)) 
    \result[0]_i_7 
       (.I0(data_q[19]),
        .I1(data_q[18]),
        .I2(data_q[17]),
        .O(\result[0]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'hBA)) 
    \result[0]_i_8 
       (.I0(data_q[23]),
        .I1(data_q[22]),
        .I2(data_q[21]),
        .O(\result[0]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'hBA)) 
    \result[0]_i_9 
       (.I0(data_q[3]),
        .I1(data_q[2]),
        .I2(data_q[1]),
        .O(\result[0]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h000F444400004444)) 
    \result[1]_i_1 
       (.I0(\result[1]_i_2_n_0 ),
        .I1(\result[1]_i_3_n_0 ),
        .I2(\result[1]_i_4_n_0 ),
        .I3(\result[1]_i_5_n_0 ),
        .I4(\result[5]_i_2_n_0 ),
        .I5(\result[1]_i_6_n_0 ),
        .O(result_d[1]));
  LUT2 #(
    .INIT(4'hE)) 
    \result[1]_i_2 
       (.I0(data_q[31]),
        .I1(data_q[30]),
        .O(\result[1]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hEEFEEEFEEEFEFFFE)) 
    \result[1]_i_3 
       (.I0(data_q[28]),
        .I1(data_q[29]),
        .I2(\result[1]_i_7_n_0 ),
        .I3(\result[5]_i_5_n_0 ),
        .I4(data_q[26]),
        .I5(data_q[27]),
        .O(\result[1]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \result[1]_i_4 
       (.I0(data_q[15]),
        .I1(data_q[14]),
        .O(\result[1]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000010)) 
    \result[1]_i_5 
       (.I0(\result[2]_i_4_n_0 ),
        .I1(\result[2]_i_5_n_0 ),
        .I2(\result[1]_i_8_n_0 ),
        .I3(data_q[0]),
        .I4(data_q[1]),
        .I5(\result[2]_i_3_n_0 ),
        .O(\result[1]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hEEFEEEFEEEFEFFFE)) 
    \result[1]_i_6 
       (.I0(data_q[12]),
        .I1(data_q[13]),
        .I2(\result[1]_i_9_n_0 ),
        .I3(\result[2]_i_4_n_0 ),
        .I4(data_q[10]),
        .I5(data_q[11]),
        .O(\result[1]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h1111111111110001)) 
    \result[1]_i_7 
       (.I0(data_q[22]),
        .I1(data_q[23]),
        .I2(data_q[19]),
        .I3(data_q[18]),
        .I4(data_q[21]),
        .I5(data_q[20]),
        .O(\result[1]_i_7_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \result[1]_i_8 
       (.I0(data_q[3]),
        .I1(data_q[2]),
        .O(\result[1]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'h1111111111110001)) 
    \result[1]_i_9 
       (.I0(data_q[6]),
        .I1(data_q[7]),
        .I2(data_q[3]),
        .I3(data_q[2]),
        .I4(data_q[5]),
        .I5(data_q[4]),
        .O(\result[1]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h03030303F3F303A3)) 
    \result[2]_i_1 
       (.I0(\result[5]_i_3_n_0 ),
        .I1(\result[2]_i_2_n_0 ),
        .I2(\result[5]_i_2_n_0 ),
        .I3(\result[2]_i_3_n_0 ),
        .I4(\result[2]_i_4_n_0 ),
        .I5(\result[2]_i_5_n_0 ),
        .O(result_d[2]));
  LUT6 #(
    .INIT(64'hFFFEFFFFFFFEFFFE)) 
    \result[2]_i_2 
       (.I0(data_q[29]),
        .I1(data_q[28]),
        .I2(data_q[31]),
        .I3(data_q[30]),
        .I4(\result[5]_i_5_n_0 ),
        .I5(\result[5]_i_8_n_0 ),
        .O(\result[2]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \result[2]_i_3 
       (.I0(data_q[4]),
        .I1(data_q[5]),
        .I2(data_q[6]),
        .I3(data_q[7]),
        .O(\result[2]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \result[2]_i_4 
       (.I0(data_q[8]),
        .I1(data_q[9]),
        .I2(data_q[10]),
        .I3(data_q[11]),
        .O(\result[2]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \result[2]_i_5 
       (.I0(data_q[14]),
        .I1(data_q[15]),
        .I2(data_q[12]),
        .I3(data_q[13]),
        .O(\result[2]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT4 #(
    .INIT(16'hAA08)) 
    \result[3]_i_1 
       (.I0(\result[3]_i_2_n_0 ),
        .I1(\result[5]_i_3_n_0 ),
        .I2(\result[5]_i_4_n_0 ),
        .I3(\result[3]_i_3_n_0 ),
        .O(result_d[3]));
  LUT5 #(
    .INIT(32'h00000001)) 
    \result[3]_i_2 
       (.I0(data_q[29]),
        .I1(data_q[28]),
        .I2(data_q[31]),
        .I3(data_q[30]),
        .I4(\result[5]_i_5_n_0 ),
        .O(\result[3]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    \result[3]_i_3 
       (.I0(\result[5]_i_8_n_0 ),
        .I1(data_q[19]),
        .I2(data_q[18]),
        .I3(data_q[17]),
        .I4(data_q[16]),
        .O(\result[3]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'hA8)) 
    \result[4]_i_1 
       (.I0(\result[5]_i_2_n_0 ),
        .I1(\result[5]_i_3_n_0 ),
        .I2(\result[5]_i_4_n_0 ),
        .O(result_d[4]));
  LUT3 #(
    .INIT(8'hFD)) 
    \result[5]_i_1 
       (.I0(\result[5]_i_2_n_0 ),
        .I1(\result[5]_i_3_n_0 ),
        .I2(\result[5]_i_4_n_0 ),
        .O(result_d[5]));
  LUT6 #(
    .INIT(64'h0000000000010000)) 
    \result[5]_i_2 
       (.I0(\result[5]_i_5_n_0 ),
        .I1(\result[5]_i_6_n_0 ),
        .I2(data_q[16]),
        .I3(data_q[17]),
        .I4(\result[5]_i_7_n_0 ),
        .I5(\result[5]_i_8_n_0 ),
        .O(\result[5]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    \result[5]_i_3 
       (.I0(\result[2]_i_3_n_0 ),
        .I1(data_q[1]),
        .I2(data_q[0]),
        .I3(data_q[3]),
        .I4(data_q[2]),
        .O(\result[5]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    \result[5]_i_4 
       (.I0(data_q[13]),
        .I1(data_q[12]),
        .I2(data_q[15]),
        .I3(data_q[14]),
        .I4(\result[2]_i_4_n_0 ),
        .O(\result[5]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \result[5]_i_5 
       (.I0(data_q[24]),
        .I1(data_q[25]),
        .I2(data_q[26]),
        .I3(data_q[27]),
        .O(\result[5]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \result[5]_i_6 
       (.I0(data_q[30]),
        .I1(data_q[31]),
        .I2(data_q[28]),
        .I3(data_q[29]),
        .O(\result[5]_i_6_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \result[5]_i_7 
       (.I0(data_q[19]),
        .I1(data_q[18]),
        .O(\result[5]_i_7_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \result[5]_i_8 
       (.I0(data_q[22]),
        .I1(data_q[23]),
        .I2(data_q[20]),
        .I3(data_q[21]),
        .O(\result[5]_i_8_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[0] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[0]),
        .Q(result[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[1] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[1]),
        .Q(result[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[2] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[2]),
        .Q(result[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[3] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[3]),
        .Q(result[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[4] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[4]),
        .Q(result[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[5] 
       (.C(CLK),
        .CE(1'b1),
        .D(result_d[5]),
        .Q(result[5]),
        .R(1'b0));
endmodule

(* ARITH = "0" *) (* ECO_CHECKSUM = "6e79358" *) (* FILL_KIND = "1" *) 
(* KIND = "2" *) (* MODE = "0" *) (* N = "32" *) 
(* RESULT_W = "6" *) (* SHIFT_W = "5" *) 
(* NotValidForBitStream *)
(* \DesignAttr:ENABLE_NOC_NETLIST_VIEW  *) 
(* \DesignAttr:ENABLE_AIE_NETLIST_VIEW  *) 
module primitive_v2_top
   (clk,
    data,
    amount,
    fill_val,
    result);
  input clk;
  input [31:0]data;
  input [4:0]amount;
  input fill_val;
  output [5:0]result;

  wire clk;
  wire clk_core;
  wire [31:0]data;
  wire [5:0]result;

  primitive_v2_boundary u_boundary
       (.CLK(clk_core),
        .data(data),
        .result(result));
  (* BOX_TYPE = "PRIMITIVE" *) 
  BUFG u_clock
       (.I(clk),
        .O(clk_core));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
