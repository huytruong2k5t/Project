`timescale 1ns/1ps
// Serial integer popcount golden, independent of LUT6 grouping in the DUT.
module tb_ops_popcount_recheck;
    logic [25:0] frac_a=0,frac_b=0;
    logic s_a=0,s_b=0,cfg_mode=0;
    logic signed [10:0] sf_a=0,sf_b=0;
    logic [1:0] cfg_ops=0;
    wire [25:0] x_frac;
    wire [26:0] y_mant;
    wire [4:0] active_width;
    wire sign_o,swapped,input_cut,cfg_error;
    wire signed [10:0] sf_o;
    ops_sel_comb dut_nf(.*);
    wire [11:0] xf;
    wire [12:0] yf;
    wire so;
    wire signed [10:0] sf;
    ops_sel_comb_fixed2 dut_f(.frac_a(frac_a[25:14]),.frac_b(frac_b[25:14]),
        .s_a(s_a),.s_b(s_b),.sf_a(sf_a),.sf_b(sf_b),.cfg_ops(cfg_ops[0]),
        .x_frac(xf),.y_mant(yf),.sign_o(so),.sf_o(sf));
    function automatic integer count(input logic [25:0] x);
        count=0;for(integer b=0;b<26;b++)count=count+x[b];
    endfunction
    integer checked=0;
    logic [25:0] aa,bb,ex;
    logic [26:0] ey;
    logic [4:0] width;
    logic choose,cut;
    logic signed [10:0] sum;
    task automatic check;
        #1;
        aa=cfg_mode ? {14'd0,frac_a[25:14]} : frac_a;
        bb=cfg_mode ? {14'd0,frac_b[25:14]} : frac_b;
        width=cfg_mode ? 12 : 26;
        choose=(cfg_ops==1)&&(count(bb)<count(aa));
        cut=cfg_mode && (|(frac_a[13:0]|frac_b[13:0]));
        sum=sf_a+sf_b;
        ex=choose?bb:aa;ey=(27'd1<<width)|(choose?aa:bb);
        if(cfg_ops>1) begin
            if({x_frac,y_mant,active_width,sign_o,sf_o,swapped,input_cut,cfg_error} !== {26'd0,27'd0,5'd0,1'b0,11'd0,1'b0,1'b0,1'b1})
                $fatal(1,"NF invalid output");
        end else if({x_frac,y_mant,active_width,sign_o,sf_o,swapped,input_cut,cfg_error} !== {ex,ey,width,(s_a^s_b),sum,choose,cut,1'b0})
            $fatal(1,"NF OPS mismatch row=%0d",checked);
        aa={14'd0,frac_a[25:14]};bb={14'd0,frac_b[25:14]};
        choose=cfg_ops[0]&&(count(bb)<count(aa));
        if({xf,yf,so,sf} !== {(choose?bb[11:0]:aa[11:0]),1'b1,(choose?aa[11:0]:bb[11:0]),(s_a^s_b),sum})
            $fatal(1,"F OPS mismatch row=%0d",checked);
        checked++;
    endtask
    initial begin
        for(integer a=0;a<4096;a++) begin
            frac_a={a[11:0],14'd0};
            for(integer b=0;b<12;b++) begin
                frac_b={(12'd1<<b),14'd0};cfg_mode=1;cfg_ops=1;check();
            end
        end
        for(integer i=0;i<100000;i++) begin
            frac_a=$urandom;frac_b=(i%8==0)?frac_a:$urandom;
            cfg_mode=i[0];cfg_ops=i[2:1];s_a=i[3];s_b=i[4];sf_a=$urandom;sf_b=$urandom;
            check();
        end
        $display("OPS_POPCOUNT_PASS checked=%0d",checked);$finish;
    end
endmodule
