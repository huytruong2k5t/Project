"""Create isolated, hash-bound F parser-sharing / NF-adder experiments."""
from pathlib import Path
import argparse
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
STUDY = ROOT / 'results/f_shared_add_20261020'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def parser2(text):
    text = text.replace('Atomic A/B/C, W12-F-1 fused MAC, one transaction.',
                        'OPT-15 F candidate: two parsers, atomic A/B/C.')
    text = text.replace('    wire ready_c;\n', '')
    text = text.replace('    wire nar_c;\n', '''    logic [NB-1:0] c_raw_q;
    logic c_pending_q;
    logic c_nar_launch_q;
    logic parser_p1_c_q;
    logic parser_p2_c_q;
    wire parser_in_valid;
    wire parser_out_valid;
    wire parser_out_ready;
    wire parser_p2_ready;
    wire [NB-1:0] parser_input;
''')
    text = text.replace('&& ready_a && ready_b && ready_c && add_ready',
                        '&& ready_a && ready_b && add_ready')
    text = text.replace('valid_a && valid_b && valid_c && core_ready',
                        'valid_a && valid_b && core_ready')
    text = text.replace('nar_a || nar_b || nar_c',
                        'nar_a || nar_b || c_nar_launch_q')
    begin = text.index('    posit_parser #(')
    end = text.index('    ops_sel_comb #(')
    nf = (ROOT / 'rtl/candidates/mac_nf/opt15/parser2/mac_nf_wrapper.sv').read_text()
    nf_begin = nf.index('    // A and C carry one role bit')
    nf_end = nf.index('    ops_sel_comb #(')
    text = text[:begin] + nf[nf_begin:nf_end] + text[end:]
    old = '''                c_sign_q <= `CK2Q s_c;
                c_zero_q <= `CK2Q z_c;
                c_sf_q <= `CK2Q sf_c;
                c_frac_q <= `CK2Q frac_c;
'''
    assert old in text
    text = text.replace(old, '''            end
            if (valid_c) begin
                c_sign_q <= `CK2Q s_c;
                c_zero_q <= `CK2Q z_c;
                c_sf_q <= `CK2Q sf_c;
                c_frac_q <= `CK2Q frac_c;
''')
    return text


def nf_add(text):
    text = text.replace('OPT-15 F candidate: two parsers, atomic A/B/C.',
                        'OPT-16 F candidate: two parsers and NF three-stage adder.')
    anchor = '    assign reset_n = reset_bridge_q;'
    assert anchor in text
    text = text.replace(anchor, '''    // Lossless adapter: P_hat has at most 13 fraction bits in this profile.
    // Normalize carry with fixed slices; NEVER pack or round the product.
    typedef logic signed [SF_W-1:0] sf_t;
    wire signed [SF_W-1:0] product_sf;
    wire [F-1:0] product_frac;
    wire [4:0] product_flags;
    assign product_sf = core_sf + sf_t'(p_magnitude[13]);
    assign product_frac = p_magnitude[13]
                        ? {p_magnitude[12:0], 13'b0}
                        : {p_magnitude[11:0], 14'b0};
    assign product_flags = nar_q ? 5'b10000 : {3'b0, loss_in};
''' + anchor)
    begin = text.index('    fused_add_pipe #(')
    end = text.index('    posit_pack #(', begin)
    text = text[:begin] + '''    // Reuse the exact production NF adder leaves and three elastic banks.
    // Its applicability to this prepack domain is checked against fused oracles.
    posit_add #(
        .NB (NB),
        .ES (ES),
        .SF_W (SF_W)
    ) u_add (
        .clk (clk),
        .reset_n (reset_n),
        .in_valid (core_done),
        .in_ready (add_ready),
        .out_valid (add_valid),
        .out_ready (pack_ready),
        .a_sign (core_sign),
        .a_is_zero (zero_q),
        .a_is_nar (nar_q),
        .a_sf (product_sf),
        .a_frac (product_frac),
        .b_sign (c_sign_q),
        .b_is_zero (c_zero_q),
        .b_is_nar (1'b0),
        .b_sf (c_sf_q),
        .b_frac (c_frac_q),
        .flags_in (product_flags),
        .sign (sum_sign),
        .is_zero (sum_zero),
        .is_nar (sum_nar),
        .sf (sum_sf),
        .frac (sum_frac),
        .sticky (sum_sticky),
        .flags_out (sum_flags)
    );
''' + text[end:]
    return text


def main():
    if STUDY.exists():
        raise SystemExit('Preserve existing study; choose a new revision for changes')
    original = (ROOT / 'rtl/mac_f/mac_f_wrapper.sv').read_text()
    candidates = {
        'parser2': ('rtl/candidates/mac_f/opt15/parser2/mac_f_wrapper.sv', parser2(original)),
        'shared_add': ('rtl/candidates/mac_f/opt16/shared_nf_add/mac_f_wrapper.sv', nf_add(parser2(original))),
    }
    paths = (ROOT / 'rtl/production.f').read_text().splitlines()
    paths = [s.strip() for s in paths if s.strip()]
    manifest = {'date': '2026-10-20', 'status': 'PREPARED_NOT_VERIFIED',
                'profile': '32/3 FW12 N_MAX8 EXACT_EN0 OPS_EN1',
                'production_unchanged': True, 'variants': {}}
    for variant, (rel, content) in candidates.items():
        dest = ROOT / rel
        if dest.exists():
            if dest.read_text() != content:
                raise SystemExit(f'Preserve modified candidate: {dest}')
        else:
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_text(content, newline='\n')
    for variant in ('reference', *candidates):
        srcroot = STUDY / 'source' / variant
        hashes = {}
        for rel in paths + ['rtl/posit_mac.vh']:
            source = ROOT / rel
            if variant in candidates and rel == 'rtl/mac_f/mac_f_wrapper.sv':
                source = ROOT / candidates[variant][0]
            dest = srcroot / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(source.read_bytes())
            hashes[rel] = sha(dest)
        (srcroot / 'rtl/production.f').write_text('\n'.join(paths) + '\n')
        manifest['variants'][variant] = {
            'source_sha256': hashes,
            'wrapper': 'rtl/mac_f/mac_f_wrapper.sv' if variant == 'reference' else candidates[variant][0],
            'input_parsers': 3 if variant == 'reference' else 2,
            'packer_instances': 1,
            'adder_stages': 3 if variant == 'shared_add' else 5,
        }
    (STUDY / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(STUDY)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--study', default='results/f_shared_add_20261020')
    args = parser.parse_args()
    STUDY = (ROOT / args.study).resolve()
    if not STUDY.is_relative_to((ROOT / 'results').resolve()):
        raise SystemExit('Study must remain inside Posit_MAC/results')
    main()
