onerror {quit -code 1}
onbreak {quit -code 1}
run 30000 ns
quit -code 0
