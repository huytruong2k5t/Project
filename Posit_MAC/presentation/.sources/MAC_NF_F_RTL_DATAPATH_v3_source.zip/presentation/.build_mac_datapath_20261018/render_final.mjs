import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {FileBlob,PresentationFile} from '@oai/artifact-tool';
const b=path.dirname(fileURLToPath(import.meta.url));
const file=path.resolve(b,'../MAC_NF_F_RTL_DATAPATH/MAC_NF_F_RTL_DATAPATH_v3.pptx');
const p=await PresentationFile.importPptx(await FileBlob.load(file));
for(const [i,s] of p.slides.items.entries()){
 const png=await p.export({slide:s,format:'png',scale:1});
 await fs.writeFile(path.join(b,`final-slide-${String(i+1).padStart(2,'0')}.png`),new Uint8Array(await png.arrayBuffer()));
}
console.log('Final actual PPTX rendered',p.slides.items.length,'slides');
