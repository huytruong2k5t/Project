// Checks carry-free magnitude used in posit_parser P1 against (p ^ {s}) + s.
module tb_parser_mag_equiv;
    function automatic logic [31:0] mag_new(input logic [31:0] p);
        logic [31:0] la; la[0] = 1'b0;
        for (int i = 1; i < 32; i++) la[i] = la[i-1] | p[i-1];
        return p ^ ({32{p[31]}} & la);
    endfunction
    initial begin
        int err = 0; logic [31:0] p, ref_m;
        for (int n = 0; n < 4000000; n++) begin
            if (n < 64)        p = 32'h1 << (n % 32) | (n >= 32 ? 32'h8000_0000 : 0);
            else if (n < 128)  p = ~(32'h0) << (n % 32);
            else               p = $urandom;
            ref_m = (p ^ {32{p[31]}}) + {31'd0, p[31]};
            if (mag_new(p) !== ref_m) begin err++; if (err < 5) $display("MISMATCH %h", p); end
        end
        $display("PARSER_MAG_EQUIV errors=%0d %s", err, err ? "FAIL" : "PASS");
        $finish;
    end
endmodule

