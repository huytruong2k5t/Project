"""Document the completed, lossless cleanup without rewriting evidence files."""
import json
from pathlib import Path

root=Path(__file__).resolve().parent.parent
batch=root/'archive/cleanup_20261102'
plan=json.loads((batch/'plan.json').read_text())
receipt=json.loads((batch/'receipt.json').read_text())
validation=json.loads((batch/'validation.json').read_text())
evidence=json.loads((batch/'evidence_validation.json').read_text())
migration=json.loads((batch/'reference_migration.json').read_text())
assert receipt['status']=='COMPLETE' and validation['status']=='PASS'
assert evidence['status']=='PASS'

def write(path,text):
    (root/path).write_text(text,encoding='utf-8')

def prepend(path,text):
    target=root/path
    marker='Dọn dẹp RTL/results — 02/11/2026'
    if marker in target.read_text(encoding='utf-8-sig').split('---',1)[0]:return
    target.write_bytes(text.encode('utf-8')+target.read_bytes())

mib=lambda n:f'{n/2**20:.2f}'
rows=[]
for label,info in receipt['archives'].items():
    rows.append(f"| [{label}.zip]({label}.zip) | {info['files']} | {mib(info['original_bytes'])} | {mib(info['bytes'])} |")
index='''# Archive dọn dẹp ngày 02/11/2026

Mọi file đưa ra khỏi RTL/results đều được lưu nguyên byte; ZIP đã kiểm CRC và SHA256 từng entry trước khi gỡ bản rời. Không thay đổi mã RTL đang dùng, golden, constraints hoặc nội dung bằng chứng giữ lại. Bảy reference chuyển sang tb/reference/rtl có biên bản riêng ở cuối.

| Archive | File | Dữ liệu gốc (MiB) | ZIP (MiB) |
| --- | ---: | ---: | ---: |
'''+ '\n'.join(rows)+'''

- rtl_inactive: module ngoài MAC hiện tại, candidate, benchmark và research lịch sử. Giữ nguyên cả các bản cũ có cùng tên module.
- results_history: các nhóm lịch sử và log/JSON/CSV rời trước đây ở gốc results. Không coi đây là kết quả sai; chúng được đưa ra khỏi cây kết quả đang dùng để tránh nhầm phiên bản.
- results_support: thư viện ModelSim, cache/compiled objects, temp/appdata và lượt synthesis/query chưa hoàn tất. Các nguồn, report, log và vector của lượt hoàn tất vẫn giữ trong results.
- metadata_before: bản README trước khi cập nhật danh mục; công cụ restore mặc định không ghi đè các README hiện hành.

[plan.json](plan.json) ghi phân loại và hash các file cần bảo vệ; [receipt.json](receipt.json) ghi SHA256 toàn ZIP; ARCHIVE_INDEX.json bên trong mỗi ZIP ghi đường dẫn gốc, số byte và SHA256 từng entry. [validation.json](validation.json) ghi kiểm tra sau dọn.

Chuyển reference bộ cộng: [reference_migration.json](reference_migration.json), [ZIP trước chuyển](verification_reference_before_move.zip). RTL hiện chỉ42 module; bảy reference được giữ nguyên byte trong tb/reference/rtl. [Verification kiểm đường dẫn mới](reference_verification/verify/) có compile/adder/packer/F log và source snapshot riêng; không chạy synthesis lại.

## Phục hồi để đọc hoặc đối chiếu riêng

Chạy từ gốc Posit_MAC:

```powershell
python scripts/cleanup_rtl_results_20261102.py restore --prefix results/week12/ --destination scratch/restore_cleanup_20261102
python scripts/cleanup_rtl_results_20261102.py restore --prefix rtl/mac_f/fused_add_pipe.sv --destination scratch/restore_cleanup_20261102
```

Nếu cần trả về đúng vị trí gốc, bỏ --destination. Công cụ kiểm trước toàn bộ đích, chỉ tạo file thiếu hoặc giữ file trùng hash; từ chối ghi đè file khác nội dung. Có thể dùng prefix cụ thể đến một file. Không extract toàn archive đè lên dự án và không compile glob RTL sau khi restore các module lịch sử trùng tên.

```powershell
python scripts/cleanup_rtl_results_20261102.py audit
```

Audit kiểm snapshot và trạng thái cây đã dọn. Nếu sau đó sửa RTL hoặc phục hồi thư mục vào vị trí gốc, danh mục/hash/count có thể khác mốc dọn một cách có chủ đích; restore tự kiểm SHA của những file nó phục hồi. Không dùng audit dọn dẹp thay cho verification chức năng hay nghiệm thu thiết kế mới.

Các script/Markdown lịch sử vẫn có thể nhắc đường dẫn đã archive. Tra plan.json hoặc ARCHIVE_INDEX.json rồi restore đúng prefix trước khi replay. Phục hồi file không tự cung cấp tool/runtime/dependency còn thiếu; ưu tiên replay từ source snapshot tương ứng thay vì trộn các thế hệ RTL.
'''
write('archive/cleanup_20261102/INDEX.md',index)

groups=plan['keep_results']
descriptions={
 'f_timing_optimization_20261101':'MAC F đã chọn P00: F2F6.602ns, LUT1265/FF820; giữ cả4 candidate, DCP, logs, vector, source và promotion/hash.',
 'parser_lod_refactor_recheck_20261101':'Baseline trước tối ưu F: F7.697ns/NF7.334ns; giữ critical_path_diagnosis_final và các truy vấn hoàn tất.',
 'readme_refactor_recheck_20261101':'Baseline NF/F trước refactor Parser/LOD: F6.602ns/NF7.334ns; kiểm OPS độc lập và regression.',
 'refactored_mac_20261101_r3':'Mốc refactor trước tối ưu packer/parser/OPS: F7.254ns/NF7.979ns; nguồn, verification, synthesis_final và F2F.',
 'fixed32_3_20261022':'Release lịch sử: summary, source/reference freeze, log/vector và báo cáo được manifest bảo vệ. Không suy nghiệm thu cho RTL hiện tại.',
 'week14':'Bằng chứng nghiệm thu/coverage/accuracy lịch sử; giữ nguồn, trace và corpus. Không suy kết quả cho RTL hiện tại.',
 'opt17_20261029':'Bằng chứng thí nghiệm gần đây, freeze/source bundle, model/profile và bảng đối chiếu.',
 'l1_floor_rne_freeze':'Mốc hợp đồng/golden FLOOR/RNE và trace replay lịch sử.',
}
results='''# Kết quả được giữ sau dọn dẹp — 02/11/2026

Giữ tám nhóm có nguồn/manifest hoặc bằng chứng hữu ích để kiểm chứng và so sánh. Log, report, vector, golden profile, DCP/constraints và snapshot của các lượt hoàn tất được bảo toàn. Thư viện/cache sinh lại được, lượt chạy dở và nhóm lịch sử khác được lưu ngoài results, không xóa mất bằng chứng.

| Nhóm | Giá trị kiểm chứng/đối chiếu |
| --- | --- |
'''+ '\n'.join(f'| [{name}/]({name}/) | {descriptions[name]} |' for name in groups)+'''

## Điểm vào cho thiết kế đang làm việc

- [So sánh tối ưu MAC F](f_timing_optimization_20261101/summary.md), [CSV toàn bộ phương án](f_timing_optimization_20261101/comparison.csv).
- [F2F từng tầng P00](f_timing_optimization_20261101/p00/f2f_f/stages.csv), [worst path](f_timing_optimization_20261101/p00/f2f_f/whole_f2f_D_CE.rpt), [top20](f_timing_optimization_20261101/p00/f2f_f/whole_f2f_top20.rpt).
- [Hash RTL đã áp dụng](f_timing_optimization_20261101/promotion.json); [nguồn đã đo](f_timing_optimization_20261101/p00/source/rtl/mac_f/mac_f_wrapper.sv).
- [Phân tích critical path NF/F](parser_lod_refactor_recheck_20261101/critical_path_diagnosis_final/diagnosis.md).

Các số trên là OOC synthesis; WHS vẫn−0.055ns, chưa place/route/board signoff. RTL còn dùng FLOOR hiện hành; không coi đây là nghiệm thu FULL_TERM26/Q24 hoặc toàn ma trận SPEC.

## Kết quả lịch sử và thư viện đã lưu trữ

[Danh mục archive và cách phục hồi](../archive/cleanup_20261102/INDEX.md). Những đường dẫn cũ trong tài liệu hoặc script lịch sử có thể cần restore trước khi dùng. Công cụ không ghi đè chỉnh sửa hiện tại. Khi chạy lại verification, nên chọn RunRoot mới và build work từ source thay vì phụ thuộc thư viện compiled cũ.

[Biên bản dọn dẹp](../docs/DON_DEP_RTL_RESULTS_20261102.md). Dọn thư mục và kiểm hash không thay cho chạy verification chức năng mới.
'''
write('results/README.md',results)

report=f'''# Dọn dẹp RTL và kết quả — 02/11/2026

Hoàn tất việc sắp xếp và lưu trữ; không sửa logic module RTL hoặc chạy Vivado. Sau khi chuyển reference bộ cộng, đã chạy lại luồng verification hiện hành ở mức smoke để kiểm đường dẫn snapshot/compile mới.

| Chỉ tiêu | Trước | Sau |
| --- | ---: | ---: |
| RTL .sv | {validation['rtl_sv_before']} | 42 MAC; 7 reference chuyển sang tb |
| Nhóm thư mục results | {validation['results_dirs_before']} | 8 |
| Dữ liệu trong results | {mib(validation['results_bytes_before'])} MiB | khoảng {mib(validation['results_bytes_after'])} MiB |

Đưa45 file SV không dùng trong MAC hiện tại và4 file phụ trợ ra khỏi RTL. Thêm7 file reference được chuyển nguyên byte sang [tb/reference/rtl/files.f](../tb/reference/rtl/files.f) vì testbench so sánh bộ cộng vẫn cần. Runner đã cập nhật đường dẫn mới và có fallback khi replay snapshot dùng đường dẫn cũ. File list DUT [mac_active.f](../rtl/mac_active.f) vẫn đủ42 module, đóng dependency từ hai top. Không sửa production.f/production_freeze.json lịch sử.

Giữ nguyên byte {validation['protected_files_unchanged']} file cần bảo vệ, gồm RTL active/reference, header, manifest, snapshot, golden/constraints và bằng chứng kết quả không thuộc cache. Các manifest nguồn của những lần đo gần nhất vẫn khớp; F2F6.602ns của F và dữ liệu đối chiếu NF/F không bị thay đổi. Việc đối chiếu hash này không thay regression chức năng đầy đủ; smoke sau chuyển reference được ghi riêng bên dưới.

Tổng {receipt['removed_files']} file được chuyển ra khỏi cây làm việc sau khi ZIP đã kiểm CRC/SHA256 từng entry. Bốn gói ZIP chính tổng {mib(validation['archive_bytes'])} MiB; bảy reference di chuyển có ZIP/receipt riêng. Mọi byte gốc của các file đã gỡ đều có thể phục hồi; metadata README trước khi cập nhật cũng được lưu riêng.

## Cách dùng sau dọn

- [Kết quả đang giữ](../results/README.md): tám mốc có ý nghĩa và điểm vào CSV/report/log/source.
- [Archive/index và hướng dẫn restore](../archive/cleanup_20261102/INDEX.md).
- [Plan/danh mục chính xác](../archive/cleanup_20261102/plan.json), [receipt/hash ZIP](../archive/cleanup_20261102/receipt.json), [kiểm tra sau dọn](../archive/cleanup_20261102/validation.json).

Luồng hiện tại run_refactored_mac.ps1, run_f_parser_equiv.ps1, report_refactored_mac_f2f.ps1 và query_mac_critical_paths.ps1 có đủ RTL/reference/source/report đầu vào. Script mô phỏng luôn build work mới khi chọn RunRoot mới. Các workflow/benchmark lịch sử đã archive cần phục hồi đúng snapshot/đường dẫn trước khi replay; không trộn module cùng tên giữa các thế hệ.

## Kiểm tra đã thực hiện

Đối chiếu SHA256 toàn ZIP và từng entry, kiểm hash tất cả file được bảo vệ, kiểm đủ42 module reachable từ hai top và đúng42 SV trong RTL, giữ nguyên các report được freeze lịch sử tham chiếu. Bảy reference mới được đối chiếu hash tại đường dẫn tb; [biên bản chuyển](../archive/cleanup_20261102/reference_migration.json) giữ mapping và ZIP trước di chuyển. Đã kiểm {evidence['source_manifests_checked']} manifest/{evidence['source_file_hashes_checked']} hash nguồn của các lần đo gần nhất và thử phục hồi3 file đại diện RTL/kết quả lịch sử/cache: tất cả PASS. Các bản phục hồi thử được gỡ sau khi đối chiếu đúng hash. [Bằng chứng bổ sung](../archive/cleanup_20261102/evidence_validation.json).

Verification sau chuyển: bộ cộng5 tầng39534 completed/0 mismatch, packer10851 completed/0 errors, MAC F1000 accepted theo golden hiện hành: PASS. [Log và nguồn đã kiểm](../archive/cleanup_20261102/reference_verification/verify/). Đây là smoke kiểm đường dẫn runner, không thay các mốc regression/synthesis lớn đã giữ nguyên trong results.
'''
write('docs/DON_DEP_RTL_RESULTS_20261102.md',report)
prepend('README.md','''## Dọn dẹp RTL/results — 02/11/2026

RTL đang làm việc chỉ giữ **42 module MAC**; 7 module reference cho verification đã chuyển sang **tb/reference/rtl/**. Các candidate/benchmark/research và module đã thay thế được lưu ngoài RTL. Results giữ8 mốc cần kiểm chứng/đối chiếu; F đã chọn vẫn6.602ns/1265LUT/820FF. Nội dung active RTL và bằng chứng giữ lại không thay đổi.

[Kết quả hiện dùng](results/README.md) · [Biên bản](docs/DON_DEP_RTL_RESULTS_20261102.md) · [Archive và phục hồi](archive/cleanup_20261102/INDEX.md).

Các mục lịch sử bên dưới giữ ngày/scope của snapshot tương ứng; đường dẫn cũ đã archive cần restore trước khi replay.

---

''')
prepend('rtl/README.md','''## Dọn dẹp RTL/results — 02/11/2026

- [mac_active.f](mac_active.f): **42 module** cho hai top MAC hiện tại; mọi nội dung giữ nguyên byte.
- [tb/reference/rtl/files.f](../tb/reference/rtl/files.f): **7 module** ngoài DUT nhưng còn dùng cho reference bộ cộng; đã chuyển khỏi RTL và cập nhật runner.
- Các fused adder/controller cũ, standalone không dùng trong luồng hiện tại, candidate/benchmark/research đã vào [archive có hash](../archive/cleanup_20261102/INDEX.md).

Dùng file list mac_active.f cho DUT và thêm reference file list khi kiểm tương đương bộ cộng. rtl/adder chỉ còn posit_add.sv cùng Prepare/Align/Arithmetic/LOD/Normalize của pipeline5 tầng. production.f/production_freeze.json là mốc lịch sử, không thay thế danh sách42 module đang làm việc. Các số46/54 trong mục lịch sử bên dưới không mô tả cây sau dọn.

---

''')
prepend('archive/README.md','''## Dọn dẹp RTL/results — 02/11/2026

Kho mới [cleanup_20261102/INDEX.md](cleanup_20261102/INDEX.md) lưu nguyên byte RTL không dùng, kết quả lịch sử, thư viện/cache và lượt chạy dở. Có SHA256/size/path từng file, kiểm toàn vẹn trước khi gỡ bản rời và công cụ restore không ghi đè.

Đây là kho của cây đang làm việc ngày02/11; các archive29/10 và audit release54 bên dưới thuộc checkpoint lịch sử riêng, không phải audit active RTL42 module hiện tại.

---

''')
prepend('scripts/README.md','''## Dọn dẹp RTL/results — 02/11/2026

Luồng hiện tại giữ nguyên: run_refactored_mac.ps1, run_f_parser_equiv.ps1, report_refactored_mac_f2f.ps1, query_mac_critical_paths.ps1. Các snapshot và baseline mặc định của chúng vẫn còn trong results.

```powershell
python scripts/cleanup_rtl_results_20261102.py audit
python scripts/cleanup_rtl_results_20261102.py restore --prefix results/week12/ --destination scratch/restore_cleanup_20261102
```

Xem [index/receipt](../archive/cleanup_20261102/INDEX.md). Các script benchmark/release cũ có thể trỏ tới file đã archive: phục hồi đúng prefix/snapshot trước khi dùng. Chọn RunRoot mới để build thư viện mô phỏng từ nguồn; không phụ thuộc cache đã dọn. Không chạy lại apply: mốc dọn đã hoàn tất và archive được giữ bất biến.

---

''')
print('CLEANUP_DOCUMENTATION_WRITTEN')
