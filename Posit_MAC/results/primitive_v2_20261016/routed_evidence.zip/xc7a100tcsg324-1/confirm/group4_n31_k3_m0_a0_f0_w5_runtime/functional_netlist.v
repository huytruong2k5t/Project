// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2026.1 (win64) Build 6511674 Tue Jun 16 11:02:23 MDT 2026
// Date        : Fri Oct 16 17:56:19 2026
// Host        : MSI running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim {C:/HCMUT/HK261/Do an
//               2/Posit_MAC/results/primitive_v2_20261016/xc7a100tcsg324-1/confirm/group4_n31_k3_m0_a0_f0_w5_runtime/functional_netlist.v}
// Design      : primitive_v2_top
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a100tcsg324-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module primitive_v2_boundary
   (result,
    data,
    clk_core);
  output [35:0]result;
  input [30:0]data;
  input clk_core;

  wire clk_core;
  wire [30:0]data;
  wire [30:0]data_q;
  wire [4:0]\g_detector.count ;
  wire \g_detector.found ;
  wire [35:0]result;
  wire \result[0]_i_1_n_0 ;
  wire \result[10]_i_1_n_0 ;
  wire \result[11]_i_1_n_0 ;
  wire \result[12]_i_1_n_0 ;
  wire \result[13]_i_1_n_0 ;
  wire \result[14]_i_1_n_0 ;
  wire \result[16]_i_2_n_0 ;
  wire \result[16]_i_3_n_0 ;
  wire \result[17]_i_2_n_0 ;
  wire \result[17]_i_3_n_0 ;
  wire \result[18]_i_2_n_0 ;
  wire \result[18]_i_3_n_0 ;
  wire \result[19]_i_2_n_0 ;
  wire \result[19]_i_3_n_0 ;
  wire \result[1]_i_1_n_0 ;
  wire \result[20]_i_2_n_0 ;
  wire \result[20]_i_3_n_0 ;
  wire \result[21]_i_2_n_0 ;
  wire \result[21]_i_3_n_0 ;
  wire \result[22]_i_2_n_0 ;
  wire \result[22]_i_3_n_0 ;
  wire \result[22]_i_4_n_0 ;
  wire \result[23]_i_2_n_0 ;
  wire \result[23]_i_3_n_0 ;
  wire \result[23]_i_4_n_0 ;
  wire \result[23]_i_5_n_0 ;
  wire \result[23]_i_6_n_0 ;
  wire \result[24]_i_3_n_0 ;
  wire \result[24]_i_4_n_0 ;
  wire \result[25]_i_3_n_0 ;
  wire \result[25]_i_4_n_0 ;
  wire \result[25]_i_5_n_0 ;
  wire \result[26]_i_10_n_0 ;
  wire \result[26]_i_11_n_0 ;
  wire \result[26]_i_3_n_0 ;
  wire \result[26]_i_4_n_0 ;
  wire \result[26]_i_5_n_0 ;
  wire \result[26]_i_6_n_0 ;
  wire \result[26]_i_7_n_0 ;
  wire \result[26]_i_8_n_0 ;
  wire \result[26]_i_9_n_0 ;
  wire \result[27]_i_10_n_0 ;
  wire \result[27]_i_3_n_0 ;
  wire \result[27]_i_4_n_0 ;
  wire \result[27]_i_5_n_0 ;
  wire \result[27]_i_6_n_0 ;
  wire \result[27]_i_7_n_0 ;
  wire \result[27]_i_8_n_0 ;
  wire \result[27]_i_9_n_0 ;
  wire \result[28]_i_10_n_0 ;
  wire \result[28]_i_11_n_0 ;
  wire \result[28]_i_12_n_0 ;
  wire \result[28]_i_3_n_0 ;
  wire \result[28]_i_4_n_0 ;
  wire \result[28]_i_5_n_0 ;
  wire \result[28]_i_6_n_0 ;
  wire \result[28]_i_7_n_0 ;
  wire \result[28]_i_8_n_0 ;
  wire \result[28]_i_9_n_0 ;
  wire \result[29]_i_10_n_0 ;
  wire \result[29]_i_11_n_0 ;
  wire \result[29]_i_12_n_0 ;
  wire \result[29]_i_3_n_0 ;
  wire \result[29]_i_4_n_0 ;
  wire \result[29]_i_5_n_0 ;
  wire \result[29]_i_6_n_0 ;
  wire \result[29]_i_7_n_0 ;
  wire \result[29]_i_8_n_0 ;
  wire \result[29]_i_9_n_0 ;
  wire \result[2]_i_1_n_0 ;
  wire \result[31]_i_10_n_0 ;
  wire \result[31]_i_11_n_0 ;
  wire \result[31]_i_2_n_0 ;
  wire \result[31]_i_3_n_0 ;
  wire \result[31]_i_4_n_0 ;
  wire \result[31]_i_5_n_0 ;
  wire \result[31]_i_6_n_0 ;
  wire \result[31]_i_7_n_0 ;
  wire \result[31]_i_8_n_0 ;
  wire \result[31]_i_9_n_0 ;
  wire \result[32]_i_2_n_0 ;
  wire \result[32]_i_3_n_0 ;
  wire \result[32]_i_4_n_0 ;
  wire \result[32]_i_5_n_0 ;
  wire \result[32]_i_6_n_0 ;
  wire \result[32]_i_7_n_0 ;
  wire \result[32]_i_8_n_0 ;
  wire \result[33]_i_2_n_0 ;
  wire \result[33]_i_3_n_0 ;
  wire \result[33]_i_4_n_0 ;
  wire \result[33]_i_5_n_0 ;
  wire \result[33]_i_6_n_0 ;
  wire \result[34]_i_2_n_0 ;
  wire \result[34]_i_3_n_0 ;
  wire \result[36]_i_2_n_0 ;
  wire \result[36]_i_3_n_0 ;
  wire \result[36]_i_4_n_0 ;
  wire \result[36]_i_5_n_0 ;
  wire \result[36]_i_6_n_0 ;
  wire \result[3]_i_1_n_0 ;
  wire \result[4]_i_1_n_0 ;
  wire \result[5]_i_1_n_0 ;
  wire \result[6]_i_1_n_0 ;
  wire \result[7]_i_1_n_0 ;
  wire \result[8]_i_1_n_0 ;
  wire \result[9]_i_1_n_0 ;
  wire [29:15]result_d;

  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[0] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[0]),
        .Q(data_q[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[10] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[10]),
        .Q(data_q[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[11] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[11]),
        .Q(data_q[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[12] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[12]),
        .Q(data_q[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[13] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[13]),
        .Q(data_q[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[14] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[14]),
        .Q(data_q[14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[15] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[15]),
        .Q(data_q[15]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[16] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[16]),
        .Q(data_q[16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[17] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[17]),
        .Q(data_q[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[18] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[18]),
        .Q(data_q[18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[19] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[19]),
        .Q(data_q[19]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[1] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[1]),
        .Q(data_q[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[20] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[20]),
        .Q(data_q[20]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[21] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[21]),
        .Q(data_q[21]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[22] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[22]),
        .Q(data_q[22]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[23] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[23]),
        .Q(data_q[23]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[24] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[24]),
        .Q(data_q[24]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[25] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[25]),
        .Q(data_q[25]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[26] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[26]),
        .Q(data_q[26]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[27] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[27]),
        .Q(data_q[27]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[28] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[28]),
        .Q(data_q[28]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[29] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[29]),
        .Q(data_q[29]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[2] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[2]),
        .Q(data_q[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[30] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[30]),
        .Q(data_q[30]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[3] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[3]),
        .Q(data_q[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[4] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[4]),
        .Q(data_q[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[5] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[5]),
        .Q(data_q[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[6] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[6]),
        .Q(data_q[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[7] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[7]),
        .Q(data_q[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[8] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[8]),
        .Q(data_q[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[9] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[9]),
        .Q(data_q[9]),
        .R(1'b0));
  LUT5 #(
    .INIT(32'h00000010)) 
    \result[0]_i_1 
       (.I0(\g_detector.count [2]),
        .I1(\g_detector.count [0]),
        .I2(data_q[0]),
        .I3(\g_detector.count [1]),
        .I4(\g_detector.count [3]),
        .O(\result[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair22" *) 
  LUT3 #(
    .INIT(8'h2E)) 
    \result[14]_i_1 
       (.I0(\result[22]_i_4_n_0 ),
        .I1(\g_detector.count [3]),
        .I2(\result[22]_i_2_n_0 ),
        .O(\result[14]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \result[15]_i_1 
       (.I0(\result[23]_i_2_n_0 ),
        .I1(\g_detector.count [3]),
        .I2(\result[23]_i_3_n_0 ),
        .O(result_d[15]));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT5 #(
    .INIT(32'h002FFF2F)) 
    \result[16]_i_1 
       (.I0(\g_detector.count [4]),
        .I1(\result[16]_i_2_n_0 ),
        .I2(\result[24]_i_3_n_0 ),
        .I3(\g_detector.count [3]),
        .I4(\result[16]_i_3_n_0 ),
        .O(result_d[16]));
  LUT4 #(
    .INIT(16'hFFEF)) 
    \result[16]_i_2 
       (.I0(\g_detector.count [2]),
        .I1(\g_detector.count [0]),
        .I2(data_q[0]),
        .I3(\g_detector.count [1]),
        .O(\result[16]_i_2_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[16]_i_3 
       (.I0(\result[28]_i_6_n_0 ),
        .I1(\g_detector.count [2]),
        .I2(\result[28]_i_7_n_0 ),
        .O(\result[16]_i_3_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT5 #(
    .INIT(32'h0FFF04F4)) 
    \result[17]_i_1 
       (.I0(\result[17]_i_2_n_0 ),
        .I1(\g_detector.count [4]),
        .I2(\g_detector.count [3]),
        .I3(\result[17]_i_3_n_0 ),
        .I4(\result[25]_i_3_n_0 ),
        .O(result_d[17]));
  LUT5 #(
    .INIT(32'hFFFFBABF)) 
    \result[17]_i_2 
       (.I0(\g_detector.count [2]),
        .I1(data_q[0]),
        .I2(\g_detector.count [0]),
        .I3(data_q[1]),
        .I4(\g_detector.count [1]),
        .O(\result[17]_i_2_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[17]_i_3 
       (.I0(\result[29]_i_6_n_0 ),
        .I1(\g_detector.count [2]),
        .I2(\result[29]_i_7_n_0 ),
        .O(\result[17]_i_3_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT5 #(
    .INIT(32'h0FFF04F4)) 
    \result[18]_i_1 
       (.I0(\result[18]_i_2_n_0 ),
        .I1(\g_detector.count [4]),
        .I2(\g_detector.count [3]),
        .I3(\result[18]_i_3_n_0 ),
        .I4(\result[26]_i_3_n_0 ),
        .O(result_d[18]));
  LUT6 #(
    .INIT(64'hFAFAABFBFFFFABFB)) 
    \result[18]_i_2 
       (.I0(\g_detector.count [2]),
        .I1(data_q[2]),
        .I2(\g_detector.count [0]),
        .I3(data_q[1]),
        .I4(\g_detector.count [1]),
        .I5(data_q[0]),
        .O(\result[18]_i_2_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[18]_i_3 
       (.I0(\result[26]_i_6_n_0 ),
        .I1(\g_detector.count [2]),
        .I2(\result[26]_i_7_n_0 ),
        .O(\result[18]_i_3_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  (* \PinAttr:I0:HOLD_DETOUR  = "138" *) 
  LUT6 #(
    .INIT(64'h00FFFFFF0020FF20)) 
    \result[19]_i_1 
       (.I0(\result[19]_i_2_n_0 ),
        .I1(\g_detector.count [2]),
        .I2(\g_detector.count [4]),
        .I3(\g_detector.count [3]),
        .I4(\result[19]_i_3_n_0 ),
        .I5(\result[27]_i_3_n_0 ),
        .O(result_d[19]));
  LUT6 #(
    .INIT(64'hAACCAACCF0FFF000)) 
    \result[19]_i_2 
       (.I0(data_q[0]),
        .I1(data_q[1]),
        .I2(data_q[2]),
        .I3(\g_detector.count [0]),
        .I4(data_q[3]),
        .I5(\g_detector.count [1]),
        .O(\result[19]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \result[19]_i_3 
       (.I0(\result[23]_i_5_n_0 ),
        .I1(\g_detector.count [1]),
        .I2(\result[23]_i_6_n_0 ),
        .I3(\g_detector.count [2]),
        .I4(\result[27]_i_6_n_0 ),
        .O(\result[19]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000004540)) 
    \result[1]_i_1 
       (.I0(\g_detector.count [2]),
        .I1(data_q[0]),
        .I2(\g_detector.count [0]),
        .I3(data_q[1]),
        .I4(\g_detector.count [1]),
        .I5(\g_detector.count [3]),
        .O(\result[1]_i_1_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT5 #(
    .INIT(32'h002FFF2F)) 
    \result[20]_i_1 
       (.I0(\g_detector.count [4]),
        .I1(\result[20]_i_2_n_0 ),
        .I2(\result[28]_i_3_n_0 ),
        .I3(\g_detector.count [3]),
        .I4(\result[20]_i_3_n_0 ),
        .O(result_d[20]));
  LUT5 #(
    .INIT(32'hFBFFFB00)) 
    \result[20]_i_2 
       (.I0(\g_detector.count [1]),
        .I1(data_q[0]),
        .I2(\g_detector.count [0]),
        .I3(\g_detector.count [2]),
        .I4(\result[28]_i_6_n_0 ),
        .O(\result[20]_i_2_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[20]_i_3 
       (.I0(\result[28]_i_7_n_0 ),
        .I1(\g_detector.count [2]),
        .I2(\result[28]_i_8_n_0 ),
        .O(\result[20]_i_3_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT5 #(
    .INIT(32'h0FFF04F4)) 
    \result[21]_i_1 
       (.I0(\result[21]_i_2_n_0 ),
        .I1(\g_detector.count [4]),
        .I2(\g_detector.count [3]),
        .I3(\result[21]_i_3_n_0 ),
        .I4(\result[29]_i_3_n_0 ),
        .O(result_d[21]));
  LUT6 #(
    .INIT(64'hABFBFFFFABFB0000)) 
    \result[21]_i_2 
       (.I0(\g_detector.count [1]),
        .I1(data_q[1]),
        .I2(\g_detector.count [0]),
        .I3(data_q[0]),
        .I4(\g_detector.count [2]),
        .I5(\result[29]_i_6_n_0 ),
        .O(\result[21]_i_2_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[21]_i_3 
       (.I0(\result[29]_i_7_n_0 ),
        .I1(\g_detector.count [2]),
        .I2(\result[29]_i_8_n_0 ),
        .O(\result[21]_i_3_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT5 #(
    .INIT(32'hFFF400F4)) 
    \result[22]_i_1 
       (.I0(\result[22]_i_2_n_0 ),
        .I1(\g_detector.count [4]),
        .I2(\result[22]_i_3_n_0 ),
        .I3(\g_detector.count [3]),
        .I4(\result[22]_i_4_n_0 ),
        .O(result_d[22]));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[22]_i_2 
       (.I0(\result[26]_i_5_n_0 ),
        .I1(\g_detector.count [2]),
        .I2(\result[26]_i_6_n_0 ),
        .O(\result[22]_i_2_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[22]_i_3 
       (.I0(\result[26]_i_9_n_0 ),
        .I1(\g_detector.count [2]),
        .I2(\result[26]_i_10_n_0 ),
        .O(\result[22]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h74)) 
    \result[22]_i_4 
       (.I0(\result[26]_i_7_n_0 ),
        .I1(\g_detector.count [2]),
        .I2(\result[26]_i_8_n_0 ),
        .O(\result[22]_i_4_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'hFFFFF088)) 
    \result[23]_i_1 
       (.I0(\result[23]_i_2_n_0 ),
        .I1(\g_detector.count [4]),
        .I2(\result[23]_i_3_n_0 ),
        .I3(\g_detector.count [3]),
        .I4(\result[23]_i_4_n_0 ),
        .O(result_d[23]));
  LUT5 #(
    .INIT(32'h8B8B88BB)) 
    \result[23]_i_2 
       (.I0(\result[19]_i_2_n_0 ),
        .I1(\g_detector.count [2]),
        .I2(\result[23]_i_5_n_0 ),
        .I3(\result[23]_i_6_n_0 ),
        .I4(\g_detector.count [1]),
        .O(\result[23]_i_2_n_0 ));
  LUT3 #(
    .INIT(8'h74)) 
    \result[23]_i_3 
       (.I0(\result[27]_i_6_n_0 ),
        .I1(\g_detector.count [2]),
        .I2(\result[27]_i_7_n_0 ),
        .O(\result[23]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'hA3)) 
    \result[23]_i_4 
       (.I0(\result[27]_i_8_n_0 ),
        .I1(\result[27]_i_10_n_0 ),
        .I2(\g_detector.count [2]),
        .O(\result[23]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h47)) 
    \result[23]_i_5 
       (.I0(data_q[4]),
        .I1(\g_detector.count [0]),
        .I2(data_q[5]),
        .O(\result[23]_i_5_n_0 ));
  LUT3 #(
    .INIT(8'h47)) 
    \result[23]_i_6 
       (.I0(data_q[6]),
        .I1(\g_detector.count [0]),
        .I2(data_q[7]),
        .O(\result[23]_i_6_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT5 #(
    .INIT(32'hFFFF88F8)) 
    \result[24]_i_1 
       (.I0(\result[8]_i_1_n_0 ),
        .I1(\g_detector.count [4]),
        .I2(\g_detector.count [3]),
        .I3(\result[24]_i_3_n_0 ),
        .I4(\result[24]_i_4_n_0 ),
        .O(result_d[24]));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT5 #(
    .INIT(32'h03440377)) 
    \result[24]_i_2 
       (.I0(\result[28]_i_5_n_0 ),
        .I1(\g_detector.count [3]),
        .I2(\result[28]_i_6_n_0 ),
        .I3(\g_detector.count [2]),
        .I4(\result[28]_i_7_n_0 ),
        .O(\result[8]_i_1_n_0 ));
  LUT3 #(
    .INIT(8'hAC)) 
    \result[24]_i_3 
       (.I0(\result[28]_i_8_n_0 ),
        .I1(\result[28]_i_9_n_0 ),
        .I2(\g_detector.count [2]),
        .O(\result[24]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h53)) 
    \result[24]_i_4 
       (.I0(\result[28]_i_10_n_0 ),
        .I1(\result[28]_i_12_n_0 ),
        .I2(\g_detector.count [2]),
        .O(\result[24]_i_4_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT5 #(
    .INIT(32'hFFFFF888)) 
    \result[25]_i_1 
       (.I0(\result[9]_i_1_n_0 ),
        .I1(\g_detector.count [4]),
        .I2(\result[25]_i_3_n_0 ),
        .I3(\g_detector.count [3]),
        .I4(\result[25]_i_4_n_0 ),
        .O(result_d[25]));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT5 #(
    .INIT(32'h03440377)) 
    \result[25]_i_2 
       (.I0(\result[29]_i_5_n_0 ),
        .I1(\g_detector.count [3]),
        .I2(\result[29]_i_6_n_0 ),
        .I3(\g_detector.count [2]),
        .I4(\result[29]_i_7_n_0 ),
        .O(\result[9]_i_1_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[25]_i_3 
       (.I0(\result[25]_i_5_n_0 ),
        .I1(\g_detector.count [2]),
        .I2(\result[29]_i_9_n_0 ),
        .O(\result[25]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h8B)) 
    \result[25]_i_4 
       (.I0(\result[29]_i_10_n_0 ),
        .I1(\g_detector.count [2]),
        .I2(\result[29]_i_12_n_0 ),
        .O(\result[25]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[25]_i_5 
       (.I0(data_q[10]),
        .I1(data_q[11]),
        .I2(\g_detector.count [1]),
        .I3(data_q[12]),
        .I4(\g_detector.count [0]),
        .I5(data_q[13]),
        .O(\result[25]_i_5_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT5 #(
    .INIT(32'hFFFFF888)) 
    \result[26]_i_1 
       (.I0(\result[10]_i_1_n_0 ),
        .I1(\g_detector.count [4]),
        .I2(\result[26]_i_3_n_0 ),
        .I3(\g_detector.count [3]),
        .I4(\result[26]_i_4_n_0 ),
        .O(result_d[26]));
  LUT6 #(
    .INIT(64'hAACCAACCF0FFF000)) 
    \result[26]_i_10 
       (.I0(data_q[19]),
        .I1(data_q[20]),
        .I2(data_q[21]),
        .I3(\g_detector.count [0]),
        .I4(data_q[22]),
        .I5(\g_detector.count [1]),
        .O(\result[26]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'h505F3030505F3F3F)) 
    \result[26]_i_11 
       (.I0(data_q[23]),
        .I1(data_q[24]),
        .I2(\g_detector.count [1]),
        .I3(data_q[25]),
        .I4(\g_detector.count [0]),
        .I5(data_q[26]),
        .O(\result[26]_i_11_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT5 #(
    .INIT(32'h03440377)) 
    \result[26]_i_2 
       (.I0(\result[26]_i_5_n_0 ),
        .I1(\g_detector.count [3]),
        .I2(\result[26]_i_6_n_0 ),
        .I3(\g_detector.count [2]),
        .I4(\result[26]_i_7_n_0 ),
        .O(\result[10]_i_1_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[26]_i_3 
       (.I0(\result[26]_i_8_n_0 ),
        .I1(\g_detector.count [2]),
        .I2(\result[26]_i_9_n_0 ),
        .O(\result[26]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'hA3)) 
    \result[26]_i_4 
       (.I0(\result[26]_i_10_n_0 ),
        .I1(\result[26]_i_11_n_0 ),
        .I2(\g_detector.count [2]),
        .O(\result[26]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'hCF44CF77)) 
    \result[26]_i_5 
       (.I0(data_q[0]),
        .I1(\g_detector.count [1]),
        .I2(data_q[1]),
        .I3(\g_detector.count [0]),
        .I4(data_q[2]),
        .O(\result[26]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h505F3030505F3F3F)) 
    \result[26]_i_6 
       (.I0(data_q[3]),
        .I1(data_q[4]),
        .I2(\g_detector.count [1]),
        .I3(data_q[5]),
        .I4(\g_detector.count [0]),
        .I5(data_q[6]),
        .O(\result[26]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h505F3030505F3F3F)) 
    \result[26]_i_7 
       (.I0(data_q[7]),
        .I1(data_q[8]),
        .I2(\g_detector.count [1]),
        .I3(data_q[9]),
        .I4(\g_detector.count [0]),
        .I5(data_q[10]),
        .O(\result[26]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hAACCAACCF0FFF000)) 
    \result[26]_i_8 
       (.I0(data_q[11]),
        .I1(data_q[12]),
        .I2(data_q[13]),
        .I3(\g_detector.count [0]),
        .I4(data_q[14]),
        .I5(\g_detector.count [1]),
        .O(\result[26]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hAACCAACCF0FFF000)) 
    \result[26]_i_9 
       (.I0(data_q[15]),
        .I1(data_q[16]),
        .I2(data_q[17]),
        .I3(\g_detector.count [0]),
        .I4(data_q[18]),
        .I5(\g_detector.count [1]),
        .O(\result[26]_i_9_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT5 #(
    .INIT(32'hFFFFF888)) 
    \result[27]_i_1 
       (.I0(\result[11]_i_1_n_0 ),
        .I1(\g_detector.count [4]),
        .I2(\result[27]_i_3_n_0 ),
        .I3(\g_detector.count [3]),
        .I4(\result[27]_i_4_n_0 ),
        .O(result_d[27]));
  LUT6 #(
    .INIT(64'h505F3030505F3F3F)) 
    \result[27]_i_10 
       (.I0(data_q[20]),
        .I1(data_q[21]),
        .I2(\g_detector.count [1]),
        .I3(data_q[22]),
        .I4(\g_detector.count [0]),
        .I5(data_q[23]),
        .O(\result[27]_i_10_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT5 #(
    .INIT(32'h038803BB)) 
    \result[27]_i_2 
       (.I0(\result[19]_i_2_n_0 ),
        .I1(\g_detector.count [3]),
        .I2(\result[27]_i_5_n_0 ),
        .I3(\g_detector.count [2]),
        .I4(\result[27]_i_6_n_0 ),
        .O(\result[11]_i_1_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[27]_i_3 
       (.I0(\result[27]_i_7_n_0 ),
        .I1(\g_detector.count [2]),
        .I2(\result[27]_i_8_n_0 ),
        .O(\result[27]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'hBA)) 
    \result[27]_i_4 
       (.I0(\result[27]_i_9_n_0 ),
        .I1(\result[27]_i_10_n_0 ),
        .I2(\g_detector.count [2]),
        .O(\result[27]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h505F3030505F3F3F)) 
    \result[27]_i_5 
       (.I0(data_q[4]),
        .I1(data_q[5]),
        .I2(\g_detector.count [1]),
        .I3(data_q[6]),
        .I4(\g_detector.count [0]),
        .I5(data_q[7]),
        .O(\result[27]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h505F3030505F3F3F)) 
    \result[27]_i_6 
       (.I0(data_q[8]),
        .I1(data_q[9]),
        .I2(\g_detector.count [1]),
        .I3(data_q[10]),
        .I4(\g_detector.count [0]),
        .I5(data_q[11]),
        .O(\result[27]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[27]_i_7 
       (.I0(data_q[12]),
        .I1(data_q[13]),
        .I2(\g_detector.count [1]),
        .I3(data_q[14]),
        .I4(\g_detector.count [0]),
        .I5(data_q[15]),
        .O(\result[27]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hAACCAACCF0FFF000)) 
    \result[27]_i_8 
       (.I0(data_q[16]),
        .I1(data_q[17]),
        .I2(data_q[18]),
        .I3(\g_detector.count [0]),
        .I4(data_q[19]),
        .I5(\g_detector.count [1]),
        .O(\result[27]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[27]_i_9 
       (.I0(data_q[24]),
        .I1(data_q[25]),
        .I2(\g_detector.count [1]),
        .I3(data_q[26]),
        .I4(\g_detector.count [0]),
        .I5(data_q[27]),
        .O(\result[27]_i_9_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT5 #(
    .INIT(32'hFFFF88F8)) 
    \result[28]_i_1 
       (.I0(\result[12]_i_1_n_0 ),
        .I1(\g_detector.count [4]),
        .I2(\g_detector.count [3]),
        .I3(\result[28]_i_3_n_0 ),
        .I4(\result[28]_i_4_n_0 ),
        .O(result_d[28]));
  LUT6 #(
    .INIT(64'h505F3030505F3F3F)) 
    \result[28]_i_10 
       (.I0(data_q[17]),
        .I1(data_q[18]),
        .I2(\g_detector.count [1]),
        .I3(data_q[19]),
        .I4(\g_detector.count [0]),
        .I5(data_q[20]),
        .O(\result[28]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[28]_i_11 
       (.I0(data_q[25]),
        .I1(data_q[26]),
        .I2(\g_detector.count [1]),
        .I3(data_q[27]),
        .I4(\g_detector.count [0]),
        .I5(data_q[28]),
        .O(\result[28]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'h505F3030505F3F3F)) 
    \result[28]_i_12 
       (.I0(data_q[21]),
        .I1(data_q[22]),
        .I2(\g_detector.count [1]),
        .I3(data_q[23]),
        .I4(\g_detector.count [0]),
        .I5(data_q[24]),
        .O(\result[28]_i_12_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT6 #(
    .INIT(64'h505F3030505F3F3F)) 
    \result[28]_i_2 
       (.I0(\result[28]_i_5_n_0 ),
        .I1(\result[28]_i_6_n_0 ),
        .I2(\g_detector.count [3]),
        .I3(\result[28]_i_7_n_0 ),
        .I4(\g_detector.count [2]),
        .I5(\result[28]_i_8_n_0 ),
        .O(\result[12]_i_1_n_0 ));
  LUT3 #(
    .INIT(8'hAC)) 
    \result[28]_i_3 
       (.I0(\result[28]_i_9_n_0 ),
        .I1(\result[28]_i_10_n_0 ),
        .I2(\g_detector.count [2]),
        .O(\result[28]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'hBA)) 
    \result[28]_i_4 
       (.I0(\result[28]_i_11_n_0 ),
        .I1(\result[28]_i_12_n_0 ),
        .I2(\g_detector.count [2]),
        .O(\result[28]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'hFB)) 
    \result[28]_i_5 
       (.I0(\g_detector.count [1]),
        .I1(data_q[0]),
        .I2(\g_detector.count [0]),
        .O(\result[28]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h505F3030505F3F3F)) 
    \result[28]_i_6 
       (.I0(data_q[1]),
        .I1(data_q[2]),
        .I2(\g_detector.count [1]),
        .I3(data_q[3]),
        .I4(\g_detector.count [0]),
        .I5(data_q[4]),
        .O(\result[28]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h505F3030505F3F3F)) 
    \result[28]_i_7 
       (.I0(data_q[5]),
        .I1(data_q[6]),
        .I2(\g_detector.count [1]),
        .I3(data_q[7]),
        .I4(\g_detector.count [0]),
        .I5(data_q[8]),
        .O(\result[28]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h505F3030505F3F3F)) 
    \result[28]_i_8 
       (.I0(data_q[9]),
        .I1(data_q[10]),
        .I2(\g_detector.count [1]),
        .I3(data_q[11]),
        .I4(\g_detector.count [0]),
        .I5(data_q[12]),
        .O(\result[28]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'h505F3030505F3F3F)) 
    \result[28]_i_9 
       (.I0(data_q[13]),
        .I1(data_q[14]),
        .I2(\g_detector.count [1]),
        .I3(data_q[15]),
        .I4(\g_detector.count [0]),
        .I5(data_q[16]),
        .O(\result[28]_i_9_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT5 #(
    .INIT(32'hFFFFF888)) 
    \result[29]_i_1 
       (.I0(\result[13]_i_1_n_0 ),
        .I1(\g_detector.count [4]),
        .I2(\result[29]_i_3_n_0 ),
        .I3(\g_detector.count [3]),
        .I4(\result[29]_i_4_n_0 ),
        .O(result_d[29]));
  LUT6 #(
    .INIT(64'hAACCAACCF0FFF000)) 
    \result[29]_i_10 
       (.I0(data_q[18]),
        .I1(data_q[19]),
        .I2(data_q[20]),
        .I3(\g_detector.count [0]),
        .I4(data_q[21]),
        .I5(\g_detector.count [1]),
        .O(\result[29]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFA08888FFA0)) 
    \result[29]_i_11 
       (.I0(\g_detector.count [1]),
        .I1(data_q[26]),
        .I2(data_q[27]),
        .I3(data_q[29]),
        .I4(\g_detector.count [0]),
        .I5(data_q[28]),
        .O(\result[29]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'h05F5030305F5F3F3)) 
    \result[29]_i_12 
       (.I0(data_q[24]),
        .I1(data_q[25]),
        .I2(\g_detector.count [1]),
        .I3(data_q[22]),
        .I4(\g_detector.count [0]),
        .I5(data_q[23]),
        .O(\result[29]_i_12_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT6 #(
    .INIT(64'h505F3030505F3F3F)) 
    \result[29]_i_2 
       (.I0(\result[29]_i_5_n_0 ),
        .I1(\result[29]_i_6_n_0 ),
        .I2(\g_detector.count [3]),
        .I3(\result[29]_i_7_n_0 ),
        .I4(\g_detector.count [2]),
        .I5(\result[29]_i_8_n_0 ),
        .O(\result[13]_i_1_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[29]_i_3 
       (.I0(\result[29]_i_9_n_0 ),
        .I1(\g_detector.count [2]),
        .I2(\result[29]_i_10_n_0 ),
        .O(\result[29]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'hBA)) 
    \result[29]_i_4 
       (.I0(\result[29]_i_11_n_0 ),
        .I1(\result[29]_i_12_n_0 ),
        .I2(\g_detector.count [2]),
        .O(\result[29]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'hABFB)) 
    \result[29]_i_5 
       (.I0(\g_detector.count [1]),
        .I1(data_q[1]),
        .I2(\g_detector.count [0]),
        .I3(data_q[0]),
        .O(\result[29]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h505F3030505F3F3F)) 
    \result[29]_i_6 
       (.I0(data_q[2]),
        .I1(data_q[3]),
        .I2(\g_detector.count [1]),
        .I3(data_q[4]),
        .I4(\g_detector.count [0]),
        .I5(data_q[5]),
        .O(\result[29]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h505F3030505F3F3F)) 
    \result[29]_i_7 
       (.I0(data_q[6]),
        .I1(data_q[7]),
        .I2(\g_detector.count [1]),
        .I3(data_q[8]),
        .I4(\g_detector.count [0]),
        .I5(data_q[9]),
        .O(\result[29]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h505F3030505F3F3F)) 
    \result[29]_i_8 
       (.I0(data_q[10]),
        .I1(data_q[11]),
        .I2(\g_detector.count [1]),
        .I3(data_q[12]),
        .I4(\g_detector.count [0]),
        .I5(data_q[13]),
        .O(\result[29]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hAACCAACCF0FFF000)) 
    \result[29]_i_9 
       (.I0(data_q[14]),
        .I1(data_q[15]),
        .I2(data_q[16]),
        .I3(\g_detector.count [0]),
        .I4(data_q[17]),
        .I5(\g_detector.count [1]),
        .O(\result[29]_i_9_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair29" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \result[2]_i_1 
       (.I0(\result[18]_i_2_n_0 ),
        .I1(\g_detector.count [3]),
        .O(\result[2]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFF54FF540054FF54)) 
    \result[31]_i_1 
       (.I0(\result[32]_i_3_n_0 ),
        .I1(\result[31]_i_2_n_0 ),
        .I2(\result[31]_i_3_n_0 ),
        .I3(\result[36]_i_2_n_0 ),
        .I4(\result[31]_i_4_n_0 ),
        .I5(\result[31]_i_5_n_0 ),
        .O(\g_detector.count [0]));
  LUT3 #(
    .INIT(8'hBA)) 
    \result[31]_i_10 
       (.I0(data_q[18]),
        .I1(data_q[17]),
        .I2(data_q[16]),
        .O(\result[31]_i_10_n_0 ));
  LUT4 #(
    .INIT(16'h5504)) 
    \result[31]_i_11 
       (.I0(data_q[26]),
        .I1(data_q[23]),
        .I2(data_q[24]),
        .I3(data_q[25]),
        .O(\result[31]_i_11_n_0 ));
  LUT5 #(
    .INIT(32'h00044404)) 
    \result[31]_i_2 
       (.I0(\result[36]_i_6_n_0 ),
        .I1(\result[33]_i_6_n_0 ),
        .I2(\result[31]_i_6_n_0 ),
        .I3(\result[36]_i_3_n_0 ),
        .I4(\result[31]_i_7_n_0 ),
        .O(\result[31]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'h22332232)) 
    \result[31]_i_3 
       (.I0(data_q[13]),
        .I1(data_q[14]),
        .I2(data_q[11]),
        .I3(data_q[12]),
        .I4(\result[31]_i_8_n_0 ),
        .O(\result[31]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hFFFEEEFE)) 
    \result[31]_i_4 
       (.I0(\result[33]_i_3_n_0 ),
        .I1(\result[33]_i_5_n_0 ),
        .I2(\result[31]_i_9_n_0 ),
        .I3(\result[33]_i_4_n_0 ),
        .I4(\result[31]_i_10_n_0 ),
        .O(\result[31]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'h22332232)) 
    \result[31]_i_5 
       (.I0(data_q[29]),
        .I1(data_q[30]),
        .I2(data_q[27]),
        .I3(data_q[28]),
        .I4(\result[31]_i_11_n_0 ),
        .O(\result[31]_i_5_n_0 ));
  LUT3 #(
    .INIT(8'hBA)) 
    \result[31]_i_6 
       (.I0(data_q[6]),
        .I1(data_q[5]),
        .I2(data_q[4]),
        .O(\result[31]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'hBA)) 
    \result[31]_i_7 
       (.I0(data_q[2]),
        .I1(data_q[1]),
        .I2(data_q[0]),
        .O(\result[31]_i_7_n_0 ));
  LUT4 #(
    .INIT(16'h5504)) 
    \result[31]_i_8 
       (.I0(data_q[10]),
        .I1(data_q[7]),
        .I2(data_q[8]),
        .I3(data_q[9]),
        .O(\result[31]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'hBA)) 
    \result[31]_i_9 
       (.I0(data_q[22]),
        .I1(data_q[21]),
        .I2(data_q[20]),
        .O(\result[31]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h0000FF0010101010)) 
    \result[32]_i_1 
       (.I0(\result[32]_i_2_n_0 ),
        .I1(\result[32]_i_3_n_0 ),
        .I2(\result[32]_i_4_n_0 ),
        .I3(\result[32]_i_5_n_0 ),
        .I4(\result[32]_i_6_n_0 ),
        .I5(\result[36]_i_2_n_0 ),
        .O(\g_detector.count [1]));
  LUT2 #(
    .INIT(4'hE)) 
    \result[32]_i_2 
       (.I0(data_q[14]),
        .I1(data_q[13]),
        .O(\result[32]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0000000400000000)) 
    \result[32]_i_3 
       (.I0(\result[36]_i_6_n_0 ),
        .I1(\result[33]_i_6_n_0 ),
        .I2(data_q[0]),
        .I3(data_q[1]),
        .I4(data_q[2]),
        .I5(\result[36]_i_3_n_0 ),
        .O(\result[32]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFEEEFEEEEEEEF)) 
    \result[32]_i_4 
       (.I0(data_q[11]),
        .I1(data_q[12]),
        .I2(data_q[9]),
        .I3(data_q[10]),
        .I4(\result[33]_i_6_n_0 ),
        .I5(\result[32]_i_7_n_0 ),
        .O(\result[32]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hEEFEEEFEEEFEFFFE)) 
    \result[32]_i_5 
       (.I0(data_q[27]),
        .I1(data_q[28]),
        .I2(\result[32]_i_8_n_0 ),
        .I3(\result[33]_i_3_n_0 ),
        .I4(data_q[25]),
        .I5(data_q[26]),
        .O(\result[32]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \result[32]_i_6 
       (.I0(data_q[30]),
        .I1(data_q[29]),
        .O(\result[32]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h1110111011101111)) 
    \result[32]_i_7 
       (.I0(data_q[5]),
        .I1(data_q[6]),
        .I2(data_q[4]),
        .I3(data_q[3]),
        .I4(data_q[2]),
        .I5(data_q[1]),
        .O(\result[32]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h1110111011101111)) 
    \result[32]_i_8 
       (.I0(data_q[21]),
        .I1(data_q[22]),
        .I2(data_q[20]),
        .I3(data_q[19]),
        .I4(data_q[18]),
        .I5(data_q[17]),
        .O(\result[32]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'h02020202A2A2A202)) 
    \result[33]_i_1 
       (.I0(\g_detector.found ),
        .I1(\result[33]_i_2_n_0 ),
        .I2(\result[36]_i_2_n_0 ),
        .I3(\result[33]_i_3_n_0 ),
        .I4(\result[33]_i_4_n_0 ),
        .I5(\result[33]_i_5_n_0 ),
        .O(\g_detector.count [2]));
  LUT6 #(
    .INIT(64'hFFFEFFFFFFFEFFFE)) 
    \result[33]_i_2 
       (.I0(data_q[12]),
        .I1(data_q[11]),
        .I2(data_q[14]),
        .I3(data_q[13]),
        .I4(\result[36]_i_3_n_0 ),
        .I5(\result[33]_i_6_n_0 ),
        .O(\result[33]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \result[33]_i_3 
       (.I0(data_q[23]),
        .I1(data_q[24]),
        .I2(data_q[25]),
        .I3(data_q[26]),
        .O(\result[33]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'h0001)) 
    \result[33]_i_4 
       (.I0(data_q[21]),
        .I1(data_q[22]),
        .I2(data_q[19]),
        .I3(data_q[20]),
        .O(\result[33]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \result[33]_i_5 
       (.I0(data_q[29]),
        .I1(data_q[30]),
        .I2(data_q[27]),
        .I3(data_q[28]),
        .O(\result[33]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'h0001)) 
    \result[33]_i_6 
       (.I0(data_q[9]),
        .I1(data_q[10]),
        .I2(data_q[7]),
        .I3(data_q[8]),
        .O(\result[33]_i_6_n_0 ));
  LUT4 #(
    .INIT(16'h00A8)) 
    \result[34]_i_1 
       (.I0(\g_detector.found ),
        .I1(\result[34]_i_2_n_0 ),
        .I2(\result[36]_i_4_n_0 ),
        .I3(\result[34]_i_3_n_0 ),
        .O(\g_detector.count [3]));
  LUT5 #(
    .INIT(32'hFFFEFFFF)) 
    \result[34]_i_2 
       (.I0(data_q[16]),
        .I1(data_q[15]),
        .I2(data_q[18]),
        .I3(data_q[17]),
        .I4(\result[33]_i_4_n_0 ),
        .O(\result[34]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    \result[34]_i_3 
       (.I0(data_q[28]),
        .I1(data_q[27]),
        .I2(data_q[30]),
        .I3(data_q[29]),
        .I4(\result[33]_i_3_n_0 ),
        .O(\result[34]_i_3_n_0 ));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT6 #(
    .INIT(64'h5555555155555555)) 
    \result[35]_i_2 
       (.I0(\result[36]_i_2_n_0 ),
        .I1(\result[36]_i_3_n_0 ),
        .I2(data_q[2]),
        .I3(data_q[1]),
        .I4(data_q[0]),
        .I5(\result[36]_i_4_n_0 ),
        .O(\g_detector.count [4]));
  LUT6 #(
    .INIT(64'hFFFFFFFBFFFFFFFF)) 
    \result[36]_i_1 
       (.I0(\result[36]_i_2_n_0 ),
        .I1(\result[36]_i_3_n_0 ),
        .I2(data_q[2]),
        .I3(data_q[1]),
        .I4(data_q[0]),
        .I5(\result[36]_i_4_n_0 ),
        .O(\g_detector.found ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFEF)) 
    \result[36]_i_2 
       (.I0(\result[33]_i_3_n_0 ),
        .I1(\result[33]_i_5_n_0 ),
        .I2(\result[33]_i_4_n_0 ),
        .I3(\result[36]_i_5_n_0 ),
        .I4(data_q[15]),
        .I5(data_q[16]),
        .O(\result[36]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'h0001)) 
    \result[36]_i_3 
       (.I0(data_q[5]),
        .I1(data_q[6]),
        .I2(data_q[3]),
        .I3(data_q[4]),
        .O(\result[36]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'h00000001)) 
    \result[36]_i_4 
       (.I0(data_q[8]),
        .I1(data_q[7]),
        .I2(data_q[10]),
        .I3(data_q[9]),
        .I4(\result[36]_i_6_n_0 ),
        .O(\result[36]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \result[36]_i_5 
       (.I0(data_q[18]),
        .I1(data_q[17]),
        .O(\result[36]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \result[36]_i_6 
       (.I0(data_q[13]),
        .I1(data_q[14]),
        .I2(data_q[11]),
        .I3(data_q[12]),
        .O(\result[36]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h04)) 
    \result[3]_i_1 
       (.I0(\g_detector.count [3]),
        .I1(\result[19]_i_2_n_0 ),
        .I2(\g_detector.count [2]),
        .O(\result[3]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair29" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \result[4]_i_1 
       (.I0(\result[20]_i_2_n_0 ),
        .I1(\g_detector.count [3]),
        .O(\result[4]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair28" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \result[5]_i_1 
       (.I0(\result[21]_i_2_n_0 ),
        .I1(\g_detector.count [3]),
        .O(\result[5]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair22" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \result[6]_i_1 
       (.I0(\result[22]_i_2_n_0 ),
        .I1(\g_detector.count [3]),
        .O(\result[6]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair28" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \result[7]_i_1 
       (.I0(\result[23]_i_2_n_0 ),
        .I1(\g_detector.count [3]),
        .O(\result[7]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[0] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[0]_i_1_n_0 ),
        .Q(result[0]),
        .R(\g_detector.count [4]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[10] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[10]_i_1_n_0 ),
        .Q(result[10]),
        .R(\g_detector.count [4]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[11] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[11]_i_1_n_0 ),
        .Q(result[11]),
        .R(\g_detector.count [4]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[12] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[12]_i_1_n_0 ),
        .Q(result[12]),
        .R(\g_detector.count [4]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[13] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[13]_i_1_n_0 ),
        .Q(result[13]),
        .R(\g_detector.count [4]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[14] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[14]_i_1_n_0 ),
        .Q(result[14]),
        .R(\g_detector.count [4]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[15] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[15]),
        .Q(result[15]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[16] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[16]),
        .Q(result[16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[17] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[17]),
        .Q(result[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[18] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[18]),
        .Q(result[18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[19] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[19]),
        .Q(result[19]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[1] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[1]_i_1_n_0 ),
        .Q(result[1]),
        .R(\g_detector.count [4]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[20] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[20]),
        .Q(result[20]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[21] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[21]),
        .Q(result[21]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[22] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[22]),
        .Q(result[22]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[23] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[23]),
        .Q(result[23]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[24] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[24]),
        .Q(result[24]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[25] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[25]),
        .Q(result[25]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[26] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[26]),
        .Q(result[26]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[27] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[27]),
        .Q(result[27]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[28] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[28]),
        .Q(result[28]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[29] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[29]),
        .Q(result[29]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[2] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[2]_i_1_n_0 ),
        .Q(result[2]),
        .R(\g_detector.count [4]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[31] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\g_detector.count [0]),
        .Q(result[30]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[32] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\g_detector.count [1]),
        .Q(result[31]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[33] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\g_detector.count [2]),
        .Q(result[32]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[34] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\g_detector.count [3]),
        .Q(result[33]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[35] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\g_detector.count [4]),
        .Q(result[34]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[36] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\g_detector.found ),
        .Q(result[35]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[3] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[3]_i_1_n_0 ),
        .Q(result[3]),
        .R(\g_detector.count [4]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[4] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[4]_i_1_n_0 ),
        .Q(result[4]),
        .R(\g_detector.count [4]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[5] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[5]_i_1_n_0 ),
        .Q(result[5]),
        .R(\g_detector.count [4]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[6] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[6]_i_1_n_0 ),
        .Q(result[6]),
        .R(\g_detector.count [4]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[7] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[7]_i_1_n_0 ),
        .Q(result[7]),
        .R(\g_detector.count [4]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[8] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[8]_i_1_n_0 ),
        .Q(result[8]),
        .R(\g_detector.count [4]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[9] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[9]_i_1_n_0 ),
        .Q(result[9]),
        .R(\g_detector.count [4]));
endmodule

(* ARITH = "0" *) (* ECO_CHECKSUM = "91ea71cf" *) (* FILL_KIND = "0" *) 
(* KIND = "3" *) (* MODE = "0" *) (* N = "31" *) 
(* RESULT_W = "37" *) (* SHIFT_W = "5" *) 
(* NotValidForBitStream *)
(* \DesignAttr:ENABLE_NOC_NETLIST_VIEW  *) 
(* \DesignAttr:ENABLE_AIE_NETLIST_VIEW  *) 
module primitive_v2_top
   (clk,
    data,
    amount,
    fill_val,
    result);
  input clk;
  input [30:0]data;
  input [4:0]amount;
  input fill_val;
  output [36:0]result;

  wire clk;
  wire clk_core;
  wire [30:0]data;
  wire [35:0]\^result ;

  assign result[36] = \^result [30];
  assign result[35:0] = \^result [35:0];
  primitive_v2_boundary u_boundary
       (.clk_core(clk_core),
        .data(data),
        .result({\^result [30],\^result [35:31],\^result [29:0]}));
  (* BOX_TYPE = "PRIMITIVE" *) 
  BUFG u_clock
       (.I(clk),
        .O(clk_core));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
