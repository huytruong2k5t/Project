#include <cassert>
#include <iostream>
#include "posit_fused_window.hpp"
#include "week12_fused_reference.hpp"
int main(){
 l1::IterConfig cfg;cfg.ops=1;cfg.rounding=l1::RoundMode::RNE;
 for(unsigned n=1;n<=8;++n){cfg.n=n;
  const auto p=l1::L1MultiplierIter<32,3,12>::mul(1291845632u,964689920u,cfg).prepack;
  const auto a=l1::FusedWindow<32,3,12,32>::add(p,1006632960u);
  const auto b=l1::FusedWindow<32,3,12,32>::add(p,3019898880u);
  assert(a.bits==1205862400u && b.bits==3077570560u);
 }
 std::cout<<"TV-FUSE-01=3.9375 TV-FUSE-02=-4.5625 n1..8 PASS\n";
}
