// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2026.1 (win64) Build 6511674 Tue Jun 16 11:02:23 MDT 2026
// Date        : Fri Oct 16 16:24:12 2026
// Host        : MSI running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim {C:/HCMUT/HK261/Do an
//               2/Posit_MAC/results/primitive_v2_20261016/xc7a100tcsg324-1/release/baseline_n12_k4_m0_a0_f0_w4_explore/functional_netlist.v}
// Design      : primitive_v2_top
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a100tcsg324-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module primitive_v2_boundary
   (result,
    data,
    clk_core);
  output [15:0]result;
  input [11:0]data;
  input clk_core;

  wire clk_core;
  wire [11:0]data;
  wire [11:0]data_q;
  wire [15:0]result;
  wire \result[10]_i_2_n_0 ;
  wire \result[10]_i_3_n_0 ;
  wire \result[11]_i_2_n_0 ;
  wire \result[11]_i_3_n_0 ;
  wire \result[12]_i_1_n_0 ;
  wire \result[12]_i_2_n_0 ;
  wire \result[13]_i_1_n_0 ;
  wire \result[13]_i_2_n_0 ;
  wire \result[14]_i_1_n_0 ;
  wire \result[14]_i_2_n_0 ;
  wire \result[15]_i_1_n_0 ;
  wire \result[15]_i_2_n_0 ;
  wire \result[16]_i_1_n_0 ;
  wire \result[16]_i_2_n_0 ;
  wire \result[1]_i_1_n_0 ;
  wire \result[4]_i_2_n_0 ;
  wire \result[5]_i_2_n_0 ;
  wire \result[6]_i_2_n_0 ;
  wire \result[6]_i_3_n_0 ;
  wire \result[7]_i_2_n_0 ;
  wire \result[7]_i_3_n_0 ;
  wire \result[8]_i_2_n_0 ;
  wire \result[8]_i_3_n_0 ;
  wire \result[8]_i_4_n_0 ;
  wire \result[9]_i_2_n_0 ;
  wire \result[9]_i_3_n_0 ;
  wire \result[9]_i_4_n_0 ;
  wire [11:2]result_d;

  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[0] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[0]),
        .Q(data_q[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[10] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[10]),
        .Q(data_q[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[11] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[11]),
        .Q(data_q[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[1] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[1]),
        .Q(data_q[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[2] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[2]),
        .Q(data_q[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[3] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[3]),
        .Q(data_q[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[4] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[4]),
        .Q(data_q[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[5] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[5]),
        .Q(data_q[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[6] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[6]),
        .Q(data_q[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[7] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[7]),
        .Q(data_q[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[8] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[8]),
        .Q(data_q[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[9] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[9]),
        .Q(data_q[9]),
        .R(1'b0));
  LUT6 #(
    .INIT(64'hEFEA4545EFEA4040)) 
    \result[10]_i_1 
       (.I0(data_q[11]),
        .I1(data_q[8]),
        .I2(data_q[10]),
        .I3(data_q[7]),
        .I4(data_q[9]),
        .I5(\result[10]_i_2_n_0 ),
        .O(result_d[10]));
  LUT6 #(
    .INIT(64'hEFEA4545EFEA4040)) 
    \result[10]_i_2 
       (.I0(data_q[8]),
        .I1(data_q[5]),
        .I2(data_q[7]),
        .I3(data_q[4]),
        .I4(data_q[6]),
        .I5(\result[10]_i_3_n_0 ),
        .O(\result[10]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFE55BA00FE44BA00)) 
    \result[10]_i_3 
       (.I0(data_q[5]),
        .I1(data_q[4]),
        .I2(data_q[1]),
        .I3(data_q[3]),
        .I4(data_q[2]),
        .I5(data_q[0]),
        .O(\result[10]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'hE5E0)) 
    \result[11]_i_1 
       (.I0(data_q[11]),
        .I1(data_q[9]),
        .I2(data_q[10]),
        .I3(\result[11]_i_2_n_0 ),
        .O(result_d[11]));
  LUT6 #(
    .INIT(64'hD9D8C9C9D9D8C8C8)) 
    \result[11]_i_2 
       (.I0(data_q[9]),
        .I1(data_q[8]),
        .I2(data_q[7]),
        .I3(data_q[5]),
        .I4(data_q[6]),
        .I5(\result[11]_i_3_n_0 ),
        .O(\result[11]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hD9D9C9C8D8D8C8C8)) 
    \result[11]_i_3 
       (.I0(data_q[5]),
        .I1(data_q[4]),
        .I2(data_q[3]),
        .I3(data_q[0]),
        .I4(data_q[2]),
        .I5(data_q[1]),
        .O(\result[11]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF55551110)) 
    \result[12]_i_1 
       (.I0(data_q[9]),
        .I1(data_q[7]),
        .I2(\result[12]_i_2_n_0 ),
        .I3(data_q[6]),
        .I4(data_q[8]),
        .I5(data_q[10]),
        .O(\result[12]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h00000000AAAAEEFE)) 
    \result[12]_i_2 
       (.I0(data_q[4]),
        .I1(data_q[2]),
        .I2(data_q[0]),
        .I3(data_q[1]),
        .I4(data_q[3]),
        .I5(data_q[5]),
        .O(\result[12]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000FFFFAABA)) 
    \result[13]_i_1 
       (.I0(data_q[9]),
        .I1(data_q[7]),
        .I2(\result[13]_i_2_n_0 ),
        .I3(data_q[6]),
        .I4(data_q[8]),
        .I5(data_q[10]),
        .O(\result[13]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFAAAABBBA)) 
    \result[13]_i_2 
       (.I0(data_q[4]),
        .I1(data_q[2]),
        .I2(data_q[1]),
        .I3(data_q[0]),
        .I4(data_q[3]),
        .I5(data_q[5]),
        .O(\result[13]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \result[14]_i_1 
       (.I0(\result[14]_i_2_n_0 ),
        .I1(data_q[10]),
        .O(\result[14]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000055555554)) 
    \result[14]_i_2 
       (.I0(data_q[8]),
        .I1(data_q[6]),
        .I2(data_q[4]),
        .I3(data_q[5]),
        .I4(data_q[7]),
        .I5(data_q[9]),
        .O(\result[14]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000010)) 
    \result[15]_i_1 
       (.I0(data_q[9]),
        .I1(data_q[7]),
        .I2(\result[15]_i_2_n_0 ),
        .I3(data_q[6]),
        .I4(data_q[8]),
        .I5(data_q[10]),
        .O(\result[15]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000055555554)) 
    \result[15]_i_2 
       (.I0(data_q[4]),
        .I1(data_q[0]),
        .I2(data_q[2]),
        .I3(data_q[1]),
        .I4(data_q[3]),
        .I5(data_q[5]),
        .O(\result[15]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \result[16]_i_1 
       (.I0(data_q[9]),
        .I1(data_q[7]),
        .I2(\result[16]_i_2_n_0 ),
        .I3(data_q[6]),
        .I4(data_q[8]),
        .I5(data_q[10]),
        .O(\result[16]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \result[16]_i_2 
       (.I0(data_q[4]),
        .I1(data_q[0]),
        .I2(data_q[2]),
        .I3(data_q[1]),
        .I4(data_q[3]),
        .I5(data_q[5]),
        .O(\result[16]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \result[1]_i_1 
       (.I0(data_q[0]),
        .I1(data_q[11]),
        .O(\result[1]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'hB888)) 
    \result[2]_i_1 
       (.I0(data_q[1]),
        .I1(data_q[11]),
        .I2(data_q[0]),
        .I3(data_q[10]),
        .O(result_d[2]));
  LUT6 #(
    .INIT(64'hB8BBB888B888B888)) 
    \result[3]_i_1 
       (.I0(data_q[2]),
        .I1(data_q[11]),
        .I2(data_q[1]),
        .I3(data_q[10]),
        .I4(data_q[0]),
        .I5(data_q[9]),
        .O(result_d[3]));
  LUT3 #(
    .INIT(8'hB8)) 
    \result[4]_i_1 
       (.I0(data_q[3]),
        .I1(data_q[11]),
        .I2(\result[4]_i_2_n_0 ),
        .O(result_d[4]));
  LUT6 #(
    .INIT(64'hB8BBB888B888B888)) 
    \result[4]_i_2 
       (.I0(data_q[2]),
        .I1(data_q[10]),
        .I2(data_q[1]),
        .I3(data_q[9]),
        .I4(data_q[0]),
        .I5(data_q[8]),
        .O(\result[4]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[5]_i_1 
       (.I0(data_q[4]),
        .I1(data_q[11]),
        .I2(data_q[3]),
        .I3(data_q[10]),
        .I4(\result[5]_i_2_n_0 ),
        .O(result_d[5]));
  LUT6 #(
    .INIT(64'hB8BBB888B888B888)) 
    \result[5]_i_2 
       (.I0(data_q[2]),
        .I1(data_q[9]),
        .I2(data_q[1]),
        .I3(data_q[8]),
        .I4(data_q[0]),
        .I5(data_q[7]),
        .O(\result[5]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \result[6]_i_1 
       (.I0(data_q[5]),
        .I1(data_q[11]),
        .I2(\result[6]_i_2_n_0 ),
        .O(result_d[6]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[6]_i_2 
       (.I0(data_q[4]),
        .I1(data_q[10]),
        .I2(data_q[3]),
        .I3(data_q[9]),
        .I4(\result[6]_i_3_n_0 ),
        .O(\result[6]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hB8BBB888B888B888)) 
    \result[6]_i_3 
       (.I0(data_q[2]),
        .I1(data_q[8]),
        .I2(data_q[1]),
        .I3(data_q[7]),
        .I4(data_q[0]),
        .I5(data_q[6]),
        .O(\result[6]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[7]_i_1 
       (.I0(data_q[6]),
        .I1(data_q[11]),
        .I2(data_q[5]),
        .I3(data_q[10]),
        .I4(\result[7]_i_2_n_0 ),
        .O(result_d[7]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[7]_i_2 
       (.I0(data_q[4]),
        .I1(data_q[9]),
        .I2(data_q[3]),
        .I3(data_q[8]),
        .I4(\result[7]_i_3_n_0 ),
        .O(\result[7]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hB8BBB888B888B888)) 
    \result[7]_i_3 
       (.I0(data_q[2]),
        .I1(data_q[7]),
        .I2(data_q[1]),
        .I3(data_q[6]),
        .I4(data_q[0]),
        .I5(data_q[5]),
        .O(\result[7]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \result[8]_i_1 
       (.I0(data_q[7]),
        .I1(data_q[11]),
        .I2(\result[8]_i_2_n_0 ),
        .O(result_d[8]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[8]_i_2 
       (.I0(data_q[6]),
        .I1(data_q[10]),
        .I2(data_q[5]),
        .I3(data_q[9]),
        .I4(\result[8]_i_3_n_0 ),
        .O(\result[8]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[8]_i_3 
       (.I0(data_q[4]),
        .I1(data_q[8]),
        .I2(data_q[3]),
        .I3(data_q[7]),
        .I4(\result[8]_i_4_n_0 ),
        .O(\result[8]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hB8BBB888B888B888)) 
    \result[8]_i_4 
       (.I0(data_q[2]),
        .I1(data_q[6]),
        .I2(data_q[1]),
        .I3(data_q[5]),
        .I4(data_q[0]),
        .I5(data_q[4]),
        .O(\result[8]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[9]_i_1 
       (.I0(data_q[8]),
        .I1(data_q[11]),
        .I2(data_q[7]),
        .I3(data_q[10]),
        .I4(\result[9]_i_2_n_0 ),
        .O(result_d[9]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[9]_i_2 
       (.I0(data_q[6]),
        .I1(data_q[9]),
        .I2(data_q[5]),
        .I3(data_q[8]),
        .I4(\result[9]_i_3_n_0 ),
        .O(\result[9]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[9]_i_3 
       (.I0(data_q[4]),
        .I1(data_q[7]),
        .I2(data_q[3]),
        .I3(data_q[6]),
        .I4(\result[9]_i_4_n_0 ),
        .O(\result[9]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hB8BBB888B888B888)) 
    \result[9]_i_4 
       (.I0(data_q[2]),
        .I1(data_q[5]),
        .I2(data_q[1]),
        .I3(data_q[4]),
        .I4(data_q[0]),
        .I5(data_q[3]),
        .O(\result[9]_i_4_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[10] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[10]),
        .Q(result[9]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[11] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[11]),
        .Q(result[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[12] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[12]_i_1_n_0 ),
        .Q(result[11]),
        .R(data_q[11]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[13] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[13]_i_1_n_0 ),
        .Q(result[12]),
        .R(data_q[11]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[14] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[14]_i_1_n_0 ),
        .Q(result[13]),
        .R(data_q[11]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[15] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[15]_i_1_n_0 ),
        .Q(result[14]),
        .R(data_q[11]));
  FDSE #(
    .INIT(1'b1)) 
    \result_reg[16] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[16]_i_1_n_0 ),
        .Q(result[15]),
        .S(data_q[11]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[1] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[1]_i_1_n_0 ),
        .Q(result[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[2] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[2]),
        .Q(result[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[3] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[3]),
        .Q(result[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[4] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[4]),
        .Q(result[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[5] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[5]),
        .Q(result[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[6] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[6]),
        .Q(result[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[7] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[7]),
        .Q(result[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[8] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[8]),
        .Q(result[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[9] 
       (.C(clk_core),
        .CE(1'b1),
        .D(result_d[9]),
        .Q(result[8]),
        .R(1'b0));
endmodule

(* ARITH = "0" *) (* ECO_CHECKSUM = "b9fb1aa7" *) (* FILL_KIND = "0" *) 
(* KIND = "4" *) (* MODE = "0" *) (* N = "12" *) 
(* RESULT_W = "17" *) (* SHIFT_W = "4" *) 
(* NotValidForBitStream *)
(* \DesignAttr:ENABLE_NOC_NETLIST_VIEW  *) 
(* \DesignAttr:ENABLE_AIE_NETLIST_VIEW  *) 
module primitive_v2_top
   (clk,
    data,
    amount,
    fill_val,
    result);
  input clk;
  input [11:0]data;
  input [3:0]amount;
  input fill_val;
  output [16:0]result;

  wire \<const0> ;
  wire clk;
  wire clk_core;
  wire [11:0]data;
  wire [16:1]\^result ;

  assign result[16:1] = \^result [16:1];
  assign result[0] = \<const0> ;
  GND GND
       (.G(\<const0> ));
  primitive_v2_boundary u_boundary
       (.clk_core(clk_core),
        .data(data),
        .result(\^result ));
  (* BOX_TYPE = "PRIMITIVE" *) 
  BUFG u_clock
       (.I(clk),
        .O(clk_core));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
