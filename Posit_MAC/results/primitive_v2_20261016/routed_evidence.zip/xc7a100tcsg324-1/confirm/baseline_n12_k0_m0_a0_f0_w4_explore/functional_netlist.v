// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2026.1 (win64) Build 6511674 Tue Jun 16 11:02:23 MDT 2026
// Date        : Fri Oct 16 15:29:27 2026
// Host        : MSI running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim {C:/HCMUT/HK261/Do an
//               2/Posit_MAC/results/primitive_v2_20261016/xc7a100tcsg324-1/confirm/baseline_n12_k0_m0_a0_f0_w4_explore/functional_netlist.v}
// Design      : primitive_v2_top
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a100tcsg324-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module primitive_v2_boundary
   (result,
    data,
    clk_core,
    amount);
  output [11:0]result;
  input [11:0]data;
  input clk_core;
  input [3:0]amount;

  wire [3:0]amount;
  wire clk_core;
  wire [11:0]data;
  wire [11:0]data_q;
  wire \g_multi_bit.is_overflow ;
  wire [11:2]\g_multi_bit.stage[2] ;
  wire [11:8]\g_multi_bit.stage[4] ;
  wire [3:0]\g_shift.amount_q ;
  wire [11:0]result;
  wire \result[0]_i_1_n_0 ;
  wire \result[10]_i_2_n_0 ;
  wire \result[1]_i_1_n_0 ;
  wire \result[2]_i_1_n_0 ;
  wire \result[3]_i_1_n_0 ;
  wire \result[4]_i_1_n_0 ;
  wire \result[5]_i_1_n_0 ;
  wire \result[5]_i_2_n_0 ;
  wire \result[6]_i_1_n_0 ;
  wire \result[7]_i_1_n_0 ;
  wire \result[8]_i_2_n_0 ;
  wire \result[9]_i_2_n_0 ;

  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[0] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[0]),
        .Q(data_q[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[10] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[10]),
        .Q(data_q[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[11] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[11]),
        .Q(data_q[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[1] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[1]),
        .Q(data_q[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[2] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[2]),
        .Q(data_q[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[3] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[3]),
        .Q(data_q[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[4] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[4]),
        .Q(data_q[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[5] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[5]),
        .Q(data_q[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[6] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[6]),
        .Q(data_q[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[7] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[7]),
        .Q(data_q[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[8] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[8]),
        .Q(data_q[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_q_reg[9] 
       (.C(clk_core),
        .CE(1'b1),
        .D(data[9]),
        .Q(data_q[9]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \g_shift.amount_q_reg[0] 
       (.C(clk_core),
        .CE(1'b1),
        .D(amount[0]),
        .Q(\g_shift.amount_q [0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \g_shift.amount_q_reg[1] 
       (.C(clk_core),
        .CE(1'b1),
        .D(amount[1]),
        .Q(\g_shift.amount_q [1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \g_shift.amount_q_reg[2] 
       (.C(clk_core),
        .CE(1'b1),
        .D(amount[2]),
        .Q(\g_shift.amount_q [2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \g_shift.amount_q_reg[3] 
       (.C(clk_core),
        .CE(1'b1),
        .D(amount[3]),
        .Q(\g_shift.amount_q [3]),
        .R(1'b0));
  LUT5 #(
    .INIT(32'h00000010)) 
    \result[0]_i_1 
       (.I0(\g_shift.amount_q [2]),
        .I1(\g_shift.amount_q [0]),
        .I2(data_q[0]),
        .I3(\g_shift.amount_q [1]),
        .I4(\g_shift.amount_q [3]),
        .O(\result[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[10]_i_1 
       (.I0(\result[10]_i_2_n_0 ),
        .I1(\g_shift.amount_q [3]),
        .I2(\g_multi_bit.stage[2] [6]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_multi_bit.stage[2] [10]),
        .O(\g_multi_bit.stage[4] [10]));
  LUT6 #(
    .INIT(64'h0000000033E200E2)) 
    \result[10]_i_2 
       (.I0(data_q[2]),
        .I1(\g_shift.amount_q [0]),
        .I2(data_q[1]),
        .I3(\g_shift.amount_q [1]),
        .I4(data_q[0]),
        .I5(\g_shift.amount_q [2]),
        .O(\result[10]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[10]_i_3 
       (.I0(data_q[3]),
        .I1(data_q[4]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[5]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[6]),
        .O(\g_multi_bit.stage[2] [6]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[10]_i_4 
       (.I0(data_q[7]),
        .I1(data_q[8]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[9]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[10]),
        .O(\g_multi_bit.stage[2] [10]));
  LUT2 #(
    .INIT(4'h8)) 
    \result[11]_i_1 
       (.I0(\g_shift.amount_q [2]),
        .I1(\g_shift.amount_q [3]),
        .O(\g_multi_bit.is_overflow ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'h30BB3088)) 
    \result[11]_i_2 
       (.I0(\g_multi_bit.stage[2] [3]),
        .I1(\g_shift.amount_q [3]),
        .I2(\g_multi_bit.stage[2] [7]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_multi_bit.stage[2] [11]),
        .O(\g_multi_bit.stage[4] [11]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[11]_i_3 
       (.I0(data_q[0]),
        .I1(data_q[1]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[2]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[3]),
        .O(\g_multi_bit.stage[2] [3]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[11]_i_4 
       (.I0(data_q[4]),
        .I1(data_q[5]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[6]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[7]),
        .O(\g_multi_bit.stage[2] [7]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[11]_i_5 
       (.I0(data_q[8]),
        .I1(data_q[9]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[10]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[11]),
        .O(\g_multi_bit.stage[2] [11]));
  LUT6 #(
    .INIT(64'h0000000000005404)) 
    \result[1]_i_1 
       (.I0(\g_shift.amount_q [2]),
        .I1(data_q[1]),
        .I2(\g_shift.amount_q [0]),
        .I3(data_q[0]),
        .I4(\g_shift.amount_q [1]),
        .I5(\g_shift.amount_q [3]),
        .O(\result[1]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \result[2]_i_1 
       (.I0(\result[10]_i_2_n_0 ),
        .I1(\g_shift.amount_q [3]),
        .O(\result[2]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'h04)) 
    \result[3]_i_1 
       (.I0(\g_shift.amount_q [2]),
        .I1(\g_multi_bit.stage[2] [3]),
        .I2(\g_shift.amount_q [3]),
        .O(\result[3]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000022222E22)) 
    \result[4]_i_1 
       (.I0(\g_multi_bit.stage[2] [4]),
        .I1(\g_shift.amount_q [2]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[0]),
        .I4(\g_shift.amount_q [0]),
        .I5(\g_shift.amount_q [3]),
        .O(\result[4]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT4 #(
    .INIT(16'h00E2)) 
    \result[5]_i_1 
       (.I0(\g_multi_bit.stage[2] [5]),
        .I1(\g_shift.amount_q [2]),
        .I2(\result[5]_i_2_n_0 ),
        .I3(\g_shift.amount_q [3]),
        .O(\result[5]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'h00E2)) 
    \result[5]_i_2 
       (.I0(data_q[1]),
        .I1(\g_shift.amount_q [0]),
        .I2(data_q[0]),
        .I3(\g_shift.amount_q [1]),
        .O(\result[5]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'h00E2)) 
    \result[6]_i_1 
       (.I0(\g_multi_bit.stage[2] [6]),
        .I1(\g_shift.amount_q [2]),
        .I2(\g_multi_bit.stage[2] [2]),
        .I3(\g_shift.amount_q [3]),
        .O(\result[6]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'h30BB3088)) 
    \result[6]_i_2 
       (.I0(data_q[0]),
        .I1(\g_shift.amount_q [1]),
        .I2(data_q[1]),
        .I3(\g_shift.amount_q [0]),
        .I4(data_q[2]),
        .O(\g_multi_bit.stage[2] [2]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'h00E2)) 
    \result[7]_i_1 
       (.I0(\g_multi_bit.stage[2] [7]),
        .I1(\g_shift.amount_q [2]),
        .I2(\g_multi_bit.stage[2] [3]),
        .I3(\g_shift.amount_q [3]),
        .O(\result[7]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[8]_i_1 
       (.I0(\result[8]_i_2_n_0 ),
        .I1(\g_shift.amount_q [3]),
        .I2(\g_multi_bit.stage[2] [4]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_multi_bit.stage[2] [8]),
        .O(\g_multi_bit.stage[4] [8]));
  LUT4 #(
    .INIT(16'h0004)) 
    \result[8]_i_2 
       (.I0(\g_shift.amount_q [1]),
        .I1(data_q[0]),
        .I2(\g_shift.amount_q [0]),
        .I3(\g_shift.amount_q [2]),
        .O(\result[8]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[8]_i_3 
       (.I0(data_q[1]),
        .I1(data_q[2]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[3]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[4]),
        .O(\g_multi_bit.stage[2] [4]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[8]_i_4 
       (.I0(data_q[5]),
        .I1(data_q[6]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[7]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[8]),
        .O(\g_multi_bit.stage[2] [8]));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \result[9]_i_1 
       (.I0(\result[9]_i_2_n_0 ),
        .I1(\g_shift.amount_q [3]),
        .I2(\g_multi_bit.stage[2] [5]),
        .I3(\g_shift.amount_q [2]),
        .I4(\g_multi_bit.stage[2] [9]),
        .O(\g_multi_bit.stage[4] [9]));
  LUT5 #(
    .INIT(32'h00004540)) 
    \result[9]_i_2 
       (.I0(\g_shift.amount_q [1]),
        .I1(data_q[0]),
        .I2(\g_shift.amount_q [0]),
        .I3(data_q[1]),
        .I4(\g_shift.amount_q [2]),
        .O(\result[9]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[9]_i_3 
       (.I0(data_q[2]),
        .I1(data_q[3]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[4]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[5]),
        .O(\g_multi_bit.stage[2] [5]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \result[9]_i_4 
       (.I0(data_q[6]),
        .I1(data_q[7]),
        .I2(\g_shift.amount_q [1]),
        .I3(data_q[8]),
        .I4(\g_shift.amount_q [0]),
        .I5(data_q[9]),
        .O(\g_multi_bit.stage[2] [9]));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[0] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[0]_i_1_n_0 ),
        .Q(result[0]),
        .R(\g_multi_bit.is_overflow ));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[10] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\g_multi_bit.stage[4] [10]),
        .Q(result[10]),
        .R(\g_multi_bit.is_overflow ));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[11] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\g_multi_bit.stage[4] [11]),
        .Q(result[11]),
        .R(\g_multi_bit.is_overflow ));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[1] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[1]_i_1_n_0 ),
        .Q(result[1]),
        .R(\g_multi_bit.is_overflow ));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[2] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[2]_i_1_n_0 ),
        .Q(result[2]),
        .R(\g_multi_bit.is_overflow ));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[3] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[3]_i_1_n_0 ),
        .Q(result[3]),
        .R(\g_multi_bit.is_overflow ));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[4] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[4]_i_1_n_0 ),
        .Q(result[4]),
        .R(\g_multi_bit.is_overflow ));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[5] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[5]_i_1_n_0 ),
        .Q(result[5]),
        .R(\g_multi_bit.is_overflow ));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[6] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[6]_i_1_n_0 ),
        .Q(result[6]),
        .R(\g_multi_bit.is_overflow ));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[7] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\result[7]_i_1_n_0 ),
        .Q(result[7]),
        .R(\g_multi_bit.is_overflow ));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[8] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\g_multi_bit.stage[4] [8]),
        .Q(result[8]),
        .R(\g_multi_bit.is_overflow ));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[9] 
       (.C(clk_core),
        .CE(1'b1),
        .D(\g_multi_bit.stage[4] [9]),
        .Q(result[9]),
        .R(\g_multi_bit.is_overflow ));
endmodule

(* ARITH = "0" *) (* ECO_CHECKSUM = "ff614665" *) (* FILL_KIND = "0" *) 
(* KIND = "0" *) (* MODE = "0" *) (* N = "12" *) 
(* RESULT_W = "12" *) (* SHIFT_W = "4" *) 
(* NotValidForBitStream *)
(* \DesignAttr:ENABLE_NOC_NETLIST_VIEW  *) 
(* \DesignAttr:ENABLE_AIE_NETLIST_VIEW  *) 
module primitive_v2_top
   (clk,
    data,
    amount,
    fill_val,
    result);
  input clk;
  input [11:0]data;
  input [3:0]amount;
  input fill_val;
  output [11:0]result;

  wire [3:0]amount;
  wire clk;
  wire clk_core;
  wire [11:0]data;
  wire [11:0]result;

  primitive_v2_boundary u_boundary
       (.amount(amount),
        .clk_core(clk_core),
        .data(data),
        .result(result));
  (* BOX_TYPE = "PRIMITIVE" *) 
  BUFG u_clock
       (.I(clk),
        .O(clk_core));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
