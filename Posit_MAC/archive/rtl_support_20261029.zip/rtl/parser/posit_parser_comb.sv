//-----------------------------------------------------------------------------
// File          : posit_parser_comb.sv
// Author(s)     : Codex, for Dan Huy
// Project       : Posit MAC IP
// Creation Date : 2026-10-05
// Description   : Combinational Posit decoder (Optimized for Posit<32, 3>).
//                 Pure combinational, no clock, no pipeline.
//                 Decodes sign, special cases (Zero, NaR), scale factor, fraction.
//-----------------------------------------------------------------------------
module posit_parser_comb (
    input  logic [31:0]        p,
    output wire                s,
    output wire                is_zero,
    output wire                is_nar,
    output wire signed [10:0]  sf,
    output wire [25:0]         frac
);
    // Posit<32, 3> configuration constants
    localparam int NB       = 32;
    localparam int ES       = 3;
    localparam int FRAC_MAX = NB - 3 - ES; // 26
    localparam int SF_W     = 11;
    localparam int CNT_W    = 5;          // $clog2(NB-1)
    localparam int REG_W    = CNT_W + 1;  // 6

    typedef logic signed [SF_W-1:0] sf_value_t;

    wire [NB-1:0]           magnitude;
    wire                    r;
    wire [NB-3:0]           terminator_bits;
    wire [CNT_W-1:0]        cnt;
    wire                    unused_terminator_valid;
    wire [NB-2:0]           detector_in;
    wire signed [REG_W-1:0] regime;
    wire [NB-4:0]           payload;
    wire signed [SF_W-1:0]  finite_sf;
    wire [ES-1:0]           exponent;
    wire                    rest_is_zero;

    // Zero / NaR detection
    assign rest_is_zero = ~(|p[NB-2:0]);
    assign s            = p[NB-1];
    assign is_zero      = !s && rest_is_zero;
    assign is_nar       =  s && rest_is_zero;

    // 2's complement magnitude (optimized for FPGA carry chain with Cin = s)
    assign magnitude = (p ^ {NB{s}}) + {{(NB-1){1'b0}}, s};
    assign r         = magnitude[NB-2]; // First Regime Bit (FRB)

    // Adjacent XOR preserves the first transition for either regime polarity
    assign terminator_bits = magnitude[NB-3:0] ^ magnitude[NB-2:1];

    // Sentinel supplies the no-terminator count (NB-2)
    assign detector_in = {terminator_bits, 1'b1};

    // Leading Zero/One Detector for regime length
    lod_lzd_core_fixed2 u_regime_detector (
        .in  (detector_in),
        .K   (cnt),
        .vld (unused_terminator_valid)
    );

    // Regime calculation: r=1 => k=cnt; r=0 => k=-(cnt+1) via bitwise XNOR
    assign regime = ~({1'b0, cnt} ^ {REG_W{r}});

    // Align payload (exponent and fraction) by shifting left by cnt
    dyn_left_shifter align_payload (
        .in  (magnitude[NB-4:0]),
        .b   (cnt),
        .out (payload)
    );

    // Optimized for fixed ES=3: extract 3 exponent bits directly
    assign exponent  = payload[NB-4 -: ES];
    // Signed concatenation: k * 2^ES + e, auto sign-extended to SF_W
    assign finite_sf = sf_value_t'($signed({regime, exponent}));

    // Output selection: reuse rest_is_zero directly to save an OR gate and reduce delay
    assign sf   = rest_is_zero ? {SF_W{1'b0}} : finite_sf;
    assign frac = rest_is_zero ? {FRAC_MAX{1'b0}} : payload[FRAC_MAX-1:0];

endmodule
