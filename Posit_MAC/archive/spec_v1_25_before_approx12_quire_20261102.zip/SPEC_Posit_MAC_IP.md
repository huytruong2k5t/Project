# SPEC lõi IP Posit MAC xấp xỉ dạng lặp

**v1.25 — 01/11/2026.** Sinh viên: Đan Huy. Tài liệu quy định thiết kế mục tiêu và nghiệm thu; nhật ký, số đo và PASS của từng snapshot nằm riêng trong `results/`, [tiến độ](docs/TIEN_DO_DO_AN.md) và [Optimization](../doc/Optimization.md).

## 1. Mục tiêu và phạm vi

Thiết kế bằng SystemVerilog hai lõi **non-fused (NF)** và **fused (F)** cho duy nhất **Posit(32,3)**. Cả hai dùng bộ nhân dịch–cộng approximate, giữ 12 bit fraction đầu vào, tích FULL_TERM 26 bit/Q24 và tối đa 12 vòng fraction. NF/F khác vị trí làm tròn tích, không phải hai chế độ exact/approximate.

- Bắt buộc: Parser, OPS, SAC/SBM/core, bộ cộng, Packer RNE, valid/ready, reset, cờ trạng thái, tích lũy và kiểm chứng tự động.
- Không có nhân exact phần cứng, `cfg_mode`, `EXACT_EN`, TRUNC hoặc lựa chọn FLOOR/STICKY_ACC trong cấu hình nghiệm thu. Độ rộng cố định; top không có public parameter đổi format/feature.
- Không bao gồm quire, chia/căn, chuyển đổi FP bằng phần cứng, ASIC hoặc tái hiện toàn bộ số liệu bài báo. Chồng lấn giao dịch/đối chứng FP là mở rộng; baseline chỉ có một giao dịch đang xử lý.
- Oracle tính chính xác bằng phần mềm vẫn bắt buộc để kiểm thiết kế approximate và đo sai số; không tạo thêm mode của DUT.

FULL_TERM giữ nguyên quyết định 29–30/10. Bản rút gọn này không sửa RTL, model, testbench, runner, manifest hay kết quả cũ. Khoảng cách giữa nguồn hiện tại và mục tiêu ở §8.

## 2. Định dạng số

Đây là cấu hình tổng quát `n=32, es=3`, không đồng nhất với posit32 exponent hai bit của Posit Standard 2022. Với hữu hạn khác 0, giải mã **mã độ lớn** sau bù hai nếu đầu vào âm:

```text
X = (-1)^s × (1+f) × 2^sf; sf = 8k+e; useed = 256
k = run-1 nếu regime bắt đầu bằng 1; k = -run nếu bắt đầu bằng 0
```

`run` không tính terminator. Exponent tối đa 3 bit, thiếu thì đệm 0 phía thấp; fraction tối đa 26 bit, căn Q26. Scale đầu vào thuộc [-240,240], tổng scale tích thuộc [-480,480], giữ bằng signed11; hiệu scale mở rộng dấu trước phép trừ.

| Giá trị | Mã 32 bit |
| --- | --- |
| Zero / NaR | `0x00000000` / `0x80000000` |
| +1 / -1 | `0x40000000` / `0xC0000000` |
| minpos / -minpos; minpos=2^-240 | `0x00000001` / `0xFFFFFFFF` |
| maxpos / -maxpos; maxpos=2^240 | `0x7FFFFFFF` / `0x80000001` |

`R(x)` là chuẩn hóa và mã hóa Posit(32,3), tạo regime/exponent/fraction, RNE theo dòng bit G/R/S rồi bù hai nếu âm. Điều kiện tăng mã độ lớn: `G && (LSB || R || S)`. Hữu hạn vượt dải kẹp ±maxpos, khác 0 dưới minpos kẹp ±minpos; zero thật giữ Zero. Carry làm tròn không sinh NaR. Oracle phải xét cả bit regime/exponent bị loại ở biên, không chỉ fraction hoặc khoảng cách cố định quanh 1.

## 3. Yêu cầu chức năng

Các yêu cầu sau bắt buộc khi nghiệm thu. Giữ ID để truy vết báo cáo cũ.

| ID | Yêu cầu |
| --- | --- |
| FR-01, FR-03 | Cố định (32,3); Parser trả dấu, Zero/NaR, sf signed11 và fraction Q26 đúng mọi mã. |
| FR-02, FR-04 | NaR ưu tiên Zero; Packer RNE/kẹp biên theo §2. |
| FR-05, FR-06 | Chỉ approximate FULL_TERM §4.3; không đường exact hay cắt từng term. |
| FR-07, FR-08 | Early-stop; OPS0/1; hòa popcount chọn A. |
| FR-09 | Adder/adapter khớp oracle (32,3), kể cả carry, cancellation, phần dư và cờ. |
| FR-10, FR-11 | NF/F theo §4.4, cùng P_hat. |
| FR-12, FR-14 | Tích lũy, acc_clr và 5 cờ theo §4.2/§4.4. |
| FR-13, FR-15 | Valid/ready, giữ output khi stall, reset flush/startup an toàn. |
| FR-16 | Nếu chồng lấn: kiểm thêm thứ tự, capacity, phụ thuộc trạng thái; không mặc định II=n. |

## 4. Cấu hình và hợp đồng số học

### 4.1 Hằng số thiết kế

| Thành phần | Giá trị cố định |
| --- | --- |
| Format / fraction giải mã | NB=32, ES=3, FRAC_MAX=26 |
| Nhân approximate | FRAC_W=12, N_MAX=12, APP_ACC_W=26, APP_Q=24 |
| Scale / tổng dịch / số vòng | signed11 / unsigned4 / unsigned4 |
| Fraction chuẩn hóa tới Packer | 53 bit, không hidden; đệm 0 không tăng precision |
| Cửa sổ cộng F | W32/Q29, có residual có dấu |
| Pipeline | Parser 2; adder NF 5; Packer RNE 2 tầng |

W32/Q29 là lựa chọn hiện thực, không thay golden full-grid. Phải kiểm lại với tích Q24; nếu khác oracle, sửa datapath/residual thay vì đổi expected.

### 4.2 Cổng và giao thức

Hai top riêng `posit_mac_nf`, `posit_mac_f` có cùng giao diện mục tiêu:

| Cổng | Hướng | Bit | Ý nghĩa |
| --- | --- | --- | --- |
| clk, rst_n | in | 1,1 | Clock; reset đồng bộ tích cực thấp tại top |
| in_valid, in_ready | in,out | 1,1 | Nhận tại cạnh lên khi cùng bằng 1 |
| a, b, c | in | 32 mỗi cổng | Hai thừa số và số hạng cộng |
| cfg_n | in | 4 | 0..12 vòng fraction; hidden khởi tạo riêng |
| cfg_ops | in | 2 | 0: X=A; 1: min-popcount fraction12, hòa chọn A |
| acc_mode, acc_clr | in | 1,1 | Chọn tích lũy; bắt đầu chuỗi mới |
| out_valid, out_ready | out,in | 1,1 | Trả tại cạnh lên khi cùng bằng 1 |
| d, flags | out | 32,5 | Mã kết quả; {nar,sat_max,sat_min,inexact,approx_cut} |

- Chốt đồng thời toán hạng hiệu dụng/cấu hình tại accept. Nguồn giữ payload/config khi `in_valid && !in_ready`; DUT giữ d/flags/out_valid khi `out_valid && !out_ready`, tới handshake hoặc reset.
- Invalid gồm n13..15, OPS2/3, hoặc `acc_clr && !acc_mode`: in_ready=0, không accept, không phát kết quả thay thế.
- Với trạng thái Posit32 S: C_eff=c nếu standalone; C_eff=S nếu tích lũy; C_eff=0 nếu tích lũy kèm clear. C ngoài cổng bị bỏ qua khi tích lũy, kể cả C=NaR.
- Chỉ giao dịch tích lũy cập nhật S, đúng một lần khi kết quả chốt vào output storage. Stall không cộng lại; lần sau dùng S mới. Clear chỉ có hiệu lực tại accept. Chuỗi không bị giới hạn 12 giao dịch; S làm tròn sau từng giao dịch, không là quire.
- Cạnh lấy mẫu rst_n=0 không có handshake; xóa valid/pending/S. Reset bridge và startup barrier giữ in_ready=out_valid=0 tới khi mọi leaf sẵn sàng, không trả lại giao dịch trước reset. Leaf giữ hợp đồng reset theo guideline.
- Adapter legacy nếu cần chỉ nhận cfg_mode=1 và từ chối 0; tách khỏi top approximate-only, không giữ nhánh exact trong lõi nghiệm thu.

<a id="full-term-contract"></a>

### 4.3 Nhân approximate FULL_TERM

Với A/B hữu hạn khác 0, lấy F_A=frac_A[25:14], F_B=frac_B[25:14]; input_cut=OR các bit [13:0] bị bỏ. OPS chọn X/Y theo §4.2; Y=4096+F_Y, sign=s_A XOR s_B, b=sf_A+sf_B. SAC xử lý các bit 1 của F_X từ cao xuống thấp; S_i là vị trí sau dấu chấm, thuộc 1..12. Số vòng thực tế t=min(popcount(F_X),cfg_n).

```text
Y_base = Y << 12                    // mở rộng 26 bit, Q24
M_0 = Y_base                        // đóng góp hidden, không tính vào t
term_i = Y_base >> S_i
M_i = M_(i-1) + term_i
P_hat = (-1)^sign × M_t × 2^(b-24)
```

Y_base có 12 bit 0 thấp nên dịch S_i≤12 không mất bit số học. M có 2 bit nguyên/24 fraction; M≤8191²=67,092,481<2²⁶. Cộng mở rộng 27 bit để kiểm tràn; bit25 là carry chuẩn hóa hợp lệ. Không clear bit thấp, FLOOR/JAM/RNE trong vòng; term_tail/numerical_tail luôn 0 trên miền hợp lệ.

n0 vẫn cho M_0; dừng khi hết bit 1 hoặc đạt n. iteration_cut/approx_cut chỉ đúng khi còn bit 1 chưa xử lý. n12 cho tích đầy đủ của hai significand **đã giữ 12 fraction**, không phục hồi 14 bit đầu vào bị cắt.

```text
carry = M[25]; sf_norm = b+carry
NF carry=0: frac_norm[52:0] = {M[23:0],29'b0}
NF carry=1: frac_norm[52:0] = {M[24:0],28'b0}
```

F nhận magnitude26/Q24, base scale signed11, dấu và cờ trước product RNE. Không dùng acc[15:2]/magnitude14 của FLOOR cũ thay FULL_TERM.

### 4.4 NF/F, ngoại lệ và cờ

```text
NF: D = R(R(P_hat) + C_eff)
F : D = R(P_hat + C_eff)
```

NF có hai lần RNE; F giữ tích approximate tới phép cộng rồi RNE cuối, không phải FMA của A×B đầy đủ. NF/F không bắt buộc cùng kết quả.

NaR của A/B/C_eff ưu tiên mọi bypass, kể cả 0×NaR: d=NaR, flags=10000. Nếu không NaR và A hoặc B=0, trả C_eff với cờ 0. Triệt tiêu đúng hai số hạng của từng profile trả Zero; phần dư căn chỉnh phải xét dấu/borrow, không chỉ OR sticky vào phép trừ.

| Cờ | Ngữ nghĩa trong một giao dịch |
| --- | --- |
| nar | NaR ở toán hạng thực sự tham gia, xóa 4 cờ còn lại |
| sat_max, sat_min | Kẹp hữu hạn tại biên; NF OR qua product pack và final pack |
| inexact | input_cut hoặc iteration_cut hoặc mất thông tin ở cộng/pack; NF OR qua hai lần làm tròn |
| approx_cut | Còn bit 1 của fraction12 khi đạt n; n12 hợp lệ luôn bằng 0 |

Loss do xấp xỉ là metadata, không OR input_cut/iteration_cut vào numerical sticky để đổi P_hat. Cờ không tự OR dồn qua cả chuỗi; state hồi tiếp là mã S. Luôn so cả d và đủ 5 cờ.

## 5. Tổ chức RTL

| Khối | Trách nhiệm và ranh giới |
| --- | --- |
| Parser | Hai tầng giải mã dấu/Zero/NaR/regime/sf/fraction; bundle và metadata cùng giữ khi stall |
| OPS → SAC → SBM/core | Chọn vai, phát term FULL_TERM, truyền first/last cùng term; done chỉ sau commit term cuối |
| NF | Chuẩn hóa tích → product Packer RNE → decode → adder → Packer RNE cuối |
| Adder NF | Prepare/Align/Arithmetic/LOD/Normalize; Q29 và residual; output fraction53 không hidden |
| F | Căn magnitude26/Q24 với C_eff, cộng/trừ/residual/borrow, chuẩn hóa → Packer RNE cuối |
| Top | Giữ context, nhận nguyên tử, kiểm cấu hình/reset, quản lý S và output slot |

Khi khóa RTL, ghi first-valid, retire và II không stall theo t, gồm n0/early-stop. Không lấy công thức pipeline cũ hoặc n+6 của paper áp cho MAC mới. Đổi số tầng phải kiểm lại lịch/metadata; số tầng không chứng minh Fmax.

## 6. Golden model và kiểm chứng Posit(32,3)

### 6.1 Golden, model và Ideal

| Thành phần | Nguồn và vai trò |
| --- | --- |
| **Golden độc lập** | [`opt17_reference::product/mac`](tb/opt17/full_term_reference.hpp) dùng [`week12_reference::Oracle<32,3>`](tb/week12_fused_reference.hpp): raw decoder, tích chọn bit dạng đóng, cộng/trừ full-grid và encoder RNE riêng. Tạo expected d/5flags của DUT. |
| **Model thuật toán L1** | [`full_term32::multiply/mac`](l1/include/posit_mac_full_term.hpp): recurrence SAC/SBM, checkpoint M, NF và cửa sổ F; phục vụ trace/debug, phải khớp golden trước sinh fixture. |
| **Ideal đo sai số** | `Oracle<32,3>::product(a,b)` rồi `Oracle::add(...,C_eff)`: giữ toàn bộ giá trị A/B để tính A×B+C_eff. Full-grid trước encode là chuẩn hữu tỉ; bits là chuẩn Posit đã RNE. Không làm expected bit-exact của DUT approximate. |
| **SoftPosit L0 hiện có** | [`softposit_api.c`](l0/softposit_api.c) gọi p8/es0, p16/es1, p32/es2. Chỉ hồi quy đúng format; l0_p32_*, ctypes và API L1 p32/es2 không là golden (32,3). |

Khi kiểm DUT, bắt buộc `full_term32::Config{true,n,ops}` (approximate=true); fused=false cho NF, true cho F. Nhánh approximate=false còn trong header chỉ là phần mềm hỗ trợ nghiên cứu, không là mode nghiệm thu RTL. Harness quản lý C_eff/S riêng từng kiến trúc; hàm mac() nhận C_eff, không tự quản lý chuỗi.

Golden tính M độc lập với vòng SAC: chọn tối đa n bit 1 cao nhất của F_X thành mask F_sel, rồi tính `M=(4096+F_sel)×(4096+F_Y)` bằng số nguyên. Với n0, F_sel=0; n12, F_sel=F_X. Từ M/Q24 và b, golden thực hiện đúng hai phương trình NF/F ở §4.4, gồm cả ngoại lệ và 5 cờ.

Golden có thể chung kiểu dữ liệu nhưng không gọi Parser/Packer/adder/recurrence L1 tạo expected. Full-grid hiện là số nguyên 1024 bit trên lưới 2^-532 cho (32,3), có kiểm bounds/tràn. Double/long double chỉ hiển thị/thống kê khi đủ miền, không quyết định tie, saturation, Zero hoặc cancellation. Python gọi lại cùng thư viện C không phải oracle độc lập thứ hai.

### 6.2 Kiểm model trước RTL

Đối chiếu dấu, sf, M/Q, t, loss metadata và d/5flags cho n0..12, OPS0/1, NF/F. Mỗi checkpoint i kiểm bằng tổng chọn i bit 1, không chỉ kết quả cuối. Decoder/encoder cần roundtrip raw32/3 và kiểm tay regime dài, dấu, G/R/S, biên.

| Vector | Đầu vào sau chọn vai X/Y | Expected FULL_TERM |
| --- | --- | --- |
| FT-01 | F_X=0,Y=4096,n bất kỳ | t0,M=16,777,216; không iteration_cut |
| FT-02 | F_X=1,Y=8191,n0 | M=33,550,336; iteration_cut=1 |
| FT-03 | F_X=1,Y=8191,n1 | S1=12,term=8191,M=33,558,527; carry25=1 |
| FT-04 | F_X=F_Y=4095,n12 | t12,M=67,092,481; không iteration_cut |
| FT-05 | A=0x1c900000,B=0x3c820000,C_eff=0,OPS0/1,n≥2 | t2,b=-11,M=24,224,768/Q24; NF/F d=0x1ae34800 |

FT-01..04 là input nội bộ **sau OPS**, không áp lại min-popcount lên bảng. FT-05 phân biệt với trace FLOOR cũ 0x1ae34000; không sửa fixture lịch sử để đổi nhãn PASS.

<a id="verification-coverage"></a>

### 6.3 Phân tầng vector

Ngoài raw random/corner, chia run regime trên mã độ lớn thành `[1,3],[4,7],[8,11],[12,15],[16,17],[18,22],[23,27],[28,31]`. Mỗi điểm nghiệm thu phủ 256 ô group_A×group_B×sign_pair, ≥4,000 completed/ô. A/B hữu hạn khác 0; run0 dài31 là Zero, kiểm riêng. Mỗi polarity/run hữu hạn hợp lệ đạt ≥10,000 lượt toán hạng trong suite tổng hợp.

Phủ popcount fraction12: 0,1,2,3–4,5–8,9–12; từng n9/10/11/12; OPS hòa/swap; input_cut độc lập iteration_cut. ≥30% completed mỗi điểm MAC có hai số hạng cộng hữu hạn khác 0, trái dấu, |Δsf|≤4. NF đo R(P_hat)/C_eff; F đo P_hat chuẩn hóa/C_eff trước window cut. Lưu counters Δsf0..4, tách standalone/accumulation; reset-abort không tính completed. Tỷ lệ corpus phân tầng không mặc nhiên đại diện dữ liệu ứng dụng.

<a id="corner-cases"></a>

### 6.4 Corner bắt buộc

- Mã §2, NaR×0/0×NaR, NaR của C_eff/S và C bị bỏ qua; tích Zero với C_eff khác 0.
- Hai dấu, min/maxpos và lân cận, fraction 0/1/xen kẽ, carry, regime đổi độ dài/exponent thiếu bit.
- n0, early-stop, hết n, đủ 12 bước; invalid n13..15/OPS2..3/clear trái phép.
- RNE up/down, tie-even/odd, sticky-only, carry làm tròn, kẹp min/max; roundtrip parser→packer.
- Triệt tiêu đúng số hạng của từng profile, near-cancellation, hai mốc căn chỉnh, hai phía ngưỡng dịch 28/29, phần giữ bằng 0 nhưng residual khác 0.
- Chuỗi >12 giao dịch, clear giữa chuỗi/NaR trong S rồi clear, standalone xen kẽ, bubble/stall dài/reset khi rỗng/đang tính/giữ output.

### 6.5 Scoreboard và bằng chứng

Chụp input/config tại accept, tạo expected bằng golden, so d/flags tại retire. Model state cập nhật đúng một lần theo giao dịch tích lũy; NF/F có S riêng. Reset hủy pending/xóa S. Cuối suite: accepted=completed+reset_aborted, queue rỗng, không output dư. Kiểm ổn định payload/valid khi stall, timeout/deadlock và done sau last commit.

Thứ tự: model/oracle → unit/fixture → pilot ≥10^5 completed/điểm → main §6.7 → audit. Verilator/C++ chạy lượt lớn; ModelSim replay fixture đã được oracle kiểm và kiểm 4-state/CK2Q/reset/stall. So comb RTL với pipeline RTL chỉ xác nhận refactor, không thay golden độc lập.

Mỗi kết quả kèm file list, SHA256 RTL/model/oracle/harness/fixture, config/seed, tool version, lệnh/exit code, counts, coverage và raw log. Thiếu bằng chứng, RUNNING, mismatch, timeout hoặc mất/nhân đôi giao dịch đều FAIL. Không cộng mẫu giữa các snapshot/profile; không mặc định make regress hoặc runner legacy đã bao đủ ma trận mới.

### 6.6 Assertion và coverage

Assertion tối thiểu: output không X sau startup; giữ payload/valid khi stall; invalid không accept; t≤n≤12; term không mất bit/overflow; done sau last commit; NaR/Zero/flags theo golden; mỗi accept có một retire hoặc reset-abort; S commit một lần; occupancy không vượt capacity.

Functional coverage 100% bin hợp lệ của §6.3–6.4: n/OPS/t/cut, dấu/mốc/Δsf/LOD, carry/RNE/biên, acc_mode/clear, reset/stall. Structural coverage trên **nguồn approximate-only nghiệm thu**: line≥95%, branch≥90%, toggle≥85%. Unreachable chỉ loại bằng giải thích gắn nguồn; không dùng exact còn sót để giảm mẫu số hoặc miễn n9..12.

<a id="acceptance-matrix"></a>

### 6.7 Ma trận nghiệm thu

Chỉ profile `(32,3), FW12, FULL_TERM26/Q24, RNE`; bỏ các trục exact, format khác, TRUNC và ROUND_SCHEME tùy chọn.

| Nhóm | Cấu hình | Ngưỡng/kiểm tra |
| --- | --- | --- |
| AC-01 bit-exact | NF/F × OPS0/1 × từng n0..12: **52 điểm** | ≥10^7 completed/điểm, 0 mismatch d/5flags; ≥520 triệu completed toàn ma trận, không đếm pilot hai lần |
| Control trong mỗi điểm AC-01 | Standalone và chuỗi tích lũy | Mỗi loại ≥10% completed; đủ corner, input/output stall, reset-abort; counters riêng |
| Unit/4-state | Parser, OPS/SAC/SBM, adder, Packer, hai top | Đạt kiểm tay/fixture/assertion; không áp 10^7 cho từng invalid hay từng unit |
| AC-03 paired accuracy | OPS1, từng n0..12, NF/F cùng A/B/C_eff | Pilot≥10^5 rồi main≥10^6 triple/n trên corpus đóng băng; báo cả trường hợp F kém NF |

OPS1 là cấu hình so sánh chính; OPS0 vẫn kiểm chức năng bắt buộc. Standalone/accumulation nằm trong số đếm mỗi điểm, không nhân đôi thành 104 điểm. Với accuracy chuỗi, S_NF/S_F có thể phân kỳ: báo suite riêng và quy tắc Ideal state; không gọi C_eff của hai DUT giống nhau sau phân kỳ.

### 6.8 Sai số

Với paired standalone, dùng cùng corpus/P_hat; r=A×B+C_eff là giá trị hữu tỉ từ toàn bộ đầu vào, y=decode(d):

```text
Err(%) = 100 × |y-r|/|r|
Relative MSE = mean(((y-r)/r)^2)
Code-distance = |signed_code(d)-signed_code(R(r))|
```

Báo tỷ lệ Err<0.1/0.5/1/5%, Relative MSE, max error, code-distance và số mẫu mỗi miền. r=0 báo zero-match/sai số tuyệt đối riêng; NaR tách riêng. Hiệu mã dùng số nguyên đủ rộng, không gọi là ULP có độ dài cố định. Giữ seed/phân bố, độ biến thiên và kết quả bất lợi; không yêu cầu F tốt hơn NF trên mọi vector. Ideal không làm tròn hồi tiếp của chuỗi cần số hữu tỉ/độ rộng được chứng minh đủ cho chiều dài chuỗi.

## 7. Điều kiện nghiệm thu và báo cáo

| ID | Điều kiện đạt |
| --- | --- |
| AC-01 | Đủ 52 điểm/số completed §6.7, 0 mismatch; protocol/control/unit đạt. |
| AC-02 | Retired: không nghiệm thu exact phần cứng; giữ ID để đọc báo cáo cũ. Oracle toán học vẫn bắt buộc. |
| AC-03 | Đủ paired accuracy §6.7–6.8; báo phân bố/ngoại lệ/seed/giới hạn. |
| AC-04 | Functional/structural coverage đạt §6.3/§6.6, đủ giải thích unreachable. |
| AC-05 | RTL không latch; lint không còn cảnh báo nghiêm trọng chưa giải thích; có tài nguyên/setup/hold post-route đúng nguồn khóa; DSP=0, BRAM=0. |
| AC-06 | Paired NF/F trên Artix-7 xc7a35tcpg236-1, cùng tool/constraints/profile, ≥3 run/cấu hình tĩnh; LUT/FF/CARRY/DSP/BRAM, clock đạt, latency/II/throughput đo thực tế. |
| AC-07, AC-08 | Tái lập và truy vết FR→testcase→log/count/coverage; manifest khóa đúng nguồn/model/fixture; PASS đúng phạm vi đã chạy. |

PPA là bước riêng sau kiểm chức năng. n là cấu hình runtime: không tổng hợp lặp cùng netlist cho 13 n; đo latency/II từng n và dùng n2/n4/n12 trình bày accuracy–throughput. Netlist chuyên biệt theo n phải khai báo và kiểm riêng.

Giữ profile A35T đã chọn: input min=max2.5ns, output min0/max0.5ns, uncertainty setup/hold0.1ns; khóa clock mục tiêu/constraints trước chạy. Clock công bố phải đạt setup/hold sau route; ước lượng từ slack không là Fmax đã sweep hay board signoff. Không lấy mốc 575MHz/698LUT của multiplier paper làm ngưỡng bắt buộc cho MAC A35T. Giữ raw report, min/median/max các run; power chỉ kết luận khi có phương pháp/activity phù hợp. Không phát sinh yêu cầu chạy PPA trong lần sửa tài liệu này.

## 8. Trạng thái nguồn và tham chiếu

Đối chiếu đọc file 01/11/2026 cho thấy nguồn hiện tại chưa đồng nhất với mục tiêu:

| Thành phần | Hiện trạng |
| --- | --- |
| rtl/mac_nf/mac_nf_wrapper.sv | Còn cfg_mode, EXACT_EN=1, N_MAX8 và bank54; chưa là top approximate-only FULL_TERM. |
| rtl/mac_f/mac_f_wrapper.sv | N_MAX12 nhưng cổng ngoài còn cfg_mode; core/bank16/prepack FLOOR, chưa magnitude26/Q24. |
| L1/golden FULL_TERM §6.1 | Header đã có; API còn nhánh phần mềm mixed. Khóa approximate=true và kiểm lại cùng manifest trước nghiệm thu. |
| tb/opt17/harness.cpp / candidate OPT17 | Còn stimulus exact/mixed, không tự thành regression 52 điểm approximate-only. |
| mac_active.f, production.f, freeze/report cũ | Các danh mục/snapshot riêng; không đổi nhãn PASS hay gán kết quả cũ cho nguồn đang refactor. |

Chỉ công bố release mới khi top, model/harness và ma trận cùng đúng hợp đồng. Thiếu hụt hiện thực không là lý do đổi FULL_TERM thành FLOOR trong spec. Bản đầy đủ trước rút gọn và tài liệu liên quan được giữ tại [archive/spec_v1_24_before_compact_20261101.zip](archive/spec_v1_24_before_compact_20261101.zip).

Tham khảo chính:

- Norris, C. J. và Kim, S. (2021), *An Approximate and Iterative Posit Multiplier Architecture for FPGAs*, ISCAS: cơ sở kiến trúc dịch–cộng; [PDF local](An%20Approximate%20and%20Iterative%20Posit%20Multiplier%20Architecture%20for%20FPGAs.pdf).
- Murillo, R., Del Barrio, A. A. và Botella, G. (2020), *Customized Posit Adders and Multipliers using the FloPoCo Core Generator*, ISCAS: giải mã/cộng/đóng gói; [PDF local](Customized%20Posit%20Adders%20and%20Multipliers%20using%20the%20FloPoCo%20Core%20Generator.pdf).
- [Digital Design Guidelines](Digital_Design_Guidelines.md): quy tắc RTL/clock/reset. Spec hiện hành ưu tiên về format/profile/nghiệm thu so với các nhật ký có ngày cũ.
