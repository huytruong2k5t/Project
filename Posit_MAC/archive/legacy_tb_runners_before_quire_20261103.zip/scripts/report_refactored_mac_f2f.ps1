param([ValidateSet('nf','f')][string]$Variant='nf',[string]$RunRoot='results/refactored_mac_20261101_r3')
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
$checkpoint=Join-Path $root "$RunRoot/synth_${Variant}_final/synthesis.dcp"
if(!(Test-Path -LiteralPath $checkpoint)){throw 'Missing synthesized checkpoint'}
$output=Join-Path $root "$RunRoot/f2f_$Variant"
if(Test-Path -LiteralPath $output){throw 'Preserve existing report'}
foreach($folder in @('tmp','appdata','localappdata')){New-Item -ItemType Directory -Force "$output/$folder"|Out-Null}
$env:TEMP="$output/tmp";$env:TMP=$env:TEMP;$env:APPDATA="$output/appdata";$env:LOCALAPPDATA="$output/localappdata";$env:XILINX_LOCAL_USER_DATA='no'
Copy-Item "$PSScriptRoot/report_refactored_mac_f2f.tcl" "$output/report.tcl"
@{checkpoint=$checkpoint;sha256=(Get-FileHash $checkpoint).Hash;script_sha256=(Get-FileHash "$output/report.tcl").Hash;scope='Read-only post-synthesis F2F report; no synth/place/route'}|ConvertTo-Json|Set-Content "$output/manifest.json"
Push-Location $output
try {
    & 'C:/AMDDesignTools/2026.1/Vivado/bin/vivado.bat' -mode batch -notrace -source "$output/report.tcl" -tclargs $checkpoint > console.log
    if($LASTEXITCODE){throw 'F2F query failed'}
    if((Get-Content status.txt -Raw).Trim() -ne 'F2F_REPORT_COMPLETE'){throw 'Incomplete F2F report'}
    Get-Content stages.csv
} finally {Pop-Location}
