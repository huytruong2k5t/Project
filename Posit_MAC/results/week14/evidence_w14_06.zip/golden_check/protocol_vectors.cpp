#include <iostream>
#include <iomanip>
#include "posit_fused_window.hpp"
int main(){for(unsigned n=0;n<9;++n){l1::IterConfig cfg;cfg.n=n;cfg.ops=1;cfg.rounding=l1::RoundMode::RNE;
 auto p=l1::L1MultiplierIter<32,3,12>::mul(0x43ffffffu,0x43ffffffu,cfg).prepack;
 auto r=l1::FusedWindow<32,3,12,32>::add(p,0);
 std::cout<<std::hex<<((uint64_t(r.flags)<<32)|r.bits)<<"\n";}}
