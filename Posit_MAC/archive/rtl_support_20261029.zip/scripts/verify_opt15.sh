#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
study=results/opt15_share_20261019
out="$study/verification"
if [[ "${1:-}" == stress ]]; then
    [[ -f "$out/status.txt" && ! -e "$out/32_3/acceptance_10m.json" ]]
    export TMPDIR="$PWD/$out/tmp"
    "$out/32_3/obj/Vopt15_compare" 10000000 "$out/32_3/acceptance_10m.json" 20261021 \
        | tee "$out/32_3/acceptance_10m.log"
    exit 0
fi
[[ ! -f "$out/status.txt" ]] || { echo 'Preserve completed verification evidence' >&2; exit 2; }
mkdir -p "$out/source/l1" "$out/tmp"
export TMPDIR="$PWD/$out/tmp"
verilator --version > "$out/verilator.txt"
g++ --version > "$out/compiler.txt"
python3 - <<'PY'
from pathlib import Path
import json, shutil
r=Path.cwd(); o=r/'results/opt15_share_20261019/verification/source'
manifest=json.loads((r/'results/opt15_share_20261019/manifest.json').read_text())
for rel in manifest['variants']['reference']:
    if rel.endswith(('.sv','.vh')) and Path(rel).name not in ('mac_nf_wrapper.sv','posit_mac_nf.sv'):
        shutil.copy2(r/rel,o/Path(rel).name)
for v in ('reference','parser2','combined'):
    p=r/'results/opt15_share_20261019/source'/v/'rtl/mac_nf/mac_nf_wrapper.sv'
    text=p.read_text().replace('module mac_nf_wrapper #(',f'module mac_nf_wrapper_{v} #(')
    (o/f'mac_nf_wrapper_{v}.sv').write_text(text)
shutil.copy2(r/'rtl/candidates/mac_nf/opt15/posit_nf_shared_pack.sv',o)
for name in ('opt15_compare.sv','opt15_harness.cpp','nf_coverage_corpus.hpp','week11_model.hpp',
             'week10_add_reference.hpp','week9_exact_reference.hpp'):
    shutil.copy2(r/'tb'/name,o/name)
for p in (r/'l1/include').glob('*.hpp'):shutil.copy2(p,o/'l1'/p.name)
PY
for format in '32 3' '8 0' '16 1' '32 2'; do
    read -r nb es <<< "$format"
    fw=$((nb-3-es<12?nb-3-es:12))
    run="$out/${nb}_${es}"
    mkdir -p "$run/tmp"
    (
        cd "$run"
        export TMPDIR="$PWD/tmp"
        src=../source
        sha256sum "$src"/*sv "$src"/*.vh "$src"/*.cpp "$src"/*.hpp "$src"/l1/*.hpp > source.sha256
        verilator --lint-only --timing --assert -Wall --top-module opt15_compare \
            -I"$src" -GNB="$nb" -GES="$es" -GFRAC_W="$fw" "$src"/*.sv > lint.log 2>&1
        # Functional cycle replay ignores the guideline's CK2Q #1 only.
        # The separate --timing lint remains strict; ModelSim checks event delays.
        verilator --cc --exe --no-timing --assert -Wall -Wno-ASSIGNDLY --top-module opt15_compare \
            -I"$src" -GNB="$nb" -GES="$es" -GFRAC_W="$fw" --Mdir obj \
            -CFLAGS "-O3 -std=c++17 -I../../source/l1 -I../../source -DPROFILE_NB=$nb -DPROFILE_ES=$es" \
            "$src"/*.sv "$src"/opt15_harness.cpp > build.log 2>&1
        make -C obj -f Vopt15_compare.mk CURDIR=. -j4 >> build.log 2>&1
        sha256sum obj/Vopt15_compare > binary.sha256
        ./obj/Vopt15_compare 20000 pilot.json 20261019 > pilot.log
        cat pilot.log
        if [[ "$nb $es" == '32 3' ]]; then
            ./obj/Vopt15_compare 1000000 main.json 20261020 > main.log
            cat main.log
        fi
    )
done
echo COMPLETE > "$out/status.txt"
